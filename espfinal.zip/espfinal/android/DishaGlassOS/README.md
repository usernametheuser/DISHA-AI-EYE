# DISHA GLASS OS (Android)

Native Kotlin app. Stage 1 proves the USB camera link: discovery, permission, connection, handshake, live frames, statistics and logs. See the main `README.md` for wiring and the test checklist, and `docs/PROTOCOL.md` for the wire format.

- **Android Studio:** *File > Open* this folder, let Gradle sync, then *Run*. (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17.)
- **Without Android Studio:** `powershell -ExecutionPolicy Bypass -File tools\build_apk.ps1` from the project root → `build\DishaGlassOS-debug.apk`.
- **Unit tests:** `gradlew test` (Android Studio: right-click `app/src/test` > Run).

minSdk 21 (Android 5.0), targetSdk 34. Runtime permissions: microphone (first mic tap) and notifications (Android 13+). No libraries besides the Kotlin standard library.

## Structure

| Package / file | Purpose |
|---|---|
| `MainActivity.kt` | Stage 1 screen: status pill, preview, controls, link stats, device card, log |
| `usb/UsbDeviceInspector.kt` | Finds the "DISHA-CAM Link" interface (or the CDC fallback), never the JTAG interface. Describes devices, diagnoses wrong ports. |
| `usb/UsbLinkConnection.kt` | Claims the interface. Reader thread with 4 queued async `UsbRequest`s (no data loss on timeouts); writes via `bulkTransfer`. |
| `usb/CameraLinkManager.kt` | State machine with no UI code: permission, handshake, ping, reconnect, commands, frame delivery |
| `protocol/DishaProtocol.kt` | Constants, encoder, CRCs (must match the firmware) |
| `protocol/MessageParser.kt` | Byte stream → messages, with resynchronisation |
| `protocol/FrameAssembler.kt` | Chunks → complete, CRC-checked frames |
| `camera/FrameDecoder.kt` | JPEG marker and size checks, decode to Bitmap |
| `camera/FpsMeter.kt` | Measured frame rate |
| `ui/AspectRatioFrameLayout.kt` | 4:3 preview container |
| `util/AppLog.kt` | In-app log (also in logcat, tag `Disha`) |
| `audio/AudioRouter.kt` | Finds Bluetooth earbuds, wired headset or phone mic/speaker; switches the earbud mic (SCO) on while listening |
| `audio/SpeechInput.kt` | Android `SpeechRecognizer` (the phone's own service): one request at a time, partial results, all error codes explained |
| `audio/WakeWordListener.kt`, `audio/SpeechSegmenter.kt`, `audio/WakeMatcher.kt`, `audio/Mfcc.kt`, `audio/WakeSamples.kt` | Hands-free "Hello Friday": continuous phone-mic listening, on-device matching (MFCC + DTW) against the user's 3 recordings, optional speech-service confirmation |
| `audio/VoiceRecorder.kt`, `audio/SpeechDetector.kt` | Default listening: records with `AudioRecord` (earbud mic over SCO, or phone mic) and finds where speech starts and ends; uploads only the speech |
| `ai/FreeSpeechClient.kt`, `ai/TranscriptCleaner.kt` | No-key Whisper speech-to-text (OVHcloud), used only after the user allows it; drops Whisper's phantom phrases |
| `audio/Speaker.kt` | `TextToSpeech`: earbuds/phone speaker, no overlapping answers, stop |
| `audio/EarbudButton.kt` | Earbud play/pause tap starts the assistant (best effort) |
| `assistant/VoiceCommandRouter.kt` | Spoken sentence → quick command (photo, timer, weather, torch, music, memory…), wake-name stripping |
| `assistant/Agent.kt`, `ai/BrainClient.kt` | The thinking model with 16 tools (look, photo, video, timer, reminder, memory, weather, news, Wikipedia, torch, volume, music); no-key OVHcloud models by default |
| `assistant/Reminders.kt` | Timers/reminders with AlarmManager → `ReminderReceiver` → spoken + notification |
| `assistant/MemoryStore.kt` | "Remember that…" facts, on the phone only, given to the AI as context |
| `assistant/WebInfo.kt`, `assistant/WeatherText.kt` | Weather (Open-Meteo), headlines (Google News RSS), Wikipedia, city from IP: all keyless |
| `assistant/PhoneActions.kt` | Torch, volume, music keys |
| `assistant/TimeParse.kt`, `assistant/SpeechText.kt` | Spoken durations/times; model output cleaned for text-to-speech |
| `assistant/AssistantController.kt` | Listen → recognise → local command or vision AI (with a fresh frame) → speak → listen for a follow-up (conversation mode); FRIDAY-style persona, audio focus, watch mode |
| `service/DishaService.kt` | Foreground service (connectedDevice + microphone): runs everything with the screen off; Talk/Stop notification |
| `core/DishaCore.kt` | Owns the link, assistant, AI, recorder; photo/recording destinations; replays state to the screen |
| `ai/VisionAi.kt` | Swappable AI provider interface |
| `ai/FreeVisionClient.kt` | **Default, no API key:** OVHcloud AI Endpoints (OpenAI-compatible, anonymous). Walks 5 vision models and skips busy ones using the service's `retry-after` / `ratelimit-*` headers (2 requests per minute per model) |
| `ai/GeminiClient.kt` | Optional: Google Gemini over HTTPS with the user's own key from Settings |
| `ai/AiRouter.kt` | Sends each question to the provider chosen in Settings, never to both |
| `storage/AviWriter.kt`, `storage/PhoneRecorder.kt`, `storage/MediaSaver.kt` | MJPEG AVI recording on the phone; photos to Pictures/DISHA, videos to Movies/DISHA |
| `skills/NavMath.kt`, `skills/Navigator.kt` | Walking directions: OSM search (Overpass / Nominatim), FOSSGIS OSRM foot route, GPS turn-by-turn, re-routing |
| `skills/LiveCaptions.kt`, `skills/CaptionsActivity.kt` | Live captions and two-way translator (CaptionBoard is shared with the web view) |
| `skills/PageWatcher.kt`, `storage/PdfMaker.kt` | Document mode: page-is-still detection, scanner-look enhancement, A4 PDF |
| `skills/ReplayBuffer.kt` | Instant replay: last 30 s of live view in memory, saved as AVI on "save that" |
| `skills/QrReader.kt`, `skills/QrContent.kt` | QR codes / barcodes with ZXing (offline) and what they mean (links, UPI read-only, Wi-Fi, contacts) |
| `web/PresenterServer.kt`, `res/raw/dashboard.html` | Presentation mode: local web dashboard for a laptop (code-protected), slide events for `tools/disha_presenter.ps1` |
| `ai/Boost.kt` | Optional user key (Groq / OpenRouter / OpenAI / custom) tried before the free services |
| `storage/Backup.kt`, `storage/BackupArchive.kt` | Backup and restore of the wake-word recordings, settings, memory, reminders and note stores (Settings → BACKUP, daily copy in Documents/DISHA/Backup). Keep the format readable when data changes: updates must never lose the user's training |
| `settings/AppSettings.kt`, `settings/SettingsActivity.kt` | All settings, stored on the phone |
| `res/xml/usb_device_filter.xml` | Auto-launch on plug-in for VID 0x303A / PID 0x0002 |

The default AI needs no key. If Gemini is chosen, its API key is typed in by the user and stored only on the phone; it is never part of the APK. Permission to send camera pictures is asked separately for each AI service.
