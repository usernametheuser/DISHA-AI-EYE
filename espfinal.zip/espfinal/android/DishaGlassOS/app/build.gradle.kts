plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.disha.glassos"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.disha.glassos"
        // Conservative until the phone's Android version is known: Android 5.0 (API 21).
        // USB host, SpeechRecognizer and TextToSpeech all exist at this level.
        minSdk = 21
        targetSdk = 34
        // Always raise versionCode: an update installed over the app keeps the wake-word training,
        // memory and settings only with a higher versionCode and the same signing key.
        versionCode = 12
        versionName = "0.12.0"
    }

    // The same key as tools/build_apk.ps1, so an Android Studio build also installs over the
    // existing app (and keeps its data) instead of needing an uninstall.
    val dishaKey = rootProject.file("../../tools/signing/disha-debug.keystore")
    signingConfigs {
        create("disha") {
            storeFile = dishaKey
            storePassword = "disha-debug"
            keyAlias = "disha"
            keyPassword = "disha-debug"
        }
    }

    buildTypes {
        debug {
            if (dishaKey.exists()) signingConfig = signingConfigs.getByName("disha")
        }
        release {
            if (dishaKey.exists()) signingConfig = signingConfigs.getByName("disha")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    // Besides the Kotlin standard library and the Android framework, only ZXing core (QR codes and
    // barcodes read on the phone, offline). No AndroidX versions to keep in step with minSdk.
    implementation("com.google.zxing:core:3.5.3")
    testImplementation("junit:junit:4.13.2")
}
