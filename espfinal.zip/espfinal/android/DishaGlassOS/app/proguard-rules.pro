# Release builds are not minified (isMinifyEnabled = false). Rules go here if that changes.
