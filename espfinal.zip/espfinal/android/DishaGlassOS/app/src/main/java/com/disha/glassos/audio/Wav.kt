package com.disha.glassos.audio

/** 16 kHz mono 16-bit WAV <-> PCM samples. Pure logic. */
object Wav {
    const val RATE = 16000

    fun fromPcm(pcm: ShortArray, from: Int = 0, to: Int = pcm.size): ByteArray {
        val len = (to - from) * 2
        val out = ByteArray(44 + len)
        fun str(o: Int, v: String) = v.forEachIndexed { i, c -> out[o + i] = c.code.toByte() }
        fun le32(o: Int, v: Int) { for (i in 0 until 4) out[o + i] = (v shr (8 * i) and 0xFF).toByte() }
        fun le16(o: Int, v: Int) { out[o] = (v and 0xFF).toByte(); out[o + 1] = (v shr 8 and 0xFF).toByte() }
        str(0, "RIFF"); le32(4, 36 + len); str(8, "WAVE")
        str(12, "fmt "); le32(16, 16); le16(20, 1); le16(22, 1); le32(24, RATE); le32(28, RATE * 2); le16(32, 2); le16(34, 16)
        str(36, "data"); le32(40, len)
        for (i in from until to) le16(44 + (i - from) * 2, pcm[i].toInt())
        return out
    }

    /** Samples of a WAV written by [fromPcm] or [VoiceRecorder] (44-byte header). */
    fun toPcm(wav: ByteArray): ShortArray {
        val n = maxOf(0, (wav.size - 44) / 2)
        return ShortArray(n) { i -> ((wav[44 + 2 * i].toInt() and 0xFF) or (wav[45 + 2 * i].toInt() shl 8)).toShort() }
    }
}
