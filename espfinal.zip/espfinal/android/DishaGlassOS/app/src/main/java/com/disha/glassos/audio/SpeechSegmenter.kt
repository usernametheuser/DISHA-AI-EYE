package com.disha.glassos.audio

import kotlin.math.sqrt

/**
 * Cuts a continuous stream of 20 ms microphone frames (320 samples at 16 kHz) into spoken
 * segments, each with a little silence before and after. Keeps the last 16 s of sound. Pure logic,
 * unit-tested on the PC. The wake word uses the defaults; live captions end a segment sooner and
 * cut long speech at [maxSpeechMs] instead of dropping it.
 */
class SpeechSegmenter(
    private val endSilenceMs: Int = SpeechDetector.END_SILENCE_MS,
    private val maxSpeechMs: Int = MAX_SPEECH_MS,
) {

    class Segment(val pcm: ShortArray, val speechMs: Int)

    companion object {
        const val FRAME = Wav.RATE * SpeechDetector.FRAME_MS / 1000  // 320
        private const val HISTORY = Wav.RATE * 16
        private const val PRE_SAMPLES = Wav.RATE * 300 / 1000
        private const val POST_SAMPLES = Wav.RATE * 250 / 1000
        private const val MIN_SPEECH_MS = 350
        const val MAX_SPEECH_MS = 9000
    }

    private val history = ShortArray(HISTORY)  // ring buffer
    private var written = 0L                   // samples ever written
    private var detector = newDetector()
    private var detectorStart = 0L             // sample index where the current detector began

    // The default keeps the detector's own 15 s limit, so too-long speech is dropped (wake word).
    private fun newDetector() =
        if (maxSpeechMs == MAX_SPEECH_MS) SpeechDetector(Int.MAX_VALUE, endSilenceMs)
        else SpeechDetector(Int.MAX_VALUE, endSilenceMs, maxSpeechMs)

    /** Start afresh (after a pause): what was being said so far is ignored. */
    fun reset() {
        detector = newDetector()
        detectorStart = written
    }

    /** Adds one frame; returns a segment when one has just ended (and was long enough). */
    fun feed(frame: ShortArray): Segment? {
        var sum = 0.0
        for (i in 0 until FRAME) {
            val v = frame[i].toDouble()
            sum += v * v
            history[((written + i) % HISTORY).toInt()] = frame[i]
        }
        written += FRAME
        if (detector.feed(sqrt(sum / FRAME)) != SpeechDetector.Result.ENDED) return null

        val d = detector
        val base = detectorStart
        reset()
        val speechMs = d.speechMs
        if (!d.enoughSpeech || speechMs !in MIN_SPEECH_MS..maxSpeechMs + 100) return null
        // Detector frame k (1-based) covers samples [base + (k-1)*FRAME, base + k*FRAME).
        val start = base + (d.speechStartFrame - 1).toLong() * FRAME - PRE_SAMPLES
        val end = base + d.lastVoiceFrame.toLong() * FRAME + POST_SAMPLES
        val from = maxOf(start, written - HISTORY, 0L)
        val to = minOf(end, written)
        if (to - from < Wav.RATE / 4) return null
        return Segment(ShortArray((to - from).toInt()) { i -> history[((from + i) % HISTORY).toInt()] }, speechMs)
    }
}
