package com.disha.glassos.skills

import android.app.Activity
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.disha.glassos.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Smart gallery: photos found by what is in them ("whiteboard today"), newest and best first. */
class GalleryActivity : Activity() {

    companion object {
        const val EXTRA_QUERY = "query"
    }

    private lateinit var gallery: Gallery
    private lateinit var info: TextView
    private val adapter = Adapter()
    private var items: List<EntryStore.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gallery = Gallery(this)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(col(R.color.disha_bg))
        root.setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), 0)
        val title = TextView(this)
        title.text = getString(R.string.gallery_title)
        title.textSize = 22f
        title.setTextColor(col(R.color.disha_cyan))
        root.addView(title)
        val search = EditText(this)
        search.hint = getString(R.string.gallery_hint)
        search.setTextColor(col(R.color.disha_text))
        search.setHintTextColor(col(R.color.disha_dim))
        search.setSingleLine()
        root.addView(search)
        info = TextView(this)
        info.setTextColor(col(R.color.disha_dim))
        info.textSize = 12f
        root.addView(info)
        val list = ListView(this)
        list.adapter = adapter
        list.divider = null
        list.setOnItemClickListener { _, _, pos, _ ->
            val intent = gallery.viewIntent(items[pos])
            if (intent != null) startActivity(intent) else Toast.makeText(this, "The full photo is no longer in Pictures/DISHA.", Toast.LENGTH_LONG).show()
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) = show(s?.toString().orEmpty())
        })
        val q = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        search.setText(q)
        show(q)
    }

    @Suppress("DEPRECATION")
    private fun col(id: Int) = if (Build.VERSION.SDK_INT >= 23) getColor(id) else resources.getColor(id)

    private fun show(query: String) {
        val range = TimeRange.parse(query, System.currentTimeMillis())
        items = if (query.isBlank()) gallery.store.all().reversed().take(200) else gallery.search(query, range, 100)
        info.text = when {
            gallery.store.all().isEmpty() -> "No captioned photos yet. Switch on Smart gallery in Settings; new photos saved on the phone then get captions."
            items.isEmpty() -> "Nothing matches \"$query\"."
            else -> "${items.size} photo${if (items.size == 1) "" else "s"}" + (range?.let { " · ${it.label}" } ?: "")
        }
        adapter.notifyDataSetChanged()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].time

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val dp = resources.displayMetrics.density
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@GalleryActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
                addView(ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams((112 * dp).toInt(), (84 * dp).toInt()))
                addView(TextView(context).apply {
                    setTextColor(col(R.color.disha_text))
                    textSize = 13f
                    setPadding((12 * dp).toInt(), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            val e = items[position]
            val image = row.getChildAt(0) as ImageView
            val thumb = gallery.thumbnail(e)
            image.setImageBitmap(thumb?.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) })
            val place = gallery.place(e)
            (row.getChildAt(1) as TextView).text = e.text + "\n" +
                SimpleDateFormat("EEE d MMM, h:mm a", Locale.ENGLISH).format(Date(e.time)) + if (place.isNotEmpty()) " · $place" else ""
            return row
        }
    }
}
