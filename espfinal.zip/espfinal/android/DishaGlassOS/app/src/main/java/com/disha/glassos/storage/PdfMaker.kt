package com.disha.glassos.storage

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream

/** Document pages: a cleaner "scanned" look for each photo, and the pages as one A4 PDF. Call off the main thread. */
object PdfMaker {

    /**
     * Stretches the brightness range (the darkest 2% become black, the brightest 2% white): grey
     * paper turns white and the text dark, as from a scanner. Returns a JPEG.
     */
    fun enhance(jpeg: ByteArray): ByteArray {
        val src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return jpeg
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        src.recycle()
        val hist = IntArray(256)
        for (c in px) hist[(Color.red(c) * 77 + Color.green(c) * 150 + Color.blue(c) * 29) shr 8]++
        val cut = px.size / 50
        var lo = 0
        var acc = 0
        while (lo < 255 && acc + hist[lo] < cut) acc += hist[lo++]
        var hi = 255
        acc = 0
        while (hi > 0 && acc + hist[hi] < cut) acc += hist[hi--]
        if (hi - lo < 40) return jpeg  // flat picture: leave it
        val lut = IntArray(256) { v -> ((v - lo) * 255 / (hi - lo)).coerceIn(0, 255) }
        for (i in px.indices) {
            val c = px[i]
            px[i] = Color.rgb(lut[Color.red(c)], lut[Color.green(c)], lut[Color.blue(c)])
        }
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val bytes = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 88, bytes)
        out.recycle()
        return bytes.toByteArray()
    }

    /** One A4 page per picture (landscape pictures on landscape pages), with a small margin. */
    fun make(pages: List<ByteArray>): ByteArray {
        val doc = PdfDocument()
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        try {
            pages.forEachIndexed { i, jpeg ->
                val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return@forEachIndexed
                val landscape = bmp.width > bmp.height
                val (pw, ph) = if (landscape) 842 to 595 else 595 to 842  // A4 in points
                val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                val margin = 18f
                val scale = minOf((pw - 2 * margin) / bmp.width, (ph - 2 * margin) / bmp.height)
                val dw = bmp.width * scale
                val dh = bmp.height * scale
                val left = (pw - dw) / 2
                val top = (ph - dh) / 2
                page.canvas.drawColor(Color.WHITE)
                page.canvas.drawBitmap(bmp, Rect(0, 0, bmp.width, bmp.height), RectF(left, top, left + dw, top + dh), paint)
                doc.finishPage(page)
                bmp.recycle()
            }
            val out = ByteArrayOutputStream()
            doc.writeTo(out)
            return out.toByteArray()
        } finally {
            doc.close()
        }
    }
}
