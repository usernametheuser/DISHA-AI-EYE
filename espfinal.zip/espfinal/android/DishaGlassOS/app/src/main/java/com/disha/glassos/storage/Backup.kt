package com.disha.glassos.storage

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.disha.glassos.BuildConfig
import com.disha.glassos.assistant.MemoryStore
import com.disha.glassos.assistant.Reminders
import com.disha.glassos.audio.WakeMatcher
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.skills.EntryStore
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Backup and restore of everything the user taught or told Disha: the wake-word recordings,
 * settings, memory, reminders, diary, places, documents and photo captions. An update installed
 * over the app keeps all of this anyway; a backup also brings it back after an uninstall or on a
 * new phone. The file format is [BackupArchive].
 */
class Backup(context: Context) {

    /** What a backup holds, for the "Restore?" question. */
    class Contents(val files: Map<String, ByteArray>, val created: Long, val appVersion: String, val format: Int) {
        val wake get() = files.filter { it.key.startsWith("wake/") && BackupArchive.isWav(it.value) }
        val hasSettings get() = BackupArchive.SETTINGS in files
    }

    private companion object {
        const val TAG = "Backup"
        const val AUTO_NAME = "disha-backup.zip"
        const val AUTO_FOLDER = "DISHA/Backup"
        const val DAY_MS = 24 * 60 * 60 * 1000L
        val LOCK = Any()  // the service and Settings may both save the automatic copy
    }

    private val app = context.applicationContext
    private val settings = AppSettings(app)
    private val wakeDir = File(app.filesDir, "wake")

    // ---------------------------------------------------------------------------------------
    // Saving
    // ---------------------------------------------------------------------------------------

    /** Writes a backup of everything to [out] (the caller closes it). */
    fun write(out: OutputStream) {
        val files = LinkedHashMap<String, ByteArray>()
        val wavs = wakeDir.listFiles { f -> f.name.endsWith(".wav") }.orEmpty().sortedBy { it.name }
        files[BackupArchive.MANIFEST] = JSONObject()
            .put("format", BackupArchive.FORMAT)
            .put("app", BuildConfig.VERSION_NAME)
            .put("code", BuildConfig.VERSION_CODE)
            .put("created", System.currentTimeMillis())
            .put("assistantName", settings.assistantName)
            .toString().toByteArray()
        for (f in wavs) if (BackupArchive.allowed("wake/${f.name}")) files["wake/${f.name}"] = f.readBytes()
        files[BackupArchive.SETTINGS] = settingsJson().toString().toByteArray()
        files[BackupArchive.MEMORY] = MemoryStore(app).toJson().toByteArray()
        files[BackupArchive.REMINDERS] = Reminders(app).toJson().toByteArray()
        for (name in BackupArchive.STORES) {
            val f = File(app.filesDir, "$name.json")  // written atomically by EntryStore, so always whole
            if (f.exists()) files["stores/$name.json"] = f.readBytes()
        }
        BackupArchive.write(out, files)
    }

    /** The settings (without the API key, consents and working state), with their types. */
    private fun settingsJson(): JSONObject {
        val json = JSONObject()
        val prefs = app.getSharedPreferences("disha", Context.MODE_PRIVATE)
        for ((key, value) in prefs.all) {
            if (key in BackupArchive.PRIVATE_SETTINGS) continue
            val typed = when (value) {
                is Boolean -> JSONObject().put("b", value)
                is Int -> JSONObject().put("i", value)
                is Long -> JSONObject().put("l", value)
                is Float -> JSONObject().put("f", value.toDouble())
                is String -> JSONObject().put("s", value)
                else -> null
            }
            if (typed != null) json.put(key, typed)
        }
        return json
    }

    /**
     * The automatic copy, Documents/DISHA/Backup/disha-backup.zip, which outlives an uninstall
     * (Android 10+; older phones keep it in the app's own folder). Replaces this app's previous
     * copy. Returns where it went, or null. Runs on the calling thread: call it off the main one.
     */
    fun saveAutomatic(): String? = synchronized(LOCK) { saveAutomaticLocked() }

    private fun saveAutomaticLocked(): String? {
        if (wakeDir.listFiles { f -> f.name.endsWith(".wav") }.isNullOrEmpty() && MemoryStore(app).all().isEmpty()) {
            return null  // nothing taught yet: don't replace a good older copy with an empty one
        }
        val bytes = try {
            ByteArrayOutputStream().also { write(it) }.toByteArray()
        } catch (e: Exception) {
            AppLog.w(TAG, "Backup failed: ${e.message}")
            return null
        }
        val where = if (Build.VERSION.SDK_INT >= 29) saveShared(bytes) else saveInAppFolder(bytes)
        if (where != null) {
            settings.lastBackupAt = System.currentTimeMillis()
            settings.lastBackupWhere = where
            AppLog.i(TAG, "Backup saved: $where (${bytes.size / 1024} KB)")
        }
        return where
    }

    /** The automatic backup, if it is switched on and the last one is a day old. */
    fun saveAutomaticIfDue() {
        if (settings.autoBackup && System.currentTimeMillis() - settings.lastBackupAt > DAY_MS) saveAutomatic()
    }

    private fun saveShared(bytes: ByteArray): String? {
        val resolver = app.contentResolver
        val collection = MediaStore.Files.getContentUri("external")
        val folder = "${Environment.DIRECTORY_DOCUMENTS}/$AUTO_FOLDER/"
        return try {
            // Only this app's own earlier copy is visible here, so nothing else can be overwritten.
            val existing = resolver.query(
                collection, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                arrayOf(AUTO_NAME, folder), null,
            )?.use { c -> if (c.moveToFirst()) ContentUris.withAppendedId(collection, c.getLong(0)) else null }
            val uri = existing ?: resolver.insert(collection, ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, AUTO_NAME)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            }) ?: throw IOException("no place in Documents")
            resolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IOException("no output stream")
            "Documents/$AUTO_FOLDER/$AUTO_NAME"
        } catch (e: Exception) {
            AppLog.w(TAG, "Documents backup failed (${e.message}); using the app folder")
            saveInAppFolder(bytes)
        }
    }

    private fun saveInAppFolder(bytes: ByteArray): String? {
        val dir = File(app.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: app.filesDir, "Backup").apply { mkdirs() }
        val file = File(dir, AUTO_NAME)
        return try {
            val tmp = File(dir, "$AUTO_NAME.tmp")
            tmp.writeBytes(bytes)
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
            file.absolutePath
        } catch (e: IOException) {
            AppLog.w(TAG, "Backup save failed: ${e.message}")
            null
        }
    }

    // ---------------------------------------------------------------------------------------
    // Restoring
    // ---------------------------------------------------------------------------------------

    /** Reads and checks a backup without changing anything. Throws IOException with a readable reason. */
    fun read(input: InputStream): Contents {
        val files = BackupArchive.read(input)
        val manifest = try {
            JSONObject(String(files.getValue(BackupArchive.MANIFEST)))
        } catch (e: Exception) {
            throw IOException("The backup's manifest is damaged.")
        }
        return Contents(files, manifest.optLong("created"), manifest.optString("app"), manifest.optInt("format"))
    }

    /** One line about what [c] holds, for the question before restoring. */
    fun describe(c: Contents): String {
        val parts = ArrayList<String>()
        val wake = c.wake.size
        if (wake > 0) parts.add("$wake wake-word recordings")
        c.files[BackupArchive.MEMORY]?.let { b -> count { MemoryStore(app).parse(String(b)).size }.takeIf { it > 0 }?.let { parts.add("$it memories") } }
        val notes = BackupArchive.STORES.sumOf { name -> c.files["stores/$name.json"]?.let { b -> count { EntryStore.parse(String(b)).size } } ?: 0 }
        if (notes > 0) parts.add("$notes diary, place, document and photo notes")
        if (c.hasSettings) parts.add("your settings")
        return parts.joinToString(", ").ifEmpty { "nothing to restore" }
    }

    private inline fun count(block: () -> Int): Int = try {
        block()
    } catch (_: Exception) {
        0
    }

    /**
     * Restores [c]: settings and wake recordings are replaced by the backup's (when it has enough
     * recordings), memories, reminders and notes are added to the ones on the phone. Returns a
     * short report. Runs on the calling thread: call it off the main one.
     */
    fun restore(c: Contents): String {
        val done = ArrayList<String>()
        if (c.hasSettings) {
            try {
                restoreSettings(JSONObject(String(c.files.getValue(BackupArchive.SETTINGS))))
                done.add("settings")
            } catch (e: Exception) {
                AppLog.w(TAG, "Settings not restored: ${e.message}")
            }
        }
        val wake = c.wake
        if (wake.size >= WakeMatcher.MIN_SAMPLES) {
            wakeDir.mkdirs()
            wakeDir.listFiles()?.forEach { it.delete() }  // the user agreed to replace them
            for ((name, bytes) in wake) File(wakeDir, name.removePrefix("wake/")).writeBytes(bytes)
            settings.wakeVersion = settings.wakeVersion + 1  // the running assistant reloads them
            done.add("${wake.size} wake-word recordings")
        }
        c.files[BackupArchive.MEMORY]?.let { b ->
            val n = count { MemoryStore(app).let { it.merge(it.parse(String(b))) } }
            if (n > 0) done.add("$n memories")
        }
        c.files[BackupArchive.REMINDERS]?.let { b ->
            val n = count { Reminders(app).addFromBackup(String(b)) }
            if (n > 0) done.add("$n reminders")
        }
        var notes = 0
        for (name in BackupArchive.STORES) {
            val b = c.files["stores/$name.json"] ?: continue
            notes += count { EntryStore(app, name, Int.MAX_VALUE).merge(EntryStore.parse(String(b))) }
        }
        if (notes > 0) done.add("$notes notes")
        AppLog.i(TAG, "Restored: ${done.joinToString()}")
        return if (done.isEmpty()) "Nothing new to restore: this phone already has everything in that backup."
        else "Restored ${done.joinToString(", ")}."
    }

    private fun restoreSettings(json: JSONObject) {
        val prefs = app.getSharedPreferences("disha", Context.MODE_PRIVATE)
        val current = prefs.all
        val edit = prefs.edit()
        for (key in json.keys()) {
            if (key in BackupArchive.PRIVATE_SETTINGS) continue
            val o = json.optJSONObject(key) ?: continue
            val value: Any = when {
                o.has("b") -> o.getBoolean("b")
                o.has("i") -> o.getInt("i")
                o.has("l") -> o.getLong("l")
                o.has("f") -> o.getDouble("f").toFloat()
                o.has("s") -> o.getString("s")
                else -> continue
            }
            // A setting whose type changed between versions is left as it is (reading it would crash).
            val now = current[key]
            if (now != null && now::class != value::class) continue
            when (value) {
                is Boolean -> edit.putBoolean(key, value)
                is Int -> edit.putInt(key, value)
                is Long -> edit.putLong(key, value)
                is Float -> edit.putFloat(key, value)
                is String -> edit.putString(key, value)
            }
        }
        edit.commit()
    }
}
