package com.disha.glassos.camera

import android.os.SystemClock

/** Frames per second over a sliding window. */
class FpsMeter(private val windowMs: Long = 3000) {
    private val times = ArrayDeque<Long>()

    @Synchronized
    fun tick(nowMs: Long = SystemClock.elapsedRealtime()) {
        times.addLast(nowMs)
        trim(nowMs)
    }

    @Synchronized
    fun fps(nowMs: Long = SystemClock.elapsedRealtime()): Double {
        trim(nowMs)
        if (times.size < 2) return 0.0
        val span = times.last() - times.first()
        return if (span <= 0) 0.0 else (times.size - 1) * 1000.0 / span
    }

    @Synchronized
    fun reset() = times.clear()

    private fun trim(nowMs: Long) {
        while (times.isNotEmpty() && nowMs - times.first() > windowMs) times.removeFirst()
    }
}
