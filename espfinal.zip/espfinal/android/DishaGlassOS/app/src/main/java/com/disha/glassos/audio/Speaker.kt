package com.disha.glassos.audio

import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Spoken answers with Android TextToSpeech. Plays as media/assistant audio, so it comes out of
 * Bluetooth earbuds when they are connected, otherwise the phone speaker. A new answer always
 * replaces the current one (no overlapping speech). Main thread only.
 */
class Speaker(context: Context, private val listener: Listener) {

    interface Listener {
        fun onTtsReady(ok: Boolean, message: String)
        fun onSpeakDone()
        fun onSpeakError(message: String)
    }

    private companion object {
        val HINDI = Locale("hi", "IN")
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var currentId: String? = null
    private var counter = 0
    private var english: Locale = Locale.US
    private var hindiAvailable = false
    private var current: Locale? = null
    private var accents: List<String> = listOf("en-IN")
    private var rate = 1.0f

    var ready = false
        private set

    /** Accent (first installed language tag wins) and speaking rate; applies now or once ready. */
    fun configure(languageTags: List<String>, speechRate: Float) {
        accents = languageTags
        rate = speechRate
        val t = tts ?: return
        if (!ready) return
        val chosen = pick(t, languageTags) ?: return
        english = chosen
        current = null  // set on the next speak()
        t.setSpeechRate(speechRate)
    }

    /**
     * The first accent with an installed voice for that exact country ("English is available" alone
     * would mean a generic voice, not the Irish or British one asked for), else any English.
     */
    private fun pick(t: TextToSpeech, tags: List<String>): Locale? {
        val all = (tags + listOf("en-IN", "en-GB", "en-US")).distinct().map { Locale.forLanguageTag(it) }
        return all.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_COUNTRY_AVAILABLE }
            ?: all.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }
    }

    /** The accent actually in use, for example "English (Ireland)". */
    val voiceName: String get() = english.getDisplayName(Locale.ENGLISH)

    init {
        tts = TextToSpeech(context.applicationContext) { status -> main.post { onInit(status) } }
    }

    private fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            listener.onTtsReady(false, "The text-to-speech engine did not start. Install or enable Google Text-to-speech.")
            return
        }
        val usage = if (Build.VERSION.SDK_INT >= 26) AudioAttributes.USAGE_ASSISTANT else AudioAttributes.USAGE_MEDIA
        t.setAudioAttributes(
            AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
        )
        val chosen = pick(t, accents)
        val lang = if (chosen != null) t.setLanguage(chosen) else TextToSpeech.LANG_NOT_SUPPORTED
        english = chosen ?: Locale.US
        current = english
        t.setSpeechRate(rate)
        hindiAvailable = t.isLanguageAvailable(HINDI) >= TextToSpeech.LANG_AVAILABLE
        if (lang < TextToSpeech.LANG_AVAILABLE) {
            listener.onTtsReady(
                false,
                "No English voice is installed. Settings > Text-to-speech output > install voice data.",
            )
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                main.post { if (utteranceId == currentId) done() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                main.post { if (utteranceId == currentId) error("Speech output failed") }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                main.post { if (utteranceId == currentId) error("Speech output failed (code $errorCode)") }
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                main.post { if (utteranceId == currentId) done() }
            }
        })
        ready = true
        listener.onTtsReady(true, "Voice ready")
    }

    /** Returns false if nothing will be spoken (empty text or engine not ready). */
    fun speak(text: String): Boolean {
        val t = tts
        if (text.isBlank() || t == null || !ready) return false
        // Hindi answers (Devanagari script) need a Hindi voice; everything else uses the English one.
        val wanted = if (hindiAvailable && text.any { it in 'ऀ'..'ॿ' }) HINDI else english
        if (wanted != current) {
            t.setLanguage(wanted)
            current = wanted
        }
        val id = "disha-${++counter}"
        currentId = id
        return t.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), id) == TextToSpeech.SUCCESS
    }

    /** Stops speaking at once. No onSpeakDone follows: the caller already knows. */
    fun stop() {
        currentId = null
        tts?.stop()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    private fun done() {
        currentId = null
        listener.onSpeakDone()
    }

    private fun error(message: String) {
        currentId = null
        listener.onSpeakError(message)
    }
}
