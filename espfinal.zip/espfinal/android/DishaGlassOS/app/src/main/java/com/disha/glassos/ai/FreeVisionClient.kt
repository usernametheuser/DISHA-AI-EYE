package com.disha.glassos.ai

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * Free vision AI with no API key: OVHcloud AI Endpoints (OpenAI-compatible chat/completions),
 * anonymous access. Each model allows about 2 requests per minute per internet connection, so the
 * client walks a list of vision models, remembers which ones are cooling down (from the
 * retry-after / ratelimit-* headers) and skips them. Nothing is sent anywhere else.
 * One request at a time; callbacks run on the main thread.
 */
class FreeVisionClient(private val settings: AppSettings) : VisionAi {

    companion object {
        private const val TAG = "FreeAI"
        private const val BASE = "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1"
        private const val CONNECT_TIMEOUT_MS = 15000
        private const val READ_TIMEOUT_MS = 30000
        private const val MAX_IMAGE_BYTES = 3 * 1024 * 1024
        private const val MAX_WAIT_MS = 20000L        // longest wait for a busy model before giving up
        private const val BUSY_DEFAULT_MS = 60000L
        private const val ERROR_COOLDOWN_MS = 30000L
        private const val GONE_COOLDOWN_MS = 10 * 60000L

        /**
         * Vision models that read a test picture correctly without a key (tested 2026-10-10), fastest first.
         * Qwen3.5-397B-A17B is left out: it reasoned past 1024 tokens without answering.
         */
        val MODELS = listOf(
            "Qwen2.5-VL-72B-Instruct",
            "Mistral-Small-3.2-24B-Instruct-2506",
            "Qwen3.8-27B",
            "Qwen3.6-27B",
            "Qwen3.5-9B",
        )

        private val THINK_BLOCK = Regex("(?s)<think>.*?</think>")

        /** Puts [preferred] first, then the other known models. */
        fun order(preferred: String): List<String> =
            if (preferred.isBlank()) MODELS else listOf(preferred) + MODELS.filter { it != preferred }

        /** The spoken answer from a chat/completions response, or null if there is none. */
        fun answerText(body: String): String? {
            val choice = try {
                JSONObject(body).optJSONArray("choices")?.optJSONObject(0)
            } catch (_: JSONException) {
                null
            } ?: return null
            val content = choice.optJSONObject("message")?.optString("content").orEmpty()
            return content.replace(THINK_BLOCK, "").trim().ifEmpty { null }
        }
    }

    /** Why one model did not answer. */
    private sealed class Outcome {
        class Answer(val text: String) : Outcome()
        class Skip(val reason: String, val coolMs: Long) : Outcome()
        class Stop(val message: String) : Outcome()
    }

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-freeai").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    private val coolUntil = HashMap<String, Long>()  // model -> elapsedRealtime; executor thread only

    override val name = "the free AI"

    override fun isConfigured() = true

    override fun ask(
        question: String,
        jpeg: ByteArray?,
        history: List<VisionAi.Turn>,
        systemPrompt: String,
        callback: (VisionAi.Result) -> Unit,
    ) {
        val models = order(settings.freeModel)
        executor.execute {
            val result = if (jpeg != null && jpeg.size > MAX_IMAGE_BYTES) {
                VisionAi.Result.Failure("The picture is too large to send.")
            } else {
                val body = requestBody(question, listOfNotNull(jpeg), history, systemPrompt)
                walk(models, body, jpeg != null)
            }
            main.post { callback(result) }
        }
    }

    /** Several pictures in one question (tested 2026-10-10 on Qwen2.5-VL, Qwen3.8 and Mistral-Small). */
    override fun askFrames(question: String, frames: List<ByteArray>, systemPrompt: String, callback: (VisionAi.Result) -> Unit) {
        val models = order(settings.freeModel)
        executor.execute {
            val result = if (frames.sumOf { it.size } > MAX_IMAGE_BYTES * 2) {
                VisionAi.Result.Failure("The pictures are too large to send together.")
            } else {
                walk(models, requestBody(question, frames, emptyList(), systemPrompt), true)
            }
            main.post { callback(result) }
        }
    }

    /** Lists the known vision models the service currently offers (for the Settings picker). */
    fun listModels(callback: (List<String>?, String?) -> Unit) {
        executor.execute {
            var models: List<String>? = null
            var error: String? = null
            try {
                val (code, body, _) = http("GET", URL("$BASE/models"), null)
                if (code != 200) {
                    error = "The free AI service answered with error $code."
                } else {
                    val arr = JSONObject(body).optJSONArray("data") ?: JSONArray()
                    val live = (0 until arr.length()).map { arr.getJSONObject(it).optString("id") }.toSet()
                    models = MODELS.filter { it in live }
                    if (models.isEmpty()) error = "The free service lists none of the vision models DISHA knows right now."
                }
            } catch (e: Exception) {
                error = networkMessage(e)
            }
            main.post { callback(models, error) }
        }
    }

    private fun requestBody(question: String, images: List<ByteArray>, history: List<VisionAi.Turn>, systemPrompt: String): JSONObject {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        for (t in history) {
            messages.put(JSONObject().put("role", "user").put("content", t.user))
            messages.put(JSONObject().put("role", "assistant").put("content", t.assistant))
        }
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", question))
        for (jpeg in images) {
            val uri = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
            content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", uri)))
        }
        messages.put(JSONObject().put("role", "user").put("content", content))
        // Room for the models that reason before answering; the answer itself is short.
        return JSONObject().put("messages", messages).put("max_tokens", 1024).put("temperature", 0.4)
    }

    private fun walk(models: List<String>, body: JSONObject, withImage: Boolean): VisionAi.Result {
        val tried = LinkedHashMap<String, String>()
        for (round in 0 until 2) {
            if (round > 0) {
                val wait = models.minOf { remainingMs(it) }
                if (wait > MAX_WAIT_MS) break
                AppLog.i(TAG, "All free models busy; waiting ${wait / 1000} s")
                SystemClock.sleep(wait + 300)
            }
            for (model in models) {
                if (remainingMs(model) > 0) {
                    tried.putIfAbsent(model, "busy")
                    continue
                }
                when (val o = askModel(model, body, withImage)) {
                    is Outcome.Answer -> return VisionAi.Result.Answer(o.text)
                    is Outcome.Stop -> return VisionAi.Result.Failure(o.message)
                    is Outcome.Skip -> {
                        tried[model] = o.reason
                        if (o.coolMs > 0) coolUntil[model] = SystemClock.elapsedRealtime() + o.coolMs
                    }
                }
            }
        }
        AppLog.w(TAG, "No free model answered: " + tried.entries.joinToString("; ") { "${it.key}: ${it.value}" })
        return VisionAi.Result.Failure(
            if (tried.values.all { it == "busy" }) {
                "The free AI is busy. It allows only a few questions a minute. Wait a minute and ask again."
            } else if (tried.values.any { it == "needs a key" }) {
                "The free AI service now asks for a key. Choose Google Gemini in Settings and paste a free key."
            } else {
                "The free AI couldn't answer right now. Try again in a minute."
            },
        )
    }

    private fun askModel(model: String, body: JSONObject, withImage: Boolean): Outcome {
        val started = SystemClock.elapsedRealtime()
        val (code, text, headers) = try {
            http("POST", URL("$BASE/chat/completions"), JSONObject(body.toString()).put("model", model).toString())
        } catch (e: Exception) {
            AppLog.w(TAG, "$model: ${e.javaClass.simpleName}: ${e.message}")
            return when (e) {
                is UnknownHostException -> Outcome.Stop(networkMessage(e))
                is SocketTimeoutException -> Outcome.Skip("too slow", ERROR_COOLDOWN_MS)
                else -> Outcome.Skip("network error", 0)
            }
        }
        val ms = SystemClock.elapsedRealtime() - started
        when {
            code == 200 -> {
                // Remember when this model's per-minute allowance runs out, so the next question skips it.
                if (headers["ratelimit-remaining"] == "0") coolUntil[model] = SystemClock.elapsedRealtime() + seconds(headers, "ratelimit-reset")
                val answer = answerText(text)
                if (answer == null) {
                    AppLog.w(TAG, "$model: empty answer after $ms ms: ${text.take(300)}")
                    return Outcome.Skip("empty answer", 0)
                }
                AppLog.i(TAG, "$model answered in $ms ms (${if (withImage) "with picture" else "text only"})")
                return Outcome.Answer(answer)
            }
            code == 429 -> {
                val wait = seconds(headers, "retry-after", "ratelimit-reset")
                AppLog.i(TAG, "$model busy for ${wait / 1000} s")
                return Outcome.Skip("busy", wait)
            }
            code == 401 || code == 403 -> return Outcome.Skip("needs a key", GONE_COOLDOWN_MS)
            code == 404 -> return Outcome.Skip("not offered any more", GONE_COOLDOWN_MS)
            code in 400..499 -> {
                AppLog.w(TAG, "$model: HTTP $code: ${text.take(300)}")
                return Outcome.Skip("rejected ($code)", GONE_COOLDOWN_MS)
            }
            else -> {
                AppLog.w(TAG, "$model: HTTP $code after $ms ms")
                return Outcome.Skip("server error $code", ERROR_COOLDOWN_MS)
            }
        }
    }

    private fun remainingMs(model: String) = ((coolUntil[model] ?: 0L) - SystemClock.elapsedRealtime()).coerceAtLeast(0L)

    /** First header that holds a number of seconds, in ms; one minute if none. */
    private fun seconds(headers: Map<String, String>, vararg names: String): Long {
        for (n in names) headers[n]?.trim()?.toLongOrNull()?.let { return (it.coerceIn(1, 3600)) * 1000 }
        return BUSY_DEFAULT_MS
    }

    private fun networkMessage(e: Exception): String = when (e) {
        is UnknownHostException -> "There's no internet connection."
        is SocketTimeoutException -> "The free AI took too long to answer. Try again."
        is IOException -> "Network problem: ${e.message ?: "connection failed"}."
        else -> "Something went wrong talking to the free AI."
    }

    /** No Authorization header: this service is used anonymously. Header names are lower-cased. */
    private fun http(method: String, url: URL, body: String?): Triple<Int, String, Map<String, String>> {
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val headers = HashMap<String, String>()
            for ((k, v) in c.headerFields) if (k != null && v.isNotEmpty()) headers[k.lowercase()] = v[0]
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return Triple(code, text, headers)
        } finally {
            c.disconnect()
        }
    }
}
