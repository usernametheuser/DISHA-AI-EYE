package com.disha.glassos.skills

import kotlin.math.abs

/**
 * Document mode: decides when a new page lies still in front of the camera, so it can be
 * photographed without a word. Fed a tiny grey thumbnail of every live-view frame. A page is taken
 * when the view has been steady for a moment and differs clearly from the page taken before (or,
 * for the first page, changed since the start or stayed put long enough). Pure logic.
 */
class PageWatcher(private val startedAt: Long) {

    companion object {
        const val SIZE = 32 * 24
        const val STILL = 7.0          // average grey difference between frames of a steady view
        const val NEW_PAGE = 16.0      // a new page differs at least this much from the last one
        const val STEADY_MS = 1300L
        const val FIRST_PAGE_WAIT_MS = 5000L

        /** Mean absolute difference of two thumbnails, 0..255. */
        fun diff(a: IntArray, b: IntArray): Double {
            var sum = 0L
            for (i in 0 until minOf(a.size, b.size)) sum += abs(a[i] - b[i])
            return sum.toDouble() / maxOf(1, minOf(a.size, b.size))
        }
    }

    private var first: IntArray? = null
    private var previous: IntArray? = null
    private var steadySince = 0L
    private var lastPage: IntArray? = null
    var paused = false

    /** true: take the page now. */
    fun feed(thumb: IntArray, now: Long): Boolean {
        if (first == null) first = thumb
        val prev = previous
        previous = thumb
        if (prev == null || diff(prev, thumb) > STILL) {
            steadySince = now
            return false
        }
        if (paused || now - steadySince < STEADY_MS) return false
        val last = lastPage
        val ready = if (last != null) {
            diff(last, thumb) >= NEW_PAGE
        } else {
            diff(first!!, thumb) >= NEW_PAGE || now - startedAt >= FIRST_PAGE_WAIT_MS
        }
        if (ready) {
            lastPage = thumb
            steadySince = now  // not twice in a row
        }
        return ready
    }

    /** The last page is to be taken again: the same view counts as new. */
    fun retake() {
        lastPage = null
        first = IntArray(SIZE)  // anything differs from black: taken as soon as it is steady
    }

    /** A page was taken another way ("scan"): remember it as the last page. */
    fun taken(thumb: IntArray?) {
        if (thumb != null) lastPage = thumb
    }
}
