package com.disha.glassos.storage

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.disha.glassos.util.AppLog
import java.io.File
import java.io.IOException

/**
 * Saves photos and videos where the user can find them.
 * Android 10+: the shared Pictures/DISHA and Movies/DISHA folders (Gallery, Files app), no permission needed.
 * Android 5-9: the app's own folder (Android/data/com.disha.glassos/files/...), also without a permission.
 */
object MediaSaver {
    private const val TAG = "Storage"

    /** Returns where the photo went, or null on failure. */
    fun savePhoto(context: Context, jpeg: ByteArray, name: String): String? {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/DISHA")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                try {
                    resolver.openOutputStream(uri)?.use { it.write(jpeg) } ?: throw IOException("no output stream")
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    return "Pictures/DISHA/$name"
                } catch (e: Exception) {
                    AppLog.e(TAG, "Gallery save failed (${e.message}); using the app folder")
                    resolver.delete(uri, null, null)
                }
            }
        }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
        return try {
            File(dir, name).writeBytes(jpeg)
            File(dir, name).absolutePath
        } catch (e: IOException) {
            AppLog.e(TAG, "Photo save failed: ${e.message}")
            null
        }
    }

    /** A text file in Documents/DISHA (Android 10+) or the app folder. Returns where it went, or null. */
    fun saveText(context: Context, text: String, name: String): String? =
        saveDocument(context, text.toByteArray(Charsets.UTF_8), name, "text/plain")

    /** Any document (text, PDF) in Documents/DISHA (Android 10+) or the app folder. Returns where it went, or null. */
    fun saveDocument(context: Context, bytes: ByteArray, name: String, mime: String): String? {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/DISHA")
            }
            val resolver = context.contentResolver
            try {
                val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IOException("no output stream")
                    return "Documents/DISHA/$name"
                }
            } catch (e: Exception) {
                AppLog.e(TAG, "Documents save failed (${e.message}); using the app folder")
            }
        }
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        return try {
            File(dir, name).writeBytes(bytes)
            File(dir, name).absolutePath
        } catch (e: IOException) {
            AppLog.e(TAG, "Text save failed: ${e.message}")
            null
        }
    }

    /** Folder for videos while they are being written (random access is needed to finish the AVI). */
    fun recordingDir(context: Context): File =
        (context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir).also { it.mkdirs() }

    /** Moves a finished video into Movies/DISHA (Android 10+). Returns where it ended up. */
    fun publishVideo(context: Context, file: File): String {
        if (Build.VERSION.SDK_INT < 29) return file.absolutePath
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/avi")
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/DISHA")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = try {
            resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        } catch (e: Exception) {
            AppLog.w(TAG, "Movies folder unavailable (${e.message}); video stays in the app folder")
            null
        } ?: return file.absolutePath
        return try {
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: throw IOException("no output stream")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            file.delete()
            "Movies/DISHA/${file.name}"
        } catch (e: Exception) {
            AppLog.e(TAG, "Moving the video failed (${e.message}); it stays in ${file.absolutePath}")
            resolver.delete(uri, null, null)
            file.absolutePath
        }
    }

    /** Free space for the phone's own storage, in MB. */
    fun phoneFreeMb(context: Context): Long =
        (context.getExternalFilesDir(null) ?: context.filesDir).usableSpace / (1024 * 1024)
}
