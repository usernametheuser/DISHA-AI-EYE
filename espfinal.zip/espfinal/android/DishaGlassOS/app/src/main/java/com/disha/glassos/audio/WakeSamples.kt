package com.disha.glassos.audio

import android.content.Context
import java.io.File

/**
 * The user's recordings of their wake phrases ("Disha", "Hello Disha", "Hi Disha"), kept in the
 * app's private storage on the phone. Each file name holds its phrase number: phrase_<g>_<n>.wav.
 */
class WakeSamples(context: Context) {

    class Sample(val pcm: ShortArray, val group: Int)

    private val dir = File(context.applicationContext.filesDir, "wake")

    fun load(): List<Sample> =
        (dir.listFiles { f -> f.name.endsWith(".wav") } ?: emptyArray())
            .sortedBy { it.name }
            .map { f ->
                val group = Regex("^phrase_(\\d+)_").find(f.name)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                Sample(Wav.toPcm(f.readBytes()), group)
            }

    fun save(samples: List<Sample>) {
        clear()
        dir.mkdirs()
        samples.forEachIndexed { i, s -> File(dir, "phrase_${s.group}_${i + 1}.wav").writeBytes(Wav.fromPcm(s.pcm)) }
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    fun count(): Int = dir.listFiles { f -> f.name.endsWith(".wav") }?.size ?: 0

    /** A matcher for the saved recordings, or null if there are too few. */
    fun matcher(sensitivity: Float): WakeMatcher? {
        val s = load()
        if (s.size < WakeMatcher.MIN_SAMPLES) return null
        return WakeMatcher(s.map { it.pcm }, s.map { it.group }, sensitivity).takeIf { it.ready }
    }
}
