package com.disha.glassos.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.disha.glassos.service.DishaService
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject

/**
 * Timers and reminders. Each one is an AlarmManager alarm (exact when the phone allows it), so it
 * fires on time with the screen off; [ReminderReceiver] then hands it to [DishaService], which
 * speaks it in the earbuds and shows a notification. Stored on the phone so a restart of the app
 * does not lose them (a phone reboot does).
 */
class Reminders(context: Context) {

    class Item(val id: Int, val at: Long, val text: String, val isTimer: Boolean, val seconds: Int)

    private companion object {
        const val TAG = "Reminders"
        const val EXTRA_ID = "id"
    }

    private val appContext = context.applicationContext
    private val p = appContext.getSharedPreferences("disha_reminders", Context.MODE_PRIVATE)
    private val alarms = appContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun pending(): List<Item> {
        val arr = try {
            JSONArray(p.getString("items", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let {
                Item(it.optInt("id"), it.optLong("at"), it.optString("text"), it.optBoolean("timer"), it.optInt("seconds"))
            }
        }.sortedBy { it.at }
    }

    fun add(seconds: Int, text: String, isTimer: Boolean): Item {
        val id = p.getInt("nextId", 1)
        val item = Item(id, System.currentTimeMillis() + seconds * 1000L, text.trim(), isTimer, seconds)
        save(pending() + item)
        p.edit().putInt("nextId", if (id >= 100000) 1 else id + 1).apply()
        schedule(item)
        AppLog.i(TAG, "${if (isTimer) "Timer" else "Reminder"} #$id in $seconds s: ${item.text}")
        return item
    }

    /** Called when an alarm fires: removes and returns the item (null if it was cancelled). */
    fun fired(id: Int): Item? {
        val all = pending()
        val item = all.firstOrNull { it.id == id } ?: return null
        save(all.filter { it.id != id })
        return item
    }

    fun cancelAll(): Int {
        val all = pending()
        for (item in all) alarms.cancel(intentFor(item.id))
        save(emptyList())
        return all.size
    }

    /** The pending items as JSON, for a backup. */
    fun toJson(): String = p.getString("items", "[]") ?: "[]"

    /** Re-arms the still-future items of a backup's [toJson] that are not set already; returns how many. */
    fun addFromBackup(json: String): Int {
        val arr = JSONArray(json)
        val now = System.currentTimeMillis()
        var have = pending()
        var added = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val at = o.optLong("at")
            val text = o.optString("text")
            if (at < now + 5000 || have.any { it.at == at && it.text == text }) continue
            val id = p.getInt("nextId", 1)
            p.edit().putInt("nextId", if (id >= 100000) 1 else id + 1).apply()
            val item = Item(id, at, text, o.optBoolean("timer"), o.optInt("seconds"))
            have = have + item
            save(have)
            schedule(item)
            added++
        }
        return added
    }

    /** After the app restarts: re-arms future alarms, returns the ones that were missed meanwhile. */
    fun restore(): List<Item> {
        val now = System.currentTimeMillis()
        val all = pending()
        // Due in the last minute: its alarm is probably what started the app, and it will be delivered.
        val missed = all.filter { it.at <= now - 60_000L }
        save(all - missed.toSet())
        for (item in all) if (item !in missed) schedule(item)
        return missed.filter { now - it.at < 60 * 60 * 1000L }  // older than an hour: not worth announcing
    }

    private fun schedule(item: Item) {
        val pi = intentFor(item.id)
        try {
            when {
                Build.VERSION.SDK_INT >= 31 && !alarms.canScheduleExactAlarms() ->
                    alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.at, pi)  // may be a few minutes late
                Build.VERSION.SDK_INT >= 23 -> alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.at, pi)
                else -> alarms.setExact(AlarmManager.RTC_WAKEUP, item.at, pi)
            }
        } catch (e: SecurityException) {
            AppLog.w(TAG, "Exact alarm refused (${e.message}); using an inexact one")
            alarms.set(AlarmManager.RTC_WAKEUP, item.at, pi)
        }
    }

    private fun intentFor(id: Int): PendingIntent {
        val i = Intent(appContext, ReminderReceiver::class.java).putExtra(EXTRA_ID, id)
        val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else PendingIntent.FLAG_UPDATE_CURRENT
        return PendingIntent.getBroadcast(appContext, id, i, flags)
    }

    private fun save(items: List<Item>) {
        val arr = JSONArray()
        for (it in items) {
            arr.put(JSONObject().put("id", it.id).put("at", it.at).put("text", it.text).put("timer", it.isTimer).put("seconds", it.seconds))
        }
        p.edit().putString("items", arr.toString()).apply()
    }
}

/** Receives a timer/reminder alarm and passes it to the running assistant (starting it if needed). */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        if (id < 0) return
        DishaService.start(context, DishaService.ACTION_REMINDER) { it.putExtra(DishaService.EXTRA_REMINDER_ID, id) }
    }
}
