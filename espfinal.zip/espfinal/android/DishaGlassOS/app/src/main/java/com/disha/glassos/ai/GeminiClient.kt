package com.disha.glassos.ai

import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * Google Gemini (generativelanguage.googleapis.com, v1beta generateContent) over HTTPS.
 * The API key comes from Settings and is sent only to Google, in the x-goog-api-key header.
 * One request at a time; callbacks run on the main thread.
 */
class GeminiClient(private val settings: AppSettings) : VisionAi {

    private companion object {
        const val TAG = "Gemini"
        const val BASE = "https://generativelanguage.googleapis.com/v1beta"
        const val CONNECT_TIMEOUT_MS = 15000
        const val READ_TIMEOUT_MS = 45000
        const val MAX_IMAGE_BYTES = 3 * 1024 * 1024
    }

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-gemini").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    override val name = "Google Gemini"

    override fun isConfigured() = settings.geminiKey.isNotBlank()

    override fun ask(
        question: String,
        jpeg: ByteArray?,
        history: List<VisionAi.Turn>,
        systemPrompt: String,
        callback: (VisionAi.Result) -> Unit,
    ) {
        val key = settings.geminiKey
        val model = settings.geminiModel
        executor.execute {
            val result = try {
                if (key.isBlank()) {
                    VisionAi.Result.Failure("Gemini isn't set up. Open Settings and paste your free Gemini API key, or choose the free AI.")
                } else if (jpeg != null && jpeg.size > MAX_IMAGE_BYTES) {
                    VisionAi.Result.Failure("The picture is too large to send.")
                } else {
                    generate(key, model, question, listOfNotNull(jpeg), history, systemPrompt, withThinkingConfig = true)
                }
            } catch (e: Exception) {
                AppLog.e(TAG, "Request failed: ${e.javaClass.simpleName}: ${e.message}")
                VisionAi.Result.Failure(networkMessage(e))
            }
            main.post { callback(result) }
        }
    }

    override fun askFrames(question: String, frames: List<ByteArray>, systemPrompt: String, callback: (VisionAi.Result) -> Unit) {
        val key = settings.geminiKey
        val model = settings.geminiModel
        executor.execute {
            val result = try {
                if (key.isBlank()) VisionAi.Result.Failure("Gemini isn't set up. Open Settings and paste your free Gemini API key, or choose the free AI.")
                else generate(key, model, question, frames, emptyList(), systemPrompt, withThinkingConfig = true)
            } catch (e: Exception) {
                AppLog.e(TAG, "Request failed: ${e.javaClass.simpleName}: ${e.message}")
                VisionAi.Result.Failure(networkMessage(e))
            }
            main.post { callback(result) }
        }
    }

    /** Lists the models this key can use for generateContent (for the Settings picker). */
    fun listModels(callback: (List<String>?, String?) -> Unit) {
        val key = settings.geminiKey
        executor.execute {
            var models: List<String>? = null
            var error: String? = null
            try {
                if (key.isBlank()) {
                    error = "Paste your API key first."
                } else {
                    val (code, body) = http("GET", URL("$BASE/models?pageSize=200"), key, null)
                    if (code != 200) {
                        error = errorMessage(code, body, "")
                    } else {
                        val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
                        val names = ArrayList<String>()
                        for (i in 0 until arr.length()) {
                            val m = arr.getJSONObject(i)
                            val methods = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
                            if (methods.contains("generateContent")) names.add(m.optString("name").removePrefix("models/"))
                        }
                        models = names.sortedWith(compareByDescending<String> { it.contains("flash") }.thenBy { it })
                    }
                }
            } catch (e: Exception) {
                error = networkMessage(e)
            }
            main.post { callback(models, error) }
        }
    }

    private fun generate(
        key: String,
        model: String,
        question: String,
        images: List<ByteArray>,
        history: List<VisionAi.Turn>,
        systemPrompt: String,
        withThinkingConfig: Boolean,
    ): VisionAi.Result {
        val contents = JSONArray()
        for (t in history) {
            contents.put(textContent("user", t.user))
            contents.put(textContent("model", t.assistant))
        }
        val parts = JSONArray()
        for (jpeg in images) {
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP)),
                ),
            )
        }
        parts.put(JSONObject().put("text", question))
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val generation = JSONObject().put("maxOutputTokens", 1024).put("temperature", 0.4)
        if (withThinkingConfig) thinkingConfig(model)?.let { generation.put("thinkingConfig", it) }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", generation)

        val started = System.nanoTime()
        val (code, text) = http("POST", URL("$BASE/models/$model:generateContent"), key, body.toString())
        val ms = (System.nanoTime() - started) / 1_000_000
        if (code == 400 && withThinkingConfig && text.contains("thinking", ignoreCase = true)) {
            AppLog.w(TAG, "Model $model rejected the thinking setting; retrying without it")
            return generate(key, model, question, images, history, systemPrompt, withThinkingConfig = false)
        }
        if (code != 200) {
            AppLog.w(TAG, "HTTP $code after $ms ms: ${text.take(300)}")
            return VisionAi.Result.Failure(errorMessage(code, text, model))
        }
        AppLog.i(TAG, "Answer in $ms ms (${if (images.isNotEmpty()) "with ${images.size} picture(s), ${images.sumOf { it.size } / 1024} KB" else "text only"})")
        return parseAnswer(text)
    }

    /** Fast answers for a voice assistant: as little "thinking" as the model allows. */
    private fun thinkingConfig(model: String): JSONObject? = when {
        model.startsWith("gemini-2.5-flash") -> JSONObject().put("thinkingBudget", 0)
        model.startsWith("gemini-3") -> JSONObject().put("thinkingLevel", "low")
        else -> null
    }

    private fun textContent(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun parseAnswer(body: String): VisionAi.Result {
        val root = try {
            JSONObject(body)
        } catch (e: JSONException) {
            return VisionAi.Result.Failure("Gemini sent an answer I couldn't read.")
        }
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val blocked = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return VisionAi.Result.Failure(
                if (blocked.isNotEmpty()) "Gemini declined to answer this ($blocked)." else "Gemini returned no answer.",
            )
        }
        val first = candidates.getJSONObject(0)
        val parts = first.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.optBoolean("thought")) continue
                sb.append(part.optString("text"))
            }
        }
        val answer = sb.toString().trim()
        val finish = first.optString("finishReason")
        if (answer.isEmpty()) {
            return VisionAi.Result.Failure(
                when (finish) {
                    "SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII" -> "Gemini declined to answer this for safety reasons."
                    "MAX_TOKENS" -> "Gemini ran out of room before answering. Try a shorter question."
                    else -> "Gemini returned an empty answer${if (finish.isNotEmpty()) " ($finish)" else ""}."
                },
            )
        }
        return VisionAi.Result.Answer(answer)
    }

    private fun errorMessage(code: Int, body: String, model: String): String {
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: JSONException) {
            ""
        }
        return when {
            code == 400 && detail.contains("API key", ignoreCase = true) -> "The Gemini API key is not valid. Check it in Settings."
            code == 400 -> "Gemini rejected the request: ${detail.ifEmpty { "bad request" }}"
            code == 401 || code == 403 -> "Gemini refused the API key. Check the key in Settings, or create a new one at aistudio.google.com."
            code == 404 -> "The Gemini model \"$model\" was not found. Choose another one in Settings with Find models."
            code == 429 -> "The free Gemini limit is used up for now. Wait a minute and ask again."
            code >= 500 -> "Gemini is busy right now. Try again in a moment."
            else -> "Gemini error $code${if (detail.isNotEmpty()) ": $detail" else ""}"
        }
    }

    private fun networkMessage(e: Exception): String = when (e) {
        is UnknownHostException -> "There's no internet connection."
        is SocketTimeoutException -> "Gemini took too long to answer. Try again."
        is IOException -> "Network problem: ${e.message ?: "connection failed"}."
        else -> "Something went wrong talking to Gemini."
    }

    private fun http(method: String, url: URL, key: String, body: String?): Pair<Int, String> {
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.setRequestProperty("x-goog-api-key", key)
            c.setRequestProperty("Accept", "application/json")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }
}
