package com.disha.glassos.skills

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.disha.glassos.ai.FreeSpeechClient
import com.disha.glassos.ai.TranscriptCleaner
import com.disha.glassos.audio.AudioFx
import com.disha.glassos.audio.Wav
import com.disha.glassos.util.AppLog
import kotlin.math.sqrt

/**
 * Lecture and meeting notes: records with the phone's microphone and has the free speech service
 * transcribe it in chunks of about 40 s (cut at a pause where possible) while recording goes on.
 * Silent chunks are not sent. The assistant pauses it while it uses the microphone itself.
 * Main-thread API; listener callbacks on the main thread.
 */
class MeetingNotes(private val stt: FreeSpeechClient, private val language: () -> String?, private val listener: Listener) {

    interface Listener {
        fun onNotesStatus(recordedSec: Int, transcribedSec: Int)
        /** All chunks transcribed after stop(); transcript may be empty. */
        fun onNotesDone(transcript: String, recordedSec: Int)
        fun onNotesError(message: String)
    }

    private companion object {
        const val TAG = "Notes"
        const val RATE = Wav.RATE
        const val FRAME = 320
        const val MIN_CHUNK_S = 30
        const val MAX_CHUNK_S = 45
        const val MAX_TOTAL_S = 3 * 3600
    }

    private class Chunk(val pcm: ShortArray, val startSec: Int)

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var recording = false
    @Volatile private var paused = false
    private var thread: Thread? = null
    private val queue = ArrayDeque<Chunk>()
    private var transcribing = false
    private val transcript = StringBuilder()
    @Volatile private var recordedSec = 0
    private var transcribedSec = 0
    private var stopping = false
    private var recorderDone = true  // the recording thread has handed over its last chunk

    val running get() = recording || stopping

    fun start() {
        if (running) return
        transcript.setLength(0)
        queue.clear()
        recordedSec = 0
        transcribedSec = 0
        recording = true
        recorderDone = false
        stopping = false
        paused = false
        val t = Thread({ record() }, "disha-notes")
        thread = t
        t.start()
        AppLog.i(TAG, "Notes started")
    }

    /** The assistant needs the microphone: hold recording (the gap is not transcribed). */
    fun pause() {
        paused = true
    }

    fun resume() {
        paused = false
    }

    /** Stops recording; onNotesDone follows once the last chunks are transcribed. */
    fun stop() {
        if (!recording) return
        recording = false  // the thread hands over its last chunk, then finishes
        stopping = true
        thread = null
    }

    @SuppressLint("MissingPermission")
    private fun record() {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 4, RATE * 2))
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            recording = false
            main.post {
                stopping = false
                recorderDone = true
                listener.onNotesError("The microphone could not be opened for notes.")
            }
            return
        }
        val effects = AudioFx.attach(rec, echo = false)
        val frame = ShortArray(FRAME)
        var chunk = ShortArray(RATE * MAX_CHUNK_S)
        var n = 0
        var loudFrames = 0
        var quietRun = 0
        var totalFrames = 0L
        var chunkStartSec = 0
        try {
            rec.startRecording()
            while (recording && recordedSec < MAX_TOTAL_S) {
                val got = rec.read(frame, 0, FRAME)
                if (got <= 0) break
                if (paused) continue
                var sum = 0.0
                for (i in 0 until got) sum += frame[i].toDouble() * frame[i]
                val rms = sqrt(sum / got)
                if (rms > 400) loudFrames++
                quietRun = if (rms < 250) quietRun + 1 else 0
                System.arraycopy(frame, 0, chunk, n, got)
                n += got
                totalFrames++
                recordedSec = (totalFrames * FRAME / RATE).toInt()
                if (totalFrames % 50 == 0L) main.post { listener.onNotesStatus(recordedSec, transcribedSec) }
                val sec = n / RATE
                // Cut at a pause after 30 s, or at 45 s whatever happens.
                if ((sec >= MIN_CHUNK_S && quietRun >= 15) || n + FRAME > chunk.size) {
                    emit(chunk, n, loudFrames, chunkStartSec)
                    chunkStartSec = recordedSec
                    chunk = ShortArray(RATE * MAX_CHUNK_S)
                    n = 0
                    loudFrames = 0
                }
            }
        } catch (e: Exception) {
            AppLog.e(TAG, "Recording failed: ${e.message}")
        } finally {
            try { rec.stop() } catch (_: IllegalStateException) {}
            AudioFx.release(effects)
            rec.release()
        }
        emit(chunk, n, loudFrames, chunkStartSec)
        recording = false
        // Posted after the last chunk, so it runs after that chunk is queued.
        main.post {
            recorderDone = true
            stopping = true
            next()
        }
    }

    private fun emit(chunk: ShortArray, n: Int, loudFrames: Int, startSec: Int) {
        if (n < RATE * 2 || loudFrames * FRAME < RATE) return  // under 1 s of speech: nothing worth sending
        val c = Chunk(chunk.copyOf(n), startSec)
        main.post {
            queue.addLast(c)
            next()
        }
    }

    private fun next() {
        if (transcribing) return
        val c = queue.removeFirstOrNull() ?: run {
            if (stopping && recorderDone) finish()
            return
        }
        transcribing = true
        stt.transcribe(Wav.fromPcm(c.pcm), language()) { r ->
            transcribing = false
            when (r) {
                is FreeSpeechClient.Result.Text -> TranscriptCleaner.clean(r.text)?.let {
                    transcript.append("[").append(c.startSec / 60).append(":").append(String.format("%02d", c.startSec % 60)).append("] ")
                        .append(it).append('\n')
                }
                is FreeSpeechClient.Result.Failure -> {
                    AppLog.w(TAG, "Chunk at ${c.startSec}s not transcribed: ${r.message}")
                    transcript.append("[").append(c.startSec / 60).append(":").append(String.format("%02d", c.startSec % 60)).append("] (not transcribed)\n")
                }
            }
            transcribedSec = c.startSec + c.pcm.size / RATE
            listener.onNotesStatus(recordedSec, transcribedSec)
            next()
        }
    }

    private fun finish() {
        if (!stopping) return
        stopping = false
        AppLog.i(TAG, "Notes finished: $recordedSec s recorded")
        listener.onNotesDone(transcript.toString().trim(), recordedSec)
    }
}
