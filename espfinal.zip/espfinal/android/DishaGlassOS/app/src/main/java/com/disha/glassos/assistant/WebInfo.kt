package com.disha.glassos.assistant

import android.os.Handler
import android.os.Looper
import android.util.Xml
import com.disha.glassos.skills.FoodText
import com.disha.glassos.util.AppLog
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * Live information from free services that need no key: weather (Open-Meteo), headlines
 * (Google News RSS), encyclopedia summaries (Wikipedia) and the approximate city of the phone's
 * internet connection (ipwho.is / ipapi.co, used only when no home city is set).
 * Requests run on a background thread; callbacks run on the main thread.
 */
class WebInfo {

    private companion object {
        const val TAG = "Web"
        const val UA = "DISHA-GLASS-OS/0.6 (personal smart-glasses assistant)"
        const val TIMEOUT_MS = 12000
    }

    class Place(val name: String, val lat: Double, val lon: Double)

    private class NotFound : IOException("not found")

    private val executor = Executors.newFixedThreadPool(3) { r -> Thread(r, "disha-web").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    // ---------------------------------------------------------------------------------------

    /** city empty = the city of the phone's internet connection. */
    fun weather(city: String, callback: (WeatherText?, String?) -> Unit) = background(callback) {
        val place = if (city.isBlank()) ipPlace() else geocode(city)
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&forecast_days=2&timezone=auto"
        val j = JSONObject(get(url))
        val cur = j.getJSONObject("current")
        val d = j.getJSONObject("daily")
        fun day(key: String, i: Int) = d.getJSONArray(key).optDouble(i, Double.NaN)
        WeatherText(
            place.name, cur.getDouble("temperature_2m"), cur.getDouble("apparent_temperature"), cur.getInt("weather_code"),
            cur.optDouble("wind_speed_10m", 0.0), day("temperature_2m_max", 0), day("temperature_2m_min", 0),
            day("precipitation_probability_max", 0).let { if (it.isNaN()) 0 else it.toInt() },
            day("temperature_2m_max", 1), day("temperature_2m_min", 1),
            day("precipitation_probability_max", 1).let { if (it.isNaN()) 0 else it.toInt() },
            d.getJSONArray("weather_code").optInt(1, 0),
        )
    }

    /** Top headlines ("Title - Source"), or headlines about a topic. lang e.g. "en-IN". */
    fun headlines(topic: String?, lang: String, callback: (List<String>?, String?) -> Unit) = background(callback) {
        val (hl, gl) = when {
            lang.startsWith("hi") -> "hi" to "IN"
            lang == "en-US" -> "en-US" to "US"
            lang == "en-GB" -> "en-GB" to "GB"
            else -> "en-IN" to "IN"
        }
        val region = "hl=$hl&gl=$gl&ceid=$gl:${hl.substringBefore('-')}"
        val url = if (topic.isNullOrBlank()) "https://news.google.com/rss?$region" else "https://news.google.com/rss/search?q=${enc(topic)}&$region"
        val titles = rssTitles(get(url)).take(8)
        if (titles.isEmpty()) throw IOException("no headlines")
        titles
    }

    /** A packaged food by barcode from Open Food Facts; result null (no error) = not in the database. */
    fun foodFacts(barcode: String, callback: (FoodText?, String?) -> Unit) = background(callback) {
        val body = try {
            get("https://world.openfoodfacts.org/api/v2/product/$barcode.json?fields=product_name,product_name_en,brands,quantity,nutriments,allergens_tags,nutriscore_grade,nova_group,categories_tags")
        } catch (e: NotFound) {
            return@background null
        }
        val j = JSONObject(body)
        if (j.optInt("status") != 1) return@background null
        val p = j.getJSONObject("product")
        val n = p.optJSONObject("nutriments") ?: JSONObject()
        fun num(k: String): Double? = if (n.has(k)) n.optDouble(k).takeIf { !it.isNaN() } else null
        val tags = p.optJSONArray("allergens_tags")
        val cats = p.optJSONArray("categories_tags")?.toString().orEmpty()
        val qty = p.optString("quantity")
        FoodText(
            p.optString("product_name_en").ifBlank { p.optString("product_name") }, p.optString("brands"), qty,
            p.optString("nutriscore_grade").takeIf { it.length == 1 }.orEmpty(), p.optInt("nova_group", 0),
            num("energy-kcal_100g"), num("sugars_100g"), num("fat_100g"), num("saturated-fat_100g"), num("salt_100g"),
            (0 until (tags?.length() ?: 0)).map { tags!!.getString(it) },
            isDrink = cats.contains("en:beverages") || Regex("(?i)\\d\\s*(ml|cl|l)\\b").containsMatchIn(qty),
        )
    }

    /** First paragraph of the best-matching Wikipedia article. */
    fun wikipedia(query: String, callback: (String?, String?) -> Unit) = background(callback) {
        val search = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&utf8=1&srsearch=${enc(query)}"))
        val hits = search.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) throw IOException("Wikipedia has no article about that")
        val title = hits.getJSONObject(0).getString("title")
        val summary = JSONObject(get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(' ', '_'))}"))
        "$title: " + summary.optString("extract").take(1500)
    }

    // ---------------------------------------------------------------------------------------

    private fun geocode(city: String): Place {
        val j = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=${enc(city)}"))
        val r = j.optJSONArray("results")?.optJSONObject(0) ?: throw IOException("I couldn't find a place called $city")
        return Place(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
    }

    private fun ipPlace(): Place {
        for (url in listOf("https://ipwho.is/", "https://ipapi.co/json/")) {
            try {
                val j = JSONObject(get(url))
                if (j.has("latitude")) return Place(j.optString("city").ifEmpty { "your area" }, j.getDouble("latitude"), j.getDouble("longitude"))
            } catch (e: Exception) {
                AppLog.w(TAG, "$url: ${e.message}")
            }
        }
        throw IOException("I couldn't work out where you are. Set your home city in Settings, or say the city")
    }

    private fun rssTitles(xml: String): List<String> {
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        val out = ArrayList<String>()
        var inItem = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                if (p.name == "item") inItem = true
                else if (inItem && p.name == "title") out.add(p.nextText().trim())
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
            }
            ev = p.next()
        }
        return out
    }

    private fun <T> background(callback: (T?, String?) -> Unit, work: () -> T) {
        executor.execute {
            var result: T? = null
            var error: String? = null
            try {
                result = work()
            } catch (e: UnknownHostException) {
                error = "There's no internet connection."
            } catch (e: SocketTimeoutException) {
                error = "The service took too long to answer."
            } catch (e: Exception) {
                AppLog.w(TAG, "${e.javaClass.simpleName}: ${e.message}")
                error = e.message ?: "The service didn't answer."
            }
            main.post { callback(result, error) }
        }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = TIMEOUT_MS
            c.readTimeout = TIMEOUT_MS
            c.setRequestProperty("User-Agent", UA)
            val code = c.responseCode
            if (code == 404) throw NotFound()
            if (code != 200) throw IOException("The service answered with error $code")
            return c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
