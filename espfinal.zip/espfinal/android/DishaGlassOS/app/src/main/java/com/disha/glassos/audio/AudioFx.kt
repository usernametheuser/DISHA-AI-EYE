package com.disha.glassos.audio

import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.NoiseSuppressor
import com.disha.glassos.util.AppLog

/**
 * The phone's own noise suppression (and echo cancelling for the earbud mic) on a recording, where
 * the phone offers them: fans, traffic and chatter get quieter, so speech is recognised better.
 */
object AudioFx {

    @Volatile var enabled = true

    fun attach(rec: AudioRecord, echo: Boolean): List<AudioEffect> {
        if (!enabled) return emptyList()
        val out = ArrayList<AudioEffect>()
        val id = rec.audioSessionId
        try {
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(id)?.let { it.enabled = true; out.add(it) }
        } catch (e: Exception) {
            AppLog.w("AudioFx", "Noise suppressor: ${e.message}")
        }
        if (echo) {
            try {
                if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(id)?.let { it.enabled = true; out.add(it) }
            } catch (e: Exception) {
                AppLog.w("AudioFx", "Echo canceller: ${e.message}")
            }
        }
        return out
    }

    fun release(effects: List<AudioEffect>) = effects.forEach {
        try { it.release() } catch (_: Exception) {}
    }
}
