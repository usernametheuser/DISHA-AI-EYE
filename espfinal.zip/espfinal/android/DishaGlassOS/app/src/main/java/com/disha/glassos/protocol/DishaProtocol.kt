package com.disha.glassos.protocol

import java.util.Locale
import java.util.zip.CRC32

/**
 * DISHA USB protocol v1.
 * Must match firmware/DISHA-CAM/src/protocol/disha_protocol.h and docs/PROTOCOL.md.
 *
 * Message = 16-byte header | payload | CRC-32 of payload. All integers little-endian.
 *   0 u8 magic 0xD1   1 u8 magic 0x5A   2 u8 version   3 u8 type
 *   4 u16 seq         6 u16 ref (seq of the request this answers, 0 if unsolicited)
 *   8 u32 payload length   12 u16 reserved   14 u16 CRC-16/CCITT-FALSE of bytes 0..13
 */
object DishaProtocol {
    const val MAGIC0 = 0xD1
    const val MAGIC1 = 0x5A
    const val VERSION = 1
    const val HEADER_LEN = 16
    const val TRAILER_LEN = 4
    const val MAX_DEVICE_PAYLOAD = 16384
    const val MAX_HOST_PAYLOAD = 512
    const val FRAME_CHUNK_HEADER_LEN = 32

    // Phone -> device
    const val HELLO = 0x01
    const val PING = 0x02
    const val GET_STATUS = 0x03
    const val CAPTURE_FRAME = 0x10
    const val START_STREAM = 0x11
    const val STOP_STREAM = 0x12
    const val SET_RESOLUTION = 0x13
    const val SET_ORIENTATION = 0x14
    const val TAKE_PHOTO = 0x20
    const val START_RECORDING = 0x21
    const val STOP_RECORDING = 0x22
    const val GET_STORAGE_STATUS = 0x23
    const val LIST_FILES = 0x24

    // Device -> phone
    const val RESULT = 0x80
    const val HELLO_ACK = 0x81
    const val PONG = 0x82
    const val STATUS = 0x83
    const val STORAGE = 0x84
    const val FILE_LIST = 0x85
    const val FRAME_CHUNK = 0x90
    const val LOG = 0xA0

    // RESULT status codes (firmware)
    const val OK = 0
    const val ERR_UNKNOWN_COMMAND = 1
    const val ERR_BAD_PAYLOAD = 2
    const val ERR_BUSY = 3
    const val ERR_CAMERA = 4
    const val ERR_ENCODE = 5
    const val ERR_UNSUPPORTED = 6
    const val ERR_NO_SESSION = 7
    const val ERR_TOO_LARGE = 8
    const val ERR_INTERNAL = 9
    const val ERR_BAD_VERSION = 10
    const val ERR_NOT_IMPLEMENTED = 11
    const val ERR_USB = 12
    const val ERR_STORAGE = 13

    // App-side only (never sent by the firmware)
    const val ERR_TIMEOUT = -1
    const val ERR_NOT_CONNECTED = -2

    const val FORMAT_JPEG = 1

    const val FLAG_FIRST = 0x01
    const val FLAG_LAST = 0x02
    const val FLAG_REQUESTED = 0x04
    const val FLAG_STREAM = 0x08

    val EMPTY = ByteArray(0)

    fun encode(type: Int, seq: Int, ref: Int = 0, payload: ByteArray = EMPTY): ByteArray {
        require(payload.size <= MAX_HOST_PAYLOAD) { "payload too large: ${payload.size}" }
        val out = ByteArray(HEADER_LEN + payload.size + TRAILER_LEN)
        out[0] = MAGIC0.toByte()
        out[1] = MAGIC1.toByte()
        out[2] = VERSION.toByte()
        out[3] = type.toByte()
        putU16(out, 4, seq)
        putU16(out, 6, ref)
        putU32(out, 8, payload.size.toLong())
        putU16(out, 12, 0)
        putU16(out, 14, crc16(out, 0, 14))
        System.arraycopy(payload, 0, out, HEADER_LEN, payload.size)
        putU32(out, HEADER_LEN + payload.size, crc32(payload, 0, payload.size))
        return out
    }

    /** CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF. "123456789" -> 0x29B1. */
    fun crc16(data: ByteArray, off: Int, len: Int): Int {
        var crc = 0xFFFF
        for (i in off until off + len) {
            crc = crc xor ((data[i].toInt() and 0xFF) shl 8)
            for (bit in 0 until 8) {
                crc = if ((crc and 0x8000) != 0) ((crc shl 1) xor 0x1021) and 0xFFFF else (crc shl 1) and 0xFFFF
            }
        }
        return crc
    }

    /** CRC-32/ISO-HDLC (zlib). "123456789" -> 0xCBF43926. */
    fun crc32(data: ByteArray, off: Int, len: Int): Long {
        val c = CRC32()
        c.update(data, off, len)
        return c.value
    }

    fun putU16(b: ByteArray, off: Int, v: Int) {
        b[off] = v.toByte()
        b[off + 1] = (v shr 8).toByte()
    }

    fun putU32(b: ByteArray, off: Int, v: Long) {
        for (i in 0 until 4) b[off + i] = (v shr (8 * i)).toByte()
    }

    fun u8(b: ByteArray, off: Int): Int = b[off].toInt() and 0xFF

    fun getU16(b: ByteArray, off: Int): Int = u8(b, off) or (u8(b, off + 1) shl 8)

    fun getU32(b: ByteArray, off: Int): Long =
        u8(b, off).toLong() or (u8(b, off + 1).toLong() shl 8) or
            (u8(b, off + 2).toLong() shl 16) or (u8(b, off + 3).toLong() shl 24)

    fun captureFramePayload(fresh: Boolean, quality: Int): ByteArray =
        byteArrayOf((if (fresh) 1 else 0).toByte(), quality.coerceIn(0, 100).toByte())

    fun startStreamPayload(fps: Int, quality: Int): ByteArray =
        byteArrayOf(fps.coerceIn(1, 15).toByte(), quality.coerceIn(0, 100).toByte())

    fun resolutionPayload(width: Int, height: Int): ByteArray =
        ByteArray(4).also {
            putU16(it, 0, width)
            putU16(it, 2, height)
        }

    fun orientationPayload(vflip: Boolean, hmirror: Boolean): ByteArray =
        byteArrayOf((if (vflip) 1 else 0).toByte(), (if (hmirror) 1 else 0).toByte())

    fun takePhotoPayload(quality: Int): ByteArray = byteArrayOf(quality.coerceIn(0, 100).toByte())

    fun startRecordingPayload(fps: Int, quality: Int): ByteArray =
        byteArrayOf(fps.coerceIn(1, 15).toByte(), quality.coerceIn(0, 100).toByte())

    fun listFilesPayload(maxFiles: Int): ByteArray = byteArrayOf(maxFiles.coerceIn(1, 40).toByte())

    fun typeName(type: Int): String = when (type) {
        HELLO -> "HELLO"
        PING -> "PING"
        GET_STATUS -> "GET_STATUS"
        CAPTURE_FRAME -> "CAPTURE_FRAME"
        START_STREAM -> "START_STREAM"
        STOP_STREAM -> "STOP_STREAM"
        SET_RESOLUTION -> "SET_RESOLUTION"
        SET_ORIENTATION -> "SET_ORIENTATION"
        TAKE_PHOTO -> "TAKE_PHOTO"
        START_RECORDING -> "START_RECORDING"
        STOP_RECORDING -> "STOP_RECORDING"
        GET_STORAGE_STATUS -> "GET_STORAGE_STATUS"
        LIST_FILES -> "LIST_FILES"
        RESULT -> "RESULT"
        HELLO_ACK -> "HELLO_ACK"
        PONG -> "PONG"
        STATUS -> "STATUS"
        STORAGE -> "STORAGE"
        FILE_LIST -> "FILE_LIST"
        FRAME_CHUNK -> "FRAME_CHUNK"
        LOG -> "LOG"
        else -> String.format(Locale.US, "0x%02X", type)
    }

    fun statusName(status: Int): String = when (status) {
        OK -> "OK"
        ERR_UNKNOWN_COMMAND -> "unknown command"
        ERR_BAD_PAYLOAD -> "bad payload"
        ERR_BUSY -> "busy"
        ERR_CAMERA -> "camera error"
        ERR_ENCODE -> "JPEG encode error"
        ERR_UNSUPPORTED -> "unsupported"
        ERR_NO_SESSION -> "no session"
        ERR_TOO_LARGE -> "too large"
        ERR_INTERNAL -> "internal error"
        ERR_BAD_VERSION -> "protocol version mismatch"
        ERR_NOT_IMPLEMENTED -> "not implemented yet"
        ERR_USB -> "USB error"
        ERR_STORAGE -> "microSD error"
        ERR_TIMEOUT -> "timeout"
        ERR_NOT_CONNECTED -> "not connected"
        else -> "status $status"
    }
}
