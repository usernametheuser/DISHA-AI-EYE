package com.disha.glassos.web

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.disha.glassos.R
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.URLDecoder
import java.security.SecureRandom
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Presentation mode: a small web server on the phone, so a laptop (or the projector's browser) on
 * the same Wi-Fi or the phone's hotspot can show the glasses' live view, Disha's conversation,
 * live captions and the slides that Disha moves on voice command. Every address carries a random
 * 6-digit code shown in the app; without it the server answers nothing. Off until the user starts
 * it; nothing leaves the local network.
 */
class PresenterServer(context: Context, private val host: Host) {

    interface Host {
        /** A typed command from the web page, handled as if spoken (main thread). */
        fun runText(text: String)
        /** A slide button on the web page (main thread). */
        fun slideFromPage(action: String)
        /** Someone started or stopped watching the live view (main thread): keep the stream running. */
        fun onViewers(count: Int)
    }

    /** Slide commands for the web page's slide viewer and the PC helper (tools/disha_presenter.ps1). */
    class SlideEvent(val id: Int, val action: String, val number: Int)

    private companion object {
        const val TAG = "Presenter"
        const val PORT = 8080
        const val BOUNDARY = "dishaframe"
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var server: ServerSocket? = null
    private var pool = Executors.newCachedThreadPool()
    private val viewers = AtomicInteger(0)
    private val slideLock = ReentrantLock()
    private val slideCond = slideLock.newCondition()
    private val slides = ArrayList<SlideEvent>()
    private var nextSlideId = 1
    private val frameLock = ReentrantLock()
    private val frameCond = frameLock.newCondition()

    /** State for the page, set by DishaCore on the main thread a few times a second. */
    @Volatile
    var stateJson: String = "{}"

    @Volatile
    private var frame: ByteArray? = null
    private var frameNo = 0L

    var code: String = ""
        private set

    val running get() = server != null

    /** Starts (or keeps) the server; returns the addresses to open on the laptop. */
    fun start(): List<String> {
        if (server == null) {
            code = (100000 + SecureRandom().nextInt(900000)).toString()
            val s = ServerSocket(PORT)
            server = s
            if (pool.isShutdown) pool = Executors.newCachedThreadPool()
            Thread({ acceptLoop(s) }, "disha-web").apply { isDaemon = true }.start()
            AppLog.i(TAG, "Presentation mode on, port $PORT")
        }
        return urls()
    }

    fun stop() {
        val s = server ?: return
        server = null
        try { s.close() } catch (_: Exception) {}
        pool.shutdownNow()
        frameLock.withLock { frameCond.signalAll() }
        slideLock.withLock { slideCond.signalAll() }
        main.post { host.onViewers(0) }
        viewers.set(0)
        AppLog.i(TAG, "Presentation mode off")
    }

    fun urls(): List<String> = addresses().map { "http://$it:$PORT/$code/" }

    /** Every camera frame (any thread). */
    fun onFrame(jpeg: ByteArray) {
        if (server == null) return
        frameLock.withLock {
            frame = jpeg
            frameNo++
            frameCond.signalAll()
        }
    }

    /** next / previous / goto / start / end / black. Returns how many slide viewers were listening recently. */
    fun slide(action: String, number: Int = 0) {
        slideLock.withLock {
            slides.add(SlideEvent(nextSlideId++, action, number))
            while (slides.size > 50) slides.removeAt(0)
            slideCond.signalAll()
        }
    }

    private fun addresses(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().map { it.hostAddress ?: "" } }
            .filter { it.isNotEmpty() && (it.startsWith("192.168.") || it.startsWith("10.") || it.startsWith("172.")) }
            .distinct()
    } catch (e: Exception) {
        emptyList()
    }

    private fun acceptLoop(s: ServerSocket) {
        while (server === s) {
            val c = try { s.accept() } catch (_: Exception) { break }
            try {
                pool.execute { serve(c) }
            } catch (_: Exception) {
                c.close()
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // HTTP (just enough: GET and small POSTs)
    // ---------------------------------------------------------------------------------------

    private fun serve(socket: Socket) {
        socket.use { sock ->
            try {
                sock.soTimeout = 30_000
                val input = sock.getInputStream()
                val requestLine = readLine(input) ?: return
                val headers = HashMap<String, String>()
                while (true) {
                    val l = readLine(input) ?: return
                    if (l.isEmpty()) break
                    headers[l.substringBefore(':').trim().lowercase()] = l.substringAfter(':').trim()
                }
                val parts = requestLine.split(' ')
                if (parts.size < 2) return
                val method = parts[0]
                val target = parts[1]
                val path = target.substringBefore('?')
                val query = target.substringAfter('?', "").split('&').filter { it.contains('=') }
                    .associate { URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8") }
                val length = headers["content-length"]?.toIntOrNull()?.coerceIn(0, 65536) ?: 0
                val body = if (length > 0) readBytes(input, length).toString(Charsets.UTF_8) else ""
                val out = BufferedOutputStream(sock.getOutputStream())
                val segs = path.trim('/').split('/')
                if (segs.isEmpty() || segs[0] != code || code.isEmpty()) {
                    respond(out, 404, "text/plain", "Not found. Open the address shown in the DISHA app (it includes a code).".toByteArray())
                    return
                }
                when (val route = segs.getOrNull(1) ?: "") {
                    "", "index.html" -> respond(out, 200, "text/html; charset=utf-8", page())
                    "state" -> respond(out, 200, "application/json", stateJson.toByteArray())
                    "frame.jpg" -> frame?.let { respond(out, 200, "image/jpeg", it) } ?: respond(out, 204, "text/plain", ByteArray(0))
                    "stream.mjpg" -> stream(out)
                    "events" -> events(out, query["after"]?.toIntOrNull() ?: 0, (query["wait"]?.toIntOrNull() ?: 25).coerceIn(0, 28))
                    "say" -> if (method == "POST" && body.isNotBlank()) {
                        val text = body.trim().take(500)
                        main.post { host.runText(text) }
                        respond(out, 200, "application/json", "{\"ok\":true}".toByteArray())
                    } else respond(out, 400, "text/plain", "POST a command".toByteArray())
                    "slide" -> if (method == "POST") {
                        val action = body.trim().lowercase()
                        if (action in setOf("next", "previous", "start", "end", "black")) {
                            main.post { host.slideFromPage(action) }
                            respond(out, 200, "application/json", "{\"ok\":true}".toByteArray())
                        } else respond(out, 400, "text/plain", "unknown action".toByteArray())
                    } else respond(out, 400, "text/plain", "POST an action".toByteArray())
                    else -> respond(out, 404, "text/plain", "No such page: $route".toByteArray())
                }
            } catch (_: SocketException) {
            } catch (e: Exception) {
                AppLog.w(TAG, "Request failed: ${e.message}")
            }
        }
    }

    private fun page(): ByteArray = appContext.resources.openRawResource(R.raw.dashboard).use { it.readBytes() }

    /** MJPEG: a new part for every new frame, until the browser goes away. */
    private fun stream(out: OutputStream) {
        val n = viewers.incrementAndGet()
        main.post { host.onViewers(n) }
        try {
            out.write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=$BOUNDARY\r\n" +
                "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
            out.flush()
            var seen = -1L
            while (server != null) {
                val jpeg = frameLock.withLock {
                    if (frameNo == seen) frameCond.await(2, TimeUnit.SECONDS)
                    val f = if (frameNo != seen) frame else null
                    seen = frameNo
                    f
                }
                if (jpeg == null) continue
                out.write("--$BOUNDARY\r\nContent-Type: image/jpeg\r\nContent-Length: ${jpeg.size}\r\n\r\n".toByteArray())
                out.write(jpeg)
                out.write("\r\n".toByteArray())
                out.flush()
            }
        } finally {
            val left = viewers.decrementAndGet().coerceAtLeast(0)
            main.post { host.onViewers(left) }
        }
    }

    /** Long poll: slide events after [after], waiting up to [waitS] seconds for one. */
    private fun events(out: OutputStream, after: Int, waitS: Int) {
        val list = slideLock.withLock {
            val end = System.currentTimeMillis() + waitS * 1000L
            while (server != null && slides.none { it.id > after } && System.currentTimeMillis() < end) {
                slideCond.await((end - System.currentTimeMillis()).coerceAtLeast(1), TimeUnit.MILLISECONDS)
            }
            slides.filter { it.id > after }
        }
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("id", e.id).put("action", e.action).put("number", e.number))
        val last = slideLock.withLock { nextSlideId - 1 }
        respond(out, 200, "application/json", JSONObject().put("events", arr).put("last", last).toString().toByteArray())
    }

    private fun respond(out: OutputStream, status: Int, type: String, body: ByteArray) {
        val reason = when (status) { 200 -> "OK"; 204 -> "No Content"; 400 -> "Bad Request"; else -> "Not Found" }
        out.write(("HTTP/1.1 $status $reason\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray())
        out.write(body)
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            if (sb.length > 8192) return null
            sb.append(b.toChar())
        }
    }

    private fun readBytes(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var got = 0
        while (got < n) {
            val r = input.read(buf, got, n - got)
            if (r < 0) break
            got += r
        }
        return buf.copyOf(got)
    }
}
