package com.disha.glassos.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import com.disha.glassos.util.AppLog
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Disha's sounds: short, soft chimes made on the phone (sine tones with smooth fades), so you
 * know what is happening without looking: listening, heard you, woke up, done, error, alert.
 */
class Earcons {

    enum class Sound(val notes: List<Pair<Double, Int>>, val volume: Float) {
        LISTEN(listOf(880.0 to 70, 1318.5 to 110), 0.30f),           // rising: "I'm listening"
        HEARD(listOf(1046.5 to 70), 0.22f),                          // one soft note: "got it"
        WAKE(listOf(659.3 to 55, 880.0 to 55, 1174.7 to 110), 0.30f),
        DONE(listOf(1046.5 to 70, 784.0 to 120), 0.22f),             // falling: conversation over
        ERROR(listOf(392.0 to 110, 293.7 to 160), 0.28f),
        ALERT(listOf(880.0 to 90, 1174.7 to 90, 880.0 to 90, 1174.7 to 160), 0.35f),
    }

    private companion object {
        const val RATE = 22050
    }

    private val tracks = HashMap<Sound, AudioTrack>()

    fun play(s: Sound) {
        try {
            val t = tracks.getOrPut(s) { build(s) }
            if (t.playState == AudioTrack.PLAYSTATE_PLAYING) t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) {
            AppLog.w("Earcons", "${s.name}: ${e.message}")
        }
    }

    fun release() {
        tracks.values.forEach { try { it.release() } catch (_: Exception) {} }
        tracks.clear()
    }

    private fun build(s: Sound): AudioTrack {
        val pcm = synth(s)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val format = AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
        val track = if (Build.VERSION.SDK_INT >= 23) {
            AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(format).setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC).build()
        } else {
            @Suppress("DEPRECATION")
            AudioTrack(attrs, format, pcm.size * 2, AudioTrack.MODE_STATIC, 0)
        }
        track.write(pcm, 0, pcm.size)
        return track
    }

    /** Each note: a sine with its octave for warmth, 6 ms fade in, exponential fade out. */
    private fun synth(s: Sound): ShortArray {
        val gap = RATE * 12 / 1000
        val total = s.notes.sumOf { RATE * it.second / 1000 + gap }
        val out = ShortArray(total)
        var pos = 0
        for ((freq, ms) in s.notes) {
            val n = RATE * ms / 1000
            for (i in 0 until n) {
                val tt = i.toDouble() / RATE
                val attack = min(1.0, i / (RATE * 0.006))
                val decay = Math.exp(-3.0 * i / n)
                val v = (sin(2 * PI * freq * tt) * 0.8 + sin(4 * PI * freq * tt) * 0.2) * attack * decay * s.volume
                out[pos + i] = (v * 32767).toInt().toShort()
            }
            pos += n + gap
        }
        return out
    }
}
