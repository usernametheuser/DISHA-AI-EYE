package com.disha.glassos.skills

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.telephony.SmsManager
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.util.AppLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Emergency SOS: an SMS with the user's location to the contact saved in Settings. Only sent after
 * the user set it up, asked for it ("Disha, help") and did not cancel within the countdown.
 */
class Sos(context: Context, private val settings: AppSettings, private val places: Places) {

    private val appContext = context.applicationContext

    val configured get() = settings.sosEnabled && settings.sosNumber.any(Char::isDigit)

    fun canSend(): Boolean = Build.VERSION.SDK_INT < 23 ||
        appContext.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** Gets the location (up to 12 s), sends the SMS, reports back what happened. Main thread. */
    fun send(test: Boolean, done: (String) -> Unit) {
        if (!canSend()) {
            done("I can't send text messages: the SMS permission is off. Allow it in Settings.")
            return
        }
        places.current(12_000) { fix ->
            val who = settings.sosSenderName.ifBlank { "Your contact" }
            val time = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            val where = if (fix != null) {
                "Location: https://maps.google.com/?q=%.6f,%.6f (within %d m, %s).".format(Locale.US, fix.lat, fix.lon, fix.accuracy.toInt(), time)
            } else {
                "Location unavailable (sent at $time)."
            }
            val battery = (appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).takeIf { it in 0..100 }?.let { " Phone battery $it%." } ?: ""
            val text = if (test) {
                "TEST from $who's DISHA smart glasses: this is only a test of the emergency message. $where"
            } else {
                "SOS: $who needs help (sent by voice from DISHA smart glasses). $where$battery"
            }
            sms(text) { ok ->
                val name = settings.sosName.ifBlank { "your emergency contact" }
                done(
                    when {
                        !ok -> "The emergency message to $name could not be sent. Please call for help another way."
                        test -> "Test message sent to $name."
                        fix == null -> "Emergency message sent to $name, but without your location."
                        else -> "Emergency message sent to $name with your location."
                    },
                )
            }
        }
    }

    private fun sms(text: String, done: (Boolean) -> Unit) {
        val action = "com.disha.glassos.SOS_SENT.${System.nanoTime()}"
        var reported = false
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (reported) return
                reported = true
                try { appContext.unregisterReceiver(this) } catch (_: Exception) {}
                done(resultCode == android.app.Activity.RESULT_OK)
            }
        }
        if (Build.VERSION.SDK_INT >= 33) appContext.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") appContext.registerReceiver(receiver, IntentFilter(action))
        val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val sent = PendingIntent.getBroadcast(appContext, 0, Intent(action).setPackage(appContext.packageName), flags)
        try {
            @Suppress("DEPRECATION")
            val sm = if (Build.VERSION.SDK_INT >= 31) appContext.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            val number = settings.sosNumber.filter { it.isDigit() || it == '+' }
            if (parts.size == 1) sm.sendTextMessage(number, null, text, sent, null)
            else sm.sendMultipartTextMessage(number, null, parts, ArrayList(parts.map { sent }), null)
            AppLog.i("SOS", "Message handed to the phone (${parts.size} part(s))")
        } catch (e: Exception) {
            AppLog.e("SOS", "Sending failed: ${e.message}")
            if (!reported) {
                reported = true
                try { appContext.unregisterReceiver(receiver) } catch (_: Exception) {}
                done(false)
            }
        }
    }
}
