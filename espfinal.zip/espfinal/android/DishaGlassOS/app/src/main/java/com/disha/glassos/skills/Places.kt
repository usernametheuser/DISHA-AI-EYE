package com.disha.glassos.skills

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.disha.glassos.util.AppLog
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Where the user is: a fresh location for SOS, and (if switched on) a sample every few minutes for
 * the daily diary, named by the phone's geocoder or OpenStreetMap (Nominatim, no key). Locations
 * stay on the phone; only coordinates are sent to look up a place name.
 */
class Places(context: Context) {

    class Fix(val lat: Double, val lon: Double, val accuracy: Float, val time: Long)

    private val appContext = context.applicationContext
    private val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-places").apply { isDaemon = true } }
    val history = EntryStore(appContext, "places", 1000)

    fun hasPermission(): Boolean = Build.VERSION.SDK_INT < 23 ||
        appContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        appContext.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** A fresh location within [timeoutMs], else the best recent one (under 30 min old), else null. Main thread. */
    @SuppressLint("MissingPermission")
    fun current(timeoutMs: Long, callback: (Fix?) -> Unit) {
        if (!hasPermission()) {
            callback(null)
            return
        }
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try { lm.isProviderEnabled(it) } catch (_: Exception) { false }
        }
        var done = false
        val listeners = ArrayList<LocationListener>()
        fun finish(l: Location?) {
            if (done) return
            done = true
            listeners.forEach { try { lm.removeUpdates(it) } catch (_: Exception) {} }
            val best = l ?: lastKnown()
            callback(best?.let { Fix(it.latitude, it.longitude, it.accuracy, it.time) })
        }
        for (p in providers) {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) = finish(location)
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            listeners.add(listener)
            try {
                lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
            } catch (e: Exception) {
                AppLog.w("Places", "$p: ${e.message}")
            }
        }
        if (providers.isEmpty()) finish(null) else main.postDelayed({ finish(null) }, timeoutMs)
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(): Location? = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
        .mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Exception) { null } }
        .filter { System.currentTimeMillis() - it.time < 30 * 60_000L }
        .maxByOrNull { it.time }

    /** For the diary: keeps this location if it is 150 m or more from the last one kept. */
    fun sample() {
        current(20_000) { fix ->
            if (fix == null) return@current
            val last = history.last()
            if (last != null) {
                val (la, lo) = last.ref.split(',').mapNotNull { it.toDoubleOrNull() }.let { if (it.size == 2) it[0] to it[1] else return@current }
                val d = FloatArray(1)
                Location.distanceBetween(la, lo, fix.lat, fix.lon, d)
                if (d[0] < 150) return@current
            }
            placeName(fix) { name -> history.add(EntryStore.Entry(fix.time, name ?: "an unnamed place", "${fix.lat},${fix.lon}")) }
        }
    }

    /** "near Rajpur Road, Dehradun". Callback on the main thread. */
    fun placeName(fix: Fix, callback: (String?) -> Unit) {
        executor.execute {
            var name: String? = null
            try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val a = Geocoder(appContext, Locale.ENGLISH).getFromLocation(fix.lat, fix.lon, 1)?.firstOrNull()
                    if (a != null) {
                        name = listOfNotNull(a.featureName?.takeIf { f -> f != a.subThoroughfare && f.any(Char::isLetter) }, a.thoroughfare, a.subLocality, a.locality)
                            .distinct().take(3).joinToString(", ").ifEmpty { null }
                    }
                }
            } catch (e: Exception) {
                AppLog.w("Places", "Geocoder: ${e.message}")
            }
            if (name == null) {
                try {
                    val c = URL("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=17&accept-language=en&lat=${fix.lat}&lon=${fix.lon}")
                        .openConnection() as HttpURLConnection
                    c.connectTimeout = 10000
                    c.readTimeout = 10000
                    c.setRequestProperty("User-Agent", "DISHA-GLASS-OS/0.9 (personal smart-glasses assistant)")
                    val j = JSONObject(c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) })
                    val a = j.optJSONObject("address")
                    name = if (a != null) {
                        listOf("amenity", "shop", "building", "road", "neighbourhood", "suburb", "city", "town", "village")
                            .mapNotNull { k -> a.optString(k).ifEmpty { null } }.distinct().take(3).joinToString(", ").ifEmpty { null }
                    } else {
                        j.optString("display_name").split(",").take(3).joinToString(",").trim().ifEmpty { null }
                    }
                } catch (e: Exception) {
                    AppLog.w("Places", "Nominatim: ${e.message}")
                }
            }
            main.post { callback(name) }
        }
    }
}
