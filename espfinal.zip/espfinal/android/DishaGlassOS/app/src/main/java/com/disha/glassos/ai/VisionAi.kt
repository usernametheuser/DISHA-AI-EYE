package com.disha.glassos.ai

/** A provider that answers a question, optionally about one camera image. Swap providers without touching the firmware. */
interface VisionAi {

    class Turn(val user: String, val assistant: String)

    sealed class Result {
        class Answer(val text: String) : Result()
        class Failure(val message: String) : Result()
    }

    val name: String

    fun isConfigured(): Boolean

    /** callback runs on the main thread. jpeg may be null for text-only questions. */
    fun ask(question: String, jpeg: ByteArray?, history: List<Turn>, systemPrompt: String, callback: (Result) -> Unit)

    /** Several pictures taken over time (oldest first) and a question about what happened. */
    fun askFrames(question: String, frames: List<ByteArray>, systemPrompt: String, callback: (Result) -> Unit)
}
