package com.disha.glassos.audio

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.disha.glassos.util.AppLog

/**
 * Decides where voice goes in and out: Bluetooth earbuds, a wired headset, or the phone itself,
 * and switches the earbuds' microphone on while the assistant listens.
 *
 * Bluetooth earbuds have two audio modes:
 *  - media (A2DP): good sound quality, but no microphone;
 *  - headset/call (SCO/HFP): microphone available, lower sound quality.
 * The assistant opens the headset link only while listening and closes it afterwards, so the
 * spoken answer plays in media quality. All methods must be called on the main thread.
 */
class AudioRouter(context: Context, private val onDevicesChanged: () -> Unit) {

    enum class Kind { BLUETOOTH, WIRED, PHONE }

    class Route(val micKind: Kind, val micName: String, val speakerKind: Kind, val speakerName: String) {
        fun describe(): String = "Mic: $micName · Speaker: $speakerName"
    }

    private companion object {
        const val TAG = "Audio"
        const val CONNECT_TIMEOUT_MS = 4000L
        const val SETTLE_MS = 600L        // headset link reported up -> wait before recording
        const val SWITCH_BACK_MS = 700L   // headset link closed -> earbuds back on media audio
    }

    private val appContext = context.applicationContext
    private val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())

    private var deviceCallback: AudioDeviceCallback? = null
    private var scoReceiver: BroadcastReceiver? = null
    private var commListener: Any? = null  // AudioManager.OnCommunicationDeviceChangedListener (API 31+)
    private var legacyScoStarted = false
    private var modeChanged = false
    private var pendingDone: ((Boolean) -> Unit)? = null
    private var timeout: Runnable? = null
    private var settling = false

    /** True while the earbud microphone is switched on. */
    var earbudMicActive = false
        private set

    fun start() {
        if (Build.VERSION.SDK_INT >= 23 && deviceCallback == null) {
            val cb = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = onDevicesChanged()
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = onDevicesChanged()
            }
            am.registerAudioDeviceCallback(cb, main)
            deviceCallback = cb
        }
    }

    fun stop() {
        finishPending(false)
        closeLink()
        if (Build.VERSION.SDK_INT >= 23) deviceCallback?.let { am.unregisterAudioDeviceCallback(it) }
        deviceCallback = null
    }

    // ---------------------------------------------------------------------------------------
    // Device discovery
    // ---------------------------------------------------------------------------------------

    private fun inputs(): Array<AudioDeviceInfo> =
        if (Build.VERSION.SDK_INT >= 23) am.getDevices(AudioManager.GET_DEVICES_INPUTS) else emptyArray()

    private fun outputs(): Array<AudioDeviceInfo> =
        if (Build.VERSION.SDK_INT >= 23) am.getDevices(AudioManager.GET_DEVICES_OUTPUTS) else emptyArray()

    private fun isBluetoothMic(type: Int) =
        type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET)

    private fun isBluetoothOut(type: Int) =
        type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            (Build.VERSION.SDK_INT >= 31 && (type == AudioDeviceInfo.TYPE_BLE_HEADSET || type == AudioDeviceInfo.TYPE_BLE_SPEAKER))

    private fun isWired(type: Int) =
        type == AudioDeviceInfo.TYPE_WIRED_HEADSET || type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            (Build.VERSION.SDK_INT >= 26 && type == AudioDeviceInfo.TYPE_USB_HEADSET)

    private fun nameOf(d: AudioDeviceInfo?, fallback: String): String {
        if (d == null || Build.VERSION.SDK_INT < 23) return fallback
        val n = d.productName?.toString()?.trim().orEmpty()
        return if (n.isEmpty() || n == Build.MODEL) fallback else n
    }

    /** Earbuds that offer a microphone (headset profile) are connected. */
    fun hasEarbudMic(): Boolean = inputs().any { isBluetoothMic(it.type) }

    /** The earbuds' microphone as an input device (to pin a recording to it), or null. */
    fun earbudMicInput(): AudioDeviceInfo? = inputs().firstOrNull { isBluetoothMic(it.type) }

    fun hasEarbuds(): Boolean = outputs().any { isBluetoothOut(it.type) } || hasEarbudMic()

    fun currentRoute(useEarbudMic: Boolean): Route {
        val outs = outputs()
        val ins = inputs()
        val btOut = outs.firstOrNull { isBluetoothOut(it.type) }
        val wiredOut = outs.firstOrNull { isWired(it.type) }
        val btMic = ins.firstOrNull { isBluetoothMic(it.type) }
        val wiredMic = ins.firstOrNull { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            (Build.VERSION.SDK_INT >= 26 && it.type == AudioDeviceInfo.TYPE_USB_HEADSET) }

        val (speakerKind, speakerName) = when {
            btOut != null -> Kind.BLUETOOTH to nameOf(btOut, "Bluetooth earbuds")
            wiredOut != null -> Kind.WIRED to nameOf(wiredOut, "Wired headset")
            else -> Kind.PHONE to "Phone speaker"
        }
        val (micKind, micName) = when {
            useEarbudMic && btMic != null -> Kind.BLUETOOTH to nameOf(btMic, nameOf(btOut, "Bluetooth earbuds")) + " mic"
            wiredMic != null -> Kind.WIRED to nameOf(wiredMic, "Wired headset") + " mic"
            btOut != null && btMic == null -> Kind.PHONE to "Phone mic (earbuds have no mic profile on)"
            else -> Kind.PHONE to "Phone mic"
        }
        return Route(micKind, micName, speakerKind, speakerName)
    }

    // ---------------------------------------------------------------------------------------
    // Earbud microphone (Bluetooth headset link)
    // ---------------------------------------------------------------------------------------

    /**
     * Switches the earbuds to headset mode so their microphone can be used.
     * done(true) once the microphone is ready; done(false) if there is no earbud microphone or
     * it did not come up within 4 s (the caller then uses the phone microphone).
     */
    fun acquireEarbudMic(done: (Boolean) -> Unit) {
        if (earbudMicActive) {
            done(true)
            return
        }
        finishPending(false)
        pendingDone = done
        val t = Runnable {
            AppLog.w(TAG, "Earbud mic did not connect within ${CONNECT_TIMEOUT_MS / 1000} s; using the phone mic")
            closeLink()
            finishPending(false)
        }
        timeout = t
        main.postDelayed(t, CONNECT_TIMEOUT_MS)
        try {
            if (am.mode != AudioManager.MODE_IN_COMMUNICATION) {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                modeChanged = true
            }
            if (Build.VERSION.SDK_INT >= 31) acquireModern() else acquireLegacy()
        } catch (e: Exception) {
            AppLog.e(TAG, "Could not switch on the earbud mic: ${e.message}")
            closeLink()
            finishPending(false)
        }
    }

    @TargetApi(31)
    private fun acquireModern() {
        val dev = am.availableCommunicationDevices.firstOrNull { isBluetoothMic(it.type) }
        if (dev == null) {
            AppLog.w(TAG, "No earbud microphone available for voice")
            closeLink()
            finishPending(false)
            return
        }
        val listener = AudioManager.OnCommunicationDeviceChangedListener { d ->
            if (d != null && d.id == dev.id) settled()
        }
        am.addOnCommunicationDeviceChangedListener(appContext.mainExecutor, listener)
        commListener = listener
        if (!am.setCommunicationDevice(dev)) {
            AppLog.w(TAG, "The phone refused to route voice to ${nameOf(dev, "the earbuds")}")
            closeLink()
            finishPending(false)
            return
        }
        if (am.communicationDevice?.id == dev.id) settled()
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")  // system broadcast, only used below Android 12
    @Suppress("DEPRECATION")
    private fun acquireLegacy() {
        if (!hasEarbudMic() && Build.VERSION.SDK_INT >= 23) {
            closeLink()
            finishPending(false)
            return
        }
        if (!am.isBluetoothScoAvailableOffCall) {
            AppLog.w(TAG, "This phone does not support Bluetooth headset audio outside calls")
            closeLink()
            finishPending(false)
            return
        }
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (isInitialStickyBroadcast) return
                when (i.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1)) {
                    AudioManager.SCO_AUDIO_STATE_CONNECTED -> {
                        am.isBluetoothScoOn = true
                        settled()
                    }
                    AudioManager.SCO_AUDIO_STATE_ERROR -> {
                        closeLink()
                        finishPending(false)
                    }
                }
            }
        }
        appContext.registerReceiver(r, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED))
        scoReceiver = r
        legacyScoStarted = true
        am.startBluetoothSco()
    }

    private fun settled() {
        if (settling || pendingDone == null) return
        settling = true
        main.postDelayed({
            settling = false
            if (pendingDone != null) {
                earbudMicActive = true
                AppLog.i(TAG, "Earbud mic on")
                finishPending(true)
            }
        }, SETTLE_MS)
    }

    /** Switches the earbuds back to media audio. done() runs once they have had time to switch. */
    fun releaseEarbudMic(done: () -> Unit) {
        val wasUsed = earbudMicActive || pendingDone != null || commListener != null || legacyScoStarted
        finishPending(false)
        closeLink()
        if (wasUsed) main.postDelayed(done, SWITCH_BACK_MS) else done()
    }

    @Suppress("DEPRECATION")
    private fun closeLink() {
        timeout?.let { main.removeCallbacks(it) }
        timeout = null
        settling = false
        if (Build.VERSION.SDK_INT >= 31) {
            if (commListener != null) {
                (commListener as? AudioManager.OnCommunicationDeviceChangedListener)?.let {
                    am.removeOnCommunicationDeviceChangedListener(it)
                }
                commListener = null
                am.clearCommunicationDevice()
            }
        } else {
            scoReceiver?.let {
                try {
                    appContext.unregisterReceiver(it)
                } catch (_: IllegalArgumentException) {
                }
            }
            scoReceiver = null
            if (legacyScoStarted) {
                am.isBluetoothScoOn = false
                am.stopBluetoothSco()
                legacyScoStarted = false
            }
        }
        if (modeChanged) {
            am.mode = AudioManager.MODE_NORMAL
            modeChanged = false
        }
        if (earbudMicActive) AppLog.i(TAG, "Earbud mic off")
        earbudMicActive = false
    }

    private fun finishPending(ok: Boolean) {
        val d = pendingDone ?: return
        pendingDone = null
        timeout?.let { main.removeCallbacks(it) }
        timeout = null
        d(ok)
    }
}
