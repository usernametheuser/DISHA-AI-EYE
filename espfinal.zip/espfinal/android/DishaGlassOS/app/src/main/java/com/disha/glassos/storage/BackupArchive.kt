package com.disha.glassos.storage

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * The backup file: a zip holding manifest.json, settings.json, memory.json, reminders.json,
 * wake/phrase_<g>_<n>.wav and stores/<name>.json. Reading keeps only those names, within size
 * limits, so a damaged or foreign zip cannot write anywhere else in the app's storage; names a
 * later version adds are skipped, so old apps still read newer backups. Pure logic.
 */
object BackupArchive {
    /** Raise when the meaning of a file changes; readers must keep understanding older numbers. */
    const val FORMAT = 1
    const val MANIFEST = "manifest.json"
    const val SETTINGS = "settings.json"
    const val MEMORY = "memory.json"
    const val REMINDERS = "reminders.json"

    /** The JSON note stores in the app's files folder (see EntryStore). */
    val STORES = listOf("gallery", "visual_memory", "documents", "events", "places")

    /**
     * Settings never put in a backup: the API key (a secret), the user's consents (asked again
     * after a restore, so pictures and voice are sent only with consent given on the phone in use)
     * and working state.
     */
    val PRIVATE_SETTINGS = setOf(
        "geminiKey", "boostKey", "boostConsent", "aiImageConsent", "aiImageConsentFree", "voiceConsent", "voiceConsentAsked", "notesAllowed",
        "wakeEnrolling", "wakeVersion", "lastBackupAt", "lastBackupWhere",
    )

    private const val MAX_FILE = 8 * 1024 * 1024
    private const val MAX_TOTAL = 64 * 1024 * 1024
    private const val MAX_FILES = 300
    private val WAKE = Regex("^wake/(phrase_\\d{1,2}_\\d{1,3}|sample_\\d{1,3})\\.wav$")
    private val STORE = Regex("^stores/([a-z_]+)\\.json$")

    fun allowed(name: String): Boolean =
        name == MANIFEST || name == SETTINGS || name == MEMORY || name == REMINDERS || WAKE.matches(name) ||
            STORE.find(name)?.groupValues?.get(1) in STORES

    /** A 16-bit WAV as the app writes them, with at least a little sound in it. */
    fun isWav(b: ByteArray): Boolean =
        b.size > 44 + 1600 && String(b, 0, 4, Charsets.US_ASCII) == "RIFF" && String(b, 8, 4, Charsets.US_ASCII) == "WAVE"

    fun write(out: OutputStream, files: Map<String, ByteArray>) {
        val zip = ZipOutputStream(out)
        for ((name, data) in files) {
            require(allowed(name)) { "not a backup file name: $name" }
            zip.putNextEntry(ZipEntry(name))
            zip.write(data)
            zip.closeEntry()
        }
        zip.finish()  // the caller closes [out]
    }

    /** The backup's files by name. Throws IOException with a readable reason if it is not a DISHA backup. */
    fun read(input: InputStream): Map<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        var total = 0L
        val zip = ZipInputStream(input)
        val chunk = ByteArray(16 * 1024)
        while (true) {
            val e = try {
                zip.nextEntry
            } catch (ex: Exception) {
                throw IOException("The file is damaged or not a DISHA backup.")
            } ?: break
            if (e.isDirectory || !allowed(e.name)) continue
            if (files.size >= MAX_FILES) throw IOException("The backup has too many files.")
            val buf = ByteArrayOutputStream()
            while (true) {
                val n = zip.read(chunk)
                if (n < 0) break
                buf.write(chunk, 0, n)
                total += n
                if (buf.size() > MAX_FILE || total > MAX_TOTAL) throw IOException("The backup is larger than a DISHA backup can be.")
            }
            files[e.name] = buf.toByteArray()
        }
        if (MANIFEST !in files) throw IOException("This is not a DISHA backup (it has no manifest.json).")
        return files
    }
}
