package com.disha.glassos.skills

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.disha.glassos.util.AppLog
import java.io.File
import java.io.FileOutputStream

/**
 * Smart gallery: every photo saved on the phone gets a one-sentence AI caption and a small
 * thumbnail, kept on the phone, so photos can be found by what is in them ("the whiteboard
 * photos from today").
 */
class Gallery(context: Context) {

    private val appContext = context.applicationContext
    val store = EntryStore(appContext, "gallery", 2000)
    private val thumbs = File(appContext.filesDir, "gallery_thumbs").apply { mkdirs() }

    /** where: as returned by MediaSaver ("Pictures/DISHA/name.jpg" or a file path). */
    fun add(jpeg: ByteArray, where: String, caption: String, place: String) {
        val time = System.currentTimeMillis()
        val thumbName = "$time.jpg"
        try {
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, opts)
            if (bmp != null) {
                FileOutputStream(File(thumbs, thumbName)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 75, it) }
                bmp.recycle()
            }
        } catch (e: Exception) {
            AppLog.w("Gallery", "Thumbnail failed: ${e.message}")
        }
        store.add(EntryStore.Entry(time, caption, where, place.ifEmpty { "" } + "|" + thumbName))
    }

    fun thumbnail(e: EntryStore.Entry): File? = e.extra.substringAfter('|', "").takeIf { it.isNotEmpty() }?.let { File(thumbs, it) }

    fun place(e: EntryStore.Entry): String = e.extra.substringBefore('|')

    fun search(query: String, range: TimeRange?, limit: Int = 30): List<EntryStore.Entry> {
        val all = store.all()
        val byTime = all.associateBy { it.time }
        return TextSearch.search(all.map { TextSearch.Item(it.time, it.text + " " + place(it)) }, query, range, limit)
            .mapNotNull { byTime[it.time] }
    }

    /** Opens the full photo in the phone's viewer, if it can still be found. */
    fun viewIntent(e: EntryStore.Entry): Intent? {
        val name = e.ref.substringAfterLast('/')
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 29 && !e.ref.startsWith("/")) {
            appContext.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.Images.Media.DISPLAY_NAME}=?", arrayOf(name), null,
            )?.use { c -> if (c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)) else null }
        } else {
            null
        }
        if (uri == null) return null
        return Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

/** "Where did I leave my keys?": what the camera saw every few minutes, as short captions. */
class VisualMemory(context: Context) {
    val store = EntryStore(context, "visual_memory", 3000)

    fun add(caption: String, place: String) = store.add(EntryStore.Entry(System.currentTimeMillis(), caption, "", place))

    fun search(query: String, range: TimeRange?, limit: Int = 8): List<TextSearch.Item> = TextSearch.search(store.items(), query, range, limit)
}
