package com.disha.glassos.audio

import android.annotation.SuppressLint
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.disha.glassos.audio.SpeechDetector.Result
import com.disha.glassos.util.AppLog
import java.io.ByteArrayOutputStream
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Records one spoken request with AudioRecord; [SpeechDetector] finds where it starts and ends.
 * Unlike Android's SpeechRecognizer this needs no speech service on the phone, and it records from
 * the earbud mic while the headset link is open. Output: 16 kHz mono 16-bit WAV of the speech plus
 * a little margin. start/finishNow/cancel on the main thread; listener callbacks on the main thread.
 */
class VoiceRecorder(private val listener: Listener) {

    interface Listener {
        fun onLevel(level: Int)  // 0..100
        fun onSpeechStarted()
        fun onRecorded(wav: ByteArray, speechMs: Int)
        fun onNoSpeech()
        fun onRecordError(message: String)
    }

    private companion object {
        const val TAG = "Rec"
        const val RATE = 16000
        const val FRAME = RATE * SpeechDetector.FRAME_MS / 1000  // 320 samples
        const val PRE_ROLL_MS = 400
        const val POST_ROLL_MS = 300
    }

    /** One recording. Flags are set on the main thread and read by the recording thread. */
    private class Session {
        @Volatile var cancelled = false
        @Volatile var finish = false
        var thread: Thread? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var session: Session? = null

    val isRecording get() = session != null

    /**
     * Starts recording. fromEarbuds selects the voice-call source, which follows the open headset
     * link; device (API 23+) pins the recording to that microphone.
     */
    fun start(
        fromEarbuds: Boolean,
        device: AudioDeviceInfo?,
        waitForSpeechMs: Int,
        endSilenceMs: Int = SpeechDetector.END_SILENCE_MS,
        maxSpeechMs: Int = SpeechDetector.MAX_SPEECH_MS,
    ) {
        cancel()
        val s = Session()
        session = s
        val t = Thread({ record(s, fromEarbuds, device, waitForSpeechMs, endSilenceMs, maxSpeechMs) }, "disha-voice")
        s.thread = t
        t.start()
    }

    /** Stop now and use what was said so far (mic tapped while listening). */
    fun finishNow() {
        session?.finish = true
    }

    /** Stop without a result. */
    fun cancel() {
        val s = session ?: return
        session = null
        s.cancelled = true
        s.thread?.join(300)  // let it release the microphone before another recording opens it
    }

    /** Runs r on the main thread if s is still the current recording, which then ends. */
    private fun deliver(s: Session, r: () -> Unit) {
        main.post {
            if (session === s && !s.cancelled) {
                session = null
                r()
            }
        }
    }

    @SuppressLint("MissingPermission")  // the caller checks RECORD_AUDIO before listening
    private fun record(s: Session, fromEarbuds: Boolean, device: AudioDeviceInfo?, waitForSpeechMs: Int, endSilenceMs: Int, maxSpeechMs: Int) {
        val source = if (fromEarbuds) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(source, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, RATE))
        } catch (e: Exception) {
            AppLog.e(TAG, "AudioRecord: ${e.message}")
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            deliver(s) { listener.onRecordError("The microphone could not be opened. Another app may be using it.") }
            return
        }
        if (device != null && Build.VERSION.SDK_INT >= 23) rec.preferredDevice = device
        val effects = AudioFx.attach(rec, echo = fromEarbuds)
        val detector = SpeechDetector(waitForSpeechMs, endSilenceMs, maxSpeechMs)
        val pcm = ByteArrayOutputStream(RATE * 2 * 8)
        val frame = ShortArray(FRAME)
        val bytes = ByteArray(FRAME * 2)
        var lastLevelPost = 0L
        var result = Result.WAITING
        var failed = false
        try {
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) failed = true
            while (!s.cancelled && !failed && result != Result.ENDED && result != Result.NO_SPEECH) {
                var got = 0
                while (got < FRAME && !s.cancelled) {
                    val n = rec.read(frame, got, FRAME - got)
                    if (n <= 0) {
                        failed = true
                        break
                    }
                    got += n
                }
                if (failed || s.cancelled) break
                var sum = 0.0
                for (i in 0 until FRAME) {
                    val v = frame[i].toInt()
                    sum += (v * v).toDouble()
                    bytes[2 * i] = (v and 0xFF).toByte()
                    bytes[2 * i + 1] = (v shr 8 and 0xFF).toByte()
                }
                pcm.write(bytes, 0, bytes.size)
                val rms = sqrt(sum / FRAME)
                result = detector.feed(rms, s.finish)
                if (result == Result.STARTED) main.post { if (session === s) listener.onSpeechStarted() }
                val now = System.currentTimeMillis()
                if (now - lastLevelPost >= 80) {
                    lastLevelPost = now
                    val db = if (rms < 1) -90.0 else 20 * log10(rms / 32768.0)
                    val level = ((db + 60) * 2).toInt().coerceIn(0, 100)
                    main.post { if (session === s) listener.onLevel(level) }
                }
            }
        } catch (e: Exception) {
            AppLog.e(TAG, "Recording failed: ${e.message}")
            failed = true
        } finally {
            try {
                rec.stop()
            } catch (_: IllegalStateException) {
            }
            AudioFx.release(effects)
            rec.release()
        }
        if (s.cancelled) return
        when {
            failed -> deliver(s) { listener.onRecordError("The microphone stopped working. Try again.") }
            result != Result.ENDED || !detector.enoughSpeech -> deliver(s) { listener.onNoSpeech() }
            else -> {
                val all = pcm.toByteArray()
                val bytesPerMs = RATE / 1000 * 2
                val startMs = (detector.speechStartFrame - 1) * SpeechDetector.FRAME_MS
                val endMs = detector.lastVoiceFrame * SpeechDetector.FRAME_MS
                val from = maxOf(0, startMs - PRE_ROLL_MS) * bytesPerMs
                val to = minOf(all.size, (endMs + POST_ROLL_MS) * bytesPerMs)
                val wav = wav(all, from, maxOf(from, to))
                val speechMs = detector.speechMs
                AppLog.i(TAG, "Recorded $speechMs ms of speech (${wav.size / 1024} KB, background level ${detector.noise.toInt()})")
                deliver(s) { listener.onRecorded(wav, speechMs) }
            }
        }
    }

    private fun wav(pcm: ByteArray, from: Int, to: Int): ByteArray {
        val len = (to - from) and 1.inv()
        val out = ByteArray(44 + len)
        fun str(o: Int, v: String) = v.forEachIndexed { i, c -> out[o + i] = c.code.toByte() }
        fun le32(o: Int, v: Int) { for (i in 0 until 4) out[o + i] = (v shr (8 * i) and 0xFF).toByte() }
        fun le16(o: Int, v: Int) { out[o] = (v and 0xFF).toByte(); out[o + 1] = (v shr 8 and 0xFF).toByte() }
        str(0, "RIFF"); le32(4, 36 + len); str(8, "WAVE")
        str(12, "fmt "); le32(16, 16); le16(20, 1); le16(22, 1); le32(24, RATE); le32(28, RATE * 2); le16(32, 2); le16(34, 16)
        str(36, "data"); le32(40, len)
        System.arraycopy(pcm, from, out, 44, len)
        return out
    }
}
