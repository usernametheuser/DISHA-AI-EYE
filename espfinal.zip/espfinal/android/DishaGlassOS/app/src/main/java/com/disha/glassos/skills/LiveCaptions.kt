package com.disha.glassos.skills

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.disha.glassos.ai.FreeSpeechClient
import com.disha.glassos.ai.TranscriptCleaner
import com.disha.glassos.audio.AudioFx
import com.disha.glassos.audio.SpeechSegmenter
import com.disha.glassos.audio.Wav
import com.disha.glassos.util.AppLog

/** What live captions show: on the phone (CaptionsActivity) and in the web view. Main thread only. */
object CaptionBoard {

    class Line(val time: Long, val text: String, val translation: String?, val language: String?)

    private val lines = ArrayList<Line>()
    private val listeners = LinkedHashSet<() -> Unit>()

    /** "" when off; otherwise "Live captions" or "Translator: English and Hindi". */
    var mode = ""
        private set

    fun setMode(m: String) {
        mode = m
        changed()
    }

    fun add(line: Line) {
        lines.add(line)
        while (lines.size > 40) lines.removeAt(0)
        changed()
    }

    fun clear() {
        lines.clear()
        changed()
    }

    fun snapshot(): List<Line> = lines.toList()

    fun listen(l: () -> Unit) { listeners.add(l) }

    fun unlisten(l: () -> Unit) { listeners.remove(l) }

    private fun changed() = listeners.toList().forEach { it() }
}

/**
 * Live captions and the two-way translator. While running, the phone's microphone is cut into
 * sentences on the phone; each one goes to the speech service (with a boost key, almost live; on
 * the free service several sentences are sent together, so captions lag a little). In translator
 * mode each sentence is translated into the other language and spoken. Everything said near the
 * phone is sent, so the user is told to let people know. Main thread API.
 */
class LiveCaptions(private val stt: FreeSpeechClient, private val listener: Listener) {

    interface Listener {
        /** Translate [text] into [toLanguage] (ISO code); done(null) if it couldn't. */
        fun translate(text: String, toLanguage: String, done: (String?) -> Unit)
        /** A sentence was understood (after translation, if any). */
        fun onCaption(line: CaptionBoard.Line)
        fun onCaptionsError(message: String)
    }

    private companion object {
        const val TAG = "Captions"
        const val MAX_BATCH_SAMPLES = Wav.RATE * 25
    }

    private class Session {
        @Volatile var stop = false
        var thread: Thread? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var session: Session? = null
    private val queue = ArrayList<ShortArray>()  // main thread
    private var busy = false
    private var failures = 0

    var translator = false
        private set
    var mine = "en"
        private set
    var other = "hi"
        private set

    /** Set while the assistant speaks (its own voice is not captioned) or listens. */
    @Volatile
    var muted = false

    var running = false
        private set
    private var generation = 0

    fun start(translate: Boolean, myLanguage: String, otherLanguage: String) {
        stop()
        translator = translate
        mine = myLanguage
        other = otherLanguage
        failures = 0
        running = true
        generation++
        openMic()
        AppLog.i(TAG, if (translate) "Translator $mine <-> $other on" else "Live captions on")
    }

    fun stop() {
        if (!running) return
        running = false
        generation++
        closeMic()
        queue.clear()
        AppLog.i(TAG, "Off")
    }

    /** The assistant needs the microphone (it is listening to a request): let go of it for now. */
    fun pauseMic() = closeMic()

    fun resumeMic() {
        if (running && session == null) openMic()
    }

    private fun openMic() {
        val s = Session()
        session = s
        val t = Thread({ loop(s) }, "disha-captions")
        s.thread = t
        t.start()
    }

    private fun closeMic() {
        val s = session ?: return
        session = null
        s.stop = true
        s.thread?.join(400)
    }

    @SuppressLint("MissingPermission")  // started only with RECORD_AUDIO granted
    private fun loop(s: Session) {
        val minBuf = AudioRecord.getMinBufferSize(Wav.RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, Wav.RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, Wav.RATE))
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            main.post { if (session === s) listener.onCaptionsError("I couldn't open the microphone for captions.") }
            return
        }
        val fx = AudioFx.attach(rec, echo = false)
        val seg = SpeechSegmenter(endSilenceMs = 600, maxSpeechMs = 8000)
        val frame = ShortArray(SpeechSegmenter.FRAME)
        var wasMuted = false
        try {
            rec.startRecording()
            while (!s.stop) {
                var got = 0
                while (got < frame.size && !s.stop) {
                    val n = rec.read(frame, got, frame.size - got)
                    if (n <= 0) return
                    got += n
                }
                if (muted) {
                    wasMuted = true
                    continue
                }
                if (wasMuted) {
                    wasMuted = false
                    seg.reset()
                }
                val piece = seg.feed(frame) ?: continue
                main.post { if (session === s && running) enqueue(piece.pcm) }
            }
        } catch (e: Exception) {
            AppLog.e(TAG, "Listening failed: ${e.message}")
        } finally {
            try { rec.stop() } catch (_: IllegalStateException) {}
            AudioFx.release(fx)
            rec.release()
        }
    }

    private fun enqueue(pcm: ShortArray) {
        queue.add(pcm)
        pump()
    }

    /** One request at a time; sentences that arrive meanwhile go together in the next one. */
    private fun pump() {
        if (busy || queue.isEmpty() || !running) return
        var total = 0
        val take = ArrayList<ShortArray>()
        while (queue.isNotEmpty() && total + queue[0].size <= MAX_BATCH_SAMPLES) {
            total += queue[0].size
            take.add(queue.removeAt(0))
        }
        if (take.isEmpty()) take.add(queue.removeAt(0))
        val gap = Wav.RATE * 3 / 10
        val joined = ShortArray(take.sumOf { it.size } + gap * (take.size - 1))
        var at = 0
        for ((i, p) in take.withIndex()) {
            if (i > 0) at += gap
            p.copyInto(joined, at)
            at += p.size
        }
        busy = true
        val gen = generation
        stt.transcribe(Wav.fromPcm(joined), null, withLanguage = true) { r ->
            busy = false
            if (gen != generation) return@transcribe
            when (r) {
                is FreeSpeechClient.Result.Text -> {
                    failures = 0
                    val text = TranscriptCleaner.clean(r.text)
                    if (text != null) deliver(text, r.language ?: guessLanguage(text))
                }
                is FreeSpeechClient.Result.Failure -> {
                    AppLog.w(TAG, r.message)
                    if (++failures == 3) listener.onCaptionsError(r.message)
                }
            }
            pump()
        }
    }

    private fun deliver(text: String, language: String?) {
        if (!translator) {
            listener.onCaption(CaptionBoard.Line(System.currentTimeMillis(), text, null, language))
            return
        }
        val target = if (language == mine) other else mine
        if (language == target) {  // already in the target language (for example a mixed sentence)
            listener.onCaption(CaptionBoard.Line(System.currentTimeMillis(), text, null, language))
            return
        }
        listener.translate(text, target) { t ->
            listener.onCaption(CaptionBoard.Line(System.currentTimeMillis(), text, t, language))
        }
    }

    /** Script-based guess when the service doesn't say: Devanagari = Hindi, Latin = English. */
    private fun guessLanguage(text: String): String? = when {
        text.any { it in 'ऀ'..'ॿ' } -> "hi"
        text.any { it in 'A'..'z' } -> "en"
        else -> null
    }
}
