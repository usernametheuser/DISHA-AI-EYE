package com.disha.glassos.ai

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * The assistant's thinking model: OpenAI-compatible chat/completions with tool calling.
 * Free (default): OVHcloud AI Endpoints with no key, walking text models that handled tools
 * correctly in tests and skipping busy ones. Gemini: Google's OpenAI-compatible endpoint with the
 * user's key. Callbacks run on the main thread.
 */
class BrainClient(private val settings: AppSettings) {

    class ToolCall(val id: String, val name: String, val args: JSONObject)

    sealed class Reply {
        class Message(val text: String, val calls: List<ToolCall>, val model: String) : Reply()
        class Failure(val message: String) : Reply()
    }

    private companion object {
        const val TAG = "Brain"
        const val OVH = "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1"
        const val GEMINI = "https://generativelanguage.googleapis.com/v1beta/openai"
        const val CONNECT_TIMEOUT_MS = 15000
        const val READ_TIMEOUT_MS = 40000
        const val MAX_WAIT_MS = 15000L
        const val BUSY_DEFAULT_MS = 60000L
        const val ERROR_COOLDOWN_MS = 30000L
        const val GONE_COOLDOWN_MS = 10 * 60000L

        /**
         * Tested 2026-10-10 without a key: all call tools correctly and answer well. Qwen3.8 was the
         * quickest and best spoken (about 2.4 s). Llama 3.3 and Mistral Nemo were left out: they
         * called tools nobody asked for.
         */
        val FREE_MODELS = listOf(
            "Qwen3.8-27B",
            "Mistral-Small-3.2-24B-Instruct-2506",
            "gpt-oss-120b",
            "Qwen3.6-27B",
            "gpt-oss-20b",
        )

        /**
         * Models that see a picture and use tools in the same answer (tested 2026-10-10: shown a red
         * ball labelled 4521, all three photographed it and remembered the number).
         */
        val FREE_VISION_MODELS = listOf("Qwen3.8-27B", "Mistral-Small-3.2-24B-Instruct-2506", "Qwen3.6-27B")
    }

    private sealed class Outcome {
        class Done(val reply: Reply.Message) : Outcome()
        class Skip(val reason: String, val coolMs: Long) : Outcome()
        class Stop(val message: String) : Outcome()
    }

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-brain").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    private val coolUntil = HashMap<String, Long>()  // executor thread only

    val usesGemini get() = settings.aiProvider == AppSettings.AiProvider.GEMINI

    fun isConfigured() = !usesGemini || settings.geminiKey.isNotBlank()

    /**
     * messages: OpenAI chat messages (system first). tools: OpenAI tool definitions.
     * withImage: the messages contain a camera picture, so only models that can see are used.
     */
    fun chat(messages: JSONArray, tools: JSONArray, withImage: Boolean, callback: (Reply) -> Unit) {
        val gemini = usesGemini
        val key = settings.geminiKey
        val models = when {
            gemini -> listOf(settings.geminiModel)
            withImage -> FREE_VISION_MODELS
            else -> FREE_MODELS
        }
        val boost = Boost.endpoint(settings)
        executor.execute {
            val result = boost?.let { tryBoost(it, messages, tools, withImage) }
                ?: walk(if (gemini) GEMINI else OVH, if (gemini) key else null, models, messages, tools)
            main.post { callback(result) }
        }
    }

    /** Only the boost service (the user's key); null result = it couldn't answer. For pictures asked without tools. */
    fun boostOnly(messages: JSONArray, withImage: Boolean, callback: (Reply?) -> Unit) {
        val boost = Boost.endpoint(settings)
        if (boost == null) {
            callback(null)
            return
        }
        executor.execute {
            val r = tryBoost(boost, messages, JSONArray(), withImage)
            main.post { callback(r) }
        }
    }

    /** The user's key service, once; null if it failed (the free services then answer). */
    private fun tryBoost(b: Boost.Endpoint, messages: JSONArray, tools: JSONArray, withImage: Boolean): Reply.Message? {
        val model = if (withImage) b.visionModel else b.textModel
        if (model.isBlank() || remainingMs("boost:$model") > 0) return null
        return when (val o = ask(b.base, b.key, model, messages, tools, coolKey = "boost:$model")) {
            is Outcome.Done -> o.reply
            is Outcome.Skip -> {
                AppLog.w(TAG, "${b.label} ($model): ${o.reason}; using the free models")
                if (o.coolMs > 0) coolUntil["boost:$model"] = SystemClock.elapsedRealtime() + o.coolMs
                null
            }
            is Outcome.Stop -> {
                AppLog.w(TAG, "${b.label}: ${o.message}")
                if (o.message.contains("refused")) coolUntil["boost:$model"] = SystemClock.elapsedRealtime() + GONE_COOLDOWN_MS
                null
            }
        }
    }

    private fun walk(base: String, key: String?, models: List<String>, messages: JSONArray, tools: JSONArray): Reply {
        val tried = LinkedHashMap<String, String>()
        for (round in 0 until 2) {
            if (round > 0) {
                val wait = models.minOf { remainingMs(it) }
                if (wait > MAX_WAIT_MS) break
                AppLog.i(TAG, "All thinking models busy; waiting ${wait / 1000} s")
                SystemClock.sleep(wait + 300)
            }
            for (model in models) {
                if (remainingMs(model) > 0) {
                    tried.putIfAbsent(model, "busy")
                    continue
                }
                when (val o = ask(base, key, model, messages, tools)) {
                    is Outcome.Done -> return o.reply
                    is Outcome.Stop -> return Reply.Failure(o.message)
                    is Outcome.Skip -> {
                        tried[model] = o.reason
                        if (o.coolMs > 0) coolUntil[model] = SystemClock.elapsedRealtime() + o.coolMs
                    }
                }
            }
            if (key != null) break  // Gemini: one model, no waiting game
            if (round == 0 && models.all { remainingMs(it) > 0 }) AppLog.i(TAG, "Free models busy; a free Groq key in Settings avoids these waits")
        }
        AppLog.w(TAG, "No thinking model answered: " + tried.entries.joinToString("; ") { "${it.key}: ${it.value}" })
        return Reply.Failure(
            when {
                tried.values.all { it == "busy" } -> "I'm getting a lot of questions at once on the free service. Give me a minute."
                key != null -> "Gemini couldn't answer: ${tried.values.firstOrNull() ?: "unknown error"}."
                tried.isEmpty() -> "I couldn't reach my thinking service just now. Try again in a moment."
                else -> "I couldn't reach my thinking service just now. Try again in a moment."
            },
        )
    }

    private fun ask(base: String, key: String?, model: String, messages: JSONArray, tools: JSONArray, coolKey: String = model): Outcome {
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", 1024)
            .put("temperature", 0.5)
        if (tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
        val started = SystemClock.elapsedRealtime()
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Accept", "application/json")
            if (key != null) c.setRequestProperty("Authorization", "Bearer $key")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            val ms = SystemClock.elapsedRealtime() - started
            fun header(name: String) = c.getHeaderField(name)?.trim()?.toLongOrNull()
            return when {
                code == 200 -> {
                    if (header("ratelimit-remaining") == 0L) {
                        coolUntil[coolKey] = SystemClock.elapsedRealtime() + (header("ratelimit-reset")?.coerceIn(1, 3600) ?: 60) * 1000
                    }
                    val reply = parse(text, model) ?: return Outcome.Skip("unreadable answer", 0)
                    if (reply.text.isEmpty() && reply.calls.isEmpty()) return Outcome.Skip("empty answer", 0)
                    AppLog.i(TAG, "$model answered in $ms ms" + if (reply.calls.isNotEmpty()) " with ${reply.calls.joinToString { it.name }}" else "")
                    Outcome.Done(reply)
                }
                code == 429 -> Outcome.Skip("busy", (header("retry-after") ?: header("ratelimit-reset"))?.coerceIn(1, 3600)?.times(1000) ?: BUSY_DEFAULT_MS)
                code == 401 || code == 403 -> if (key != null) Outcome.Stop("The AI service refused the API key. Check it in Settings.") else Outcome.Skip("needs a key", GONE_COOLDOWN_MS)
                code == 404 -> Outcome.Skip("not offered any more", GONE_COOLDOWN_MS)
                code in 400..499 -> {
                    // Usually this particular request (for example a tool-call format); the model stays usable.
                    AppLog.w(TAG, "$model: HTTP $code: ${text.take(300)}")
                    Outcome.Skip("rejected ($code)", 0)
                }
                else -> Outcome.Skip("server error $code", ERROR_COOLDOWN_MS)
            }
        } catch (e: UnknownHostException) {
            return Outcome.Stop("There's no internet connection right now.")
        } catch (e: SocketTimeoutException) {
            return Outcome.Skip("too slow", ERROR_COOLDOWN_MS)
        } catch (e: IOException) {
            AppLog.w(TAG, "$model: ${e.message}")
            return Outcome.Skip("network error", 0)
        } finally {
            c.disconnect()
        }
    }

    private fun parse(body: String, model: String): Reply.Message? = try {
        val msg = JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val content = if (msg.isNull("content")) "" else msg.optString("content")
        val calls = ArrayList<ToolCall>()
        val arr = msg.optJSONArray("tool_calls")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val tc = arr.getJSONObject(i)
                val fn = tc.optJSONObject("function") ?: continue
                val raw = fn.opt("arguments")
                val args = when (raw) {
                    is JSONObject -> raw
                    is String -> try { JSONObject(raw.ifBlank { "{}" }) } catch (_: JSONException) { JSONObject() }
                    else -> JSONObject()
                }
                calls.add(ToolCall(tc.optString("id").ifEmpty { "call_$i" }, fn.optString("name"), args))
            }
        }
        Reply.Message(content.replace(Regex("(?s)<think>.*?</think>"), "").trim(), calls, model)
    } catch (_: JSONException) {
        null
    }

    private fun remainingMs(model: String) = ((coolUntil[model] ?: 0L) - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
}
