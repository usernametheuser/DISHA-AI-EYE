package com.disha.glassos.skills

/** "reply to Rahul saying I'm on my way" -> (Rahul, I'm on my way). Pure logic, unit-tested. */
object ReplyParse {
    class Reply(val conversation: String?, val text: String)

    private val lead = Regex("(?i)^[\\s,:]*(?:(?:saying|that|with)\\s+)?")

    /**
     * names: conversations the user has messages from, to recognise "reply to <name> <text>".
     * conversation null = the latest conversation; text empty = not said yet.
     */
    fun parse(sentence: String, names: List<String>): Reply? {
        val s = sentence.trim().trimEnd('.', '!')
        val m = Regex("(?i)^(?:please\\s+)?(?:reply|respond|text back|write back|message back|send a reply)\\b\\s*(.*)$").find(s)
            ?: return null
        var rest = m.groupValues[1].trim()
        if (!rest.startsWith("to ", ignoreCase = true)) return Reply(null, rest.replaceFirst(lead, "").trim())
        rest = rest.substring(3).trim()
        // "reply to him / her / that ..." = the latest conversation
        Regex("(?i)^(?:him|her|them|that|this|it)\\b(.*)$").find(rest)?.let { return Reply(null, it.groupValues[1].replaceFirst(lead, "").trim()) }
        // a name the user has messages from
        for (n in names.filter { it.isNotBlank() }.sortedByDescending { it.length }) {
            if (rest.equals(n, ignoreCase = true)) return Reply(n, "")
            if (rest.startsWith("$n ", ignoreCase = true) || rest.startsWith("$n,", ignoreCase = true) || rest.startsWith("$n:", ignoreCase = true)) {
                return Reply(n, rest.substring(n.length).replaceFirst(lead, "").trim())
            }
        }
        // "to Rahul saying ..." / "to Rahul: ..." (a name of up to three words)
        Regex("(?i)^(\\S+(?:\\s+\\S+){0,2}?)\\s*(?::|,|\\s+saying|\\s+that|\\s+with)\\s+(.+)$").find(rest)?.let {
            return Reply(it.groupValues[1].trim(), it.groupValues[2].trim())
        }
        // unknown name: its first word
        val parts = rest.split(Regex("\\s+"), 2)
        return Reply(parts[0], parts.getOrElse(1) { "" }.trim())
    }
}
