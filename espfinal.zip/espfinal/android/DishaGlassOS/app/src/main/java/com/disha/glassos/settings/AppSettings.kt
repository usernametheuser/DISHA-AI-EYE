package com.disha.glassos.settings

import android.content.Context
import android.content.SharedPreferences
import com.disha.glassos.ai.FreeVisionClient

/** All user settings, stored on the phone (SharedPreferences). The API key never leaves the phone except to Google. */
class AppSettings(context: Context) {

    enum class Destination(val label: String) {
        PHONE("Phone (Gallery)"),
        GLASSES("Glasses microSD card"),
        BOTH("Phone and glasses card"),
    }

    enum class AiProvider(val label: String) {
        FREE("Free AI, no key (OVHcloud)"),
        GEMINI("Google Gemini (your own free key)"),
    }

    /** Text-to-speech accent; the first installed language in the list is used. */
    enum class VoiceStyle(val label: String, val languageTags: List<String>) {
        FRIDAY("Irish, like FRIDAY (falls back to British)", listOf("en-IE", "en-GB", "en-IN")),
        BRITISH("British", listOf("en-GB", "en-IN")),
        INDIAN("Indian English", listOf("en-IN", "en-GB")),
        AMERICAN("American", listOf("en-US", "en-IN")),
    }

    /** Optional services with the user's own key, tried before the free ones (models can be changed in Settings). */
    enum class BoostProvider(val label: String, val base: String, val textModel: String, val visionModel: String, val speechModel: String, val keyUrl: String) {
        NONE("Off (free AI only)", "", "", "", "", ""),
        GROQ(
            "Groq (free key, fastest)", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile",
            "meta-llama/llama-4-scout-17b-16e-instruct", "whisper-large-v3-turbo", "console.groq.com/keys",
        ),
        OPENROUTER(
            "OpenRouter (free key)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free",
            "google/gemma-3-27b-it:free", "", "openrouter.ai/keys",
        ),
        OPENAI("OpenAI (paid key)", "https://api.openai.com/v1", "gpt-4o-mini", "gpt-4o-mini", "whisper-1", "platform.openai.com/api-keys"),
        CUSTOM("Other OpenAI-compatible service", "", "", "", "", ""),
    }

    enum class SpeechEngine(val label: String) {
        ONLINE("Free online (Whisper, no key) - recommended"),
        PHONE("The phone's own speech service"),
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
        const val AUTO_LANGUAGE = "auto"
        val LANGUAGES = listOf(
            "en-IN" to "English (India)", "en-US" to "English (US)", "en-GB" to "English (UK)", "hi-IN" to "Hindi",
            AUTO_LANGUAGE to "Any language (Hindi, English, mixed)",
        )
        val RESOLUTIONS = listOf(320 to 240, 640 to 480, 800 to 600)
        val FPS_CHOICES = listOf(1, 2, 5, 10)
        val SPEED_CHOICES = listOf(600 to "Quick (answers right after you stop)", 850 to "Normal", 1300 to "Patient (for slow or thoughtful speech)")
        val MEMORY_CHOICES = listOf(0 to "Off", 2 to "Every 2 minutes", 5 to "Every 5 minutes", 10 to "Every 10 minutes")
        val WAKE_SENSITIVITY = listOf(0.85f to "Strict (fewer false wake-ups)", 1.0f to "Normal", 1.2f to "Easy (wakes more readily)")
        val RATE_CHOICES = listOf(0.9f to "Relaxed", 1.0f to "Normal", 1.1f to "Brisk, like FRIDAY", 1.25f to "Fast")
        val WATCH_CHOICES = listOf(0 to "Off", 30 to "Every 30 s", 60 to "Every minute", 120 to "Every 2 minutes", 300 to "Every 5 minutes")
    }

    private val p: SharedPreferences = context.applicationContext.getSharedPreferences("disha", Context.MODE_PRIVATE)

    private fun str(key: String, def: String) = p.getString(key, def) ?: def
    private fun put(key: String, v: String) = p.edit().putString(key, v).apply()
    private fun put(key: String, v: Boolean) = p.edit().putBoolean(key, v).apply()
    private fun put(key: String, v: Int) = p.edit().putInt(key, v).apply()

    // AI
    var aiProvider: AiProvider
        get() = AiProvider.entries.getOrElse(p.getInt("aiProvider", 0)) { AiProvider.FREE }
        set(v) = put("aiProvider", v.ordinal)

    /** The free model tried first; the others follow automatically when it is busy. */
    var freeModel: String
        get() = str("freeModel", FreeVisionClient.MODELS[0]).ifBlank { FreeVisionClient.MODELS[0] }
        set(v) = put("freeModel", v.trim())

    var geminiKey: String
        get() = str("geminiKey", "")
        set(v) = put("geminiKey", v.trim())

    var geminiModel: String
        get() = str("geminiModel", DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
        set(v) = put("geminiModel", v.trim().removePrefix("models/"))

    /**
     * The user agreed that camera images may be sent to the chosen AI provider. Off until they agree,
     * and asked again for each provider, because the pictures go to a different company.
     */
    var aiImageConsent: Boolean
        get() = p.getBoolean(consentKey(), false)
        set(v) = put(consentKey(), v)

    private fun consentKey() = if (aiProvider == AiProvider.GEMINI) "aiImageConsent" else "aiImageConsentFree"

    /** Seconds between automatic "anything important?" checks; 0 = off. */
    var watchSeconds: Int
        get() = p.getInt("watchSeconds", 0)
        set(v) = put("watchSeconds", v)

    var aiResolution: Pair<Int, Int>
        get() = RESOLUTIONS.getOrElse(p.getInt("aiResolution", 1)) { RESOLUTIONS[1] }
        set(v) = put("aiResolution", RESOLUTIONS.indexOf(v).coerceAtLeast(0))

    // Voice
    var speechLanguage: String
        get() = str("speechLanguage", "en-IN")
        set(v) = put("speechLanguage", v)

    var speechEngine: SpeechEngine
        get() = SpeechEngine.entries.getOrElse(p.getInt("speechEngine", 0)) { SpeechEngine.ONLINE }
        set(v) = put("speechEngine", v.ordinal)

    /** The user agreed that their spoken requests may be sent to the free online speech service. */
    var voiceConsent: Boolean
        get() = p.getBoolean("voiceConsent", false)
        set(v) = put("voiceConsent", v)

    /** The user has answered the speech question once (allowed it, or chose the phone's service). */
    var voiceConsentAsked: Boolean
        get() = p.getBoolean("voiceConsentAsked", false)
        set(v) = put("voiceConsentAsked", v)

    /** Online speech recognition is chosen and allowed. */
    val useOnlineSpeech get() = speechEngine == SpeechEngine.ONLINE && voiceConsent

    /** After each answer, listen for a follow-up without another tap (silence ends the conversation). */
    var conversationMode: Boolean
        get() = p.getBoolean("conversationMode", true)
        set(v) = put("conversationMode", v)

    var assistantName: String
        get() = str("assistantName", "Disha").ifBlank { "Disha" }
        set(v) = put("assistantName", v.trim())

    init {
        // 0.8: the assistant is called Disha now. An old default "Friday" becomes "Disha" once.
        if (!p.getBoolean("renamedToDisha", false)) {
            if (p.getString("assistantName", "") == "Friday") put("assistantName", "Disha")
            p.edit().putBoolean("renamedToDisha", true).apply()
        }
    }

    /** How the assistant addresses the user, for example "Boss"; empty = no title. */
    var userTitle: String
        get() = str("userTitle", "Boss")
        set(v) = put("userTitle", v.trim())

    /** For weather and briefings; empty = the city of the phone's internet connection. */
    var homeCity: String
        get() = str("homeCity", "")
        set(v) = put("homeCity", v.trim())

    var voiceStyle: VoiceStyle
        get() = VoiceStyle.entries.getOrElse(p.getInt("voiceStyle", 0)) { VoiceStyle.FRIDAY }
        set(v) = put("voiceStyle", v.ordinal)

    /** Text-to-speech rate, 1.0 = normal. */
    var speechRate: Float
        get() = p.getFloat("speechRate", 1.1f)
        set(v) = p.edit().putFloat("speechRate", v).apply()

    /** Quiet after speech that ends a request, in ms: lower answers sooner, higher suits slow speakers. */
    var endSilenceMs: Int
        get() = p.getInt("endSilenceMs", 850)
        set(v) = put("endSilenceMs", v)

    /** The phone's noise suppression on the microphone. */
    var noiseReduction: Boolean
        get() = p.getBoolean("noiseReduction", true)
        set(v) = put("noiseReduction", v)

    /** Short chimes for listening, heard, done (instead of silence). */
    var sounds: Boolean
        get() = p.getBoolean("sounds", true)
        set(v) = put("sounds", v)

    /** Hands-free: listen on the phone mic for the user's recorded wake phrase. */
    var wakeEnabled: Boolean
        get() = p.getBoolean("wakeEnabled", false)
        set(v) = put("wakeEnabled", v)

    /** Multiplies the wake threshold: lower = stricter (fewer false wakes), higher = easier. */
    var wakeSensitivity: Float
        get() = p.getFloat("wakeSensitivity", 1.0f)
        set(v) = p.edit().putFloat("wakeSensitivity", v).apply()

    /** Set while Settings records new samples: the running listener lets go of the microphone. */
    var wakeEnrolling: Boolean
        get() = p.getBoolean("wakeEnrolling", false)
        set(v) = p.edit().putBoolean("wakeEnrolling", v).commit().let { }

    /** Bumped when new samples are saved, so the running assistant reloads them. */
    var wakeVersion: Int
        get() = p.getInt("wakeVersion", 0)
        set(v) = put("wakeVersion", v)

    // ---- Skills ----

    /** "Where did I leave my keys": minutes between captions of what the camera sees; 0 = off. */
    var visualMemoryMinutes: Int
        get() = p.getInt("visualMemoryMinutes", 0)
        set(v) = put("visualMemoryMinutes", v)

    /** Each photo saved on the phone gets an AI caption, for searching. */
    var smartGallery: Boolean
        get() = p.getBoolean("smartGallery", false)
        set(v) = put("smartGallery", v)

    /** Say new messages (sender and app) as they arrive. */
    var announceMessages: Boolean
        get() = p.getBoolean("announceMessages", false)
        set(v) = put("announceMessages", v)

    /** Say who is calling when the phone rings. */
    var announceCalls: Boolean
        get() = p.getBoolean("announceCalls", true)
        set(v) = put("announceCalls", v)

    /** Note places every few minutes for the daily diary. */
    var rememberPlaces: Boolean
        get() = p.getBoolean("rememberPlaces", false)
        set(v) = put("rememberPlaces", v)

    /** The user agreed that meeting notes record everyone nearby and send the audio to the speech service. */
    var notesAllowed: Boolean
        get() = p.getBoolean("notesAllowed", false)
        set(v) = put("notesAllowed", v)

    var sosEnabled: Boolean
        get() = p.getBoolean("sosEnabled", false)
        set(v) = put("sosEnabled", v)

    var sosName: String
        get() = str("sosName", "")
        set(v) = put("sosName", v.trim())

    var sosNumber: String
        get() = str("sosNumber", "")
        set(v) = put("sosNumber", v.trim())

    /** The user's own name, as written in the SOS message. */
    var sosSenderName: String
        get() = str("sosSenderName", "")
        set(v) = put("sosSenderName", v.trim())

    /** Speak up unasked: low phone battery, hot camera board, glasses online/offline, reminders. */
    var proactiveAlerts: Boolean
        get() = p.getBoolean("proactiveAlerts", true)
        set(v) = put("proactiveAlerts", v)

    var preferOfflineSpeech: Boolean
        get() = p.getBoolean("preferOfflineSpeech", false)
        set(v) = put("preferOfflineSpeech", v)

    var useEarbudMic: Boolean
        get() = p.getBoolean("useEarbudMic", true)
        set(v) = put("useEarbudMic", v)

    var earbudTap: Boolean
        get() = p.getBoolean("earbudTap", true)
        set(v) = put("earbudTap", v)

    // Camera and storage
    var streamFps: Int
        get() = p.getInt("streamFps", 2)
        set(v) = put("streamFps", v)

    var photoDestination: Destination
        get() = Destination.entries.getOrElse(p.getInt("photoDestination", 0)) { Destination.PHONE }
        set(v) = put("photoDestination", v.ordinal)

    var recordDestination: Destination
        get() = Destination.entries.getOrElse(p.getInt("recordDestination", 0)) { Destination.PHONE }
        set(v) = put("recordDestination", v.ordinal)

    var recordFps: Int
        get() = p.getInt("recordFps", 5)
        set(v) = put("recordFps", v)

    // AI boost: the user's own key, tried before the free services
    var boostProvider: BoostProvider
        get() = BoostProvider.entries.getOrElse(p.getInt("boostProvider", 0)) { BoostProvider.NONE }
        set(v) = put("boostProvider", v.ordinal)

    var boostKey: String
        get() = str("boostKey", "")
        set(v) = put("boostKey", v.trim())

    var boostBaseUrl: String
        get() = str("boostBaseUrl", "")
        set(v) = put("boostBaseUrl", v.trim())

    var boostTextModel: String
        get() = str("boostTextModel", "")
        set(v) = put("boostTextModel", v.trim())

    var boostVisionModel: String
        get() = str("boostVisionModel", "")
        set(v) = put("boostVisionModel", v.trim())

    var boostSpeechModel: String
        get() = str("boostSpeechModel", "")
        set(v) = put("boostSpeechModel", v.trim())

    /** The user agreed that questions, pictures and voice may go to the boost service. */
    var boostConsent: Boolean
        get() = p.getBoolean("boostConsent", false)
        set(v) = put("boostConsent", v)

    /** No internet: understand speech with the phone's on-device recogniser, if it has one. */
    var offlineFallback: Boolean
        get() = p.getBoolean("offlineFallback", true)
        set(v) = put("offlineFallback", v)

    /** Instant replay: keep the last 30 s of the live view in memory. */
    var replayOn: Boolean
        get() = p.getBoolean("replayOn", false)
        set(v) = put("replayOn", v)

    /** Translator languages (ISO 639-1): the user's language and the other person's. */
    var translatorMine: String
        get() = str("translatorMine", "en")
        set(v) = put("translatorMine", v)

    var translatorOther: String
        get() = str("translatorOther", "hi")
        set(v) = put("translatorOther", v)

    // Backup
    /** Keep a daily backup copy in Documents/DISHA/Backup (outlives an uninstall). */
    var autoBackup: Boolean
        get() = p.getBoolean("autoBackup", true)
        set(v) = put("autoBackup", v)

    var lastBackupAt: Long
        get() = p.getLong("lastBackupAt", 0L)
        set(v) = p.edit().putLong("lastBackupAt", v).apply()

    var lastBackupWhere: String
        get() = str("lastBackupWhere", "")
        set(v) = put("lastBackupWhere", v)

    // Screen
    var showDebug: Boolean
        get() = p.getBoolean("showDebug", true)
        set(v) = put("showDebug", v)

    fun register(l: SharedPreferences.OnSharedPreferenceChangeListener) = p.registerOnSharedPreferenceChangeListener(l)

    fun unregister(l: SharedPreferences.OnSharedPreferenceChangeListener) = p.unregisterOnSharedPreferenceChangeListener(l)
}
