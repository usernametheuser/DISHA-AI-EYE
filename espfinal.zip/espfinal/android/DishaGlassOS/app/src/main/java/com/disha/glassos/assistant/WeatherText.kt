package com.disha.glassos.assistant

import kotlin.math.roundToInt

/** Weather data from Open-Meteo and how to say it. Pure logic, unit-tested on the PC. */
class WeatherText(
    val place: String,
    val tempC: Double,
    val feelsC: Double,
    val code: Int,
    val windKmh: Double,
    val todayMaxC: Double,
    val todayMinC: Double,
    val todayRainPct: Int,
    val tomorrowMaxC: Double,
    val tomorrowMinC: Double,
    val tomorrowRainPct: Int,
    val tomorrowCode: Int,
) {
    companion object {
        /** WMO weather interpretation codes, as used by Open-Meteo. */
        fun words(code: Int): String = when (code) {
            0 -> "clear skies"
            1 -> "mostly clear skies"
            2 -> "partly cloudy skies"
            3 -> "overcast skies"
            45, 48 -> "fog"
            51, 53, 55 -> "drizzle"
            56, 57 -> "freezing drizzle"
            61 -> "light rain"
            63 -> "rain"
            65 -> "heavy rain"
            66, 67 -> "freezing rain"
            71 -> "light snow"
            73 -> "snow"
            75 -> "heavy snow"
            77 -> "snow grains"
            80 -> "light showers"
            81 -> "showers"
            82 -> "heavy showers"
            85, 86 -> "snow showers"
            95 -> "thunderstorms"
            96, 99 -> "thunderstorms with hail"
            else -> "mixed weather"
        }

        private fun deg(c: Double) = "${c.roundToInt()} degrees"
    }

    /** One or two spoken sentences. */
    fun sentence(tomorrow: Boolean): String = if (tomorrow) {
        "Tomorrow in $place: ${words(tomorrowCode)}, between ${deg(tomorrowMinC)} and ${deg(tomorrowMaxC)}" +
            (if (tomorrowRainPct >= 20) ", with a $tomorrowRainPct percent chance of rain." else ".")
    } else {
        val feels = if ((feelsC - tempC) >= 3 || (tempC - feelsC) >= 3) ", feels like ${deg(feelsC)}" else ""
        "In $place it's ${deg(tempC)}$feels, with ${words(code)}. Today's high is ${deg(todayMaxC)}" +
            (if (todayRainPct >= 20) " and there's a $todayRainPct percent chance of rain." else ".")
    }

    /** Compact data for the AI, so it can answer questions like "do I need an umbrella". */
    fun forModel(): String =
        "Weather for $place. Now: ${tempC.roundToInt()} C (feels ${feelsC.roundToInt()} C), ${words(code)}, wind ${windKmh.roundToInt()} km/h. " +
            "Today: ${todayMinC.roundToInt()} to ${todayMaxC.roundToInt()} C, rain chance $todayRainPct%. " +
            "Tomorrow: ${words(tomorrowCode)}, ${tomorrowMinC.roundToInt()} to ${tomorrowMaxC.roundToInt()} C, rain chance $tomorrowRainPct%."
}
