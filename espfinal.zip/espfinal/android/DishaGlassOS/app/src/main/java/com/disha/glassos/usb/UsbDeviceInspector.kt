package com.disha.glassos.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import java.util.Locale

/** Finds the DISHA-CAM data interface on a USB device and describes devices for the UI. */
object UsbDeviceInspector {
    const val ESPRESSIF_VID = 0x303A
    const val PID_ARDUINO_TINYUSB = 0x0002
    const val PID_USB_SERIAL_JTAG = 0x1001
    const val LINK_INTERFACE_NAME = "DISHA-CAM Link"

    enum class Transport(val label: String) {
        VENDOR_BULK("native USB vendor bulk (TinyUSB)"),
        CDC_ACM("native USB Serial/JTAG CDC (fallback)"),
    }

    class LinkSelection(
        val device: UsbDevice,
        val iface: UsbInterface,
        val epIn: UsbEndpoint,
        val epOut: UsbEndpoint,
        val transport: Transport,
    )

    private val UART_BRIDGES = mapOf(
        0x1A86 to "WCH CH34x",
        0x10C4 to "Silicon Labs CP210x",
        0x0403 to "FTDI",
    )

    /**
     * Primary: the vendor interface named "DISHA-CAM Link" (class 0xFF/0x00/0x00).
     * Fallback: the CDC data interface of the ESP32-S3 USB Serial/JTAG controller.
     * Never the Espressif JTAG interface (class 0xFF/0xFF/0x01), which also has bulk endpoints.
     */
    fun select(device: UsbDevice): LinkSelection? {
        var cdc: LinkSelection? = null
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            val isJtag = itf.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC &&
                itf.interfaceSubclass == 0xFF && itf.interfaceProtocol == 0x01
            if (isJtag) continue
            val (epIn, epOut) = bulkPair(itf) ?: continue
            val named = itf.name == LINK_INTERFACE_NAME
            val plainVendor = device.vendorId == ESPRESSIF_VID &&
                itf.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC &&
                itf.interfaceSubclass == 0 && itf.interfaceProtocol == 0
            if (named || plainVendor) return LinkSelection(device, itf, epIn, epOut, Transport.VENDOR_BULK)
            if (cdc == null && device.vendorId == ESPRESSIF_VID && itf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) {
                cdc = LinkSelection(device, itf, epIn, epOut, Transport.CDC_ACM)
            }
        }
        return cdc
    }

    private fun bulkPair(itf: UsbInterface): Pair<UsbEndpoint, UsbEndpoint>? {
        var epIn: UsbEndpoint? = null
        var epOut: UsbEndpoint? = null
        for (e in 0 until itf.endpointCount) {
            val ep = itf.getEndpoint(e)
            if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (ep.direction == UsbConstants.USB_DIR_IN) {
                if (epIn == null) epIn = ep
            } else if (epOut == null) {
                epOut = ep
            }
        }
        return if (epIn != null && epOut != null) epIn to epOut else null
    }

    /** Explains why an attached device cannot be used, or null if there is nothing specific to say. */
    fun diagnose(device: UsbDevice): String? {
        UART_BRIDGES[device.vendorId]?.let { bridge ->
            return "This is the board's USB-UART port ($bridge USB-to-serial bridge, VID ${hex4(device.vendorId)}). " +
                "It is only for flashing and the debug log. Plug the phone into the port labelled USB-OTG."
        }
        if (device.vendorId == ESPRESSIF_VID && device.productId == PID_USB_SERIAL_JTAG) {
            return "ESP32-S3 USB Serial/JTAG found but no usable data interface. The board may still be booting " +
                "or is in download mode. Press RST on the board."
        }
        if (device.vendorId == ESPRESSIF_VID) {
            return "Espressif device ${hex4(device.vendorId)}:${hex4(device.productId)} has no DISHA-CAM link " +
                "interface. Flash the DISHA-CAM firmware."
        }
        return null
    }

    fun describe(device: UsbDevice): String = buildString {
        append("USB ${hex4(device.vendorId)}:${hex4(device.productId)}  ${device.deviceName}\n")
        val product = device.productName
        val maker = device.manufacturerName
        if (product != null || maker != null) append("  ${maker ?: "?"} / ${product ?: "?"}\n")
        val serial = try {
            device.serialNumber
        } catch (e: SecurityException) {
            null  // Android 10+ hides the serial number until permission is granted
        }
        if (serial != null) append("  serial $serial\n")
        append(
            String.format(
                Locale.US, "  device class 0x%02X/0x%02X/0x%02X, %d interface(s)\n",
                device.deviceClass, device.deviceSubclass, device.deviceProtocol, device.interfaceCount,
            ),
        )
        for (i in 0 until device.interfaceCount) {
            val itf = device.getInterface(i)
            append(
                String.format(
                    Locale.US, "  if %d alt %d: class 0x%02X/0x%02X/0x%02X%s\n",
                    itf.id, itf.alternateSetting, itf.interfaceClass, itf.interfaceSubclass, itf.interfaceProtocol,
                    itf.name?.let { " \"$it\"" } ?: "",
                ),
            )
            for (e in 0 until itf.endpointCount) {
                val ep = itf.getEndpoint(e)
                append(
                    String.format(
                        Locale.US, "    EP 0x%02X %s %s, max packet %d\n",
                        ep.address, if (ep.direction == UsbConstants.USB_DIR_IN) "IN " else "OUT",
                        endpointType(ep.type), ep.maxPacketSize,
                    ),
                )
            }
        }
    }

    private fun endpointType(t: Int) = when (t) {
        UsbConstants.USB_ENDPOINT_XFER_BULK -> "bulk"
        UsbConstants.USB_ENDPOINT_XFER_INT -> "interrupt"
        UsbConstants.USB_ENDPOINT_XFER_ISOC -> "isochronous"
        UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "control"
        else -> "type $t"
    }

    fun hex4(v: Int): String = String.format(Locale.US, "0x%04X", v)
}
