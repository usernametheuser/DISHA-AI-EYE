package com.disha.glassos.skills

import java.util.Calendar
import java.util.Locale

/**
 * Time ranges in requests: "today", "yesterday", "this morning", "this week", "last 3 days".
 * Pure logic (the clock is passed in), unit-tested on the PC.
 */
class TimeRange(val from: Long, val to: Long, val label: String) {

    operator fun contains(t: Long) = t in from until to

    companion object {
        /** The range named in [text], or null if it names none. now: epoch ms. */
        fun parse(text: String, now: Long): TimeRange? {
            val s = " " + text.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim() + " "
            val day = startOfDay(now)
            val dayMs = 24 * 3600 * 1000L
            Regex(" (?:last|past) (\\d+|two|three|four|five|six|seven) days ").find(s)?.let {
                val n = it.groupValues[1].toIntOrNull() ?: listOf("two", "three", "four", "five", "six", "seven").indexOf(it.groupValues[1]) + 2
                return TimeRange(day - (n - 1) * dayMs, now + 1, "the last $n days")
            }
            return when {
                s.contains(" this morning ") -> TimeRange(day, minOf(day + 12 * 3600_000L, now + 1), "this morning")
                s.contains(" this afternoon ") -> TimeRange(day + 12 * 3600_000L, minOf(day + 17 * 3600_000L, now + 1), "this afternoon")
                s.contains(" this evening ") || s.contains(" tonight ") -> TimeRange(day + 17 * 3600_000L, now + 1, "this evening")
                s.contains(" yesterday ") -> TimeRange(day - dayMs, day, "yesterday")
                s.contains(" today ") -> TimeRange(day, now + 1, "today")
                s.contains(" this week ") -> TimeRange(startOfWeek(now), now + 1, "this week")
                s.contains(" last week ") -> TimeRange(startOfWeek(now) - 7 * dayMs, startOfWeek(now), "last week")
                s.contains(" last hour ") || s.contains(" past hour ") -> TimeRange(now - 3600_000L, now + 1, "the last hour")
                else -> null
            }
        }

        fun startOfDay(t: Long): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = t
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        private fun startOfWeek(t: Long): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = startOfDay(t)
            val back = (c.get(Calendar.DAY_OF_WEEK) - Calendar.MONDAY + 7) % 7  // weeks start on Monday
            c.add(Calendar.DAY_OF_MONTH, -back)
            return c.timeInMillis
        }
    }
}
