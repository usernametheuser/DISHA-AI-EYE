package com.disha.glassos.ui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Disha's face: an animated orb that shows what the assistant is doing. Idle it breathes;
 * waiting for "Disha" a dotted ring turns slowly; listening it pulses with your voice and sends
 * out ripples; thinking two arcs spin; speaking it shows sound waves around the core.
 */
class DishaOrb(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    enum class Mode(val color: Int) {
        IDLE(0xFF22D3EE.toInt()),
        WAKE(0xFF22D3EE.toInt()),
        PREPARING(0xFFFBBF24.toInt()),
        LISTENING(0xFF34D399.toInt()),
        THINKING(0xFFA78BFA.toInt()),
        SPEAKING(0xFF60A5FA.toInt()),
    }

    var mode: Mode = Mode.IDLE
        set(value) {
            if (field == value) return
            field = value
            fadeTo(value.color)
            invalidate()
        }

    /** Microphone level 0..100 while listening. */
    fun setLevel(level: Int) {
        targetLevel = (level / 100f).coerceIn(0f, 1f)
    }

    private var color = Mode.IDLE.color
    private var colorAnim: ValueAnimator? = null
    private var targetLevel = 0f
    private var level = 0f
    private val start = SystemClock.uptimeMillis()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true; letterSpacing = 0.18f }
    private val arc = RectF()

    private fun fadeTo(target: Int) {
        colorAnim?.cancel()
        colorAnim = ValueAnimator.ofObject(ArgbEvaluator(), color, target).apply {
            duration = 350
            addUpdateListener { color = it.animatedValue as Int }
            start()
        }
    }

    private fun alpha(c: Int, a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(canvas: Canvas) {
        if (width < 8 || height < 8) return  // gradients need a real size
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.96f
        val base = r * 0.40f
        level += (targetLevel - level) * 0.25f  // smooth the mic level
        if (mode != Mode.LISTENING) targetLevel = 0f

        var core = base
        when (mode) {
            Mode.IDLE, Mode.WAKE -> core = base * (1f + 0.045f * sin(t * 1.7f))
            Mode.PREPARING -> core = base * (1f + 0.08f * sin(t * 7f))
            Mode.LISTENING -> {
                core = base * (1f + 0.30f * level + 0.03f * sin(t * 4f))
                // ripples going out, faster and stronger with a louder voice
                for (k in 0 until 3) {
                    val p = ((t * (0.55f + level) + k / 3f) % 1f)
                    stroke.strokeWidth = r * 0.025f * (1f - p) + 1f
                    stroke.color = alpha(color, (1f - p) * (0.35f + 0.5f * level))
                    canvas.drawCircle(cx, cy, base + (r - base) * p, stroke)
                }
            }
            Mode.THINKING -> {
                core = base * (1f + 0.04f * sin(t * 3f))
                stroke.strokeWidth = r * 0.05f
                stroke.strokeCap = Paint.Cap.ROUND
                for ((i, rr) in listOf(r * 0.70f, r * 0.86f).withIndex()) {
                    arc.set(cx - rr, cy - rr, cx + rr, cy + rr)
                    val dir = if (i == 0) 1 else -1
                    val a0 = (t * 220f * dir + i * 90f) % 360f
                    stroke.color = alpha(color, 0.85f - i * 0.3f)
                    canvas.drawArc(arc, a0, 95f, false, stroke)
                    stroke.color = alpha(color, 0.35f - i * 0.1f)
                    canvas.drawArc(arc, a0 + 180f, 55f, false, stroke)
                }
            }
            Mode.SPEAKING -> {
                core = base * (1f + 0.05f * sin(t * 6f))
                // sound waves around the core
                stroke.strokeCap = Paint.Cap.ROUND
                stroke.strokeWidth = r * 0.035f
                val bars = 40
                for (i in 0 until bars) {
                    val a = (2 * PI * i / bars).toFloat()
                    val wave = abs(sin(t * 5.3f + i * 0.9f) * 0.6f + sin(t * 3.1f + i * 0.37f) * 0.4f)
                    val inner = core * 1.18f
                    val outer = inner + (r * 0.98f - inner) * (0.15f + 0.85f * wave)
                    stroke.color = alpha(color, 0.35f + 0.55f * wave)
                    canvas.drawLine(cx + cos(a) * inner, cy + sin(a) * inner, cx + cos(a) * outer, cy + sin(a) * outer, stroke)
                }
            }
        }
        if (mode == Mode.WAKE) {
            // waiting for "Disha": a slowly turning ring of dots
            val dots = 28
            for (i in 0 until dots) {
                val a = (2 * PI * i / dots + t * 0.35f).toFloat()
                val rr = r * 0.82f
                fill.shader = null
                fill.color = alpha(color, 0.15f + 0.45f * ((sin(t * 2f + i * 0.45f) + 1f) / 2f))
                canvas.drawCircle(cx + cos(a) * rr, cy + sin(a) * rr, r * 0.022f, fill)
            }
        }
        // glow
        fill.shader = RadialGradient(cx, cy, core * 1.9f, alpha(color, 0.38f), alpha(color, 0f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, core * 1.9f, fill)
        // core: light centre fading into the mode colour
        fill.shader = RadialGradient(
            cx - core * 0.25f, cy - core * 0.3f, core * 1.15f,
            intArrayOf(Color.WHITE, color, alpha(color, 0.55f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, core, fill)
        fill.shader = null
        stroke.strokeWidth = r * 0.02f
        stroke.color = alpha(Color.WHITE, 0.55f)
        canvas.drawCircle(cx, cy, core, stroke)
        label.textSize = core * 0.30f
        label.color = 0xFF05070D.toInt()
        canvas.drawText("DISHA", cx, cy + label.textSize * 0.36f, label)

        // In step with the display (60 Hz or more) for smooth motion; Android stops drawing it with the screen off.
        postInvalidateOnAnimation()
    }
}
