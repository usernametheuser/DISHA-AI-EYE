package com.disha.glassos.audio

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * One-shot speech recognition with Android's SpeechRecognizer (normally Google's, on-device or
 * online depending on the phone). The microphone it records from follows the current audio
 * route, so the earbud mic is used while AudioRouter has the headset link open.
 * Main thread only.
 */
class SpeechInput(context: Context, private val listener: Listener) {

    interface Listener {
        fun onListening()
        fun onSpeechEnded()
        fun onPartial(text: String)
        fun onLevel(level: Int)  // 0..100
        fun onFinalResult(text: String)
        fun onFailed(code: Int, message: String)
    }

    companion object {
        const val ERROR_NO_RESPONSE = 1000  // app-side: the recognizer never answered

        fun errorMessage(code: Int): String = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Speech recognition needs the internet, and the connection isn't working."
            SpeechRecognizer.ERROR_AUDIO -> "The microphone could not be opened."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Microphone permission is missing. Open the app and tap the mic once to allow it."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
            SpeechRecognizer.ERROR_SERVER -> "The speech service had a problem. Try again."
            SpeechRecognizer.ERROR_CLIENT -> "Listening was cancelled."
            SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> "Too many requests to the speech service. Wait a moment."
            SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "The speech service disconnected. Try again."
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "The speech recognizer doesn't support this language."
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "The language pack for speech recognition isn't downloaded yet."
            ERROR_NO_RESPONSE -> "The speech recognizer did not respond. Try again."
            else -> "Speech recognition error $code."
        }
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var finished = true
    private val watchdog = Runnable { fail(ERROR_NO_RESPONSE) }

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(appContext)

    /** Android 12+: the phone has a recogniser that works entirely on the phone (no internet). */
    fun onDeviceAvailable(): Boolean = Build.VERSION.SDK_INT >= 31 && try {
        SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)
    } catch (_: Exception) {
        false
    }

    /** onDevice: use the on-phone recogniser (offline), when the phone has one. */
    fun start(languageTag: String, preferOffline: Boolean, onDevice: Boolean = false) {
        destroyRecognizer()  // a fresh recognizer per request avoids "busy" states on some phones
        val r = if (onDevice && Build.VERSION.SDK_INT >= 31 && onDeviceAvailable()) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext)
        } else {
            SpeechRecognizer.createSpeechRecognizer(appContext)
        }
        recognizer = r
        finished = false
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (!finished) listener.onListening()
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                if (!finished) listener.onLevel(((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                if (!finished) listener.onSpeechEnded()
            }

            override fun onError(error: Int) = fail(error)

            override fun onResults(results: Bundle?) {
                if (finished) return
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull { it.isNotBlank() }
                if (text == null) {
                    fail(SpeechRecognizer.ERROR_NO_MATCH)
                    return
                }
                finish()
                listener.onFinalResult(text.trim())
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (finished) return
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.let { listener.onPartial(it) }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
            if ((preferOffline || onDevice) && Build.VERSION.SDK_INT >= 23) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        main.postDelayed(watchdog, 20000)
        r.startListening(intent)
    }

    /** Stop recording and recognise what was said so far. */
    fun stop() {
        recognizer?.stopListening()
    }

    /** Abort without a result. */
    fun cancel() {
        if (finished) return
        finish()
        recognizer?.cancel()
    }

    fun destroy() {
        finish()
        destroyRecognizer()
    }

    private fun fail(code: Int) {
        if (finished) return
        finish()
        listener.onFailed(code, errorMessage(code))
    }

    private fun finish() {
        finished = true
        main.removeCallbacks(watchdog)
    }

    private fun destroyRecognizer() {
        recognizer?.let {
            try {
                it.destroy()
            } catch (_: Exception) {
            }
        }
        recognizer = null
    }
}
