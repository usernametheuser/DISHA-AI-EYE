package com.disha.glassos.ai

import com.disha.glassos.settings.AppSettings

/**
 * Optional "boost": an OpenAI-compatible service with the user's own key (Groq's free key is the
 * fastest), tried first for thinking, pictures and speech; the free no-key services take over
 * whenever it fails or is busy. The key is pasted in Settings and stays on the phone; it is used
 * only after the user agreed where their questions, pictures and voice go.
 */
object Boost {

    class Endpoint(val base: String, val key: String, val label: String, val textModel: String, val visionModel: String, val speechModel: String)

    /** null when no key is set, or the user hasn't agreed. */
    fun endpoint(s: AppSettings): Endpoint? {
        val p = s.boostProvider
        if (p == AppSettings.BoostProvider.NONE || s.boostKey.isBlank() || !s.boostConsent) return null
        val base = (if (p == AppSettings.BoostProvider.CUSTOM) s.boostBaseUrl else p.base).trim().trimEnd('/')
        if (!base.startsWith("https://")) return null
        return Endpoint(
            base, s.boostKey.trim(), p.label.substringBefore(" ("),
            s.boostTextModel.ifBlank { p.textModel },
            s.boostVisionModel.ifBlank { p.visionModel },
            s.boostSpeechModel.ifBlank { p.speechModel },
        )
    }
}
