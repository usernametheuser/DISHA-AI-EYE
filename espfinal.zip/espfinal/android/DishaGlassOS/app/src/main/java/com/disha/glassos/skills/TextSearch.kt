package com.disha.glassos.skills

import java.util.Locale

/**
 * Finds notes (photo captions, things seen, documents) that match a spoken request, by the
 * important words they share, newest first among equals. Pure logic, unit-tested on the PC.
 */
object TextSearch {

    class Item(val time: Long, val text: String, val ref: String = "")

    private val stop = setOf(
        "the", "a", "an", "my", "me", "i", "is", "are", "was", "were", "of", "to", "on", "in", "at", "it", "this", "that",
        "where", "did", "do", "does", "what", "which", "show", "find", "photo", "photos", "picture", "pictures", "pic",
        "pics", "image", "images", "from", "today", "yesterday", "week", "last", "leave", "left", "put", "kept", "keep",
        "have", "has", "you", "seen", "see", "saw", "for", "with", "and", "or", "please", "disha", "some", "any", "all",
        "morning", "afternoon", "evening", "tonight", "past", "hour", "days", "can", "could", "tell", "about", "there",
    )

    /** Lower case, plural "s"/"es" removed, so "keys" finds "key" and "glasses" finds "glass". */
    fun words(s: String): Set<String> =
        s.lowercase(Locale.US).split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 2 && it !in stop }
            .map { stem(it) }
            .toSet()

    private fun stem(w: String) = when {
        w.length > 4 && w.endsWith("ies") -> w.dropLast(3) + "y"
        w.length > 4 && (w.endsWith("ses") || w.endsWith("xes") || w.endsWith("ches") || w.endsWith("shes")) -> w.dropLast(2)
        w.length > 3 && w.endsWith("s") && !w.endsWith("ss") -> w.dropLast(1)
        else -> w
    }

    /**
     * Items sharing at least one important word with [query] (within [range] if given), best first.
     * With no important words (for example "show today's photos"), everything in range, newest first.
     */
    fun search(items: List<Item>, query: String, range: TimeRange?, limit: Int = 10): List<Item> {
        val q = words(query)
        val inRange = items.filter { range == null || it.time in range }
        if (q.isEmpty()) return inRange.sortedByDescending { it.time }.take(limit)
        return inRange
            .map { it to words(it.text).intersect(q).size }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Item, Int>> { it.second }.thenByDescending { it.first.time })
            .take(limit)
            .map { it.first }
    }
}
