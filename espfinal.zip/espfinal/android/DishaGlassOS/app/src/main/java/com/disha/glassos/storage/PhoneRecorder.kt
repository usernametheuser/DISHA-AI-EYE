package com.disha.glassos.storage

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.disha.glassos.protocol.FrameAssembler
import com.disha.glassos.util.AppLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Records the frames arriving over USB into MJPEG AVI files on the phone. Frames are written on a
 * background thread; a new file starts if the resolution changes or a file reaches 1 GB.
 * Finished files are moved to Movies/DISHA (Android 10+).
 */
class PhoneRecorder(context: Context) {

    class Summary(val frames: Int, val seconds: Long, val megabytes: Double, val locations: List<String>)

    private companion object {
        const val TAG = "Recorder"
    }

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-recorder").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var active = false
        private set

    // recorder thread only
    private var writer: AviWriter? = null
    private var file: File? = null
    private var currentW = 0
    private var currentH = 0
    private var nominalFps = 5
    private var frames = 0
    private var bytes = 0L
    private var firstMs = 0L
    private var lastMs = 0L
    private val finished = ArrayList<String>()

    @Volatile
    var framesWritten = 0
        private set

    fun start(fps: Int) {
        if (active) return
        active = true
        executor.execute {
            nominalFps = fps
            frames = 0
            bytes = 0
            firstMs = 0
            lastMs = 0
            framesWritten = 0
            finished.clear()
        }
        AppLog.i(TAG, "Phone recording started")
    }

    /** Any thread. Ignored unless recording. */
    fun onFrame(frame: FrameAssembler.Frame) {
        if (!active) return
        val received = System.currentTimeMillis()
        executor.execute { write(frame, received) }
    }

    private fun write(frame: FrameAssembler.Frame, receivedMs: Long) {
        if (!active) return
        try {
            var w = writer
            if (w != null && (w.full || frame.width != currentW || frame.height != currentH)) {
                finishFile()  // file full or resolution changed: continue in a new file
                w = null
            }
            if (w == null) {
                val name = "DISHA_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.avi"
                val f = File(MediaSaver.recordingDir(appContext), name)
                w = AviWriter(f, frame.width, frame.height, nominalFps)
                writer = w
                file = f
                currentW = frame.width
                currentH = frame.height
            }
            w.addFrame(frame.data, receivedMs)
            if (frames == 0) firstMs = receivedMs
            lastMs = receivedMs
            frames++
            framesWritten = frames
            bytes += frame.data.size + 8
        } catch (e: Exception) {
            AppLog.e(TAG, "Writing the video failed: ${e.message}")
            active = false
            finishFile()
        }
    }

    private fun finishFile() {
        val w = writer ?: return
        val f = file
        writer = null
        file = null
        try {
            w.close()
        } catch (e: Exception) {
            AppLog.e(TAG, "Closing the video failed: ${e.message}")
        }
        if (f != null) {
            if (w.frames == 0) {
                f.delete()
            } else {
                finished.add(MediaSaver.publishVideo(appContext, f))
            }
        }
    }

    /** Stops and finalises. onDone runs on the main thread. */
    fun stop(onDone: (Summary) -> Unit) {
        active = false
        executor.execute {
            finishFile()
            val summary = Summary(frames, if (frames > 1) (lastMs - firstMs) / 1000 else 0, bytes / 1048576.0, finished.toList())
            AppLog.i(TAG, "Phone recording saved: ${summary.frames} frames, ${summary.seconds} s -> ${summary.locations}")
            main.post { onDone(summary) }
        }
    }
}
