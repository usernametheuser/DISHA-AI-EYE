package com.disha.glassos.skills

import java.net.URLDecoder

/**
 * What a QR code holds, and how to say it. Links are opened and contacts saved only after the
 * user says yes; payment codes are only read out, never paid. Pure logic.
 */
object QrContent {

    sealed class Item {
        class Link(val url: String) : Item()
        class Upi(val payee: String, val id: String, val amount: String, val note: String) : Item()
        class Wifi(val ssid: String, val security: String) : Item()
        class Contact(val name: String, val phones: List<String>, val emails: List<String>, val org: String) : Item()
        class Phone(val number: String) : Item()
        class Email(val address: String) : Item()
        class Place(val lat: Double, val lon: Double) : Item()
        class Text(val text: String) : Item()
    }

    fun parse(raw: String): Item {
        val s = raw.trim()
        val low = s.lowercase()
        return when {
            low.startsWith("upi://") -> upi(s)
            low.startsWith("http://") || low.startsWith("https://") -> Item.Link(s)
            low.startsWith("www.") -> Item.Link("https://$s")
            low.startsWith("wifi:") -> Item.Wifi(field(s.substring(5), "S"), field(s.substring(5), "T").ifEmpty { "nopass" })
            low.startsWith("begin:vcard") -> vcard(s)
            low.startsWith("mecard:") -> mecard(s.substring(7))
            low.startsWith("tel:") -> Item.Phone(s.substring(4))
            low.startsWith("mailto:") -> Item.Email(s.substring(7).substringBefore('?'))
            low.startsWith("smsto:") || low.startsWith("sms:") -> Item.Phone(s.substringAfter(':').substringBefore(':'))
            low.startsWith("geo:") -> s.substring(4).substringBefore('?').split(',').let { p ->
                val lat = p.getOrNull(0)?.toDoubleOrNull()
                val lon = p.getOrNull(1)?.toDoubleOrNull()
                if (lat != null && lon != null) Item.Place(lat, lon) else Item.Text(s)
            }
            else -> Item.Text(s)
        }
    }

    /** One or two spoken sentences; [question] is asked when an action is possible. */
    fun describe(item: Item): Pair<String, String?> = when (item) {
        is Item.Link -> "It's a link to ${host(item.url)}." to "Shall I open it?"
        is Item.Upi -> buildString {
            append("It's a UPI payment code")
            if (item.payee.isNotBlank()) append(" for ${item.payee}")
            if (item.id.isNotBlank()) append(", UPI ID ${item.id}")
            if (item.amount.isNotBlank()) append(", asking for ${item.amount} rupees")
            if (item.note.isNotBlank()) append(", note: ${item.note}")
            append(". I only read payment codes; pay from your UPI app if you want to.")
        } to null
        is Item.Wifi -> "It's the Wi-Fi network ${item.ssid.ifBlank { "with no name" }}" +
            (if (item.security.equals("nopass", true)) ", with no password." else ", with its password. Scan it with the phone's camera to join.") to null
        is Item.Contact -> buildString {
            append("It's a contact card for ${item.name.ifBlank { "someone" }}")
            if (item.org.isNotBlank()) append(" at ${item.org}")
            item.phones.firstOrNull()?.let { append(", phone ${spaced(it)}") }
            item.emails.firstOrNull()?.let { append(", email $it") }
            append(".")
        } to "Shall I add it to your contacts?"
        is Item.Phone -> "It's the phone number ${spaced(item.number)}." to "Shall I add it to your contacts?"
        is Item.Email -> "It's the email address ${item.address}." to null
        is Item.Place -> "It's a map location." to "Shall I open it in maps?"
        is Item.Text -> "It says: ${item.text.take(300)}" to null
    }

    fun host(url: String): String =
        url.substringAfter("://").substringBefore('/').substringBefore('?').removePrefix("www.").ifEmpty { url }

    /** "+91 98765 43210" -> "98765 43210" so it is read as digits in groups, not as one huge number. */
    fun spaced(n: String): String {
        var d = n.filter { it.isDigit() }
        if (d.length == 12 && d.startsWith("91")) d = d.drop(2)
        if (d.length == 11 && d.startsWith("0")) d = d.drop(1)
        return if (d.length == 10) "${d.take(5)} ${d.drop(5)}" else d.chunked(3).joinToString(" ")
    }

    private fun upi(s: String): Item.Upi {
        val q = s.substringAfter('?', "").split('&').associate { kv ->
            val k = kv.substringBefore('=').lowercase()
            val v = try { URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8") } catch (_: Exception) { kv.substringAfter('=', "") }
            k to v.trim()
        }
        val amount = q["am"].orEmpty().let { a -> a.toDoubleOrNull()?.let { if (it == Math.floor(it)) it.toLong().toString() else a } ?: "" }
        return Item.Upi(q["pn"].orEmpty(), q["pa"].orEmpty(), amount, q["tn"].orEmpty())
    }

    /** "S:Home;T:WPA;P:secret;;" -> field("S") = "Home" (backslash escapes kept simple). */
    private fun field(body: String, key: String): String {
        var i = 0
        while (i < body.length) {
            val end = nextSemicolon(body, i)
            val part = body.substring(i, end)
            if (part.startsWith("$key:")) return part.substring(key.length + 1).replace("\\;", ";").replace("\\:", ":").replace("\\\\", "\\")
            i = end + 1
        }
        return ""
    }

    private fun nextSemicolon(s: String, from: Int): Int {
        var i = from
        while (i < s.length) {
            if (s[i] == '\\') i += 2 else if (s[i] == ';') return i else i++
        }
        return s.length
    }

    private fun mecard(body: String): Item.Contact {
        val n = field(body, "N")
        val name = if (n.contains(',')) n.substringAfter(',').trim() + " " + n.substringBefore(',').trim() else n
        val phones = ArrayList<String>()
        val emails = ArrayList<String>()
        var i = 0
        while (i < body.length) {
            val end = nextSemicolon(body, i)
            val part = body.substring(i, end)
            if (part.startsWith("TEL:")) phones.add(part.substring(4))
            if (part.startsWith("EMAIL:")) emails.add(part.substring(6))
            i = end + 1
        }
        return Item.Contact(name.trim(), phones, emails, field(body, "ORG"))
    }

    private fun vcard(s: String): Item.Contact {
        var name = ""
        var org = ""
        val phones = ArrayList<String>()
        val emails = ArrayList<String>()
        for (line in s.lines()) {
            val key = line.substringBefore(':').substringBefore(';').uppercase()
            val v = line.substringAfter(':', "").trim()
            when (key) {
                "FN" -> name = v
                "N" -> if (name.isEmpty()) name = v.split(';').let { p -> listOfNotNull(p.getOrNull(1), p.getOrNull(0)).joinToString(" ").trim() }
                "TEL" -> phones.add(v)
                "EMAIL" -> emails.add(v)
                "ORG" -> org = v.replace(';', ' ').trim()
            }
        }
        return Item.Contact(name, phones, emails, org)
    }
}
