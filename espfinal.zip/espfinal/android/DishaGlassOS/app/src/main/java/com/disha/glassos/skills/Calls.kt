@file:Suppress("DEPRECATION")  // PhoneStateListener: only used below Android 12

package com.disha.glassos.skills

import android.Manifest
import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import com.disha.glassos.util.AppLog

/**
 * Incoming calls by voice: who is calling (from the dialer's notification, through notification
 * access), answer and reject (Android's call controls with the user's "phone calls" permission,
 * or the notification's own buttons).
 */
class Calls(context: Context, private val onRinging: (caller: String) -> Unit) {

    private val appContext = context.applicationContext
    private val tm = appContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val main = Handler(Looper.getMainLooper())
    private var callback: Any? = null

    @Volatile var ringing = false
        private set

    fun canWatch() = has(Manifest.permission.READ_PHONE_STATE)

    fun canControl() = Build.VERSION.SDK_INT >= 26 && has(Manifest.permission.ANSWER_PHONE_CALLS)

    private fun has(p: String) = Build.VERSION.SDK_INT < 23 || appContext.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (callback != null || !canWatch()) return
        try {
            if (Build.VERSION.SDK_INT >= 31) startModern() else startLegacy()
        } catch (e: Exception) {
            AppLog.w("Calls", "Can't watch calls: ${e.message}")
        }
    }

    @TargetApi(31)
    @SuppressLint("MissingPermission")
    private fun startModern() {
        val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
            override fun onCallStateChanged(state: Int) = changed(state)
        }
        tm.registerTelephonyCallback(appContext.mainExecutor, cb)
        callback = cb
    }

    @Suppress("DEPRECATION")
    private fun startLegacy() {
        val l = object : PhoneStateListener() {
            @Deprecated("Deprecated in Java")
            override fun onCallStateChanged(state: Int, phoneNumber: String?) = changed(state)
        }
        tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
        callback = l
    }

    fun stop() {
        val c = callback ?: return
        try {
            if (Build.VERSION.SDK_INT >= 31 && c is TelephonyCallback) tm.unregisterTelephonyCallback(c)
            else @Suppress("DEPRECATION") tm.listen(c as PhoneStateListener, PhoneStateListener.LISTEN_NONE)
        } catch (_: Exception) {
        }
        callback = null
    }

    private fun changed(state: Int) {
        val now = state == TelephonyManager.CALL_STATE_RINGING
        if (now && !ringing) {
            ringing = true
            // The dialer's notification (with the caller's name) arrives a moment after the ring.
            main.postDelayed({ if (ringing) onRinging(callerName()) }, 900)
        } else if (!now) {
            ringing = false
        }
    }

    fun callerName(): String = MessageCenter.call?.caller ?: "an unknown caller"

    @SuppressLint("MissingPermission")
    fun answer(): String {
        if (!ringing) return "There's no call ringing."
        try {
            if (canControl()) {
                @Suppress("DEPRECATION")
                (appContext.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
                return "Answering."
            }
            MessageCenter.call?.answer?.send()?.let { return "Answering." }
        } catch (e: Exception) {
            AppLog.w("Calls", "Answer failed: ${e.message}")
        }
        return "I can't answer calls yet. Allow call control in Settings."
    }

    @SuppressLint("MissingPermission")
    fun reject(): String {
        if (!ringing) return "There's no call ringing."
        try {
            if (Build.VERSION.SDK_INT >= 28 && canControl()) {
                @Suppress("DEPRECATION")
                if ((appContext.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()) return "Call rejected."
            }
            MessageCenter.call?.decline?.send()?.let { return "Call rejected." }
        } catch (e: Exception) {
            AppLog.w("Calls", "Reject failed: ${e.message}")
        }
        return "I can't reject calls yet. Allow call control in Settings."
    }
}
