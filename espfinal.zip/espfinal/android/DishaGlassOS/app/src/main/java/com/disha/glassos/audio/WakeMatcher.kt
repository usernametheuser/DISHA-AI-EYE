package com.disha.glassos.audio

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min

/**
 * Recognises the user's own wake phrases ("Disha", "Hello Disha", "Hi Disha") by comparing the
 * start of a spoken segment with recordings of the user saying them (dynamic time warping on MFCC
 * features with energy and deltas). Works on the phone, with no network and nothing to download;
 * it is tuned to the voice that recorded the samples. The segment may go on after the phrase
 * ("Disha, take a photo"): only its start is compared.
 *
 * This is a fast first check that catches the phrase readily; for a short name it also lets
 * through some similar-sounding speech, so unclear matches are confirmed by the speech service.
 * Pure logic, unit-tested on the PC.
 *
 * samples: recordings; groups: which phrase each recording is (same number = same phrase).
 */
class WakeMatcher(samples: List<ShortArray>, groups: List<Int>? = null, sensitivity: Float = 1f) {

    companion object {
        const val MIN_SAMPLES = 3

        /** Feature options chosen by tests on a 30-phrase "sh"-heavy decoy set. */
        private const val ENERGY = true
        private const val DELTAS = 2f

        /** Bounds for the personal threshold factor (times the spread between the user's samples). */
        private const val MIN_FACTOR = 1.5f
        private const val MAX_FACTOR = 3.0f

        /**
         * Working range of the threshold for these features, whatever the recordings say: very
         * consistent recordings must not make it too strict, sloppy ones not too loose. Measured
         * on synthetic speech (names at +-20 % speed and +-12 % pitch, four noise levels).
         */
        const val MIN_THRESHOLD = 1.9f
        const val MAX_THRESHOLD = 2.6f

        fun features(pcm: ShortArray, from: Int, to: Int) = Mfcc.features(pcm, from, to, cmn = false, energy = ENERGY, deltas = DELTAS)

        /**
         * Average per-step distance of the best alignment of [t] (template) with [x]. openEnd: x may be
         * longer; the alignment may stop anywhere between 0.6x and 1.7x the template length.
         */
        fun dtw(t: Array<FloatArray>, x: Array<FloatArray>, openEnd: Boolean): Float {
            val n = t.size
            val m = if (openEnd) min(x.size, ceil(n * 1.7).toInt()) else x.size
            if (n == 0 || m == 0) return NO_MATCH
            val inf = Float.MAX_VALUE / 4
            var prev = FloatArray(m) { inf }
            var cur = FloatArray(m) { inf }
            for (i in 0 until n) {
                // Slope limits: the input runs between half and twice the template's speed.
                val lo = maxOf(0, floor(i * 0.5).toInt() - 2)
                val hi = min(m - 1, ceil(i * 2.0).toInt() + 2)
                cur.fill(inf)
                for (j in lo..hi) {
                    val d = Mfcc.distance(t[i], x[j])
                    cur[j] = when {
                        i == 0 && j == 0 -> 2 * d
                        else -> minOf(
                            if (i > 0 && j > 0) prev[j - 1] + 2 * d else inf,
                            if (i > 0) prev[j] + d else inf,
                            if (j > 0) cur[j - 1] + d else inf,
                        )
                    }
                }
                val tmp = prev
                prev = cur
                cur = tmp
            }
            // prev = last template row. Normalise by the path's weight (n + j + 1).
            if (!openEnd) return if (prev[m - 1] >= inf) NO_MATCH else prev[m - 1] / (n + m)
            var best = NO_MATCH
            val from = maxOf(0, floor(n * 0.6).toInt() - 1)
            for (j in from until m) if (prev[j] < inf) best = minOf(best, prev[j] / (n + j + 1))
            return best
        }

        /** Score of something that cannot be the phrase at all. */
        const val NO_MATCH = 1e6f
    }

    private val templates: List<Array<FloatArray>>
    private val groupOf: List<Int>

    init {
        val kept = ArrayList<Array<FloatArray>>()
        val g = ArrayList<Int>()
        samples.forEachIndexed { i, pcm ->
            val b = Mfcc.speechBounds(pcm)
            val f = features(pcm, b[0], b[1])
            if (f.size >= 20) {  // at least 0.2 s of speech
                kept.add(f)
                g.add(groups?.getOrNull(i) ?: 0)
            }
        }
        templates = kept
        groupOf = g
    }

    /** Sample lengths in audio samples: how much of a segment's start is compared. */
    private val maxTemplateSamples = templates.maxOfOrNull { it.size }?.let { it * Mfcc.HOP + Mfcc.WINDOW } ?: 0
    private val minTemplateSamples = templates.minOfOrNull { it.size }?.let { it * Mfcc.HOP + Mfcc.WINDOW } ?: 0

    /** How long the longest phrase takes the user to say, in milliseconds. */
    val phraseMs: Int = maxTemplateSamples * 1000 / Mfcc.RATE

    /** Average distance between recordings of the same phrase (lower = said more consistently). */
    val spread: Float = run {
        fun pairs(sameGroupOnly: Boolean): List<Float> {
            val d = ArrayList<Float>()
            for (a in templates.indices) for (b in templates.indices) {
                if (a >= b || (sameGroupOnly && groupOf[a] != groupOf[b])) continue
                val ab = dtw(templates[a], templates[b], false)
                val ba = dtw(templates[b], templates[a], false)
                if (ab < NO_MATCH && ba < NO_MATCH) d.add((ab + ba) / 2)
            }
            return d
        }
        val same = pairs(true)
        val d = same.ifEmpty { pairs(false) }
        if (d.isEmpty()) 0f else d.average().toFloat()
    }

    /**
     * Personal factor: each recording is scored as if it were heard live, against the others; the
     * threshold must let all of them through with some margin. Real voices vary more than the
     * spread alone shows, so this adapts the threshold to how the user actually speaks.
     */
    val factor: Float = run {
        if (templates.size < 2 || spread <= 0f) return@run MIN_FACTOR
        var worst = 0f
        for (i in templates.indices) {
            val s = templates.indices.filter { it != i }.minOf { dtw(templates[it], templates[i], openEnd = true) }
            if (s < NO_MATCH) worst = maxOf(worst, s / spread)
        }
        (worst * 1.25f).coerceIn(MIN_FACTOR, MAX_FACTOR)
    }

    val threshold: Float = (spread * factor).coerceIn(MIN_THRESHOLD, MAX_THRESHOLD) * sensitivity

    val ready: Boolean get() = templates.size >= MIN_SAMPLES && spread > 0f

    /** Lowest distance of the segment's start to any recording (lower = more alike). */
    fun score(pcm: ShortArray, from: Int = 0, to: Int = pcm.size): Float {
        if (!ready) return NO_MATCH
        val b = Mfcc.speechBounds(pcm, from, to)
        val end = min(b[1], b[0] + (maxTemplateSamples * 1.7f).toInt())
        if (end - b[0] < minTemplateSamples * 0.55f) return NO_MATCH  // far too short to be the phrase
        val x = features(pcm, b[0], end)
        return templates.minOf { dtw(it, x, openEnd = true) }
    }

    fun matches(pcm: ShortArray, from: Int = 0, to: Int = pcm.size) = score(pcm, from, to) <= threshold
}
