package com.disha.glassos.assistant

import java.util.Locale

/**
 * Understands spoken durations and times for timers and reminders ("5 minutes", "an hour and a
 * half", "remind me at 6:30 pm to call mom"). Pure logic, unit-tested on the PC.
 */
object TimeParse {

    class Reminder(val seconds: Int, val text: String)

    private val units = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
        "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19,
    )
    private val tens = mapOf("twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "ninety" to 90)
    private val spaces = Regex("\\s+")
    private val unitPattern = "hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s"
    private val amount = Regex("(\\d+(?:\\.\\d+)?)(\\s+and\\s+a\\s+half)?\\s*($unitPattern)\\b(\\s+and\\s+a\\s+half)?")
    private val clock = Regex("\\bat\\s+(\\d{1,2})(?:[:.](\\d{2})|\\s+(\\d{2}))?\\s*(am|pm)?\\b")

    /** Lower case, digits instead of number words, "a"/"an" before a unit as 1, "p.m." as "pm". */
    fun normalize(text: String): String {
        var s = " " + text.lowercase(Locale.US)
            .replace(Regex("\\b([ap])\\.?\\s?m\\b\\.?"), "$1m")
            .replace(Regex("[^a-z0-9:.' ]"), " ")
            .replace(Regex("(?<!\\d)\\.|\\.(?!\\d)"), " ")  // keep "7.15", drop sentence full stops
            .replace(spaces, " ").trim() + " "
        // "forty five" -> 45, "twenty" -> 20, "seven" -> 7
        for ((t, tv) in tens) {
            for ((u, uv) in units) if (uv in 1..9) s = s.replace(" $t $u ", " ${tv + uv} ").replace(" $t-$u ", " ${tv + uv} ")
            s = s.replace(" $t ", " $tv ")
        }
        for ((u, uv) in units) s = s.replace(" $u ", " $uv ")
        // Before "an hour" -> "1 hour", or "half an hour" would become "half 1 hour".
        s = s.replace(" half an hour ", " 30 minutes ").replace(" half hour ", " 30 minutes ")
            .replace(" quarter of an hour ", " 15 minutes ").replace(" a quarter hour ", " 15 minutes ")
        s = s.replace(Regex(" (?:a|an) (?=($unitPattern) )"), " 1 ")
        return s.replace(spaces, " ").trim()
    }

    /** Total seconds of all durations in the sentence, or null if there is none. */
    fun durationSeconds(text: String): Int? {
        val s = normalize(text)
        var total = 0.0
        var found = false
        for (m in amount.findAll(s)) {
            val unit = m.groupValues[3]
            var n = m.groupValues[1].toDouble()
            if (m.groupValues[2].isNotEmpty() || m.groupValues[4].isNotEmpty()) n += 0.5
            total += n * when {
                unit.startsWith("h") -> 3600
                unit.startsWith("m") -> 60
                else -> 1
            }
            found = true
        }
        return if (found && total >= 1) total.toInt() else null
    }

    /**
     * Seconds from now until a spoken clock time ("at 6 pm", "at 18:30", "at 7.15"), or null.
     * nowMinute = minutes since midnight. Without am/pm, the next matching time within 12 hours is used.
     */
    fun secondsUntilClock(text: String, nowMinute: Int): Int? {
        val m = clock.find(normalize(text)) ?: return null
        val hour = m.groupValues[1].toInt()
        val minute = (m.groupValues[2].ifEmpty { m.groupValues[3] }).ifEmpty { "0" }.toInt()
        val ampm = m.groupValues[4]
        if (hour > 23 || minute > 59) return null
        val candidates = when {
            ampm == "am" -> listOf(if (hour == 12) 0 else hour)
            ampm == "pm" -> listOf(if (hour == 12) 12 else hour + 12)
            hour <= 12 -> listOf(hour % 12, hour % 12 + 12)  // "at 6" = 6:00 or 18:00, whichever comes first
            else -> listOf(hour)
        }.map { it * 60 + minute }
        val waitMinutes = candidates.map { ((it - nowMinute) % 1440 + 1440) % 1440 }.filter { it > 0 }.minOrNull() ?: 1440
        return waitMinutes * 60
    }

    /** "remind me in 10 minutes to call mom" / "remind me to call mom at 6 pm" -> when and what. */
    fun reminder(text: String, nowMinute: Int): Reminder? {
        val s = text.trim()
        val low = s.lowercase(Locale.US)
        val at = low.indexOf("remind me")
        if (at < 0) return null
        val rest = s.substring(at + "remind me".length).trim()
        // "at 6 pm to stretch for 5 minutes": a time said first wins over a duration later on.
        val seconds = (if (rest.startsWith("at ", ignoreCase = true)) {
            secondsUntilClock(rest, nowMinute) ?: durationSeconds(rest)
        } else {
            durationSeconds(rest) ?: secondsUntilClock(rest, nowMinute)
        }) ?: return null
        // What to say: the part after "to"/"that"/"about", without the time phrase.
        var what = Regex("(?i)^(?:in|after)\\s+.+?\\s+(?:to|that|about)\\s+(.+)$").find(rest)?.groupValues?.get(1)
            ?: Regex("(?i)^(?:to|that|about)\\s+(.+)$").find(rest)?.groupValues?.get(1)
            ?: Regex("(?i)^at\\s+.+?\\s+(?:to|that|about)\\s+(.+)$").find(rest)?.groupValues?.get(1)
            ?: ""
        what = what.replace(Regex("(?i)\\s+(?:in|after)\\s+[\\w\\s.]+?(?:hours?|minutes?|mins?|seconds?|secs?)\\s*$"), "")
            .replace(Regex("(?i)\\s+at\\s+\\d{1,2}(?:[:.]\\d{2})?\\s*(?:[ap]\\.?\\s?m\\.?)?\\s*$"), "")
            .trim().trimEnd('.', '!', '?')
        return Reminder(seconds, what)
    }

    /** "5 minutes", "1 hour and 30 minutes", "45 seconds" for speaking. */
    fun describe(seconds: Int): String {
        val h = seconds / 3600
        val m = seconds % 3600 / 60
        val s = seconds % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add(if (h == 1) "1 hour" else "$h hours")
        if (m > 0) parts.add(if (m == 1) "1 minute" else "$m minutes")
        if (s > 0 && h == 0) parts.add(if (s == 1) "1 second" else "$s seconds")
        return if (parts.isEmpty()) "0 seconds" else parts.joinToString(" and ")
    }
}
