package com.disha.glassos.skills

import android.content.Context
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * A small list of timestamped notes kept in the app's private storage on the phone (things seen,
 * photo captions, documents, places, events). Oldest entries are dropped past [max]. Thread-safe.
 * Several objects may use the same file (the service, Settings' restore): each re-reads it when
 * the file changed since it last read or wrote it.
 */
class EntryStore(context: Context, name: String, private val max: Int) {

    /** text: what it says; ref: where the thing is (file, path); extra: anything else (place, title). */
    class Entry(val time: Long, val text: String, val ref: String = "", val extra: String = "")

    companion object {
        /** Entries of a store file's contents; throws if it is not one. */
        fun parse(json: String): List<Entry> {
            val list = ArrayList<Entry>()
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(Entry(o.optLong("t"), o.optString("x"), o.optString("r"), o.optString("e")))
            }
            return list
        }
    }

    private val file = File(context.applicationContext.filesDir, "$name.json")
    private var cache: MutableList<Entry>? = null
    private var stamp = 0L

    @Synchronized
    fun all(): List<Entry> = load().toList()

    @Synchronized
    fun add(e: Entry) {
        val list = load()
        list.add(e)
        while (list.size > max) list.removeAt(0)
        save(list)
    }

    @Synchronized
    fun last(): Entry? = load().lastOrNull()

    @Synchronized
    fun clear() {
        cache = ArrayList()
        file.delete()
        stamp = 0L
    }

    /** Adds entries (from a backup) that are not here yet; returns how many were new. */
    @Synchronized
    fun merge(entries: List<Entry>): Int {
        val list = load()
        val have = list.mapTo(HashSet()) { it.time to it.text }
        val new = entries.filter { have.add(it.time to it.text) }
        if (new.isEmpty()) return 0
        list.addAll(new)
        list.sortBy { it.time }
        while (list.size > max) list.removeAt(0)
        save(list)
        return new.size
    }

    /** For the search helpers. */
    fun items(): List<TextSearch.Item> = all().map { TextSearch.Item(it.time, it.text + if (it.extra.isNotEmpty()) " (${it.extra})" else "", it.ref) }

    private fun load(): MutableList<Entry> {
        cache?.let { if (file.lastModified() == stamp) return it }
        val list = ArrayList<Entry>()
        try {
            if (file.exists()) list.addAll(parse(file.readText()))
        } catch (e: Exception) {
            AppLog.w("Store", "${file.name} unreadable: ${e.message}")
        }
        cache = list
        stamp = file.lastModified()
        return list
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("t", e.time).put("x", e.text).put("r", e.ref).put("e", e.extra))
        try {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        } catch (e: Exception) {
            AppLog.w("Store", "Saving ${file.name} failed: ${e.message}")
        }
        stamp = file.lastModified()
    }
}
