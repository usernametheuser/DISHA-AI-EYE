package com.disha.glassos.ai

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.util.AppLog
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.Executors

/**
 * Free speech-to-text with no API key: Whisper on OVHcloud AI Endpoints (OpenAI-compatible
 * /audio/transcriptions, anonymous). Two models, about 2 requests per minute each from one internet
 * connection; busy models are skipped using the service's retry-after / ratelimit-* headers.
 * Used only after the user allowed sending voice in Settings. With a boost key (Settings), that
 * service's Whisper is tried first: much faster and with higher limits. Callbacks run on the main thread.
 */
class FreeSpeechClient(private val settings: AppSettings? = null) {

    sealed class Result {
        /** text is empty if nothing was recognised; language (ISO 639-1) when it was asked for. */
        class Text(val text: String, val language: String? = null) : Result()
        class Failure(val message: String) : Result()
    }

    private companion object {
        const val TAG = "FreeSTT"
        const val URL_TRANSCRIBE = "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/audio/transcriptions"
        const val CONNECT_TIMEOUT_MS = 10000
        const val READ_TIMEOUT_MS = 30000
        const val MAX_WAIT_MS = 12000L
        const val BUSY_DEFAULT_MS = 60000L
        const val ERROR_COOLDOWN_MS = 20000L
        const val GONE_COOLDOWN_MS = 10 * 60000L

        /** Both answered a test sentence correctly without a key (tested 2026-10-10). */
        val MODELS = listOf("whisper-large-v3-turbo", "whisper-large-v3")
    }

    private sealed class Outcome {
        class Done(val text: String, val language: String?) : Outcome()
        class Skip(val reason: String, val coolMs: Long) : Outcome()
        class Stop(val message: String) : Outcome()
    }

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-stt").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())
    private val coolUntil = HashMap<String, Long>()  // executor thread only

    /**
     * language: ISO 639-1 code ("en", "hi") or null to detect it. withLanguage: also report the
     * language that was spoken (for the translator).
     */
    fun transcribe(wav: ByteArray, language: String?, withLanguage: Boolean = false, callback: (Result) -> Unit) {
        executor.execute {
            val result = walk(wav, language, withLanguage)
            main.post { callback(result) }
        }
    }

    /** Whisper's language names ("hindi") or codes ("hi") -> ISO 639-1. */
    private fun languageCode(s: String?): String? {
        val l = s?.trim()?.lowercase() ?: return null
        if (l.isEmpty()) return null
        if (l.length <= 3) return l.take(2)
        return mapOf(
            "english" to "en", "hindi" to "hi", "urdu" to "ur", "bengali" to "bn", "tamil" to "ta", "telugu" to "te", "marathi" to "mr",
            "gujarati" to "gu", "kannada" to "kn", "malayalam" to "ml", "punjabi" to "pa", "nepali" to "ne", "french" to "fr",
            "german" to "de", "spanish" to "es", "japanese" to "ja", "chinese" to "zh", "arabic" to "ar", "russian" to "ru",
        )[l]
    }

    private fun walk(wav: ByteArray, language: String?, withLanguage: Boolean): Result {
        settings?.let { Boost.endpoint(it) }?.takeIf { it.speechModel.isNotBlank() }?.let { b ->
            val key = "boost:${b.speechModel}"
            if (remainingMs(key) == 0L) {
                when (val o = askModel(b.speechModel, wav, language, withLanguage, "${b.base}/audio/transcriptions", b.key)) {
                    is Outcome.Done -> return Result.Text(o.text, o.language)
                    is Outcome.Skip -> {
                        AppLog.w(TAG, "${b.label} speech: ${o.reason}; using the free service")
                        if (o.coolMs > 0) coolUntil[key] = SystemClock.elapsedRealtime() + o.coolMs
                    }
                    is Outcome.Stop -> return Result.Failure(o.message)
                }
            }
        }
        val tried = LinkedHashMap<String, String>()
        for (round in 0 until 2) {
            if (round > 0) {
                val wait = MODELS.minOf { remainingMs(it) }
                if (wait > MAX_WAIT_MS) break
                AppLog.i(TAG, "Both speech models busy; waiting ${wait / 1000} s")
                SystemClock.sleep(wait + 300)
            }
            for (model in MODELS) {
                if (remainingMs(model) > 0) {
                    tried.putIfAbsent(model, "busy")
                    continue
                }
                when (val o = askModel(model, wav, language, withLanguage, URL_TRANSCRIBE, null)) {
                    is Outcome.Done -> return Result.Text(o.text, o.language)
                    is Outcome.Stop -> return Result.Failure(o.message)
                    is Outcome.Skip -> {
                        tried[model] = o.reason
                        if (o.coolMs > 0) coolUntil[model] = SystemClock.elapsedRealtime() + o.coolMs
                    }
                }
            }
        }
        AppLog.w(TAG, "No speech model answered: " + tried.entries.joinToString("; ") { "${it.key}: ${it.value}" })
        return Result.Failure(
            when {
                tried.values.all { it == "busy" } -> "The free speech service is busy. It allows about four requests a minute. Try again in a minute."
                tried.values.any { it == "needs a key" } -> "The free speech service now asks for a key. Switch speech recognition to the phone's service in Settings."
                else -> "The free speech service couldn't understand the recording right now. Try again."
            },
        )
    }

    private fun askModel(model: String, wav: ByteArray, language: String?, withLanguage: Boolean, url: String, key: String?): Outcome {
        val started = SystemClock.elapsedRealtime()
        val boundary = "disha" + System.nanoTime()
        val body = ByteArrayOutputStream(wav.size + 1024)
        fun field(name: String, value: String) {
            body.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
        }
        field("model", model)
        field("response_format", if (withLanguage) "verbose_json" else "json")
        field("temperature", "0")
        if (language != null) field("language", language)
        body.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray())
        body.write(wav)
        body.write("\r\n--$boundary--\r\n".toByteArray())

        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.doOutput = true
            c.setRequestProperty("Accept", "application/json")
            if (key != null) c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.setFixedLengthStreamingMode(body.size())
            c.outputStream.use { body.writeTo(it) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            val ms = SystemClock.elapsedRealtime() - started
            fun header(name: String) = c.getHeaderField(name)?.trim()?.toLongOrNull()
            return when {
                code == 200 -> {
                    if (header("ratelimit-remaining") == 0L) {
                        coolUntil[model] = SystemClock.elapsedRealtime() + (header("ratelimit-reset")?.coerceIn(1, 3600) ?: 60) * 1000
                    }
                    val json = try {
                        JSONObject(text)
                    } catch (_: JSONException) {
                        return Outcome.Skip("unreadable answer", 0)
                    }
                    val heard = json.optString("text").trim()
                    val lang = languageCode(json.optString("language"))
                    AppLog.i(TAG, "$model: ${heard.length} characters in $ms ms" + (lang?.let { " ($it)" } ?: ""))
                    Outcome.Done(heard, lang)
                }
                code == 429 -> {
                    val wait = (header("retry-after") ?: header("ratelimit-reset"))?.coerceIn(1, 3600)?.times(1000) ?: BUSY_DEFAULT_MS
                    AppLog.i(TAG, "$model busy for ${wait / 1000} s")
                    Outcome.Skip("busy", wait)
                }
                code == 401 || code == 403 -> Outcome.Skip(if (key != null) "the key was refused" else "needs a key", GONE_COOLDOWN_MS)
                code in 400..499 -> {
                    AppLog.w(TAG, "$model: HTTP $code: ${text.take(300)}")
                    Outcome.Skip("rejected ($code)", GONE_COOLDOWN_MS)
                }
                else -> {
                    AppLog.w(TAG, "$model: HTTP $code after $ms ms")
                    Outcome.Skip("server error $code", ERROR_COOLDOWN_MS)
                }
            }
        } catch (e: UnknownHostException) {
            return Outcome.Stop("There's no internet connection, so I can't understand speech right now.")
        } catch (e: SocketTimeoutException) {
            AppLog.w(TAG, "$model: timed out")
            return Outcome.Skip("too slow", ERROR_COOLDOWN_MS)
        } catch (e: IOException) {
            AppLog.w(TAG, "$model: ${e.message}")
            return Outcome.Skip("network error", 0)
        } finally {
            c.disconnect()
        }
    }

    private fun remainingMs(model: String) = ((coolUntil[model] ?: 0L) - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
}
