package com.disha.glassos.audio

import android.content.Context
import android.content.Intent
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.view.KeyEvent

/**
 * Lets the earbuds' play/pause tap start the assistant (best effort).
 *
 * Android sends earbud button presses to the app that most recently played audio, so this works
 * while DISHA GLASS OS is open and was the last app to make a sound (the assistant's "listening"
 * beep counts). If a music app played after that, the tap goes to the music app instead.
 */
class EarbudButton(context: Context, private val onPress: () -> Unit) {

    private val session = MediaSession(context.applicationContext, "DishaAssistant")
    private val keys = setOf(
        KeyEvent.KEYCODE_HEADSETHOOK,
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
        KeyEvent.KEYCODE_MEDIA_PLAY,
        KeyEvent.KEYCODE_MEDIA_PAUSE,
    )

    init {
        session.setCallback(object : MediaSession.Callback() {
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                val ev = mediaButtonIntent.keyEvent() ?: return false
                if (ev.keyCode !in keys) return false
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) onPress()
                return true
            }
        })
        @Suppress("DEPRECATION")
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE)
                .setState(PlaybackState.STATE_PAUSED, 0, 1f)
                .build(),
        )
    }

    var enabled: Boolean
        get() = session.isActive
        set(value) {
            session.isActive = value
        }

    fun release() = session.release()
}

@Suppress("DEPRECATION")
private fun Intent.keyEvent(): KeyEvent? =
    if (Build.VERSION.SDK_INT >= 34) {
        getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
    } else {
        getParcelableExtra(Intent.EXTRA_KEY_EVENT)
    }
