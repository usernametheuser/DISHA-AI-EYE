package com.disha.glassos.ai

import java.util.Locale

/**
 * Tidies a speech-to-text result. Whisper sometimes "hears" stock phrases in noise (subtitle
 * credits, "thanks for watching"); those are dropped. Pure logic, unit-tested on the PC.
 */
object TranscriptCleaner {

    private val tags = Regex("\\[[^\\]]*]|\\([^)]*\\)|[♪♫*]")
    private val spaces = Regex("\\s+")
    private val phantoms = setOf(
        "you", "thanks for watching", "thank you for watching", "thanks for watching and see you next time",
        "please subscribe", "subscribe", "like and subscribe", "subtitles by the amara org community",
        "subtitles by", "transcribed by", "music",
    )

    /** The cleaned sentence, or null if nothing real was said. */
    fun clean(text: String): String? {
        val t = text.replace(tags, " ").replace(spaces, " ").trim()
        val key = t.lowercase(Locale.US).replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(spaces, " ").trim()
        if (key.isEmpty() || key in phantoms) return null
        return t
    }
}
