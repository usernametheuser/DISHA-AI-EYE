package com.disha.glassos.skills

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.disha.glassos.service.DishaService

/**
 * Live captions full screen: big white text on black, the translation in cyan under each
 * sentence, newest at the bottom. Turn the phone to the other person to show them the translation.
 */
class CaptionsActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var title: TextView
    private val refresh: () -> Unit = { show() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding((18 * dp).toInt(), (18 * dp).toInt(), (18 * dp).toInt(), (12 * dp).toInt())
        }
        title = TextView(this).apply {
            setTextColor(0xFF22D3EE.toInt())
            textSize = 13f
            letterSpacing = 0.15f
            isAllCaps = true
        }
        root.addView(title)
        scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val stop = Button(this).apply {
            text = "Stop"
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply { cornerRadius = 999f; setColor(0xFF1A1A1A.toInt()); setStroke((1 * dp).toInt(), 0xFF333333.toInt()) }
            setOnClickListener {
                DishaService.start(this@CaptionsActivity, DishaService.ACTION_COMMAND) { it.putExtra(DishaService.EXTRA_TEXT, "stop captions") }
                finish()
            }
        }
        root.addView(stop, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (52 * dp).toInt()).apply { topMargin = (8 * dp).toInt() })
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        CaptionBoard.listen(refresh)
        show()
    }

    override fun onStop() {
        CaptionBoard.unlisten(refresh)
        super.onStop()
    }

    private fun show() {
        title.text = CaptionBoard.mode.ifEmpty { "Captions off" }
        val lines = CaptionBoard.snapshot().takeLast(12)
        val dp = resources.displayMetrics.density
        list.removeAllViews()
        if (lines.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (CaptionBoard.mode.isEmpty()) "Say \"Disha, live captions\" or \"Disha, be my translator\"." else "Listening… speak normally."
                setTextColor(0xFF7C8BA1.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                setPadding(0, (24 * dp).toInt(), 0, 0)
            })
        }
        lines.forEachIndexed { i, l ->
            val newest = i == lines.size - 1
            list.addView(TextView(this).apply {
                text = l.text
                setTextColor(if (newest) Color.WHITE else 0xFFB8C2CF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (newest) 30f else 22f)
                setPadding(0, (14 * dp).toInt(), 0, 0)
            })
            l.translation?.let { t ->
                list.addView(TextView(this).apply {
                    text = t
                    setTextColor(0xFF22D3EE.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (newest) 30f else 22f)
                    gravity = Gravity.START
                })
            }
            if (newest) {
                list.getChildAt(list.childCount - 1).apply {
                    alpha = 0f
                    translationY = 16 * dp
                    animate().alpha(1f).translationY(0f).setDuration(240).start()
                }
            }
        }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        if (CaptionBoard.mode.isEmpty() && lines.isNotEmpty()) title.text = "Captions stopped"
    }

    companion object {
        fun intent(a: Activity) = Intent(a, CaptionsActivity::class.java)
    }
}
