package com.disha.glassos.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import com.disha.glassos.MainActivity
import com.disha.glassos.R
import com.disha.glassos.assistant.Reminders
import com.disha.glassos.assistant.TimeParse
import com.disha.glassos.core.DishaCore
import com.disha.glassos.util.AppLog

/**
 * Foreground service that owns [DishaCore], so the USB camera link, recording and the voice
 * assistant keep working with the screen off and the phone in a pocket.
 *
 * Types: connectedDevice (the USB glasses) and, once the microphone permission is granted,
 * microphone (listening with the screen off). The notification has Talk and Stop buttons.
 */
class DishaService : Service() {

    companion object {
        const val ACTION_TALK = "com.disha.glassos.action.TALK"
        const val ACTION_STOP = "com.disha.glassos.action.STOP"
        const val ACTION_REFRESH = "com.disha.glassos.action.REFRESH"
        const val ACTION_REMINDER = "com.disha.glassos.action.REMINDER"
        /** A typed command from another screen (captions Stop button), handled as if spoken. */
        const val ACTION_COMMAND = "com.disha.glassos.action.COMMAND"
        const val EXTRA_REMINDER_ID = "reminderId"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "disha"
        private const val CHANNEL_REMINDERS = "disha_reminders"
        private const val NOTIFICATION_ID = 1
        private const val TAG = "Service"

        fun start(context: Context, action: String? = null, extras: (Intent) -> Unit = {}) {
            val i = Intent(context, DishaService::class.java).setAction(action)
            extras(i)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }

    inner class LocalBinder : Binder() {
        val core: DishaCore get() = this@DishaService.core
    }

    private val binder = LocalBinder()
    lateinit var core: DishaCore
        private set
    private var shownText = ""

    override fun onCreate() {
        super.onCreate()
        createChannel()
        goForeground()
        core = DishaCore(this)
        core.onSummaryChanged = { updateNotification() }
        core.start()
        AppLog.i(TAG, "DISHA service started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()  // every start request must be answered with startForeground
        when (intent?.action) {
            ACTION_TALK -> core.assistant.onMicButton()
            ACTION_COMMAND -> intent.getStringExtra(EXTRA_TEXT)?.let { core.assistant.runText(it) }
            ACTION_REMINDER -> core.onReminderFired(intent.getIntExtra(EXTRA_REMINDER_ID, -1))?.let { showReminder(it) }
            ACTION_STOP -> {
                AppLog.i(TAG, "Stopped from the notification")
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        core.shutdown()
        AppLog.i(TAG, "DISHA service stopped")
        super.onDestroy()
    }

    private fun hasLocationPermission() = Build.VERSION.SDK_INT >= 23 &&
        (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)

    private fun hasMicPermission() =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun goForeground() {
        val notification = buildNotification(if (::core.isInitialized) core.summary() else "Starting…")
        if (Build.VERSION.SDK_INT >= 29) {
            val device = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            val mic = if (Build.VERSION.SDK_INT >= 30 && hasMicPermission()) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            // Location for SOS and the diary's places, once the user allowed it.
            val location = if (hasLocationPermission()) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
            // Android refuses microphone / location when the service is (re)started from the background:
            // step down one type at a time instead of losing all of them.
            val attempts = listOf(device or mic or location, device or mic, device).distinct()
            for ((i, types) in attempts.withIndex()) {
                try {
                    startForeground(NOTIFICATION_ID, notification, types)
                    if (i > 0) AppLog.w(TAG, "Running without some background abilities (location or screen-off listening) until the app is opened")
                    break
                } catch (e: Exception) {
                    if (i == attempts.lastIndex) AppLog.e(TAG, "Could not run in the foreground: ${e.message}")
                }
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL, "DISHA glasses", NotificationManager.IMPORTANCE_LOW)
        channel.description = "Shows that the glasses and the assistant are running"
        nm.createNotificationChannel(channel)
        val reminders = NotificationChannel(CHANNEL_REMINDERS, "Timers and reminders", NotificationManager.IMPORTANCE_HIGH)
        reminders.description = "Timers and reminders you set by voice (also spoken in the earbuds)"
        nm.createNotificationChannel(reminders)
    }

    /** Timers and reminders also appear (with sound) on the phone, in case the earbuds are out. */
    @Suppress("DEPRECATION")
    private fun showReminder(item: Reminders.Item) {
        val open = PendingIntent.getActivity(
            this, 3, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), pendingFlags(),
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_REMINDERS) else Notification.Builder(this)
        val text = when {
            item.isTimer -> (if (item.text.isNotEmpty()) "${item.text.replaceFirstChar { it.uppercase() }} timer" else "Timer") +
                " (${TimeParse.describe(item.seconds)}) is done"
            else -> item.text.ifEmpty { "Reminder" }
        }
        if (Build.VERSION.SDK_INT < 26) b.setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH)
        val n = b.setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(if (item.isTimer) "Timer" else "Reminder")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1000 + item.id % 100000, n)
    }

    private fun pendingFlags(): Int =
        if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else PendingIntent.FLAG_UPDATE_CURRENT

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), pendingFlags(),
        )
        val talk = PendingIntent.getService(this, 1, Intent(this, DishaService::class.java).setAction(ACTION_TALK), pendingFlags())
        val stop = PendingIntent.getService(this, 2, Intent(this, DishaService::class.java).setAction(ACTION_STOP), pendingFlags())
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        shownText = text
        return b.setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .addAction(R.drawable.ic_notify, "Talk", talk)
            .addAction(R.drawable.ic_notify, "Stop", stop)
            .build()
    }

    private fun updateNotification() {
        val text = core.summary()
        if (text == shownText) return
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification(text))
    }
}
