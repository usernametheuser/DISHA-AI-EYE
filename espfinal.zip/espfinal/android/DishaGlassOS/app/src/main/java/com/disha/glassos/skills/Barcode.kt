package com.disha.glassos.skills

/** Product barcodes (EAN-13, UPC-A, EAN-8) read from text, with the check digit verified. Pure logic. */
object Barcode {

    /** The first valid barcode in [text] (for example a model's reading "5 449000 000996"), or null. */
    fun find(text: String): String? {
        val digits = Regex("\\d[\\d\\s-]{6,20}\\d").findAll(text).map { it.value.filter(Char::isDigit) }
        for (d in digits) {
            when {
                d.length in setOf(8, 12, 13) && valid(d) -> return d
                d.length == 14 && valid(d) -> return d.drop(1)  // GTIN-14 with a leading packaging digit
            }
        }
        return null
    }

    /** GS1 check digit: from the right, weights 3,1,3,1... on all digits before the last. */
    fun valid(code: String): Boolean {
        if (code.isEmpty() || !code.all(Char::isDigit)) return false
        val body = code.dropLast(1)
        var sum = 0
        for ((i, c) in body.reversed().withIndex()) sum += (c - '0') * (if (i % 2 == 0) 3 else 1)
        return (10 - sum % 10) % 10 == code.last() - '0'
    }
}
