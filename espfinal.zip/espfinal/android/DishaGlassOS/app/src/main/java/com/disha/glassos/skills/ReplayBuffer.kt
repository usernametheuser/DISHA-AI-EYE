package com.disha.glassos.skills

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.disha.glassos.protocol.FrameAssembler
import com.disha.glassos.storage.AviWriter
import com.disha.glassos.storage.MediaSaver
import com.disha.glassos.util.AppLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Instant replay: while on, the last [SECONDS] seconds of the glasses' live view are kept in the
 * phone's memory (never written anywhere), so "Disha, save that" can keep a moment that already
 * happened, as a video in Movies/DISHA.
 */
class ReplayBuffer(context: Context) {

    companion object {
        const val SECONDS = 30
        const val FPS = 5
        private const val MAX_BYTES = 16L * 1024 * 1024  // about 30 s at 640x480; older frames go first
    }

    private class Shot(val at: Long, val frame: FrameAssembler.Frame)

    private val appContext = context.applicationContext
    private val frames = ArrayDeque<Shot>()
    private var bytes = 0L
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-replay").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var active = false
        private set

    fun start() {
        active = true
    }

    fun stop() {
        active = false
        synchronized(frames) {
            frames.clear()
            bytes = 0
        }
    }

    /** Seconds of picture kept right now. */
    fun keptSeconds(): Int = synchronized(frames) {
        if (frames.size < 2) 0 else ((frames.last().at - frames.first().at) / 1000).toInt()
    }

    /** Any thread: every frame from the glasses. */
    fun onFrame(frame: FrameAssembler.Frame) {
        if (!active) return
        val now = System.currentTimeMillis()
        synchronized(frames) {
            frames.addLast(Shot(now, frame))
            bytes += frame.data.size
            while (frames.isNotEmpty() && (now - frames.first().at > SECONDS * 1000L || bytes > MAX_BYTES)) {
                bytes -= frames.removeFirst().frame.data.size
            }
        }
    }

    /** Saves the last [seconds] as a video; done(sentence) on the main thread. */
    fun save(seconds: Int, done: (String) -> Unit) {
        val since = System.currentTimeMillis() - seconds.coerceIn(3, SECONDS) * 1000L
        val clip = synchronized(frames) { frames.filter { it.at >= since } }
        if (clip.size < 3) {
            done(if (!active) "Instant replay is off, so there's nothing to save. Say start instant replay, and I'll always keep the last 30 seconds."
            else "I don't have enough of the last moments yet. The live view needs a few seconds to fill the replay.")
            return
        }
        executor.execute {
            val sentence = try {
                // One size per file: the most common one (a picture for the AI may have used another).
                val size = clip.groupingBy { it.frame.width to it.frame.height }.eachCount().maxByOrNull { it.value }!!.key
                val use = clip.filter { (it.frame.width to it.frame.height) == size }
                val name = "DISHA_REPLAY_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.avi"
                val file = File(MediaSaver.recordingDir(appContext), name)
                val fps = ((use.size - 1) * 1000.0 / maxOf(1L, use.last().at - use.first().at)).toInt().coerceIn(1, 15)
                val w = AviWriter(file, size.first, size.second, fps)
                for (s in use) w.addFrame(s.frame.data, s.at)
                w.close()
                val where = MediaSaver.publishVideo(appContext, file)
                val secs = ((use.last().at - use.first().at) / 1000).coerceAtLeast(1)
                AppLog.i("Replay", "Saved $secs s (${use.size} frames) -> $where")
                "Saved the last $secs seconds in Movies, DISHA."
            } catch (e: Exception) {
                AppLog.e("Replay", "Saving failed: ${e.message}")
                "I couldn't save the replay: ${e.message}"
            }
            main.post { done(sentence) }
        }
    }
}
