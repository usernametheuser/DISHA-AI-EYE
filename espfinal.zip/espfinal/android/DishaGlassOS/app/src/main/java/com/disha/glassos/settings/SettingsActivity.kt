package com.disha.glassos.settings

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import com.disha.glassos.BuildConfig
import com.disha.glassos.R
import com.disha.glassos.ai.AiRouter
import com.disha.glassos.ai.VisionAi
import com.disha.glassos.assistant.MemoryStore
import com.disha.glassos.skills.MessageCenter
import com.disha.glassos.skills.Places
import com.disha.glassos.skills.Sos
import com.disha.glassos.audio.VoiceRecorder
import com.disha.glassos.audio.Wav
import com.disha.glassos.audio.WakeMatcher
import com.disha.glassos.audio.WakeSamples
import com.disha.glassos.protocol.DishaProtocol
import com.disha.glassos.storage.Backup
import com.disha.glassos.storage.BackupArchive
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings screen. Every change is saved immediately; the running service picks it up. */
class SettingsActivity : Activity() {

    companion object {
        const val EXTRA_FIRMWARE = "firmware"
        private const val REQ_MIC = 7
        private const val REQ_LOCATION = 8
        private const val REQ_CALLS = 9
        private const val REQ_SOS = 10
        private const val REQ_BACKUP_SAVE = 11
        private const val REQ_BACKUP_OPEN = 12
    }

    private lateinit var settings: AppSettings
    private lateinit var ai: AiRouter
    private lateinit var aiResult: TextView
    private lateinit var model: EditText
    private lateinit var consent: Switch
    private var showing = false  // true while the AI fields are being filled for a newly chosen provider

    private val gemini get() = settings.aiProvider == AppSettings.AiProvider.GEMINI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        settings = AppSettings(this)
        ai = AiRouter(settings)
        aiResult = findViewById(R.id.ai_result)

        // AI
        val key = findViewById<EditText>(R.id.edit_key)
        key.setText(settings.geminiKey)
        key.addTextChangedListener(onText { settings.geminiKey = it })
        model = findViewById(R.id.edit_model)
        model.addTextChangedListener(onText {
            if (showing) return@onText
            if (gemini) settings.geminiModel = it else settings.freeModel = it
        })
        findViewById<Button>(R.id.btn_find_models).setOnClickListener { findModels() }
        findViewById<Button>(R.id.btn_test_ai).setOnClickListener { testAi() }

        consent = findViewById(R.id.switch_consent)
        consent.setOnCheckedChangeListener { view, on ->
            if (showing) return@setOnCheckedChangeListener
            if (!on) {
                settings.aiImageConsent = false
                return@setOnCheckedChangeListener
            }
            if (settings.aiImageConsent) return@setOnCheckedChangeListener
            val (title, message) = if (gemini) {
                "Send camera pictures to Google?" to
                    "When you ask about what you see, DISHA sends one picture from the glasses and your question " +
                    "to Google Gemini. Nothing is sent unless you ask (or turn on watch mode). On the free tier " +
                    "Google may use this data to improve its products, so avoid private scenes."
            } else {
                "Send camera pictures to OVHcloud?" to
                    "When you ask about what you see, DISHA sends one picture from the glasses and your question " +
                    "to OVHcloud AI Endpoints (a French cloud company), without any account or key. Nothing is sent " +
                    "unless you ask (or turn on watch mode). It is a free public service, so avoid private scenes, " +
                    "documents and screens with personal details."
            }
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Allow") { _, _ -> settings.aiImageConsent = true }
                .setNegativeButton("Cancel") { _, _ -> view.isChecked = false }
                .setOnCancelListener { view.isChecked = false }
                .show()
        }

        val providers = AppSettings.AiProvider.entries
        spinner(R.id.spin_provider, providers.map { it.label }, settings.aiProvider.ordinal) {
            if (settings.aiProvider != providers[it]) {
                settings.aiProvider = providers[it]
                showProvider()
            }
        }
        showProvider()

        spinner(
            R.id.spin_ai_resolution, AppSettings.RESOLUTIONS.map { "${it.first} × ${it.second}" },
            AppSettings.RESOLUTIONS.indexOf(settings.aiResolution),
        ) { settings.aiResolution = AppSettings.RESOLUTIONS[it] }
        spinner(
            R.id.spin_watch, AppSettings.WATCH_CHOICES.map { it.second },
            AppSettings.WATCH_CHOICES.indexOfFirst { it.first == settings.watchSeconds },
        ) { settings.watchSeconds = AppSettings.WATCH_CHOICES[it].first }

        // Voice
        spinner(
            R.id.spin_language, AppSettings.LANGUAGES.map { it.second },
            AppSettings.LANGUAGES.indexOfFirst { it.first == settings.speechLanguage },
        ) { settings.speechLanguage = AppSettings.LANGUAGES[it].first }
        val engines = AppSettings.SpeechEngine.entries
        spinner(R.id.spin_speech_engine, engines.map { it.label }, settings.speechEngine.ordinal) {
            settings.speechEngine = engines[it]
        }
        val voiceConsent = findViewById<Switch>(R.id.switch_voice_consent)
        voiceConsent.isChecked = settings.voiceConsent
        voiceConsent.setOnCheckedChangeListener { view, on ->
            if (!on) {
                settings.voiceConsent = false
                return@setOnCheckedChangeListener
            }
            if (settings.voiceConsent) return@setOnCheckedChangeListener
            AlertDialog.Builder(this)
                .setTitle("Send your voice to OVHcloud?")
                .setMessage(
                    "When you talk to the assistant, the recording of what you say (a few seconds) is sent to the " +
                        "free Whisper speech recogniser on OVHcloud AI Endpoints (France), without any account or " +
                        "key, and only the text comes back. Nothing is sent while you are not talking to the assistant.",
                )
                .setPositiveButton("Allow") { _, _ ->
                    settings.voiceConsent = true
                    settings.voiceConsentAsked = true
                }
                .setNegativeButton("Cancel") { _, _ -> view.isChecked = false }
                .setOnCancelListener { view.isChecked = false }
                .show()
        }
        switch(R.id.switch_conversation, settings.conversationMode) { settings.conversationMode = it }
        findViewById<Button>(R.id.btn_record_wake).setOnClickListener { startEnrollment() }
        val wakeSwitch = findViewById<Switch>(R.id.switch_wake_enabled)
        wakeSwitch.isChecked = settings.wakeEnabled
        wakeSwitch.setOnCheckedChangeListener { _, on -> settings.wakeEnabled = on }
        val sens = AppSettings.WAKE_SENSITIVITY
        spinner(R.id.spin_wake_sensitivity, sens.map { it.second }, sens.indexOfFirst { it.first == settings.wakeSensitivity }) {
            settings.wakeSensitivity = sens[it].first
        }
        showWake()
        val assistantName = findViewById<EditText>(R.id.edit_assistant_name)
        assistantName.setText(settings.assistantName)
        assistantName.addTextChangedListener(onText { settings.assistantName = it })
        val userTitle = findViewById<EditText>(R.id.edit_user_title)
        userTitle.setText(settings.userTitle)
        userTitle.addTextChangedListener(onText { settings.userTitle = it })
        val styles = AppSettings.VoiceStyle.entries
        spinner(R.id.spin_voice_style, styles.map { it.label }, settings.voiceStyle.ordinal) { settings.voiceStyle = styles[it] }
        val rates = AppSettings.RATE_CHOICES
        spinner(R.id.spin_speech_rate, rates.map { it.second }, rates.indexOfFirst { it.first == settings.speechRate }) {
            settings.speechRate = rates[it].first
        }
        val homeCity = findViewById<EditText>(R.id.edit_home_city)
        homeCity.setText(settings.homeCity)
        homeCity.addTextChangedListener(onText { settings.homeCity = it })
        switch(R.id.switch_proactive, settings.proactiveAlerts) { settings.proactiveAlerts = it }
        showMemory()
        setupSkills()
        findViewById<Button>(R.id.btn_clear_memory).setOnClickListener {
            val count = MemoryStore(this).all().size
            if (count == 0) return@setOnClickListener
            AlertDialog.Builder(this)
                .setTitle("Clear memory?")
                .setMessage("This deletes all $count things you asked the assistant to remember. It can't be undone.")
                .setPositiveButton("Delete all") { _, _ ->
                    MemoryStore(this).clear()
                    showMemory()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        val speeds = AppSettings.SPEED_CHOICES
        spinner(R.id.spin_response_speed, speeds.map { it.second }, speeds.indexOfFirst { it.first == settings.endSilenceMs }) {
            settings.endSilenceMs = speeds[it].first
        }
        switch(R.id.switch_noise, settings.noiseReduction) { settings.noiseReduction = it }
        switch(R.id.switch_sounds, settings.sounds) { settings.sounds = it }
        switch(R.id.switch_earbud_mic, settings.useEarbudMic) { settings.useEarbudMic = it }
        switch(R.id.switch_earbud_tap, settings.earbudTap) { settings.earbudTap = it }
        switch(R.id.switch_offline, settings.preferOfflineSpeech) { settings.preferOfflineSpeech = it }
        switch(R.id.switch_offline_fallback, settings.offlineFallback) { settings.offlineFallback = it }
        setupOffline()
        setupBoost()

        // Photos and video
        val destinations = AppSettings.Destination.entries
        spinner(R.id.spin_photo_dest, destinations.map { it.label }, settings.photoDestination.ordinal) {
            settings.photoDestination = destinations[it]
        }
        spinner(R.id.spin_record_dest, destinations.map { it.label }, settings.recordDestination.ordinal) {
            settings.recordDestination = destinations[it]
        }
        val recordFps = listOf(2, 5, 10)
        spinner(R.id.spin_record_fps, recordFps.map { "$it fps" }, recordFps.indexOf(settings.recordFps)) {
            settings.recordFps = recordFps[it]
        }

        setupBackup()

        // Screen and about
        switch(R.id.switch_debug, settings.showDebug) { settings.showDebug = it }
        findViewById<TextView>(R.id.about).text =
            "App ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE}) · USB protocol v${DishaProtocol.VERSION}\n" +
                "Glasses firmware: ${intent.getStringExtra(EXTRA_FIRMWARE) ?: "not connected"}"
    }

    // ---------------------------------------------------------------------------------------
    // Wake phrases: record "Disha", "Hello Disha" and "Hi Disha", twice each
    // ---------------------------------------------------------------------------------------

    private val main = Handler(Looper.getMainLooper())
    private var enrollRecorder: VoiceRecorder? = null
    private var enrollDialog: AlertDialog? = null
    private var enrollText: TextView? = null
    private val enrollSamples = ArrayList<WakeSamples.Sample>()
    private val perPhrase = 2
    private fun phrases() = settings.assistantName.let { listOf(it, "Hello $it", "Hi $it") }
    private var enrollTries = 0
    private var enrolling = false
    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    } catch (_: RuntimeException) {
        null
    }

    private fun showWake() {
        val recorded = WakeSamples(this).count() >= WakeMatcher.MIN_SAMPLES
        val names = phrases().joinToString(", ") { "\"$it\"" }
        findViewById<TextView>(R.id.wake_info).text = if (recorded) {
            "Recorded. Say $names any time the assistant is idle (the app or its notification running). Record again if it wakes too rarely or too often."
        } else {
            "Not recorded yet. Tap the button and say $names, twice each, the way you normally would (about 20 seconds)."
        }
        val sw = findViewById<Switch>(R.id.switch_wake_enabled)
        sw.isEnabled = recorded
        if (!recorded) sw.isChecked = false
    }

    private fun startEnrollment() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        enrolling = true
        settings.wakeEnrolling = true  // the running assistant lets go of the microphone
        enrollSamples.clear()
        enrollTries = 0
        val text = TextView(this)
        text.textSize = 18f
        text.setPadding(56, 40, 56, 8)
        enrollText = text
        enrollDialog = AlertDialog.Builder(this)
            .setTitle("Your wake phrase")
            .setView(text)
            .setNegativeButton("Cancel") { _, _ -> endEnrollment() }
            .setOnCancelListener { endEnrollment() }
            .show()
        text.text = "Getting ready…"
        main.postDelayed({ if (enrolling) recordNext() }, 700)
    }

    private fun recordNext() {
        val all = phrases()
        val total = all.size * perPhrase
        val n = enrollSamples.size + 1
        val group = enrollSamples.size / perPhrase
        val phrase = all[group]
        enrollText?.text = "After the beep, say \"$phrase\"  ($n of $total)\n\n" +
            "Speak normally, with the phone where you usually keep it."
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        val rec = VoiceRecorder(object : VoiceRecorder.Listener {
            override fun onLevel(level: Int) = Unit
            override fun onSpeechStarted() {
                enrollText?.text = "Listening…  ($n of $total)"
            }
            override fun onRecorded(wav: ByteArray, speechMs: Int) {
                when {
                    speechMs < 250 -> retry("That was very short.")
                    speechMs > 3000 -> retry("That was long: just \"$phrase\", please.")
                    else -> {
                        enrollSamples.add(WakeSamples.Sample(Wav.toPcm(wav), group))
                        if (enrollSamples.size >= total) {
                            learn()
                        } else {
                            enrollText?.text = "Got it."
                            main.postDelayed({ if (enrolling) recordNext() }, 800)
                        }
                    }
                }
            }
            override fun onNoSpeech() = retry("I didn't hear anything.")
            override fun onRecordError(message: String) = fail(message)
        })
        enrollRecorder = rec
        main.postDelayed({ if (enrolling) rec.start(false, null, 6000) }, 250)  // after the beep
    }

    private fun retry(reason: String) {
        if (!enrolling) return
        if (++enrollTries > 6) {
            fail("Too many tries. Try again somewhere quieter.")
            return
        }
        enrollText?.text = "$reason Let's try again."
        main.postDelayed({ if (enrolling) recordNext() }, 1500)
    }

    private fun learn() {
        val m = WakeMatcher(enrollSamples.map { it.pcm }, enrollSamples.map { it.group }, settings.wakeSensitivity)
        if (!m.ready) {
            fail("I couldn't learn it from these recordings. Try again somewhere quieter.")
            return
        }
        WakeSamples(this).save(enrollSamples)
        settings.wakeVersion = settings.wakeVersion + 1
        settings.wakeEnabled = true
        if (settings.autoBackup) backupInBackground()  // the new training is safe from now on
        findViewById<Switch>(R.id.switch_wake_enabled).isChecked = true
        val name = settings.assistantName
        enrollText?.text = "Learned! Now say \"$name\", \"Hello $name\" or \"Hi $name\" whenever the assistant is idle. " +
            "You can also go straight on: \"$name, take a photo\"."
        enrollDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)?.text = "Done"
        stopEnrollRecording()
        showWake()
    }

    private fun fail(message: String) {
        enrollText?.text = message
        enrollDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)?.text = "Close"
        stopEnrollRecording()
    }

    private fun stopEnrollRecording() {
        enrollRecorder?.cancel()
        enrollRecorder = null
        if (enrolling) {
            enrolling = false
            settings.wakeEnrolling = false
        }
    }

    private fun endEnrollment() {
        stopEnrollRecording()
        enrollDialog = null
        enrollText = null
        showWake()
    }

    // ---------------------------------------------------------------------------------------
    // AI boost (the user's own key) and offline speech
    // ---------------------------------------------------------------------------------------

    private var boostShowing = false

    private fun setupBoost() {
        val providers = AppSettings.BoostProvider.entries
        val key = findViewById<EditText>(R.id.edit_boost_key)
        val url = findViewById<EditText>(R.id.edit_boost_url)
        val text = findViewById<EditText>(R.id.edit_boost_text)
        val vision = findViewById<EditText>(R.id.edit_boost_vision)
        val speechModel = findViewById<EditText>(R.id.edit_boost_speech)
        val consentSwitch = findViewById<Switch>(R.id.switch_boost_consent)
        val result = findViewById<TextView>(R.id.boost_result)
        fun show() {
            boostShowing = true
            val p = settings.boostProvider
            findViewById<View>(R.id.boost_box).visibility = if (p == AppSettings.BoostProvider.NONE) View.GONE else View.VISIBLE
            url.visibility = if (p == AppSettings.BoostProvider.CUSTOM) View.VISIBLE else View.GONE
            key.setText(settings.boostKey)
            url.setText(settings.boostBaseUrl)
            text.setText(settings.boostTextModel)
            vision.setText(settings.boostVisionModel)
            speechModel.setText(settings.boostSpeechModel)
            text.hint = "Thinking model: " + p.textModel.ifEmpty { "required" }
            vision.hint = "Picture model: " + p.visionModel.ifEmpty { "required" }
            speechModel.hint = "Speech model: " + p.speechModel.ifEmpty { "none (free Whisper)" }
            consentSwitch.isChecked = settings.boostConsent
            result.text = if (p.keyUrl.isNotEmpty()) "Get a key at ${p.keyUrl}" else ""
            boostShowing = false
        }
        spinner(R.id.spin_boost, providers.map { it.label }, settings.boostProvider.ordinal) {
            if (settings.boostProvider != providers[it]) {
                settings.boostProvider = providers[it]
                settings.boostConsent = false  // another company: ask again
                show()
            }
        }
        key.addTextChangedListener(onText { if (!boostShowing) settings.boostKey = it })
        url.addTextChangedListener(onText { if (!boostShowing) settings.boostBaseUrl = it })
        text.addTextChangedListener(onText { if (!boostShowing) settings.boostTextModel = it })
        vision.addTextChangedListener(onText { if (!boostShowing) settings.boostVisionModel = it })
        speechModel.addTextChangedListener(onText { if (!boostShowing) settings.boostSpeechModel = it })
        consentSwitch.setOnCheckedChangeListener { view, on ->
            if (boostShowing) return@setOnCheckedChangeListener
            if (!on) {
                settings.boostConsent = false
                return@setOnCheckedChangeListener
            }
            val who = settings.boostProvider.label.substringBefore(" (")
            AlertDialog.Builder(this)
                .setTitle("Use $who with your key?")
                .setMessage(
                    "Your questions, and camera pictures and voice recordings when those are allowed, will go to $who first, " +
                        "using your key and its terms. The free no-key AI still answers whenever $who fails or is busy.",
                )
                .setPositiveButton("Allow") { _, _ -> settings.boostConsent = true }
                .setNegativeButton("Cancel") { _, _ -> view.isChecked = false }
                .setOnCancelListener { view.isChecked = false }
                .show()
        }
        findViewById<Button>(R.id.btn_boost_test).setOnClickListener {
            val b = com.disha.glassos.ai.Boost.endpoint(settings)
            if (b == null) {
                result.text = "Paste the key and allow sending to the service first."
                return@setOnClickListener
            }
            result.text = "Asking ${b.label} (${b.textModel})…"
            val messages = org.json.JSONArray()
                .put(org.json.JSONObject().put("role", "user").put("content", "Reply with exactly: Disha boost works"))
            com.disha.glassos.ai.BrainClient(settings).boostOnly(messages, false) { r ->
                result.text = when (r) {
                    is com.disha.glassos.ai.BrainClient.Reply.Message -> "Working: ${r.model} answered \"${r.text.take(60)}\"."
                    else -> "No answer: the key may be wrong, or the model name isn't offered. The app log has the details."
                }
            }
        }
        show()
    }

    private fun setupOffline() {
        val info = findViewById<TextView>(R.id.offline_info)
        val onDevice = Build.VERSION.SDK_INT >= 31 && try {
            android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        } catch (_: Exception) {
            false
        }
        info.text = if (onDevice) "This phone has an offline speech recogniser: without internet, Disha still understands commands."
        else "No offline speech recogniser found on this phone (Android 12+ with Google's speech services has one)."
        val btn = findViewById<Button>(R.id.btn_offline_download)
        btn.isEnabled = Build.VERSION.SDK_INT >= 33 && onDevice
        btn.setOnClickListener {
            if (Build.VERSION.SDK_INT < 33) return@setOnClickListener
            try {
                val lang = settings.speechLanguage.let { if (it == AppSettings.AUTO_LANGUAGE) "en-IN" else it }
                val r = android.speech.SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                r.triggerModelDownload(Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, lang))
                main.postDelayed({ r.destroy() }, 5000)
                info.text = "Download of offline speech for $lang requested. The phone downloads it in the background over Wi-Fi."
            } catch (e: Exception) {
                info.text = "The phone refused the download: ${e.message}"
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Backup and restore
    // ---------------------------------------------------------------------------------------

    private fun setupBackup() {
        switch(R.id.switch_auto_backup, settings.autoBackup) { on ->
            settings.autoBackup = on
            if (on) backupInBackground()
        }
        findViewById<Button>(R.id.btn_backup_save).setOnClickListener {
            val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val pick = Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("application/zip")
                .putExtra(Intent.EXTRA_TITLE, "disha-backup-$day.zip")
            startPicker(pick, REQ_BACKUP_SAVE)
        }
        findViewById<Button>(R.id.btn_backup_restore).setOnClickListener {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")  // some file apps call a zip application/octet-stream
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            startPicker(pick, REQ_BACKUP_OPEN)
        }
        showBackup()
    }

    private fun startPicker(i: Intent, request: Int) {
        if (Build.VERSION.SDK_INT < 19) {
            showBackup("This Android version has no file picker; the automatic copy is kept in the app's folder.")
            return
        }
        try {
            startActivityForResult(i, request)
        } catch (_: Exception) {
            showBackup("No file picker app found on this phone.")
        }
    }

    private fun showBackup(message: String? = null) {
        val last = settings.lastBackupAt
        val status = when {
            !settings.autoBackup -> "Automatic copy: off."
            last == 0L -> "Automatic copy: none yet (made once there is something to keep, then daily)."
            else -> "Last automatic copy: ${SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).format(Date(last))}, in ${settings.lastBackupWhere}."
        }
        findViewById<TextView>(R.id.backup_info).text = if (message != null) "$message\n$status" else status
    }

    private fun backupInBackground() {
        Thread {
            Backup(this).saveAutomatic()
            main.post { if (!isFinishing) showBackup() }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_BACKUP_SAVE -> {
                showBackup("Saving the backup…")
                Thread {
                    val message = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { Backup(this).write(it) } ?: throw IOException("can't write there")
                        "Backup saved. Keep it somewhere safe (Drive, PC or a memory card) for a new phone."
                    } catch (e: Exception) {
                        "Backup failed: ${e.message}"
                    }
                    main.post { if (!isFinishing) showBackup(message) }
                }.start()
            }
            REQ_BACKUP_OPEN -> {
                showBackup("Reading the backup…")
                Thread {
                    val backup = Backup(this)
                    val result = try {
                        val c = contentResolver.openInputStream(uri)?.use { backup.read(it) } ?: throw IOException("can't open it")
                        c to backup.describe(c)
                    } catch (e: Exception) {
                        null to (e.message ?: "unreadable")
                    }
                    main.post { if (!isFinishing) askRestore(result.first, result.second) }
                }.start()
            }
        }
    }

    private fun askRestore(c: Backup.Contents?, text: String) {
        if (c == null) {
            showBackup("Can't restore: $text")
            return
        }
        val from = if (c.created > 0) SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(Date(c.created)) else "an unknown date"
        val wakeNote = if (c.wake.size >= WakeMatcher.MIN_SAMPLES) {
            " Your current wake-word recordings will be replaced by the ones in the backup."
        } else {
            ""
        }
        val newer = if (c.format > BackupArchive.FORMAT) " It was made by a newer version of the app; parts this version doesn't know are skipped." else ""
        AlertDialog.Builder(this)
            .setTitle("Restore this backup?")
            .setMessage(
                "From $from (app ${c.appVersion.ifEmpty { "?" }}): $text.$wakeNote Settings come back as they were; memories, " +
                    "reminders and notes are added to the ones already on this phone.$newer Permissions and the Gemini key " +
                    "are not in backups.",
            )
            .setPositiveButton("Restore") { _, _ ->
                showBackup("Restoring…")
                Thread {
                    val report = try {
                        Backup(this).restore(c)
                    } catch (e: Exception) {
                        "Restore failed: ${e.message}"
                    }
                    main.post {
                        if (isFinishing) return@post
                        AlertDialog.Builder(this)
                            .setTitle("Backup")
                            .setMessage(report)
                            .setPositiveButton("OK") { _, _ -> recreate() }  // show the restored settings
                            .setOnCancelListener { recreate() }
                            .show()
                    }
                }.start()
            }
            .setNegativeButton("Cancel") { _, _ -> showBackup() }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startEnrollment()
        updateSkillStatus()
    }

    override fun onDestroy() {
        stopEnrollRecording()
        tone?.release()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Skills and the permissions they need
    // ---------------------------------------------------------------------------------------

    private val locationPerms = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)

    private fun granted(p: String) = Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun setupSkills() {
        val mem = AppSettings.MEMORY_CHOICES
        spinner(R.id.spin_visual_memory, mem.map { it.second }, mem.indexOfFirst { it.first == settings.visualMemoryMinutes }) {
            settings.visualMemoryMinutes = mem[it].first
        }
        switch(R.id.switch_smart_gallery, settings.smartGallery) { settings.smartGallery = it }
        switch(R.id.switch_places, settings.rememberPlaces) { on ->
            settings.rememberPlaces = on
            if (on && !granted(Manifest.permission.ACCESS_FINE_LOCATION) && Build.VERSION.SDK_INT >= 23) requestPermissions(locationPerms, REQ_LOCATION)
        }
        val notesSwitch = findViewById<Switch>(R.id.switch_notes_allowed)
        notesSwitch.isChecked = settings.notesAllowed
        notesSwitch.setOnCheckedChangeListener { view, on ->
            if (!on) {
                settings.notesAllowed = false
                return@setOnCheckedChangeListener
            }
            if (settings.notesAllowed) return@setOnCheckedChangeListener
            AlertDialog.Builder(this)
                .setTitle("Allow meeting notes?")
                .setMessage(
                    "When you say \"take notes\", Disha records everything the phone's microphone hears, including other " +
                        "people, and sends it in short pieces to the free online speech service (OVHcloud) to write it down. " +
                        "The transcript and summary are saved in Documents/DISHA on this phone. Tell people before you record them.",
                )
                .setPositiveButton("Allow") { _, _ -> settings.notesAllowed = true }
                .setNegativeButton("Cancel") { _, _ -> view.isChecked = false }
                .setOnCancelListener { view.isChecked = false }
                .show()
        }
        findViewById<Button>(R.id.btn_notification_access).setOnClickListener {
            try {
                startActivity(MessageCenter.settingsIntent())
            } catch (_: Exception) {
                aiResult.text = "Open the phone's Settings > Notifications > Notification access, and allow DISHA GLASS OS."
            }
        }
        findViewById<Button>(R.id.btn_call_permissions).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 26) {
                requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS), REQ_CALLS)
            } else if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), REQ_CALLS)
            }
        }
        switch(R.id.switch_announce_messages, settings.announceMessages) { settings.announceMessages = it }
        switch(R.id.switch_announce_calls, settings.announceCalls) { settings.announceCalls = it }

        val sosName = findViewById<EditText>(R.id.edit_sos_name)
        sosName.setText(settings.sosName)
        sosName.addTextChangedListener(onText { settings.sosName = it })
        val sosNumber = findViewById<EditText>(R.id.edit_sos_number)
        sosNumber.setText(settings.sosNumber)
        sosNumber.addTextChangedListener(onText { settings.sosNumber = it })
        val sosSender = findViewById<EditText>(R.id.edit_sos_sender)
        sosSender.setText(settings.sosSenderName)
        sosSender.addTextChangedListener(onText { settings.sosSenderName = it })
        switch(R.id.switch_sos, settings.sosEnabled) { on ->
            settings.sosEnabled = on
            if (on && Build.VERSION.SDK_INT >= 23 && (!granted(Manifest.permission.SEND_SMS) || !granted(Manifest.permission.ACCESS_FINE_LOCATION))) {
                requestPermissions(arrayOf(Manifest.permission.SEND_SMS) + locationPerms, REQ_SOS)
            }
        }
        findViewById<Button>(R.id.btn_sos_test).setOnClickListener {
            if (!settings.sosNumber.any(Char::isDigit)) {
                aiResult.text = "Enter the emergency contact's phone number first."
                return@setOnClickListener
            }
            val who = settings.sosName.ifBlank { settings.sosNumber }
            AlertDialog.Builder(this)
                .setTitle("Send a test message?")
                .setMessage("This sends a real SMS, marked TEST, with your location to $who (${settings.sosNumber}).")
                .setPositiveButton("Send") { _, _ ->
                    aiResult.text = "Sending the test message…"
                    Sos(this, settings, Places(this)).send(test = true) { result -> aiResult.text = result }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        updateSkillStatus()
    }

    private fun updateSkillStatus() {
        val notes = if (MessageCenter.isAllowed(this)) "allowed" else "off (tap Notification access)"
        val calls = when {
            Build.VERSION.SDK_INT >= 26 && granted(Manifest.permission.READ_PHONE_STATE) && granted(Manifest.permission.ANSWER_PHONE_CALLS) -> "allowed"
            granted(Manifest.permission.READ_PHONE_STATE) -> "ringing seen, answering off"
            else -> "off (tap Call control)"
        }
        findViewById<TextView>(R.id.messages_status).text =
            "Notification access (read and reply to messages, caller names): $notes. Call control (answer / reject): $calls."
    }

    override fun onResume() {
        super.onResume()
        updateSkillStatus()
    }

    private fun showMemory() {
        val facts = MemoryStore(this).all()
        findViewById<TextView>(R.id.memory_info).text = if (facts.isEmpty()) {
            "Memory: empty. Say \"remember that…\" to add something; it stays on this phone."
        } else {
            "Memory: ${facts.size} things, stored only on this phone. Latest: \"${facts.last().text}\""
        }
        findViewById<Button>(R.id.btn_clear_memory).isEnabled = facts.isNotEmpty()
    }

    /** Fills the AI fields for the chosen provider (each provider has its own model and picture permission). */
    private fun showProvider() {
        showing = true
        findViewById<View>(R.id.gemini_box).visibility = if (gemini) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.provider_note).setText(if (gemini) R.string.s_provider_gemini_note else R.string.s_provider_free_note)
        model.setText(if (gemini) settings.geminiModel else settings.freeModel)
        consent.isChecked = settings.aiImageConsent
        aiResult.text = ""
        showing = false
    }

    private fun findModels() {
        val forGemini = gemini
        aiResult.text = if (forGemini) "Asking Google which models your key can use…" else "Asking the free service which vision models it offers…"
        val show: (List<String>?, String?) -> Unit = show@{ models, error ->
            if (forGemini != gemini) return@show
            if (models == null) {
                aiResult.text = error ?: "Could not list models."
                return@show
            }
            aiResult.text = if (forGemini) {
                "${models.size} models available. Flash models are fast and on the free tier."
            } else {
                "${models.size} vision models available. The one you choose is tried first; the others take over when it is busy."
            }
            AlertDialog.Builder(this)
                .setTitle("Choose a model")
                .setItems(models.toTypedArray()) { _, which -> model.setText(models[which]) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        if (forGemini) ai.gemini.listModels(show) else ai.free.listModels(show)
    }

    /** Sends a test picture drawn by the app (not a camera picture) and shows whether the AI could read it. */
    private fun testAi() {
        val forGemini = gemini
        aiResult.text = "Sending a test picture made by the app (not the camera) to " +
            (if (forGemini) "Gemini (${settings.geminiModel})…" else "the free AI (${settings.freeModel} first)…")
        val question = "What text is written in this picture, and what colour is the circle? Answer in one short sentence."
        ai.ask(question, testPicture(), emptyList(), "You check that an image-reading assistant works.") { r ->
            if (forGemini != gemini) return@ask
            aiResult.text = when (r) {
                is VisionAi.Result.Answer ->
                    if (r.text.contains("47")) "Working: it read the test picture. Answer: ${r.text}"
                    else "It answered but did not read the test number 47. Answer: ${r.text}"
                is VisionAi.Result.Failure -> "Not working: ${r.message}"
            }
        }
    }

    private fun testPicture(): ByteArray {
        val bmp = Bitmap.createBitmap(320, 240, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.RED
        canvas.drawCircle(245f, 165f, 45f, paint)
        paint.color = Color.BLACK
        paint.textSize = 48f
        paint.isFakeBoldText = true
        canvas.drawText("DISHA 47", 12f, 80f, paint)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
        bmp.recycle()
        return out.toByteArray()
    }

    private fun onText(save: (String) -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(s: Editable?) = save(s?.toString().orEmpty())
    }

    private fun switch(id: Int, value: Boolean, save: (Boolean) -> Unit) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, on -> save(on) }
    }

    private fun spinner(id: Int, items: List<String>, selected: Int, save: (Int) -> Unit) {
        val sp = findViewById<Spinner>(id)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(selected.coerceIn(0, items.size - 1), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = save(position)
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }
}
