package com.disha.glassos.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.disha.glassos.protocol.DishaProtocol
import com.disha.glassos.protocol.FrameAssembler

/** Validates and decodes a received frame. Never called on the main thread. */
object FrameDecoder {

    class Decoded(val bitmap: Bitmap, val decodeMs: Long)

    class DecodeException(message: String) : Exception(message)

    fun hasJpegMarkers(d: ByteArray): Boolean =
        d.size >= 4 &&
            d[0] == 0xFF.toByte() && d[1] == 0xD8.toByte() &&
            d[d.size - 2] == 0xFF.toByte() && d[d.size - 1] == 0xD9.toByte()

    @Throws(DecodeException::class)
    fun decode(frame: FrameAssembler.Frame): Decoded {
        if (frame.format != DishaProtocol.FORMAT_JPEG) throw DecodeException("unsupported pixel format ${frame.format}")
        val data = frame.data
        if (!hasJpegMarkers(data)) throw DecodeException("incomplete JPEG (SOI/EOI markers missing)")
        val t0 = System.nanoTime()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth != frame.width || bounds.outHeight != frame.height) {
            throw DecodeException(
                "JPEG is ${bounds.outWidth}x${bounds.outHeight} but the frame header says ${frame.width}x${frame.height}",
            )
        }
        val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
            ?: throw DecodeException("Android could not decode the JPEG")
        return Decoded(bitmap, (System.nanoTime() - t0) / 1_000_000)
    }
}
