package com.disha.glassos.assistant

/**
 * Makes model output fit for text-to-speech: no markdown (bold, headings, bullets, links, code),
 * no emojis or URLs, and symbols said as words. Pure logic, unit-tested on the PC.
 */
object SpeechText {

    private val codeFence = Regex("```[\\s\\S]*?```")
    private val link = Regex("\\[([^\\]]+)]\\([^)]*\\)")
    private val url = Regex("https?://\\S+|www\\.\\S+")
    private val bold = Regex("(\\*\\*|__)(.+?)\\1")
    private val italic = Regex("(?<![\\w*])[*_](?!\\s)(.+?)(?<!\\s)[*_](?![\\w*])")
    private val heading = Regex("(?m)^\\s{0,3}#{1,6}\\s+")
    private val bullet = Regex("(?m)^\\s*(?:[-*•]|\\d{1,2}[.)])\\s+")
    private val emoji = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]")
    private val spaces = Regex("[ \\t\\u00A0\\u202F\\u2009]+")

    fun forSpeech(text: String): String {
        var s = text.replace(codeFence, " ")
            .replace(link, "$1")
            .replace(url, "")
            .replace(bold, "$2")
            .replace(italic, "$1")
            .replace(heading, "")
            .replace(bullet, "")
            .replace("`", "")
            .replace(emoji, "")
            .replace("≈", " about ")
            .replace("°C", " degrees")
            .replace("°", " degrees")
            .replace(" & ", " and ")
            .replace(spaces, " ")
        // Lines (list items, paragraphs) become sentences.
        s = s.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ") { line ->
            if (line.last() in ".!?:;,।") line else "$line."
        }
        return s.replace(Regex("\\s+([.,!?;:])"), "$1").replace(spaces, " ").trim()
    }
}
