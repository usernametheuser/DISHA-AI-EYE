package com.disha.glassos.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.disha.glassos.R
import com.disha.glassos.ai.AiRouter
import com.disha.glassos.assistant.AssistantController
import com.disha.glassos.assistant.Reminders
import com.disha.glassos.audio.AudioRouter
import com.disha.glassos.protocol.FrameAssembler
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.settings.AppSettings.Destination
import com.disha.glassos.skills.CaptionBoard
import com.disha.glassos.skills.ReplayBuffer
import com.disha.glassos.storage.Backup
import com.disha.glassos.storage.MediaSaver
import com.disha.glassos.storage.PhoneRecorder
import com.disha.glassos.usb.CameraLinkManager
import com.disha.glassos.usb.CameraLinkManager.State
import com.disha.glassos.util.AppLog
import com.disha.glassos.web.PresenterServer
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Everything that keeps running while the phone is in a pocket: the USB camera link, the voice
 * assistant, the AI, photos and recordings. Owned by DishaService; the screen attaches as [ui]
 * and gets the current state replayed. Main thread only.
 */
class DishaCore(context: Context) : CameraLinkManager.Listener {

    interface Ui {
        fun onLinkState(state: State, detail: String)
        fun onDeviceInfo(info: CameraLinkManager.DeviceInfo)
        fun onFrame(frame: CameraLinkManager.ReceivedFrame)
        fun onDeviceStatus(status: JSONObject)
        fun onCommandResult(result: CameraLinkManager.CommandResult)
        fun onStats(stats: CameraLinkManager.LinkStats)
        fun onStorage(storage: JSONObject)
        fun onRecording(phone: Boolean, glasses: Boolean)
        fun onAssistantState(state: AssistantController.State, detail: String)
        fun onMicLevel(level: Int)
        fun onPartialSpeech(text: String)
        fun onTranscript(lines: List<String>)
        fun onAudioRoute(route: AudioRouter.Route)
        fun onTasks(text: String)
        fun onShowGallery(query: String): Boolean
        fun onShowCaptions(): Boolean
        /** Opens a link, contact or map from the screen; false if it can't (then a notification is shown). */
        fun onOpenIntent(intent: Intent): Boolean
        /** Presentation mode addresses for the laptop, or empty when it is off. */
        fun onPresenter(urls: List<String>)
    }

    private companion object {
        const val TAG = "Core"
        const val MAX_TRANSCRIPT = 30
        const val CHANNEL_ACTIONS = "disha_actions"
    }

    private val appContext = context.applicationContext
    val settings = AppSettings(appContext)
    val ai = AiRouter(settings)
    val recorder = PhoneRecorder(appContext)
    val manager = CameraLinkManager(appContext, this)

    // ---- cached state, replayed when the screen attaches ----
    var linkState = State.DISCONNECTED
        private set
    private var linkDetail = "Looking for DISHA-CAM…"
    private var deviceInfo: CameraLinkManager.DeviceInfo? = null
    private var lastFrame: CameraLinkManager.ReceivedFrame? = null
    var lastStatus: JSONObject? = null
        private set
    var lastHello: JSONObject? = null
        private set
    private var lastStorage: JSONObject? = null
    private var assistantState = AssistantController.State.STARTING
    private var assistantDetail = ""
    private var route: AudioRouter.Route? = null
    private var tasksText = ""
    private val transcript = ArrayDeque<String>()
    var recordingPhone = false
        private set
    var recordingGlasses = false
        private set
    private var streamStartedForRecording = false

    /** The service updates its notification when this fires. */
    var onSummaryChanged: (() -> Unit)? = null

    var ui: Ui? = null
        set(value) {
            field = value
            if (value != null) replayState(value)
        }

    private val assistantUi = object : AssistantController.Ui {
        override fun onAssistantState(state: AssistantController.State, detail: String) {
            assistantState = state
            assistantDetail = detail
            ui?.onAssistantState(state, detail)
            onSummaryChanged?.invoke()
        }

        override fun onMicLevel(level: Int) {
            ui?.onMicLevel(level)
        }

        override fun onPartialSpeech(text: String) {
            ui?.onPartialSpeech(text)
        }

        override fun onTranscript(who: String, text: String) = addTranscript(who, text)

        override fun onAudioRoute(route: AudioRouter.Route) {
            this@DishaCore.route = route
            ui?.onAudioRoute(route)
        }

        override fun onShowGallery(query: String): Boolean = ui?.onShowGallery(query) ?: false

        override fun onShowCaptions(): Boolean = ui?.onShowCaptions() ?: false

        override fun openIntent(intent: Intent, label: String): Boolean = this@DishaCore.openIntent(intent, label)

        override fun onTasks(text: String) {
            val changed = (text.isEmpty()) != (tasksText.isEmpty())
            tasksText = text
            ui?.onTasks(text)
            if (changed) onSummaryChanged?.invoke()
        }
    }

    private val cameraActions = object : AssistantController.CameraActions {
        override fun isCameraReady() = linkState == State.READY || linkState == State.STREAMING
        override fun isStreaming() = linkState == State.STREAMING
        override fun isRecording() = recordingPhone || recordingGlasses
        override fun cameraStatusSentence() = cameraStatusSentenceImpl()
        override fun captureForAi(highRes: Boolean, onResult: (FrameAssembler.Frame?, String?) -> Unit) {
            // Reading small text needs every pixel: the largest size, at a higher JPEG quality.
            val (w, h) = if (highRes) AppSettings.RESOLUTIONS.last() else settings.aiResolution
            manager.captureAt(w, h, if (highRes) 92 else 85, onResult)
        }
        override fun takePhoto(onDone: (String) -> Unit) = this@DishaCore.takePhoto(onDone)
        override fun startRecording(onDone: (String) -> Unit) = this@DishaCore.startRecording(onDone)
        override fun stopRecording(onDone: (String) -> Unit) = this@DishaCore.stopRecording(onDone)
        override fun storageSentence(onDone: (String) -> Unit) = this@DishaCore.storageSentence(onDone)
        override fun connectCamera() = manager.reconnect()
        override fun disconnectCamera() = manager.disconnect()
        override fun startStream() = manager.startStream(settings.streamFps)
        override fun stopStream() = manager.stopStream()
        override fun holdStream(tag: String, fps: Int) = this@DishaCore.holdStream(tag, fps)
        override fun releaseStream(tag: String) = this@DishaCore.releaseStream(tag)
        override fun setReplay(on: Boolean): String = this@DishaCore.setReplay(on)
        override fun saveReplay(seconds: Int, onDone: (String) -> Unit) = replay.save(seconds, onDone)
        override fun replayOn(): Boolean = replay.active
        override fun presenterStart(): List<String> = this@DishaCore.presenterStart()
        override fun presenterStop() = this@DishaCore.presenterStop()
        override fun presenterRunning(): Boolean = presenter.running
        override fun presenterUrls(): List<String> = if (presenter.running) presenter.urls() else emptyList()
        override fun slide(action: String, number: Int) = presenter.slide(action, number)
    }

    // ---- instant replay, presentation mode, shared live view ----
    val replay: ReplayBuffer = ReplayBuffer(appContext)
    val presenter: PresenterServer = PresenterServer(appContext, object : PresenterServer.Host {
        override fun runText(text: String) = assistant.runText(text)
        override fun slideFromPage(action: String) = this@DishaCore.presenter.slide(action)
        override fun onViewers(count: Int) = if (count > 0) holdStream("web", 3) else releaseStream("web")
    })
    private val streamHolds = HashMap<String, Int>()  // who needs the live view, at what fps
    private var streamOwned = false
    private var ownFps = 0
    private val presenterTicker = object : Runnable {
        override fun run() {
            if (!presenter.running) return
            presenter.stateJson = presenterState()
            main.postDelayed(this, 600)
        }
    }

    val assistant = AssistantController(appContext, settings, cameraActions, ai, assistantUi)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> assistant.applySettings() }

    // ---- proactive alerts (Disha speaks up unasked) ----
    private var batteryWarned = 101       // lowest threshold already announced
    private var hotWarned = false
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = onBattery(i)
    }

    // ---- daily backup copy of the wake-word training, memory and notes ----
    private val main = Handler(Looper.getMainLooper())
    private val backupCheck = object : Runnable {
        override fun run() {
            Thread { Backup(appContext).saveAutomaticIfDue() }.start()
            main.postDelayed(this, 6 * 60 * 60 * 1000L)
        }
    }

    init {
        manager.frameTap = { frame ->
            recorder.onFrame(frame)
            replay.onFrame(frame)
            presenter.onFrame(frame.data)
        }
    }

    fun start() {
        manager.start()
        assistant.start()
        settings.register(prefListener)
        appContext.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        // Timers and reminders survive an app restart; ones that came due meanwhile are said now.
        for (missed in assistant.reminders.restore()) assistant.onReminderDue(missed)
        main.postDelayed(backupCheck, 2 * 60 * 1000L)  // not while everything is starting up
        if (settings.replayOn) setReplay(true)
    }

    fun shutdown() {
        main.removeCallbacks(backupCheck)
        presenterStop()
        replay.stop()
        settings.unregister(prefListener)
        try {
            appContext.unregisterReceiver(batteryReceiver)
        } catch (_: IllegalArgumentException) {
        }
        if (recordingPhone) recorder.stop {}
        assistant.shutdown()
        manager.stop()
    }

    /** A timer or reminder alarm fired. Returns it (for the notification), or null if it was cancelled. */
    fun onReminderFired(id: Int): Reminders.Item? {
        val item = assistant.reminders.fired(id) ?: return null
        assistant.onReminderDue(item)
        return item
    }

    private fun onBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        if (level < 0) return
        val pct = level * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (plugged || pct > 25) {
            batteryWarned = 101
            return
        }
        val threshold = listOf(20, 10, 5).firstOrNull { pct <= it && it < batteryWarned } ?: return
        batteryWarned = threshold
        if (!settings.proactiveAlerts) return
        val who = settings.userTitle.let { if (it.isEmpty()) "" else "$it, " }
        assistant.announce(
            "${who}the phone battery is down to $pct percent." +
                if (linkState.connected) " The glasses run on it too, so you may want to charge soon." else "",
        )
    }

    fun summary(): String = buildString {
        append(linkState.label)
        if (recordingPhone || recordingGlasses) append(" · REC")
        append(" · ").append(assistantState.label)
        if (tasksText.isNotEmpty()) append(" · ").append(tasksText.substringBefore(" · ").substringBefore(","))
        if (assistant.wakeListening) append(" · say \"${settings.assistantName}\"")
    }

    // =========================================================================================
    // Shared live view, instant replay, presentation mode, opening things
    // =========================================================================================

    /** [tag] needs the live view (replay, document pages, the web view): it runs while anyone holds it. */
    fun holdStream(tag: String, fps: Int) {
        streamHolds[tag] = fps
        applyStream()
    }

    fun releaseStream(tag: String) {
        if (streamHolds.remove(tag) != null) applyStream()
    }

    private fun applyStream() {
        val want = streamHolds.values.maxOrNull()
        val ready = linkState == State.READY || linkState == State.STREAMING
        if (want != null) {
            if (ready && (linkState != State.STREAMING || (streamOwned && want != ownFps) || (!streamOwned && !recordingPhone))) {
                manager.startStream(maxOf(want, if (recordingPhone) settings.recordFps else 0))
                streamOwned = true
                ownFps = want
            }
        } else if (streamOwned) {
            streamOwned = false
            ownFps = 0
            if (linkState == State.STREAMING && !streamStartedForRecording) manager.stopStream()
        }
    }

    private fun setReplay(on: Boolean): String {
        settings.replayOn = on
        return if (on) {
            replay.start()
            holdStream("replay", ReplayBuffer.FPS)
            if (linkState.connected) "Instant replay on. I'll always keep the last 30 seconds; say save that to keep a moment."
            else "Instant replay is on and starts when the glasses connect."
        } else {
            replay.stop()
            releaseStream("replay")
            "Instant replay off."
        }
    }

    private fun presenterStart(): List<String> {
        val urls = try {
            presenter.start()
        } catch (e: Exception) {
            AppLog.e(TAG, "Presentation mode: ${e.message}")
            return emptyList()
        }
        main.removeCallbacks(presenterTicker)
        presenterTicker.run()
        ui?.onPresenter(urls)
        return urls
    }

    private fun presenterStop() {
        if (!presenter.running) return
        presenter.stop()
        main.removeCallbacks(presenterTicker)
        releaseStream("web")
        ui?.onPresenter(emptyList())
    }

    /** Everything the web view shows, as JSON (main thread). */
    private fun presenterState(): String {
        val o = JSONObject()
            .put("state", assistantState.name).put("stateLabel", assistantState.label).put("detail", assistantDetail)
            .put("linkLabel", if (linkState.connected) "Glasses: ${linkState.label}" else "Glasses offline")
            .put("cameraReady", linkState == State.READY || linkState == State.STREAMING)
            .put("recording", recordingPhone || recordingGlasses)
            .put("replay", replay.active)
            .put("tasks", tasksText)
            .put("nav", assistant.navLine())
            .put("document", assistant.documentLine())
            .put("captionsMode", CaptionBoard.mode)
            .put("ai", assistant.aiLabel())
        val pct = (appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (pct in 0..100) o.put("battery", pct)
        val t = JSONArray()
        for (line in transcript.toList().takeLast(16)) {
            t.put(JSONObject().put("who", line.substringBefore(": ", "")).put("text", line.substringAfter(": ", line)))
        }
        o.put("transcript", t)
        val c = JSONArray()
        for (l in CaptionBoard.snapshot().takeLast(3)) c.put(JSONObject().put("text", l.text).put("tr", l.translation ?: ""))
        o.put("captions", c)
        return o.toString()
    }

    private var actionRequest = 100

    /** Opens on the screen if the app is open; otherwise a notification to tap (Android blocks it from the background). */
    private fun openIntent(intent: Intent, label: String): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (ui?.onOpenIntent(intent) == true) return true
        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_ACTIONS) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ACTIONS, "Things Disha opens", NotificationManager.IMPORTANCE_HIGH))
        }
        val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getActivity(appContext, actionRequest, intent, flags)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(appContext, CHANNEL_ACTIONS) else Notification.Builder(appContext)
        val n = b.setSmallIcon(R.drawable.ic_notify).setContentTitle(label).setContentText("Tap to open").setContentIntent(pi).setAutoCancel(true).build()
        try {
            nm.notify(actionRequest++, n)
        } catch (e: SecurityException) {
            AppLog.w(TAG, "Notification refused: ${e.message}")
        }
        return false
    }

    private fun replayState(u: Ui) {
        u.onLinkState(linkState, linkDetail)
        deviceInfo?.let { u.onDeviceInfo(it) }
        lastFrame?.let { u.onFrame(it) }
        lastStatus?.let { u.onDeviceStatus(it) }
        lastStorage?.let { u.onStorage(it) }
        u.onRecording(recordingPhone, recordingGlasses)
        u.onAssistantState(assistantState, assistantDetail)
        route?.let { u.onAudioRoute(it) }
        u.onTasks(tasksText)
        u.onTranscript(transcript.toList())
        u.onPresenter(if (presenter.running) presenter.urls() else emptyList())
    }

    private fun addTranscript(who: String, text: String) {
        transcript.addLast("$who: $text")
        while (transcript.size > MAX_TRANSCRIPT) transcript.removeFirst()
        ui?.onTranscript(transcript.toList())
    }

    // =========================================================================================
    // Photos, recordings, storage
    // =========================================================================================

    fun takePhoto(onDone: (String) -> Unit) {
        when (settings.photoDestination) {
            Destination.PHONE -> photoToPhone(onDone)
            Destination.GLASSES -> photoToGlasses(onDone)
            Destination.BOTH -> photoToGlasses { a -> photoToPhone { b -> onDone("$a $b") } }
        }
    }

    private fun photoToPhone(onDone: (String) -> Unit) {
        manager.captureFrame(fresh = true, quality = 90) { frame, error ->
            if (frame == null) {
                onDone("I couldn't take the photo. ${error ?: ""}".trim())
                return@captureFrame
            }
            val name = "DISHA_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}_${frame.frameId}.jpg"
            val where = MediaSaver.savePhoto(appContext, frame.data, name)
            AppLog.i(TAG, "Photo ${frame.width}x${frame.height} -> ${where ?: "failed"}")
            if (where != null) assistant.onPhotoSaved(frame.data, where)  // smart gallery caption
            onDone(if (where != null) "Photo saved on the phone." else "I took the photo, but couldn't save it on the phone.")
        }
    }

    private fun photoToGlasses(onDone: (String) -> Unit) {
        manager.takeSdPhoto { r ->
            AppLog.i(TAG, "Glasses photo: ${r.message}")
            onDone(if (r.ok) "Photo saved on the glasses card." else "The glasses couldn't save the photo: ${r.message}")
            if (r.ok) manager.requestStorage()
        }
    }

    fun startRecording(onDone: (String) -> Unit) {
        if (recordingPhone || recordingGlasses) {
            onDone("I'm already recording.")
            return
        }
        val dest = settings.recordDestination
        val fps = settings.recordFps
        val startPhone = {
            recorder.start(fps)
            recordingPhone = true
            if (linkState != State.STREAMING) {
                manager.startStream(fps)
                streamStartedForRecording = true
            }
        }
        if (dest == Destination.PHONE) {
            startPhone()
            publishRecording()
            onDone("Recording on the phone.")
            return
        }
        manager.startSdRecording(fps) { r ->
            val parts = ArrayList<String>()
            if (r.ok) {
                recordingGlasses = true
                parts.add("on the glasses card")
            } else {
                AppLog.w(TAG, "Glasses recording failed: ${r.message}")
            }
            if (dest == Destination.BOTH) {
                startPhone()
                parts.add("on the phone")
            }
            publishRecording()
            onDone(
                if (parts.isEmpty()) "The glasses couldn't start recording: ${r.message}"
                else "Recording ${parts.joinToString(" and ")}." + if (!r.ok) " The glasses card failed: ${r.message}" else "",
            )
        }
    }

    fun stopRecording(onDone: (String) -> Unit) {
        if (!recordingPhone && !recordingGlasses) {
            onDone("I'm not recording.")
            return
        }
        val results = ArrayList<String>()
        var waiting = (if (recordingGlasses) 1 else 0) + (if (recordingPhone) 1 else 0)
        val finish = {
            waiting--
            if (waiting == 0) {
                publishRecording()
                onDone(results.joinToString(" "))
            }
        }
        if (recordingGlasses) {
            manager.stopSdRecording { r ->
                recordingGlasses = false
                results.add(if (r.ok) "The glasses video is saved." else "Glasses: ${r.message}")
                manager.requestStorage()
                finish()
            }
        }
        if (recordingPhone) stopPhoneRecording { sentence ->
            results.add(sentence)
            finish()
        }
    }

    private fun stopPhoneRecording(onDone: (String) -> Unit) {
        recordingPhone = false
        if (streamStartedForRecording) {
            streamStartedForRecording = false
            // Others (replay, document, web view) may still need the live view.
            if (linkState == State.STREAMING && streamHolds.isEmpty()) manager.stopStream()
        }
        recorder.stop { s ->
            onDone(
                if (s.frames > 0) "The phone video is saved: ${s.seconds} seconds, in Movies, DISHA."
                else "The phone recording had no frames.",
            )
        }
    }

    fun storageSentence(onDone: (String) -> Unit) {
        manager.requestStorage { r ->
            val json = r.json
            val glasses = when {
                json == null -> "I couldn't read the glasses card."
                !json.optBoolean("mounted") -> "The glasses have no usable memory card."
                else -> "The glasses card has ${gb(json.optLong("freeMB"))} free, with ${json.optInt("photos")} photos " +
                    "and ${json.optInt("videos")} videos."
            }
            onDone("$glasses The phone has ${gb(MediaSaver.phoneFreeMb(appContext))} free.")
        }
    }

    private fun gb(mb: Long): String =
        if (mb >= 1024) String.format(Locale.US, "%.1f gigabytes", mb / 1024.0) else "$mb megabytes"

    private fun publishRecording() {
        ui?.onRecording(recordingPhone, recordingGlasses)
        onSummaryChanged?.invoke()
    }

    private fun cameraStatusSentenceImpl(): String {
        val cam = lastStatus?.optJSONObject("camera") ?: lastHello?.optJSONObject("camera")
        return when (linkState) {
            State.READY, State.STREAMING -> buildString {
                append("The camera is ready")
                if (cam != null) append(", ${cam.optString("sensor")} at ${cam.optInt("width")} by ${cam.optInt("height")}")
                append(".")
                if (linkState == State.STREAMING) append(" Live view is on.")
                if (recordingPhone || recordingGlasses) append(" Recording is on.")
                val temp = lastStatus?.optDouble("tempC") ?: Double.NaN
                if (!temp.isNaN()) append(" The camera board is at ${temp.toInt()} degrees.")
            }
            State.CAMERA_INITIALISING -> "The camera is starting."
            State.CAMERA_ERROR -> "The camera has a problem: ${cam?.optString("problem") ?: "unknown"}."
            else -> "The camera is not connected."
        }
    }

    // =========================================================================================
    // CameraLinkManager.Listener (main thread)
    // =========================================================================================

    override fun onLinkState(state: State, detail: String) {
        val wasConnected = linkState.connected
        linkState = state
        linkDetail = detail
        if (wasConnected && !state.connected) {
            // Cable removed or link lost: finish the phone video cleanly; the glasses lose power.
            if (recordingPhone) stopPhoneRecording { sentence -> addTranscript(settings.assistantName,"Camera disconnected. $sentence") }
            if (recordingGlasses) {
                recordingGlasses = false
                addTranscript(settings.assistantName,"Camera disconnected while the glasses were recording; the video on the card is kept up to the last few seconds.")
            }
            streamStartedForRecording = false
            publishRecording()
        }
        // JARVIS-style status in the earbuds when the glasses come online or drop out.
        val title = settings.userTitle.let { if (it.isEmpty()) "" else ", $it" }
        if (settings.proactiveAlerts && !wasConnected && (state == State.READY || state == State.STREAMING)) {
            assistant.announce("Glasses online$title. Camera ready.")
        } else if (settings.proactiveAlerts && wasConnected && !state.connected) {
            assistant.announce("Glasses disconnected$title.")
        }
        ui?.onLinkState(state, detail)
        onSummaryChanged?.invoke()
        if (!state.connected) {
            streamOwned = false
            ownFps = 0
        }
        if (state == State.READY && streamHolds.isNotEmpty()) applyStream()  // live view wanted before the glasses came
    }

    override fun onDeviceInfo(info: CameraLinkManager.DeviceInfo) {
        deviceInfo = info
        info.hello?.let { lastHello = it }
        ui?.onDeviceInfo(info)
    }

    override fun onFrame(frame: CameraLinkManager.ReceivedFrame) {
        lastFrame = frame
        ui?.onFrame(frame)
        assistant.onLiveFrame(frame.bitmap)  // document mode: is a new page lying still?
    }

    override fun onDeviceStatus(status: JSONObject) {
        lastStatus = status
        // The camera board heats up when streaming for long; warn once, again only after it cooled down.
        val temp = status.optDouble("tempC", Double.NaN)
        if (!temp.isNaN()) {
            if (!hotWarned && temp >= 70) {
                hotWarned = true
                if (settings.proactiveAlerts) {
                    assistant.announce("Heads up: the camera board is at ${temp.toInt()} degrees. Consider stopping the live view for a while.")
                }
            } else if (temp < 62) {
                hotWarned = false
            }
        }
        ui?.onDeviceStatus(status)
    }

    override fun onCommandResult(result: CameraLinkManager.CommandResult) {
        ui?.onCommandResult(result)
    }

    override fun onStats(stats: CameraLinkManager.LinkStats) {
        ui?.onStats(stats)
    }

    override fun onStorageStatus(storage: JSONObject) {
        lastStorage = storage
        val active = storage.optJSONObject("recording")?.optBoolean("active") ?: false
        if (recordingGlasses && !active) {
            recordingGlasses = false
            val why = storage.optString("problem").ifEmpty { "the card may be full" }
            assistant.announce("The glasses stopped recording: $why")
            publishRecording()
        } else if (!recordingGlasses && active) {
            recordingGlasses = true  // started with the BOOT button on the glasses
            publishRecording()
        }
        ui?.onStorage(storage)
    }
}
