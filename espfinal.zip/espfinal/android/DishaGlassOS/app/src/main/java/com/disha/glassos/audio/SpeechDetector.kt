package com.disha.glassos.audio

/**
 * Finds where speech starts and ends from the loudness (RMS) of 20 ms audio frames, with an
 * adaptive background level. Pure logic (no Android), so it is unit-tested on the PC.
 *
 * endSilenceMs: this much quiet after speech ends the request (the "response speed" setting).
 * maxSpeechMs: longest request (hold-to-talk allows longer).
 */
class SpeechDetector(
    private val waitForSpeechMs: Int,
    private val endSilenceMs: Int = END_SILENCE_MS,
    private val maxSpeechMs: Int = MAX_SPEECH_MS,
) {

    enum class Result { WAITING, STARTED, SPEAKING, ENDED, NO_SPEECH }

    companion object {
        const val FRAME_MS = 20
        const val IGNORE_MS = 200             // start beep and switching noise
        const val START_FRAMES = 4            // 80 ms above the threshold = speech
        const val END_SILENCE_MS = 1000       // this much quiet after speech = end of the request
        const val MAX_SPEECH_MS = 15000
        const val MIN_SPEECH_MS = 300
        const val MIN_RMS = 220.0             // about -43 dBFS: quieter is never speech
        const val MAX_NOISE = 2500.0
    }

    var frames = 0
        private set
    var noise = 0.0
        private set
    var speechStartFrame = -1
        private set
    var lastVoiceFrame = -1
        private set
    private var voicedFrames = 0
    private var above = 0
    private var done = false

    /** Milliseconds from the first to the last loud frame. */
    val speechMs get() = if (speechStartFrame < 0) 0 else (lastVoiceFrame - speechStartFrame) * FRAME_MS

    /** Enough loud frames to be worth recognising (not a click or a cough). */
    val enoughSpeech get() = voicedFrames * FRAME_MS >= MIN_SPEECH_MS

    /** Feeds one frame; finish = the user asked to stop now. ENDED / NO_SPEECH are final. */
    fun feed(rms: Double, finish: Boolean = false): Result {
        if (done) return if (speechStartFrame >= 0) Result.ENDED else Result.NO_SPEECH
        frames++
        val ms = frames * FRAME_MS
        if (ms <= IGNORE_MS) return if (finish) end(Result.NO_SPEECH) else Result.WAITING
        if (noise == 0.0) noise = rms.coerceAtMost(MAX_NOISE)

        if (speechStartFrame < 0) {
            val started = if (rms > maxOf(noise * 3.0, MIN_RMS)) {
                ++above >= START_FRAMES
            } else {
                above = 0
                // Background level (only from frames that are not speech): falls quickly (pauses between
                // words), rises slowly (steady noise), so speaking right after the beep can't hold it high.
                noise = if (rms < noise) noise * 0.7 + rms * 0.3 else minOf(noise * 0.98 + rms * 0.02, MAX_NOISE)
                false
            }
            if (started) {
                speechStartFrame = frames - above + 1
                lastVoiceFrame = frames
                voicedFrames = above
                return if (finish) end(Result.ENDED) else Result.STARTED
            }
            return if (ms >= waitForSpeechMs || finish) end(Result.NO_SPEECH) else Result.WAITING
        }
        if (rms > maxOf(noise * 2.0, MIN_RMS * 0.8)) {
            lastVoiceFrame = frames
            voicedFrames++
        }
        val silentMs = (frames - lastVoiceFrame) * FRAME_MS
        return if (silentMs >= endSilenceMs || finish || (frames - speechStartFrame) * FRAME_MS >= maxSpeechMs) {
            end(Result.ENDED)
        } else {
            Result.SPEAKING
        }
    }

    private fun end(r: Result): Result {
        done = true
        return r
    }
}
