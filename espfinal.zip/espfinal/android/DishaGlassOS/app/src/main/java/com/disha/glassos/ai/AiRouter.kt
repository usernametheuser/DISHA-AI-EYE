package com.disha.glassos.ai

import android.util.Base64
import com.disha.glassos.settings.AppSettings
import org.json.JSONArray
import org.json.JSONObject

/**
 * The AI chosen in Settings: the free no-key service (default) or Google Gemini with the user's key.
 * Each question goes only to that one provider; there is no silent switch to the other. When the
 * user also pasted a boost key (and agreed), that service is asked first and the chosen provider
 * answers whenever it can't.
 */
class AiRouter(private val settings: AppSettings) : VisionAi {

    val free = FreeVisionClient(settings)
    val gemini = GeminiClient(settings)
    private val boost = BrainClient(settings)

    private val current: VisionAi
        get() = if (settings.aiProvider == AppSettings.AiProvider.GEMINI) gemini else free

    override val name: String
        get() = Boost.endpoint(settings)?.label ?: current.name

    override fun isConfigured() = Boost.endpoint(settings) != null || current.isConfigured()

    override fun ask(
        question: String,
        jpeg: ByteArray?,
        history: List<VisionAi.Turn>,
        systemPrompt: String,
        callback: (VisionAi.Result) -> Unit,
    ) {
        if (Boost.endpoint(settings) == null) {
            current.ask(question, jpeg, history, systemPrompt, callback)
            return
        }
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
        for (t in history) {
            messages.put(JSONObject().put("role", "user").put("content", t.user))
            messages.put(JSONObject().put("role", "assistant").put("content", t.assistant))
        }
        messages.put(userMessage(question, listOfNotNull(jpeg)))
        boost.boostOnly(messages, jpeg != null) { r ->
            val text = (r as? BrainClient.Reply.Message)?.text?.takeIf { it.isNotBlank() }
            if (text != null) callback(VisionAi.Result.Answer(text)) else current.ask(question, jpeg, history, systemPrompt, callback)
        }
    }

    override fun askFrames(question: String, frames: List<ByteArray>, systemPrompt: String, callback: (VisionAi.Result) -> Unit) {
        if (Boost.endpoint(settings) == null) {
            current.askFrames(question, frames, systemPrompt, callback)
            return
        }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", systemPrompt))
            .put(userMessage(question, frames))
        boost.boostOnly(messages, true) { r ->
            val text = (r as? BrainClient.Reply.Message)?.text?.takeIf { it.isNotBlank() }
            if (text != null) callback(VisionAi.Result.Answer(text)) else current.askFrames(question, frames, systemPrompt, callback)
        }
    }

    private fun userMessage(text: String, images: List<ByteArray>): JSONObject {
        if (images.isEmpty()) return JSONObject().put("role", "user").put("content", text)
        val parts = JSONArray().put(JSONObject().put("type", "text").put("text", text))
        for (img in images) {
            val uri = "data:image/jpeg;base64," + Base64.encodeToString(img, Base64.NO_WRAP)
            parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", uri)))
        }
        return JSONObject().put("role", "user").put("content", parts)
    }
}
