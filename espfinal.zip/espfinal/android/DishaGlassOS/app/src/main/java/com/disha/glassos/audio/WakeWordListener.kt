package com.disha.glassos.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.disha.glassos.util.AppLog

/**
 * Hands-free wake phrase. While running, it listens on the phone's microphone, cuts the sound
 * into spoken segments and compares the start of each with the user's own recordings
 * ([WakeMatcher]). All of this happens on the phone and nothing is stored or sent; a segment that
 * matches is handed to [onCandidate] (main thread), and listening pauses until [resume] or a
 * new [start]. The assistant stops this listener whenever it uses the microphone itself.
 */
class WakeWordListener(private val onCandidate: (Candidate) -> Unit) {

    class Candidate(val pcm: ShortArray, val score: Float, val threshold: Float, val speechMs: Int)

    private companion object {
        const val TAG = "Wake"
        const val RATE = Wav.RATE
        const val FRAME = SpeechSegmenter.FRAME   // 20 ms
        const val RETRY_MS = 5000L
    }

    private class Session {
        @Volatile var stop = false
        @Volatile var paused = false
        var thread: Thread? = null
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var matcher: WakeMatcher? = null
    private var session: Session? = null

    val isRunning get() = session != null

    fun setMatcher(m: WakeMatcher?) {
        matcher = m
    }

    fun start() {
        if (session != null) {
            resume()
            return
        }
        val s = Session()
        session = s
        val t = Thread({ loop(s) }, "disha-wake")
        s.thread = t
        t.start()
        AppLog.i(TAG, "Listening for the wake phrase")
    }

    /** Listen again after a candidate was handled. */
    fun resume() {
        session?.paused = false
    }

    fun stop() {
        val s = session ?: return
        session = null
        s.stop = true
        s.thread?.join(400)  // free the microphone before the assistant opens it
        AppLog.i(TAG, "Wake phrase listening off")
    }

    @SuppressLint("MissingPermission")  // started only with RECORD_AUDIO granted
    private fun loop(s: Session) {
        while (!s.stop) {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, RATE))
            } catch (e: Exception) {
                null
            }
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
                rec?.release()
                AppLog.w(TAG, "Microphone busy; trying again in ${RETRY_MS / 1000} s")
                sleep(s, RETRY_MS)
                continue
            }
            val effects = AudioFx.attach(rec, echo = false)  // same processing as the recorded samples
            try {
                rec.startRecording()
                listen(s, rec)
            } catch (e: Exception) {
                AppLog.e(TAG, "Listening failed: ${e.message}")
            } finally {
                try {
                    rec.stop()
                } catch (_: IllegalStateException) {
                }
                AudioFx.release(effects)
                rec.release()
            }
            if (!s.stop) sleep(s, RETRY_MS)
        }
    }

    private fun listen(s: Session, rec: AudioRecord) {
        val segmenter = SpeechSegmenter()
        val frame = ShortArray(FRAME)
        var wasPaused = false
        while (!s.stop) {
            var got = 0
            while (got < FRAME && !s.stop) {
                val n = rec.read(frame, got, FRAME - got)
                if (n <= 0) return  // microphone taken away: reopen
                got += n
            }
            if (s.stop) return
            if (s.paused) {
                wasPaused = true
                continue
            }
            if (wasPaused) {
                wasPaused = false
                segmenter.reset()
            }
            val seg = segmenter.feed(frame) ?: continue
            val m = matcher ?: continue
            val score = m.score(seg.pcm)
            if (score <= m.threshold) {
                AppLog.i(TAG, "Wake phrase? score %.2f (threshold %.2f), %d ms".format(score, m.threshold, seg.speechMs))
                s.paused = true
                main.post { if (session === s) onCandidate(Candidate(seg.pcm, score, m.threshold, seg.speechMs)) }
            }
        }
    }

    private fun sleep(s: Session, ms: Long) {
        var left = ms
        while (left > 0 && !s.stop) {
            Thread.sleep(100)
            left -= 100
        }
    }
}
