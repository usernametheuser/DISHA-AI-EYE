package com.disha.glassos.skills

import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Walking directions: distances on the map, spoken instructions, and when to say them. Pure logic. */
object NavMath {

    class Point(val lat: Double, val lon: Double)

    /** One manoeuvre of the route: what to do at [at]. */
    class Step(val instruction: String, val at: Point, val arrive: Boolean = false)

    private const val EARTH_M = 6_371_000.0

    fun distance(a: Point, b: Point): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).let { it * it } + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).let { it * it }
        return 2 * EARTH_M * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }

    /** Shortest distance from [p] to the route line, in metres. */
    fun distanceToPath(p: Point, path: List<Point>): Double {
        if (path.isEmpty()) return Double.MAX_VALUE
        if (path.size == 1) return distance(p, path[0])
        val k = cos(Math.toRadians(p.lat))
        fun xy(q: Point) = Pair(Math.toRadians(q.lon - p.lon) * k * EARTH_M, Math.toRadians(q.lat - p.lat) * EARTH_M)
        var best = Double.MAX_VALUE
        for (i in 0 until path.size - 1) {
            val (ax, ay) = xy(path[i])
            val (bx, by) = xy(path[i + 1])
            val dx = bx - ax
            val dy = by - ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 == 0.0) 0.0 else ((-ax) * dx + (-ay) * dy) / len2
            val tt = t.coerceIn(0.0, 1.0)
            val cx = ax + tt * dx
            val cy = ay + tt * dy
            best = minOf(best, sqrt(cx * cx + cy * cy))
        }
        return best
    }

    /** "50 metres", "1.2 kilometres", rounded the way people say it. */
    fun spoken(m: Double): String = when {
        m < 15 -> "a few metres"
        m < 100 -> "${(m / 10).roundToInt() * 10} metres"
        m < 1000 -> "${(m / 50).roundToInt() * 50} metres"
        m < 1050 -> "1 kilometre"
        else -> "%.1f kilometres".format(java.util.Locale.US, m / 1000).replace(".0 ", " ")
    }

    fun cardinal(bearing: Double): String {
        val names = listOf("north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west")
        return names[(((bearing % 360) + 360) % 360 / 45.0).roundToInt() % 8]
    }

    fun bearing(a: Point, b: Point): Double {
        val y = sin(Math.toRadians(b.lon - a.lon)) * cos(Math.toRadians(b.lat))
        val x = cos(Math.toRadians(a.lat)) * sin(Math.toRadians(b.lat)) -
            sin(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * cos(Math.toRadians(b.lon - a.lon))
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    /**
     * A spoken instruction from an OSRM step (maneuver type and modifier, road name, roundabout exit,
     * bearing after a departure).
     */
    fun instruction(type: String, modifier: String, name: String, exit: Int = 0, bearingAfter: Double = 0.0): String {
        val onto = if (name.isNotBlank()) " onto $name" else ""
        val on = if (name.isNotBlank()) " on $name" else ""
        return when (type) {
            "depart" -> "Head ${cardinal(bearingAfter)}$on"
            "arrive" -> when (modifier) {
                "left", "slight left", "sharp left" -> "Your destination is on the left"
                "right", "slight right", "sharp right" -> "Your destination is on the right"
                else -> "You have arrived"
            }
            "roundabout", "rotary", "roundabout turn" ->
                if (exit > 0) "At the roundabout, take the ${ordinal(exit)} exit$onto" else "Go around the roundabout$onto"
            "fork" -> "Keep ${side(modifier)}$onto"
            "merge" -> "Merge ${side(modifier)}$onto"
            "end of road" -> "At the end of the road, turn ${side(modifier)}$onto"
            else -> when (modifier) {
                "uturn" -> "Turn around$onto"
                "straight", "" -> if (type == "new name" || type == "continue") "Continue straight$onto" else "Go straight$onto"
                else -> "Turn $modifier$onto"
            }
        }
    }

    private fun side(modifier: String) = when {
        modifier.contains("left") -> "left"
        modifier.contains("right") -> "right"
        else -> "straight"
    }

    private fun ordinal(n: Int) = when (n) {
        1 -> "first"; 2 -> "second"; 3 -> "third"; 4 -> "fourth"; 5 -> "fifth"; else -> "${n}th"
    }

    /**
     * Turn-by-turn guidance along [steps] (steps[0] is the departure) and the route line [path].
     * Feed it location fixes; it says what to say and when the walker has left the route or arrived.
     */
    class Guide(val steps: List<Step>, private val path: List<Point>) {

        class Update(val say: String?, val arrived: Boolean = false, val offRoute: Boolean = false)

        var next = 1  // the manoeuvre coming up
            private set
        private var warnedFor = -1   // "in 40 metres, turn left" said for this step
        private var offCount = 0

        private companion object {
            const val NEAR_M = 40.0      // say the turn this far ahead
            const val PASSED_M = 12.0    // at the turn
            const val OFF_ROUTE_M = 35.0
            const val OFF_ROUTE_FIXES = 3
        }

        /** The first thing to say: the departure and the first turn. */
        fun opening(from: Point): String {
            val first = steps.getOrNull(0)?.instruction ?: "Start walking"
            val turn = steps.getOrNull(1) ?: return "$first."
            val d = distance(from, turn.at)
            return if (turn.arrive) "$first. Your destination is about ${spoken(d)} ahead."
            else "$first. In ${spoken(d)}, ${turn.instruction.replaceFirstChar { it.lowercase() }}."
        }

        fun update(p: Point): Update {
            if (next >= steps.size) return Update(null, arrived = true)
            if (distanceToPath(p, path) > OFF_ROUTE_M) {
                if (++offCount >= OFF_ROUTE_FIXES) {
                    offCount = 0
                    return Update(null, offRoute = true)
                }
            } else {
                offCount = 0
            }
            val step = steps[next]
            val d = distance(p, step.at)
            if (step.arrive && d <= 20) {
                next = steps.size
                return Update("${step.instruction}.", arrived = true)
            }
            if (d <= PASSED_M) {
                // At the turn: say it now if it wasn't announced, then preview the one after.
                val now = if (warnedFor != next) "Now, ${step.instruction.replaceFirstChar { it.lowercase() }}. " else ""
                next++
                val after = steps.getOrNull(next) ?: return Update(now.trim().ifEmpty { null })
                val d2 = distance(p, after.at)
                val then = if (after.arrive) "Your destination is ${spoken(d2)} ahead."
                else if (d2 > NEAR_M * 1.5) "Then continue for ${spoken(d2)}." else ""
                return Update((now + then).trim().ifEmpty { null })
            }
            if (d <= NEAR_M && warnedFor != next && !step.arrive) {
                warnedFor = next
                return Update("In ${spoken(d)}, ${step.instruction.replaceFirstChar { it.lowercase() }}.")
            }
            return Update(null)
        }

        /** Distance and instruction of the next manoeuvre, for "where now?". */
        fun nextSentence(p: Point): String {
            val step = steps.getOrNull(next) ?: return "You have arrived."
            return "In ${spoken(distance(p, step.at))}, ${step.instruction.replaceFirstChar { it.lowercase() }}."
        }
    }
}
