package com.disha.glassos.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.ContactsContract
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.text.format.DateFormat
import android.view.KeyEvent
import com.disha.glassos.ai.Boost
import com.disha.glassos.ai.BrainClient
import com.disha.glassos.ai.FreeSpeechClient
import com.disha.glassos.ai.TranscriptCleaner
import com.disha.glassos.ai.VisionAi
import com.disha.glassos.assistant.VoiceCommandRouter.Command
import com.disha.glassos.audio.AudioFx
import com.disha.glassos.audio.AudioRouter
import com.disha.glassos.audio.Earcons
import com.disha.glassos.audio.EarbudButton
import com.disha.glassos.audio.SpeechInput
import com.disha.glassos.audio.Speaker
import com.disha.glassos.audio.VoiceRecorder
import com.disha.glassos.audio.Wav
import com.disha.glassos.audio.WakeMatcher
import com.disha.glassos.audio.WakeSamples
import com.disha.glassos.audio.WakeWordListener
import com.disha.glassos.protocol.FrameAssembler
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.skills.Barcode
import com.disha.glassos.skills.Calls
import com.disha.glassos.skills.CaptionBoard
import com.disha.glassos.skills.EntryStore
import com.disha.glassos.skills.Gallery
import com.disha.glassos.skills.LiveCaptions
import com.disha.glassos.skills.MeetingNotes
import com.disha.glassos.skills.MessageCenter
import com.disha.glassos.skills.Navigator
import com.disha.glassos.skills.PageWatcher
import com.disha.glassos.skills.Places
import com.disha.glassos.skills.QrContent
import com.disha.glassos.skills.QrReader
import com.disha.glassos.skills.ReplyParse
import com.disha.glassos.skills.Sos
import com.disha.glassos.skills.TextSearch
import com.disha.glassos.skills.TimeRange
import com.disha.glassos.skills.VisualMemory
import com.disha.glassos.storage.MediaSaver
import com.disha.glassos.storage.PdfMaker
import com.disha.glassos.util.AppLog
import com.disha.glassos.util.Net
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The FRIDAY-style voice assistant.
 *
 * Tap (or earbud tap / notification) → beep → listen through the earbud mic (or phone mic) →
 * recognise → a quick local command (photo, timer, weather, torch, music…), the vision model for
 * questions about what the user sees, or the thinking model with tools for everything else →
 * speak the answer in the earbuds → in conversation mode, listen again for a follow-up.
 * Also speaks timers, reminders and alerts when they happen. Main thread only.
 */
class AssistantController(
    context: Context,
    private val settings: AppSettings,
    private val camera: CameraActions,
    private val ai: VisionAi,
    private val ui: Ui,
) : SpeechInput.Listener, VoiceRecorder.Listener, Speaker.Listener {

    enum class State(val label: String) {
        STARTING("Starting voice…"),
        IDLE("Tap the mic and speak"),
        PREPARING_MIC("Switching to the earbud mic…"),
        LISTENING("Listening…"),
        PROCESSING("Processing…"),
        SPEAKING("Speaking…"),
    }

    interface Ui {
        fun onAssistantState(state: State, detail: String)
        fun onMicLevel(level: Int)
        fun onPartialSpeech(text: String)
        fun onTranscript(who: String, text: String)
        fun onAudioRoute(route: AudioRouter.Route)
        /** Running background tasks in a line ("Watching for a bus, 4 minutes left"), or empty. */
        fun onTasks(text: String)
        /** Show photos matching [query] on the screen; false if the screen isn't open. */
        fun onShowGallery(query: String): Boolean
        /** Show live captions full screen; false if the screen isn't open. */
        fun onShowCaptions(): Boolean
        /** Open a link / contact / map: on the screen, or as a notification to tap. true if opened. */
        fun openIntent(intent: Intent, label: String): Boolean
    }

    /** What the assistant can do with the glasses. Callbacks run on the main thread. */
    interface CameraActions {
        fun isCameraReady(): Boolean
        fun isStreaming(): Boolean
        fun isRecording(): Boolean
        fun cameraStatusSentence(): String
        /** highRes: the largest picture size, for reading small text. */
        fun captureForAi(highRes: Boolean, onResult: (FrameAssembler.Frame?, String?) -> Unit)
        fun takePhoto(onDone: (String) -> Unit)
        fun startRecording(onDone: (String) -> Unit)
        fun stopRecording(onDone: (String) -> Unit)
        fun storageSentence(onDone: (String) -> Unit)
        fun connectCamera()
        fun disconnectCamera()
        fun startStream()
        fun stopStream()
        /** Keep the live view running for [tag] (document pages, captions...) until released. */
        fun holdStream(tag: String, fps: Int)
        fun releaseStream(tag: String)
        fun setReplay(on: Boolean): String
        fun saveReplay(seconds: Int, onDone: (String) -> Unit)
        fun replayOn(): Boolean
        /** Presentation mode (web view for a laptop): addresses to open, empty if it couldn't start. */
        fun presenterStart(): List<String>
        fun presenterStop()
        fun presenterRunning(): Boolean
        fun presenterUrls(): List<String>
        /** next / previous / goto / start / end / black, for the web slides and the PC helper. */
        fun slide(action: String, number: Int)
    }

    private companion object {
        const val TAG = "Voice"
        const val MAX_HISTORY = 8
        const val NOTHING = "NOTHING"
        const val WAIT_FOR_SPEECH_MS = 8000
        const val WAIT_FOR_FOLLOW_UP_MS = 6000
        const val FOLLOW_UP_DELAY_MS = 350L
        const val HOLD_MAX_MS = 60_000
        const val WATCH_FOR_INTERVAL_MS = 10_000L
        const val SOS_DELAY_MS = 10_000L
        const val GUIDE_INTERVAL_MS = 8_000L  // about 7 pictures a minute: within the free vision limits

        const val MEMORY_PROMPT =
            "List the objects you can see in this picture and where they are (on, next to or inside what), then the kind " +
                "of place, in one sentence of at most 40 words. Mention small personal items (keys, wallet, phone, glasses, " +
                "bag, bottle, remote, charger) when present. If the picture is too dark or blurry, reply NOTHING."
        const val CAPTION_PROMPT =
            "Write a one-sentence caption for this photo for finding it later: the main subject, the setting, and any " +
                "clearly readable words. At most 25 words, no preamble."
        const val GUIDE_PROMPT =
            "You are guiding a blind person who is walking. This picture is straight ahead from their glasses. In one short " +
                "sentence of at most 15 words: first warn about anything close ahead they could trip on or bump into (steps, " +
                "stairs, kerb, hole, pole, door, vehicle, bicycle, person), with its direction (left, right or ahead) and " +
                "roughly how many steps away; otherwise say briefly what is ahead. Read an important sign if there is one. If " +
                "the view is too dark or blurry, say: I can't see clearly."
        val HAZARD = Regex("(?i)\\b(careful|watch out|stop|step|steps|stairs|kerb|curb|hole|pole|vehicle|car|bike|bicycle|scooter|truck|bus|obstacle|wall|door|person|dog|edge|traffic)\\b")
        const val CURRENCY_PROMPT =
            "Identify any Indian currency notes or coins in this picture: the value of each (10, 20, 50, 100, 200 or 500 " +
                "rupee notes, or coins) and the total if there are several, using the printed numbers, colours and size. Answer in " +
                "one short spoken sentence. If you are not sure, say so; if it isn't money, say what it is."
        const val BARCODE_PROMPT =
            "Find a product barcode in this picture and read the number printed under it. Reply with only the digits, or " +
                "NONE if there is no readable barcode."
        const val SCAN_PROMPT =
            "Transcribe all the text in this picture exactly, in reading order, keeping headings, line breaks, lists and " +
                "numbers. Output only the text, nothing else. If there is no readable text, output NONE."
        const val WATCH_PROMPT =
            "Look at this image from my glasses. If there is something important or a hazard I should know " +
                "about right now (a vehicle approaching, a step, an obstacle, someone waving at me, a sign meant " +
                "for me), tell me in one short sentence. Otherwise reply with exactly: $NOTHING"

        /** Phone recogniser errors that mean its service is broken, not that nothing was said. */
        val SERVICE_ERRORS = setOf(
            SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_SERVER_DISCONNECTED, SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechInput.ERROR_NO_RESPONSE,
        )
        /** Commands whose own wording often contains "and" (descriptions, reminders, notes): kept local. */
        val SINGLE_ONLY_OK = setOf(
            Command.DESCRIBE_SCENE, Command.READ_TEXT, Command.REMEMBER, Command.REMINDER, Command.DISMISS,
            Command.STOP_SPEAKING, Command.BRIEFING, Command.HELP, Command.OBSERVE, Command.STOP_TASKS,
        )
        val REMEMBER_VIEW = setOf("this", "that", "this place", "this thing", "what i'm looking at", "what i am looking at", "what i see", "where i am")
        const val OFFLINE_ANSWER =
            "There's no internet right now, so I can't think that through. Offline I can still take photos and videos, save " +
                "the last 30 seconds, scan QR codes, scan pages into a PDF, move your slides, and set timers and reminders."
        const val CARD_PROMPT =
            "This is a business card or visiting card. Reply with JSON only, no other text, in this form: " +
                "{\"name\":\"\",\"title\":\"\",\"company\":\"\",\"phones\":[],\"emails\":[],\"website\":\"\",\"address\":\"\"}. " +
                "Copy names, numbers and addresses exactly as printed; leave out anything not on the card. If it is not a card, reply {}."
        val LANGUAGE_NAMES = linkedMapOf(
            "en" to "English", "hi" to "Hindi", "ta" to "Tamil", "te" to "Telugu", "bn" to "Bengali", "mr" to "Marathi",
            "gu" to "Gujarati", "kn" to "Kannada", "ml" to "Malayalam", "pa" to "Punjabi", "ur" to "Urdu", "fr" to "French",
            "de" to "German", "es" to "Spanish", "ja" to "Japanese", "zh" to "Chinese", "ar" to "Arabic", "ru" to "Russian",
        )
    }

    private val appContext = context.applicationContext
    private val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())
    private val router = AudioRouter(appContext) { publishRoute() }
    private val speech = SpeechInput(appContext, this)
    private val recorder = VoiceRecorder(this)
    private val stt = FreeSpeechClient(settings)
    private val speaker = Speaker(appContext, this)
    private val earcons = Earcons()

    private fun chime(s: Earcons.Sound) {
        if (settings.sounds) earcons.play(s)
    }
    private val earbudButton = EarbudButton(appContext) { onMicButton() }
    private val phone = PhoneActions(appContext, earbudButton)
    private val web = WebInfo()
    val memory = MemoryStore(appContext)
    val reminders = Reminders(appContext)
    private val brain = BrainClient(settings)
    // ---- skills ----
    val gallery = Gallery(appContext)
    private val visualMemory = VisualMemory(appContext)
    private val documents = EntryStore(appContext, "documents", 300)
    private val events = EntryStore(appContext, "events", 3000)
    private val places = Places(appContext)
    private val sos = Sos(appContext, settings, places)
    private val calls = Calls(appContext) { caller -> onIncomingCall(caller) }
    private val notes = MeetingNotes(stt, { whisperLanguage() }, NotesListener())
    private val navigator = Navigator(appContext, places, NavListener())
    private val captions = LiveCaptions(stt, CaptionsListener())
    private val work = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-skills").apply { isDaemon = true } }
    private val agent = Agent(brain, AgentHost())
    private val wake = WakeWordListener { onWakeCandidate(it) }
    private var wakeMatcher: WakeMatcher? = null
    private var wakeLoaded = ""          // version + sensitivity of the loaded samples
    private var lastWakeCheckAt = 0L

    private var state = State.STARTING
    private var micFromEarbuds = false
    private var turn = 0  // incremented per listen and by stopAll(); late callbacks of an old turn are ignored
    private var followUp = false          // the current listening is a follow-up in a conversation
    private var listenAfterSpeaking = false
    private var onlineThisTurn = false
    private var offlineThisTurn = false  // no internet: on-device recogniser
    private val history = ArrayList<VisionAi.Turn>()
    private val queued = ArrayList<String>()  // announcements waiting for the assistant to be free
    private var focusHandle: Any? = null
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) onFocusLost()
    }
    private val watchRunnable = Runnable { watchTick() }

    val currentState: State get() = state

    private val name get() = settings.assistantName
    private val title get() = settings.userTitle

    fun start() {
        router.start()
        applySettings()
        publishRoute()
        if (!speech.isAvailable()) AppLog.w(TAG, "No speech recognizer service on this phone")
        MessageCenter.onNewMessage = { m -> onNewMessage(m) }
        main.postDelayed(skillTicker, 30_000)
        restoreHistory()
    }

    /** Re-read settings that need action (earbud tap, watch mode, voice, wake phrase, routes). */
    fun applySettings() {
        earbudButton.enabled = settings.earbudTap
        speaker.configure(settings.voiceStyle.languageTags, settings.speechRate)
        AudioFx.enabled = settings.noiseReduction
        main.removeCallbacks(watchRunnable)
        if (settings.watchSeconds > 0) main.postDelayed(watchRunnable, settings.watchSeconds * 1000L)
        val wakeKey = "${settings.wakeVersion}/${settings.wakeSensitivity}"
        if (wakeKey != wakeLoaded) {
            wakeLoaded = wakeKey
            wakeMatcher = WakeSamples(appContext).matcher(settings.wakeSensitivity)
            wake.setMatcher(wakeMatcher)
            AppLog.i(TAG, "Wake phrase: " + (wakeMatcher?.let { "threshold %.2f (personal factor %.2f)".format(it.threshold, it.factor) } ?: "not recorded"))
        }
        updateWake()
        calls.start()  // once the phone-state permission is granted
        publishRoute()
    }

    /** True while the phone mic is listening for the wake phrase. */
    val wakeListening: Boolean get() = wake.isRunning

    /** The wake listener runs only while the assistant is idle; the assistant needs the mic otherwise. */
    private fun updateWake() {
        val want = settings.wakeEnabled && !settings.wakeEnrolling && wakeMatcher?.ready == true &&
            state == State.IDLE && micPermission() && !notes.running && !captions.running  // they hold the microphone
        when {
            want && !wake.isRunning -> wake.start()
            want -> wake.resume()
            wake.isRunning -> wake.stop()
        }
    }

    private fun micPermission() = Build.VERSION.SDK_INT < 23 ||
        appContext.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /**
     * The phone heard something like the user's wake phrase. A clear, short match wakes at once
     * (beep, then listening). Otherwise, if online speech is allowed, the snippet is checked by the
     * speech service, which also catches a request said in the same breath ("Disha, what's
     * this?"). Without online speech the phone's match alone decides.
     */
    private fun onWakeCandidate(c: WakeWordListener.Candidate) {
        if (state != State.IDLE) return
        val m = wakeMatcher ?: return
        val shortPhrase = c.speechMs <= m.phraseMs * 1.35f + 150
        // Only a very close match wakes without confirmation: a false wake would start recording.
        val clear = c.score <= c.threshold * 0.5f
        if (!settings.useOnlineSpeech || (shortPhrase && clear)) {
            wakeUp()
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastWakeCheckAt < 5000) {  // don't flood the free speech service with near-misses
            wake.resume()
            return
        }
        lastWakeCheckAt = now
        val myTurn = ++turn
        setState(State.PROCESSING, "Was that my name? Checking…")
        // At most the first 6 s: enough for "Disha, <request>", and no more of anyone else's speech.
        stt.transcribe(Wav.fromPcm(c.pcm, 0, minOf(c.pcm.size, Wav.RATE * 6)), whisperLanguage()) { r ->
            if (myTurn != turn) return@transcribe
            val text = (r as? FreeSpeechClient.Result.Text)?.let { TranscriptCleaner.clean(it.text) }
            when {
                text != null && mentionsName(text) -> {
                    AppLog.i(TAG, "Wake phrase confirmed: \"$text\"")
                    if (VoiceCommandRouter.stripName(text, wakeNames()).isBlank()) wakeUp() else handle(text)
                }
                r is FreeSpeechClient.Result.Failure && shortPhrase -> wakeUp()  // service busy: trust the phone
                else -> {
                    AppLog.i(TAG, "Not the wake phrase: \"${text ?: ""}\"")
                    setState(State.IDLE, State.IDLE.label)
                }
            }
        }
    }

    private fun wakeUp() {
        AppLog.i(TAG, "Woken by the wake phrase")
        chime(Earcons.Sound.WAKE)
        listen(followUp = true, silentStart = true)  // silent if nothing follows
    }

    // ---- hold to talk: press and hold the orb, speak, let go ----

    private var holdMode = false
    private var holdReleased = false

    fun holdStart() {
        if (state == State.PROCESSING || state == State.PREPARING_MIC || state == State.LISTENING) return
        listenAfterSpeaking = false
        speaker.stop()
        listen(followUp = false, hold = true)
    }

    fun holdEnd() {
        if (!holdMode) return
        holdReleased = true
        if (state == State.LISTENING) {
            if (onlineThisTurn) recorder.finishNow() else speech.stop()
        }
    }

    /** The name and how speech recognition may spell it ("Diha", "Deesha", Hindi "दिशा"). */
    private fun wakeNames() = (listOf(name) + VoiceCommandRouter.NAME_VARIANTS).distinct()

    private fun mentionsName(text: String): Boolean {
        val first = text.lowercase(Locale.US).split(Regex("\\s+")).take(5).joinToString(" ")
        val names = wakeNames().map { Regex.escape(it.lowercase(Locale.US)) }
        return Regex("(?<![\\p{L}\\p{M}])(${names.joinToString("|")})(?![\\p{L}\\p{M}])").containsMatchIn(first)
    }

    private fun whisperLanguage(): String? =
        settings.speechLanguage.let { if (it == AppSettings.AUTO_LANGUAGE) null else it.substringBefore('-') }

    fun shutdown() {
        main.removeCallbacks(watchRunnable)
        main.removeCallbacks(skillTicker)
        MessageCenter.onNewMessage = null
        calls.stop()
        notes.stop()
        captions.stop()
        CaptionBoard.setMode("")
        navigator.stop()
        doc?.let { camera.releaseStream("doc") }
        doc = null
        work.shutdown()
        wake.stop()
        speech.destroy()
        recorder.cancel()
        speaker.shutdown()
        router.releaseEarbudMic {}
        router.stop()
        earbudButton.release()
        earcons.release()
        abandonFocus()
    }

    /** Mic button, earbud tap or notification "Talk". */
    fun onMicButton() {
        when (state) {
            State.STARTING, State.IDLE -> listen(followUp = false)
            State.LISTENING -> if (onlineThisTurn) recorder.finishNow() else speech.stop()  // recognise what was said so far
            State.SPEAKING -> {
                listenAfterSpeaking = false
                speaker.stop()
                listen(followUp = false)
            }
            State.PREPARING_MIC, State.PROCESSING -> Unit
        }
    }

    /** Stop button: stop listening, thinking and speaking, and end the conversation. */
    fun stopAll() {
        turn++
        if (sosCountdown != null) {  // Stop pressed during the countdown: no emergency message
            main.removeCallbacks(sosCountdown!!)
            sosCountdown = null
            ui.onTranscript(name, "Emergency message cancelled.")
        }
        listenAfterSpeaking = false
        speech.cancel()
        recorder.cancel()
        speaker.stop()
        ui.onMicLevel(0)
        ui.onPartialSpeech("")
        micFromEarbuds = false
        router.releaseEarbudMic { publishRoute() }
        abandonFocus()
        setState(State.IDLE, State.IDLE.label)
    }

    /**
     * Say something unasked (glasses online, low battery, a reminder). Waits until the assistant is
     * free and its voice is ready, so it never cuts into a conversation.
     */
    fun announce(text: String) {
        if (speaker.ready && (state == State.IDLE || state == State.STARTING)) {
            reply(text)
        } else {
            queued.add(text)
            AppLog.i(TAG, "Queued: $text")
        }
    }

    /** A timer or reminder is due: alert tone, then say it. */
    fun onReminderDue(item: Reminders.Item) {
        val who = if (title.isNotEmpty()) "$title, " else ""
        val text = when {
            item.isTimer && item.text.isNotEmpty() -> "${who}your ${item.text} timer is done."
            item.isTimer -> "${who}your ${TimeParse.describe(item.seconds)} timer is done."
            item.text.isNotEmpty() -> "${who}reminder: ${item.text}."
            else -> "${who}this is your reminder."
        }.replaceFirstChar { it.uppercase() }
        chime(Earcons.Sound.ALERT)
        main.postDelayed({ announce(text) }, 600)
    }

    // ---------------------------------------------------------------------------------------
    // Listening
    // ---------------------------------------------------------------------------------------

    private fun listen(followUp: Boolean, hold: Boolean = false, silentStart: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 23 &&
            appContext.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            reply("Microphone permission is missing. Open the app and tap the mic once to allow it.")
            return
        }
        onlineThisTurn = settings.useOnlineSpeech
        offlineThisTurn = false
        // No internet: the phone's own (on-device) recogniser still understands commands.
        if (onlineThisTurn && settings.offlineFallback && !Net.online(appContext) && speech.isAvailable()) {
            AppLog.i(TAG, "Offline: using the phone's on-device speech recogniser" + if (speech.onDeviceAvailable()) "" else " (may need a download)")
            onlineThisTurn = false
            offlineThisTurn = true
        }
        if (!onlineThisTurn && !speech.isAvailable()) {
            reply("This phone has no working speech service. Open the app, tap the mic, and allow free online speech recognition.")
            return
        }
        val myTurn = ++turn
        this.followUp = followUp
        holdMode = hold
        holdReleased = false
        listenAfterSpeaking = false
        requestFocus(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
        if (!silentStart) chime(Earcons.Sound.LISTEN)
        if (settings.useEarbudMic && router.hasEarbudMic()) {
            setState(State.PREPARING_MIC, "Switching the earbuds to headset mode…")
            router.acquireEarbudMic { ok ->
                if (myTurn != turn) return@acquireEarbudMic  // stopped meanwhile
                micFromEarbuds = ok
                if (!ok) AppLog.w(TAG, "Earbud mic unavailable; listening with the phone mic")
                publishRoute()
                beginRecognition()
            }
        } else {
            micFromEarbuds = false
            beginRecognition()
        }
    }

    private fun beginRecognition() {
        val where = if (micFromEarbuds) "your earbuds" else "the phone mic"
        setState(
            State.LISTENING,
            when {
                holdMode -> "Holding: speak, then let go…"
                followUp -> "Anything else? Listening through $where…"
                else -> "Listening through $where…"
            },
        )
        if (onlineThisTurn) {
            val device = if (micFromEarbuds) router.earbudMicInput() else null
            if (holdMode) {
                // Ends when the orb is let go (up to a minute), not at a pause.
                recorder.start(micFromEarbuds, device, HOLD_MAX_MS, HOLD_MAX_MS, HOLD_MAX_MS)
                if (holdReleased) recorder.finishNow()  // let go while the earbuds were still switching
            } else {
                recorder.start(micFromEarbuds, device, if (followUp) WAIT_FOR_FOLLOW_UP_MS else WAIT_FOR_SPEECH_MS, settings.endSilenceMs)
            }
        } else {
            val lang = settings.speechLanguage.let { if (it == AppSettings.AUTO_LANGUAGE) Locale.getDefault().toLanguageTag() else it }
            speech.start(lang, settings.preferOfflineSpeech, onDevice = offlineThisTurn)
        }
    }

    // ---- shared by both recognisers ----

    override fun onLevel(level: Int) = ui.onMicLevel(level)

    /** Nothing was said: the end of a conversation is silent, a direct request gets an answer. */
    private fun heardNothing(message: String) {
        ui.onMicLevel(0)
        ui.onPartialSpeech("")
        afterListening {
            if (followUp) {
                AppLog.i(TAG, "No follow-up; conversation ended")
                chime(Earcons.Sound.DONE)
                abandonFocus()
                setState(State.IDLE, State.IDLE.label)
            } else {
                reply(message)
            }
        }
    }

    private fun heard(raw: String) {
        AppLog.i(TAG, "Heard: \"$raw\"")
        ui.onMicLevel(0)
        ui.onPartialSpeech("")
        afterListening { handle(raw) }
    }

    // ---- online recogniser (VoiceRecorder + FreeSpeechClient) ----

    override fun onSpeechStarted() = ui.onPartialSpeech("…")

    override fun onRecorded(wav: ByteArray, speechMs: Int) {
        ui.onMicLevel(0)
        chime(Earcons.Sound.HEARD)  // got it: the answer is on its way
        setState(State.PROCESSING, "Recognising…")
        val myTurn = turn
        // Recognise while the earbuds switch back to media audio; continue when both are done.
        var released = !(micFromEarbuds || router.earbudMicActive)
        var result: FreeSpeechClient.Result? = null
        fun proceed() {
            val r = result ?: return
            if (!released || myTurn != turn) return
            when (r) {
                is FreeSpeechClient.Result.Text -> {
                    val text = TranscriptCleaner.clean(r.text)
                    if (text == null) heardNothing("I didn't catch that.") else heard(text)
                }
                is FreeSpeechClient.Result.Failure -> {
                    ui.onPartialSpeech("")
                    chime(Earcons.Sound.ERROR)
                    reply(r.message)
                }
            }
        }
        if (!released) {
            router.releaseEarbudMic {
                micFromEarbuds = false
                publishRoute()
                released = true
                proceed()
            }
        }
        stt.transcribe(wav, whisperLanguage()) { r ->
            result = r
            proceed()
        }
    }

    override fun onNoSpeech() = heardNothing("I didn't hear anything.")

    override fun onRecordError(message: String) {
        AppLog.w(TAG, "Recording: $message")
        chime(Earcons.Sound.ERROR)
        ui.onMicLevel(0)
        ui.onPartialSpeech("")
        afterListening { reply(message) }
    }

    // ---- phone recogniser (SpeechInput) ----

    override fun onListening() = Unit

    override fun onSpeechEnded() {
        setState(State.PROCESSING, "Recognising…")
    }

    override fun onPartial(text: String) = ui.onPartialSpeech(text)

    override fun onFinalResult(text: String) = heard(text)

    override fun onFailed(code: Int, message: String) {
        AppLog.w(TAG, "Recognition: $message (code $code)")
        if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            heardNothing(message)
            return
        }
        ui.onMicLevel(0)
        ui.onPartialSpeech("")
        val hint = when {
            offlineThisTurn && code in SERVICE_ERRORS ->
                " There's no internet, and this phone has no offline speech recogniser ready. In Settings, tap Download offline speech while online."
            code in SERVICE_ERRORS && !settings.useOnlineSpeech ->
                " This phone's speech service isn't working. In Settings, choose free online speech recognition and allow it."
            else -> ""
        }
        afterListening { reply(message + hint) }
    }

    /** Close the earbud mic first, so the answer plays in media quality. */
    private fun afterListening(next: () -> Unit) {
        if (micFromEarbuds || router.earbudMicActive) {
            setState(State.PROCESSING, "Switching the earbuds back to media audio…")
            val myTurn = turn
            router.releaseEarbudMic {
                micFromEarbuds = false
                publishRoute()
                if (myTurn == turn) next()
            }
        } else {
            next()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Understanding a request
    // ---------------------------------------------------------------------------------------

    private fun handle(heard: String) {
        ui.onTranscript("You", heard)
        val text = VoiceCommandRouter.stripName(heard, wakeNames())
        if (handlePending(text)) return
        if (handleDocument(text)) return
        if (text.isEmpty()) {
            // Only the name: answer and keep listening.
            reply(if (title.isNotEmpty()) "Yes, $title?" else "Yes?", thenListen = true)
            return
        }
        var command = VoiceCommandRouter.parse(text)
        // "Take a photo and start recording": the quick commands handle one thing, the thinking model several.
        if (command !in SINGLE_ONLY_OK && VoiceCommandRouter.hasSeveralParts(text)) command = Command.UNKNOWN
        AppLog.i(TAG, "Command: $command")
        val myTurn = turn
        val answer: (String) -> Unit = { sentence -> if (myTurn == turn) reply(sentence, thenListen = true) }
        when (command) {
            Command.TAKE_PHOTO -> withCamera("Taking a photo…") { camera.takePhoto(answer) }
            Command.START_RECORDING -> withCamera("Starting the recording…") { recordVideo(TimeParse.durationSeconds(text), answer) }
            Command.STOP_RECORDING -> {
                setState(State.PROCESSING, "Stopping the recording…")
                camera.stopRecording(answer)
            }
            Command.STORAGE_STATUS -> {
                setState(State.PROCESSING, "Checking storage…")
                camera.storageSentence(answer)
            }
            Command.DESCRIBE_SCENE -> askAi(text, needImage = true)
            Command.READ_TEXT -> askAi("$text\n(Read any text in the image exactly as written.)", needImage = true, highRes = true)
            Command.CAMERA_STATUS -> answer(camera.cameraStatusSentence() + " " + earbudSentence() + " " + aiSentence())
            Command.STOP_SPEAKING -> {
                speaker.stop()
                abandonFocus()
                setState(State.IDLE, State.IDLE.label)
            }
            Command.DISMISS -> reply(if (title.isNotEmpty()) "Anytime, $title." else "Anytime.")
            Command.DISCONNECT_CAMERA -> {
                camera.disconnectCamera()
                reply("Camera disconnected.")
            }
            Command.CONNECT_CAMERA -> {
                camera.connectCamera()
                reply("Connecting to the camera.")
            }
            Command.START_STREAM -> withCamera("Starting the live view…") {
                camera.startStream()
                answer("Live view started.")
            }
            Command.STOP_STREAM -> {
                camera.stopStream()
                answer("Live view stopped.")
            }
            Command.TIME -> answer("It's ${timeNow()}.")
            Command.DATE -> answer("Today is ${dateNow()}.")
            Command.BATTERY -> answer(batterySentence())
            Command.HELP -> answer(
                "Ask me anything. I can look and describe, read, translate signs and menus, check if food is healthy, " +
                    "recognise money, scan QR codes and business cards, scan many pages into a PDF, take photos and videos, " +
                    "save the last 30 seconds, watch for something, take meeting notes, show live captions or translate a " +
                    "conversation, walk you somewhere with turn by turn directions, move your slides, read and reply to your " +
                    "messages, answer calls, remember things and find where you left them, tell you about your day, set " +
                    "timers and reminders, and send an emergency message if you say help.",
            )
            Command.TIMER -> {
                val seconds = TimeParse.durationSeconds(text)
                answer(if (seconds == null) "How long should the timer be?" else setTimer(seconds, ""))
            }
            Command.REMINDER -> {
                val r = TimeParse.reminder(text, minuteOfDay())
                answer(if (r == null) "When should I remind you?" else setReminder(r.seconds, r.text))
            }
            Command.CANCEL_TIMERS -> answer(cancelTimers())
            Command.LIST_TIMERS -> answer(timersSentence())
            Command.WEATHER -> weather(text, myTurn)
            Command.NEWS -> news(VoiceCommandRouter.newsTopic(text), myTurn)
            Command.BRIEFING -> briefing(myTurn)
            Command.FLASHLIGHT_ON -> answer(phone.flashlight(true))
            Command.FLASHLIGHT_OFF -> answer(phone.flashlight(false))
            Command.VOLUME_UP -> answer(phone.volume(2))
            Command.VOLUME_DOWN -> answer(phone.volume(-2))
            Command.MUTE, Command.MEDIA_PAUSE -> reply(phone.media(KeyEvent.KEYCODE_MEDIA_PAUSE))
            Command.MEDIA_PLAY -> reply(phone.media(KeyEvent.KEYCODE_MEDIA_PLAY))
            Command.MEDIA_NEXT -> reply(phone.media(KeyEvent.KEYCODE_MEDIA_NEXT))
            Command.MEDIA_PREVIOUS -> reply(phone.media(KeyEvent.KEYCODE_MEDIA_PREVIOUS))
            Command.REMEMBER -> {
                val fact = VoiceCommandRouter.rememberText(text)
                when {
                    fact.lowercase(Locale.US).trim('.', '!', ' ') in REMEMBER_VIEW -> rememberView(myTurn)
                    fact.isEmpty() -> answer("What should I remember?")
                    else -> answer(remember(fact))
                }
            }
            Command.RECALL -> answer(recallSentence())
            Command.FORGET -> {
                val what = VoiceCommandRouter.forgetText(text)
                when {
                    what.lowercase(Locale.US) in setOf("everything", "all", "all of it", "it all", "everything you remember") ->
                        answer("To wipe everything I remember, use Clear memory in Settings. I'd rather not lose it by accident.")
                    memory.forget(what) > 0 -> answer("Done, I've forgotten that.")
                    else -> think(text, null)  // let the thinking model pick the right fact by number
                }
            }
            Command.STOP_TASKS -> answer(stopTasks())
            Command.SOS -> startSos()
            Command.CALL_WHO -> answer(if (calls.ringing) "${calls.callerName().replaceFirstChar { it.uppercase() }} is calling." else "No call is ringing right now.")
            Command.CALL_ANSWER -> if (calls.ringing) reply(calls.answer()) else think(text, null)
            Command.CALL_REJECT -> if (calls.ringing) reply(calls.reject()) else think(text, null)
            Command.READ_MESSAGES -> answer(readMessages())
            Command.REPLY_MESSAGE -> prepareReply(text)
            Command.GUIDE_START -> startGuide()
            Command.GUIDE_STOP -> answer(stopGuide())
            Command.NOTES_START -> startNotes()
            Command.NOTES_STOP -> stopNotes()
            Command.MEMORY_LOG_ON -> answer(setVisualMemory(true))
            Command.MEMORY_LOG_OFF -> answer(setVisualMemory(false))
            Command.DIARY -> diary(text)
            Command.FIND_OBJECT -> findObject(text)
            Command.GALLERY_SEARCH -> gallerySearch(text)
            Command.TRANSLATE -> translate(text)
            Command.FOOD -> food(text)
            Command.CURRENCY -> lookAndSay(CURRENCY_PROMPT, "Counting the money…", logAs = "Checked money")
            Command.SCAN_DOC -> scanDocument()
            Command.DOC_SUMMARY -> summariseDocument()
            Command.DOC_READ -> readDocument()
            Command.OBSERVE -> observe((TimeParse.durationSeconds(text) ?: 10).coerceIn(3, 30), text)
            Command.DOC_START -> startDocument(text)
            Command.DOC_DONE -> reply("There's no document in progress. Say make a document to start one.")
            Command.REPLAY_ON -> answer(camera.setReplay(true))
            Command.REPLAY_OFF -> answer(camera.setReplay(false))
            Command.REPLAY_SAVE -> {
                setState(State.PROCESSING, "Saving the replay…")
                camera.saveReplay(TimeParse.durationSeconds(text) ?: 30) { s ->
                    if (s.startsWith("Saved")) logEvent("Saved an instant replay")
                    answer(s)
                }
            }
            Command.NAVIGATE -> navigate(VoiceCommandRouter.navDestination(text) ?: text)
            Command.NAV_STOP -> answer(stopNavigation())
            Command.NAV_STATUS -> if (navigator.active) answer(navigator.statusSentence()) else think(text, null)
            Command.CAPTIONS_START -> startCaptions(false, text)
            Command.TRANSLATOR_START -> startCaptions(true, text)
            Command.CAPTIONS_STOP -> reply(stopCaptions())
            Command.QR_SCAN -> scanCode()
            Command.CARD_SCAN -> scanCard()
            Command.SLIDE_NEXT -> slide("next")
            Command.SLIDE_PREVIOUS -> slide("previous")
            Command.SLIDE_GOTO -> slide("goto", VoiceCommandRouter.slideNumber(text) ?: 1)
            Command.SLIDE_START -> slide("start")
            Command.SLIDE_END -> slide("end")
            Command.SLIDE_BLACK -> slide("black")
            Command.PRESENT_ON -> answer(startPresenting())
            Command.PRESENT_OFF -> {
                camera.presenterStop()
                answer("Presentation mode off.")
            }
            Command.UNKNOWN -> {
                // About what the user sees: the thinking model gets a fresh picture, so it can answer
                // and act on it in one go ("if that's a receipt, remember the total").
                // Hindi and mixed sentences are not parsed locally, so they get a picture too.
                val visual = VoiceCommandRouter.looksVisual(text) || settings.speechLanguage.startsWith("hi") ||
                    text.any { it in 'ऀ'..'ॿ' }
                if (visual && camera.isCameraReady() && settings.aiImageConsent) {
                    setState(State.PROCESSING, "Looking…")
                    camera.captureForAi(looksLikeReading(text)) { frame, _ ->
                        if (myTurn == turn) think(text, frame?.data)
                    }
                } else {
                    think(text, null)
                }
            }
        }
    }

    private fun withCamera(working: String, action: () -> Unit) {
        if (!camera.isCameraReady()) {
            reply("The camera isn't connected. Plug the glasses into the phone, or say connect camera.")
            return
        }
        setState(State.PROCESSING, working)
        action()
    }

    // ---------------------------------------------------------------------------------------
    // Thinking model with tools
    // ---------------------------------------------------------------------------------------

    /** image: what the camera sees now, when the request is about it (the model can see and act). */
    private fun think(text: String, image: ByteArray?) {
        if (!brain.isConfigured()) {
            reply("Gemini isn't set up yet. Open Settings in the app: choose the free AI, or paste your Gemini key.")
            return
        }
        if (!Net.online(appContext)) {
            reply(OFFLINE_ANSWER)
            return
        }
        val myTurn = turn
        setState(State.PROCESSING, if (image != null) "Looking and thinking…" else "Thinking…")
        agent.run(brainPrompt(), history.toList(), text, image) { result ->
            if (myTurn != turn) return@run
            when (result) {
                is Agent.Result.Speak -> {
                    addHistory(text, result.text)
                    reply(result.text, thenListen = true)
                }
                is Agent.Result.Look -> askAi(result.question, needImage = true, highRes = looksLikeReading(result.question))
                is Agent.Result.Observe -> observe(result.seconds, result.question)
                is Agent.Result.Handoff -> runHandoff(result.tool, result.args, text)
                is Agent.Result.Failure -> {
                    // The thinking models are busy or unreachable: the vision models can still answer in words.
                    AppLog.w(TAG, "Thinking model: ${result.message}; asking ${ai.name} instead")
                    if (ai.isConfigured()) callAi(text, image, myTurn) else reply(result.message)
                }
            }
        }
    }

    private fun looksLikeReading(q: String) =
        Regex("(?i)\\b(read|written|text|says|say|label|sign|menu|price|number|name)\\b").containsMatchIn(q)

    /** Persona + rules + live context + memory, for the thinking model. */
    private fun brainPrompt(): String =
        persona() +
            " You can act through tools: use them whenever they fit, right away, and confirm briefly. When a picture " +
            "is attached, it is what the glasses camera sees right now: use it, and act on it when asked (for example " +
            "take_photo of something you see, or remember a number you read). Without a picture, call look for " +
            "anything about what the user sees or holds (\"this\", \"that\", objects, text, people, places), and " +
            "watch_briefly for what happens over the next few seconds. For things that take time use record_video with seconds, " +
            "photo_series, or alert_when_seen (it keeps watching and alerts the user later), and stop_tasks to end them. Use get_weather and get_news for " +
            "current information, and search_wikipedia for facts you are not sure about. Use remember when the user " +
            "tells you something to keep, and forget_memory with the fact's number to delete one. Never invent tool " +
            "results, and never say you did something unless you called its tool now; when asked for several things, " +
            "call a tool for each. When the user mentions a lasting fact about themselves (their name, family members, " +
            "diet, allergies, health, home or work area, likes and dislikes), save it with remember without being asked " +
            "and say in a few words that you will remember it; don't save passing remarks. " +
            "Use read_messages for the user's messages and reply_message to answer one (for example " +
            "\"tell Rahul I'm coming\"); it is sent only after the user says yes. Use search_my_memory for where things were, " +
            "what was seen, or what happened earlier. Use start_document when the user wants to scan several pages into a " +
            "document or PDF (you will then scan each page they show), navigate_to for walking directions to a place, " +
            "slide_control to move the user's presentation slides (next, previous, go to a number), save_replay to keep " +
            "the last seconds of video (\"save that\"), scan_code for QR codes and barcodes, read_business_card to save a " +
            "contact from a card, and live_captions for captions or a two-way translator. Only offer help you can actually " +
            "give with these tools (you cannot control lights or other devices). You cannot place calls, start new chats, " +
            "browse websites or pay; if asked, say so in a few words.\n\n" +
            contextBlock()

    /** Persona + rules + context, for the vision model (it sees the picture, but has no tools). */
    private fun visionPrompt(): String =
        persona() +
            " When an image is attached, it was just taken by the camera on the glasses and shows what the user is " +
            "looking at: use it. When asked to read text, read it exactly. If the image is unclear, say so and suggest " +
            "moving closer or adding light. If you see a hazard (traffic, a step, an obstacle), mention it first.\n\n" +
            contextBlock()

    private fun persona(): String =
        "You are $name, the AI built into ${if (title.isNotEmpty()) "the smart glasses of the person you call \"$title\"" else "the user's smart glasses"}, " +
            "in the spirit of JARVIS and FRIDAY from the Iron Man films: calm, sharp, quick, quietly witty and loyal. " +
            "You anticipate what the user needs: when a request is ambiguous, make the sensible assumption and say it in " +
            "a few words instead of asking; when you notice something useful or a risk, mention it once. Think through " +
            "the request before answering, but speak only the result. Your words are spoken aloud in their earbuds, so " +
            "keep answers to one to three short sentences unless they ask for more, with no markdown, lists, emojis or links. " +
            (if (title.isNotEmpty()) "Call them \"$title\" now and then, not in every reply. " else "") +
            "Reply in the language the user spoke; write Hindi in Devanagari script. The user is in India: use rupees, " +
            "kilometres and Celsius, and understand Hinglish. Answer first, then at most one useful extra."

    private fun contextBlock(): String = buildString {
        append("Context right now:\n")
        append("- Local time: ").append(SimpleDateFormat("EEEE d MMMM yyyy, h:mm a", Locale.ENGLISH).format(Date())).append('\n')
        append("- User's city: ").append(settings.homeCity.ifEmpty { "not set (the weather tool finds it from the internet connection)" }).append('\n')
        append("- Phone battery: ").append(batteryPercent()?.let { "$it%" } ?: "unknown").append('\n')
        append("- Glasses camera: ").append(if (camera.isCameraReady()) "connected" else "not connected")
        if (camera.isRecording()) append(", recording video")
        append('\n')
        append("- Audio: ").append(earbudSentence()).append('\n')
        val pending = reminders.pending()
        if (pending.isNotEmpty()) append("- Timers and reminders: ").append(timersSentence()).append('\n')
        if (tasks.isNotEmpty()) append("- Background tasks: ").append(tasksSentence()).append('\n')
        if (navigator.active) append("- Navigating on foot to ").append(navigator.destinationName).append('\n')
        doc?.let { append("- Making a document: ").append(it.pages.size).append(" pages scanned so far\n") }
        if (camera.presenterRunning()) append("- Presentation mode is on (slides can be moved)\n")
        if (camera.replayOn()) append("- Instant replay is keeping the last 30 seconds\n")
        val facts = memory.promptText()
        append("\nThings the user asked you to remember (numbered):\n").append(facts.ifEmpty { "(nothing yet)" })
    }

    private inner class AgentHost : Agent.Host {
        override fun takePhoto(done: (String) -> Unit) =
            if (camera.isCameraReady()) camera.takePhoto(done) else done("The camera isn't connected.")
        override fun recordVideo(seconds: Int?, done: (String) -> Unit) = this@AssistantController.recordVideo(seconds, done)
        override fun stopRecording(done: (String) -> Unit) {
            tasks.values.filter { it.kind == "record" }.forEach { removeTask(it.id, run = false) }
            camera.stopRecording(done)
        }
        override fun photoSeries(count: Int, intervalSeconds: Int) = this@AssistantController.photoSeries(count, intervalSeconds)
        override fun watchFor(target: String, minutes: Double, photo: Boolean) = this@AssistantController.watchFor(target, minutes, photo)
        override fun stopTasks() = this@AssistantController.stopTasks()
        override fun listTasks() = if (tasks.isEmpty()) "No background tasks are running." else tasksSentence()
        override fun searchMemory(query: String): String {
            val found = memoryNotes(query, TimeRange.parse(query, System.currentTimeMillis()), 8)
            return if (found.isEmpty()) "No notes match \"$query\"." else found.joinToString("\n") { "${stamp(it.time)}: ${it.text}" }
        }
        override fun readMessages() = this@AssistantController.readMessages()
        override fun prepareReply(to: String?, text: String): String {
            if (!MessageCenter.isAllowed(appContext)) return "I can't reach your messages: allow notification access for DISHA in Settings."
            val target = MessageCenter.replyTarget(to) ?: return "I don't have a recent message ${to?.let { "from $it " } ?: ""}that I can reply to."
            return armReply(target, text)
        }
        override fun setTimer(seconds: Int, label: String) = this@AssistantController.setTimer(seconds, label)
        override fun setReminder(seconds: Int, text: String) = this@AssistantController.setReminder(seconds, text)
        override fun cancelTimers() = this@AssistantController.cancelTimers()
        override fun listTimers() = timersSentence()
        override fun remember(fact: String) = this@AssistantController.remember(fact)
        override fun forgetMemory(number: Int): String {
            val f = memory.forgetNumber(number) ?: return "There's no remembered fact number $number."
            return "Forgotten: ${f.text}."
        }
        override fun weather(city: String, done: (String?, String?) -> Unit) =
            web.weather(city.ifBlank { settings.homeCity }) { w, e -> done(w?.forModel(), e) }
        override fun news(topic: String?, done: (String?, String?) -> Unit) =
            web.headlines(topic, settings.speechLanguage) { h, e -> done(h?.take(8)?.joinToString("\n"), e) }
        override fun wikipedia(query: String, done: (String?, String?) -> Unit) = web.wikipedia(query, done)
        override fun flashlight(on: Boolean) = phone.flashlight(on)
        override fun volume(steps: Int) = phone.volume(steps)
        override fun media(action: String) = phone.media(
            when (action) {
                "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                else -> KeyEvent.KEYCODE_MEDIA_PLAY
            },
        )
        override fun minuteOfDay() = this@AssistantController.minuteOfDay()
        override fun skill(name: String, args: org.json.JSONObject, done: (String) -> Unit) {
            when (name) {
                "slide_control" -> {
                    val action = args.optString("action").ifBlank { "next" }
                    slide(action, args.optInt("number", 1), speak = false)
                    done("")
                }
                "save_replay" -> camera.saveReplay(args.optInt("seconds", 30).takeIf { it > 0 } ?: 30, done)
                "instant_replay" -> done(camera.setReplay(args.optBoolean("on", true)))
                "stop_navigation" -> done(stopNavigation())
                "stop_captions" -> done(stopCaptions())
                "presentation_mode" -> done(if (args.optBoolean("on", true)) startPresenting() else { camera.presenterStop(); "Presentation mode off." })
                else -> done("")
            }
        }
    }

    /** A tool that runs its own conversation, chosen by the thinking model. */
    private fun runHandoff(tool: String, args: org.json.JSONObject, text: String) {
        when (tool) {
            "start_document" -> startDocument(args.optString("title").let { if (it.isBlank()) text else "$text called $it" })
            "finish_document" -> if (doc != null) finishDocument() else reply("There's no document in progress.")
            "navigate_to" -> navigate(args.optString("place").ifBlank { VoiceCommandRouter.navDestination(text) ?: text })
            "scan_code" -> scanCode()
            "read_business_card" -> scanCard()
            "live_captions" -> startCaptions(args.optBoolean("translate", false), text + " " + args.optString("other_language"))
            else -> reply("Done.")
        }
    }

    // ---------------------------------------------------------------------------------------
    // Skills: SOS, calls, messages, guide mode, meeting notes, memory of the day, seeing
    // ---------------------------------------------------------------------------------------

    /** A question waiting for yes / no ("Send it?"), or for the text of a reply. */
    private class Pending(val until: Long, val onYes: (() -> Unit)? = null, val onText: ((String) -> Unit)? = null)

    private var pending: Pending? = null
    private var sosCountdown: Runnable? = null
    private var guideTaskId = 0
    private var guideHazardsOnly = false
    private var notesTaskId = 0
    private var lastMemoryAt = 0L
    private var lastPlaceAt = 0L

    /** Answers to an open question come first; returns true if [text] was one. */
    private fun handlePending(text: String): Boolean {
        if (sosCountdown != null && (VoiceCommandRouter.isNo(text) || text.contains("false alarm", ignoreCase = true))) {
            cancelSos()
            return true
        }
        val p = pending ?: return false
        pending = null
        if (System.currentTimeMillis() > p.until || text.isBlank()) return false
        p.onText?.let {
            if (VoiceCommandRouter.isNo(text)) reply("Okay, nothing sent.") else it(text)
            return true
        }
        return when {
            VoiceCommandRouter.isYes(text) -> { p.onYes?.invoke(); true }
            VoiceCommandRouter.isNo(text) -> { reply("Okay, I won't."); true }
            else -> false  // something else entirely: handle it normally
        }
    }

    private fun logEvent(text: String) = events.add(EntryStore.Entry(System.currentTimeMillis(), text))

    private val skillTicker = object : Runnable {
        override fun run() {
            main.postDelayed(this, 60_000)
            val now = System.currentTimeMillis()
            val mins = settings.visualMemoryMinutes
            // Not while recording: the picture may need another camera size, which would interrupt the video.
            if (mins > 0 && now - lastMemoryAt >= mins * 60_000L && camera.isCameraReady() && settings.aiImageConsent &&
                !tasks.containsKey(guideTaskId) && !camera.isRecording()
            ) {
                lastMemoryAt = now
                camera.captureForAi(false) { frame, _ ->
                    if (frame == null) return@captureForAi
                    ai.ask(MEMORY_PROMPT, frame.data, emptyList(), "You describe pictures briefly and precisely.") { r ->
                        if (r is VisionAi.Result.Answer && !r.text.contains("NOTHING")) {
                            visualMemory.add(SpeechText.forSpeech(r.text), places.history.last()?.text.orEmpty())
                        }
                    }
                }
            }
            if (settings.rememberPlaces && places.hasPermission() && now - lastPlaceAt >= 10 * 60_000L) {
                lastPlaceAt = now
                places.sample()
            }
        }
    }

    /** DishaCore calls this for every photo saved on the phone: caption it for the smart gallery. */
    fun onPhotoSaved(jpeg: ByteArray, where: String) {
        logEvent("Took a photo")
        if (!settings.smartGallery || !settings.aiImageConsent) return
        ai.ask(CAPTION_PROMPT, jpeg, emptyList(), "You write short, specific photo captions.") { r ->
            val caption = (r as? VisionAi.Result.Answer)?.let { SpeechText.forSpeech(it.text) } ?: "A photo"
            gallery.add(jpeg, where, caption, places.history.last()?.text.orEmpty())
        }
    }

    // ---- SOS ----

    private fun startSos() {
        if (!sos.configured) {
            reply("Emergency SOS isn't set up. Add an emergency contact in Settings and switch on voice SOS. If you're in danger, call 112.")
            return
        }
        if (sosCountdown != null) {  // asked again during the countdown: don't wait
            sendSosNow()
            return
        }
        val name = settings.sosName.ifBlank { "your emergency contact" }
        val r = Runnable {
            sosCountdown = null
            sendSosNow()
        }
        sosCountdown = r
        main.postDelayed(r, SOS_DELAY_MS)
        chime(Earcons.Sound.ALERT)
        reply("Sending an emergency message to $name in 10 seconds. Say cancel to stop.", thenListen = true)
    }

    private fun cancelSos() {
        sosCountdown?.let { main.removeCallbacks(it) }
        sosCountdown = null
        reply("Cancelled. No message was sent.")
    }

    private fun sendSosNow() {
        sosCountdown?.let { main.removeCallbacks(it) }
        sosCountdown = null
        logEvent("Sent an emergency message")
        sos.send(test = false) { result -> announce(result) }
    }

    // ---- calls ----

    private fun onIncomingCall(caller: String) {
        logEvent("Call from $caller")
        if (settings.announceCalls) announce("Call from $caller. Say $name, answer, or $name, reject.")
    }

    // ---- messages ----

    private fun onNewMessage(m: MessageCenter.Message) {
        if (settings.announceMessages) announce("${m.app} message from ${m.sender}.")
    }

    private fun readMessages(): String {
        if (!MessageCenter.isAllowed(appContext)) return "I can't see your messages yet. In Settings, allow notification access for DISHA."
        val unread = MessageCenter.unread()
        if (unread.isEmpty()) return "No new messages."
        MessageCenter.markRead(unread)
        val groups = unread.takeLast(8).groupBy { it.app + "|" + it.conversation }
        return groups.entries.joinToString(" ") { (k, ms) ->
            val app = k.substringBefore('|')
            val conv = k.substringAfter('|')
            val lines = ms.takeLast(3).joinToString(" ") { m ->
                (if (m.sender.isNotBlank() && m.sender != conv) "${m.sender}: " else "") + m.text.trimEnd('.', ' ') + "."
            }
            "$conv on $app: $lines"
        } + " To answer, say reply, then your message."
    }

    private fun prepareReply(text: String) {
        if (!MessageCenter.isAllowed(appContext)) {
            reply("I can't reach your messages yet. In Settings, allow notification access for DISHA.")
            return
        }
        val r = ReplyParse.parse(text, MessageCenter.conversations()) ?: run { think(text, null); return }
        val target = MessageCenter.replyTarget(r.conversation)
        if (target == null) {
            reply(if (r.conversation != null) "I don't have a recent message from ${r.conversation} that I can reply to." else "There's no recent message I can reply to.")
            return
        }
        if (r.text.isBlank()) {
            pending = Pending(System.currentTimeMillis() + 30_000, onText = { msg -> confirmReply(target, msg) })
            reply("What should I say to ${target.conversation}?", thenListen = true)
            return
        }
        confirmReply(target, r.text)
    }

    /** Messages are only sent after a spoken yes. */
    private fun confirmReply(target: MessageCenter.Message, msg: String) = reply(armReply(target, msg), thenListen = true)

    /** Waits for the user's yes; returns the question to ask. */
    private fun armReply(target: MessageCenter.Message, msg: String): String {
        pending = Pending(System.currentTimeMillis() + 30_000, onYes = {
            val ok = MessageCenter.reply(appContext, target, msg)
            if (ok) logEvent("Replied to ${target.conversation} on ${target.app}")
            reply(if (ok) "Sent." else "That didn't work: the message may have been cleared from the phone. Reply from the phone instead.")
        })
        return "Reply to ${target.conversation} on ${target.app}: $msg. Send it?"
    }

    // ---- guide mode (blind and low-vision help) ----

    /** hazardsOnly: while navigating, speak only about obstacles and traffic (directions do the talking). */
    private fun startGuide(hazardsOnly: Boolean = false) {
        if (!camera.isCameraReady()) { if (!hazardsOnly) reply("The camera isn't connected, so I can't guide you."); return }
        if (!settings.aiImageConsent) { if (!hazardsOnly) reply("Sending camera pictures to ${ai.name} is switched off. You can allow it in Settings."); return }
        if (tasks.containsKey(guideTaskId)) { if (!hazardsOnly) reply("Guide mode is already on."); return }
        guideHazardsOnly = hazardsOnly
        var busy = false
        var last = emptySet<String>()
        var repeats = 0
        var id = 0
        val tick = object : Runnable {
            override fun run() {
                if (!tasks.containsKey(id)) return
                main.postDelayed(this, GUIDE_INTERVAL_MS)
                if (busy || !camera.isCameraReady() || state != State.IDLE) return  // never talk over a conversation
                busy = true
                camera.captureForAi(false) { frame, _ ->
                    if (frame == null || !tasks.containsKey(id)) { busy = false; return@captureForAi }
                    ai.ask(GUIDE_PROMPT, frame.data, emptyList(), visionPrompt()) { r ->
                        busy = false
                        if (!tasks.containsKey(id) || r !is VisionAi.Result.Answer || state != State.IDLE) return@ask
                        val said = SpeechText.forSpeech(r.text)
                        val words = TextSearch.words(said)
                        val same = last.isNotEmpty() && words.intersect(last).size * 10 >= maxOf(words.size, 1) * 6
                        val hazard = HAZARD.containsMatchIn(said)
                        if (guideHazardsOnly && !hazard) return@ask
                        if (same && !hazard && ++repeats < 3) return@ask  // don't repeat "path clear" every few seconds
                        repeats = 0
                        last = words
                        reply(said)
                    }
                }
            }
        }
        id = addTask("guide", if (hazardsOnly) "Watching for obstacles" else "Guide mode", 60 * 60_000L) { main.removeCallbacks(tick) }
        guideTaskId = id
        logEvent("Started guide mode")
        if (!hazardsOnly) {
            reply("Guide mode on. I'll tell you what's ahead every few seconds. I'm an extra pair of eyes, not a replacement for your cane or a guide. Say stop guiding to end it.")
        }
        main.postDelayed(tick, 6000)
    }

    private fun stopGuide(): String {
        if (!tasks.containsKey(guideTaskId)) return "Guide mode isn't on."
        removeTask(guideTaskId, run = true)
        return "Guide mode off."
    }

    // ---- meeting notes ----

    private inner class NotesListener : MeetingNotes.Listener {
        override fun onNotesStatus(recordedSec: Int, transcribedSec: Int) {
            tasks[notesTaskId]?.label = "Taking notes: ${clock(recordedSec)} recorded, ${clock(transcribedSec)} transcribed"
            publishTasks()
        }

        override fun onNotesDone(transcript: String, recordedSec: Int) {
            if (tasks.containsKey(notesTaskId)) removeTask(notesTaskId, run = false)
            updateWake()  // the microphone is free again
            if (transcript.isBlank()) {
                announce("The notes are empty: I didn't hear any speech.")
                return
            }
            summarise(transcript, "These are notes transcribed from a meeting or lecture (${clock(recordedSec)} long). Write a summary: what it was about, the key points, and any decisions or action items with names and dates. Plain sentences, no markdown.") { summary ->
                val date = SimpleDateFormat("d MMMM yyyy, h:mm a", Locale.ENGLISH).format(Date())
                val body = "Meeting notes, $date (${clock(recordedSec)})\n\nSUMMARY\n${summary ?: "(not available)"}\n\nTRANSCRIPT\n$transcript\n"
                val where = saveDocument("Notes", body, null, "Meeting notes $date")
                val spoken = summary?.let { SpeechText.forSpeech(it).split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" ") }
                announce("Meeting notes saved in $where. " + (spoken?.let { "Summary: $it" } ?: "I couldn't summarise them right now; say summarise it later."))
            }
        }

        override fun onNotesError(message: String) {
            if (tasks.containsKey(notesTaskId)) removeTask(notesTaskId, run = false)
            updateWake()
            announce(message)
        }
    }

    private fun clock(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)

    private fun startNotes() {
        if (!settings.notesAllowed) {
            reply("Meeting notes record everyone nearby and send the audio to the online speech service. Turn on Allow meeting notes in Settings first.")
            return
        }
        if (!settings.useOnlineSpeech) { reply("Meeting notes need online speech recognition. Allow it in Settings."); return }
        if (notes.running) { reply("I'm already taking notes."); return }
        if (!micPermission()) { reply("Microphone permission is missing. Open the app and tap the mic once to allow it."); return }
        notes.start()
        notesTaskId = addTask("notes", "Taking notes", 3 * 3600_000L) { notes.stop() }
        logEvent("Started meeting notes")
        updateWake()
        reply("Taking notes. Please tell people you're recording. Say stop taking notes when it's over.")
    }

    private fun stopNotes() {
        if (!notes.running) { reply("I'm not taking notes right now."); return }
        removeTask(notesTaskId, run = true)
        reply("Stopping. I'll summarise once the last part is transcribed.")
    }

    // ---- memory of the day ----

    private fun setVisualMemory(on: Boolean): String {
        if (!on) {
            settings.visualMemoryMinutes = 0
            return "Okay, I've stopped remembering what I see."
        }
        if (!settings.aiImageConsent) return "Sending camera pictures to ${ai.name} is switched off, so I can't remember what I see. You can allow it in Settings."
        if (settings.visualMemoryMinutes == 0) settings.visualMemoryMinutes = 5
        lastMemoryAt = 0
        return "Okay. Every ${settings.visualMemoryMinutes} minutes I'll note what's in view, so you can ask where you left things. The notes stay on the phone."
    }

    /** Recent notes of what the glasses saw, photos, documents and events matching [query]. */
    private fun memoryNotes(query: String, range: TimeRange?, limit: Int): List<TextSearch.Item> {
        val all = visualMemory.store.items().map { TextSearch.Item(it.time, "saw: " + it.text) } +
            gallery.store.items().map { TextSearch.Item(it.time, "photo: " + it.text) } +
            documents.all().map { TextSearch.Item(it.time, "document: " + it.extra) } +
            events.items()
        return TextSearch.search(all, query, range, limit)
    }

    private fun stamp(t: Long): String {
        val today = TimeRange.startOfDay(System.currentTimeMillis())
        val fmt = if (t >= today) "h:mm a" else if (t >= today - 86_400_000L) "'yesterday' h:mm a" else "EEE d MMM, h:mm a"
        return SimpleDateFormat(fmt, Locale.ENGLISH).format(Date(t))
    }

    private fun findObject(text: String) {
        val found = memoryNotes(text, TimeRange.parse(text, System.currentTimeMillis()), 6)
        if (found.isEmpty()) {
            if (settings.visualMemoryMinutes == 0 && memory.all().isEmpty()) {
                reply("I haven't been keeping track of things. Say start remembering what I see, and I'll note what's around you every few minutes.")
            } else {
                think(text, null)  // maybe something the user asked me to remember
            }
            return
        }
        val notesText = found.joinToString("\n") { "- ${stamp(it.time)}: ${it.text}" }
        think("$text\n\n(Notes of what my glasses saw and did, best matches first:\n$notesText\nAnswer from these notes: where it was last seen and when. If they don't mention it, say so.)", null)
    }

    private fun diary(text: String) {
        val now = System.currentTimeMillis()
        val range = TimeRange.parse(text, now) ?: TimeRange(TimeRange.startOfDay(now), now + 1, "today")
        val lines = ArrayList<TextSearch.Item>()
        lines += gallery.store.all().filter { it.time in range }.map { TextSearch.Item(it.time, "photo: ${it.text}") }
        var lastSeen = 0L
        for (e in visualMemory.store.all().filter { it.time in range }) {
            if (e.time - lastSeen < 20 * 60_000L) continue  // one note per 20 minutes is plenty for a diary
            lastSeen = e.time
            lines += TextSearch.Item(e.time, "saw: ${e.text}")
        }
        lines += documents.all().filter { it.time in range }.map { TextSearch.Item(it.time, "saved: ${it.extra}") }
        lines += events.all().filter { it.time in range }.map { TextSearch.Item(it.time, it.text) }
        lines += places.history.all().filter { it.time in range }.map { TextSearch.Item(it.time, "at ${it.text}") }
        if (lines.isEmpty()) {
            reply("I don't have much about ${range.label} yet. Switch on smart gallery, visual memory or places in Settings, and I'll keep a diary for you.")
            return
        }
        val log = lines.sortedBy { it.time }.takeLast(120).joinToString("\n") { "${SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date(it.time))} ${it.text}" }
        setState(State.PROCESSING, "Writing your diary…")
        val myTurn = turn
        summarise(log, "This is a log of my day (${range.label}). Tell me about it as a short, warm spoken diary of 3 to 6 sentences, in time order, mentioning places and notable things. Use only what is in the log; don't invent anything.") { s ->
            if (myTurn != turn) return@summarise
            if (s == null) {
                reply("I couldn't write the diary right now. Try again in a minute.")
            } else {
                addHistory(text, s)
                reply(SpeechText.forSpeech(s), thenListen = true)
            }
        }
    }

    private fun gallerySearch(text: String) {
        val range = TimeRange.parse(text, System.currentTimeMillis())
        val found = gallery.search(text, range)
        if (found.isEmpty()) {
            reply(
                if (gallery.store.all().isEmpty()) "I don't have any captioned photos yet. Switch on smart gallery in Settings; new photos then get captions."
                else "I didn't find photos like that${range?.let { " from ${it.label}" } ?: ""}.",
            )
            return
        }
        val shown = ui.onShowGallery(text)
        val latest = found.first()
        reply(
            "Found ${found.size} ${if (found.size == 1) "photo" else "photos"}. The latest, from ${stamp(latest.time)}: ${latest.text.trimEnd('.')}." +
                if (shown) "" else " Open the app to see them.",
            thenListen = true,
        )
    }

    // ---- seeing: translate, food, money, documents ----

    /** A fresh (sharp) picture, one question to the vision model, the answer spoken. */
    private fun lookAndSay(prompt: String, working: String, logAs: String? = null, highRes: Boolean = true) {
        if (!camera.isCameraReady()) { reply("The camera isn't connected, so I can't see anything right now."); return }
        if (!settings.aiImageConsent) { reply("Sending camera pictures to ${ai.name} is switched off. You can allow it in Settings."); return }
        val myTurn = turn
        setState(State.PROCESSING, working)
        camera.captureForAi(highRes) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) { reply("I couldn't get a picture from the camera. ${error ?: ""}".trim()); return@captureForAi }
            ai.ask(prompt, frame.data, emptyList(), visionPrompt()) { r ->
                if (myTurn != turn) return@ask
                when (r) {
                    is VisionAi.Result.Answer -> {
                        val said = SpeechText.forSpeech(r.text)
                        addHistory(prompt.take(80), said)
                        logAs?.let { logEvent("$it: ${said.take(80)}") }
                        reply(said, thenListen = true)
                    }
                    is VisionAi.Result.Failure -> reply(r.message)
                }
            }
        }
    }

    private fun translate(text: String) {
        val target = when {
            text.contains("hindi", ignoreCase = true) -> "Hindi, written in Devanagari script"
            text.contains("english", ignoreCase = true) -> "English"
            settings.speechLanguage.startsWith("hi") -> "Hindi, written in Devanagari script"
            else -> "English"
        }
        lookAndSay(
            "Read all the text in this picture and translate it into $target. Say only the translation, naturally, as you " +
                "would read it aloud; for a menu, read the dishes with their prices. If it is already in that language, just read it. " +
                "If there is no text, say so.",
            "Reading and translating…", logAs = "Translated a sign",
        )
    }

    /** Barcode -> Open Food Facts; no barcode or unknown product -> what the pack itself shows. */
    private fun food(text: String) {
        if (!camera.isCameraReady()) { reply("The camera isn't connected, so I can't see the product."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Looking at the product…")
        camera.captureForAi(true) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) { reply("I couldn't get a picture from the camera. ${error ?: ""}".trim()); return@captureForAi }
            // The barcode is read on the phone first (offline, exact); the vision model only if that fails.
            work.execute {
                val onPhone = try { QrReader.decode(frame.data, products = true)?.text?.let { Barcode.find(it) } } catch (_: Exception) { null }
                main.post {
                    if (myTurn != turn) return@post
                    when {
                        onPhone != null -> lookUpProduct(text, onPhone, frame.data, myTurn)
                        !settings.aiImageConsent -> reply("I can't find a barcode. Hold it closer and flat. To read the label instead, allow sending camera pictures in Settings.")
                        else -> ai.ask(BARCODE_PROMPT, frame.data, emptyList(), "You read product barcodes exactly.") { r ->
                            if (myTurn != turn) return@ask
                            val code = (r as? VisionAi.Result.Answer)?.text?.let { Barcode.find(it) }
                            if (code == null) foodFromPicture(text, frame.data, myTurn, "") else lookUpProduct(text, code, frame.data, myTurn)
                        }
                    }
                }
            }
        }
    }

    private fun lookUpProduct(text: String, code: String, jpeg: ByteArray, myTurn: Int) {
        setState(State.PROCESSING, "Looking up the product…")
        web.foodFacts(code) { product, err ->
            if (myTurn != turn) return@foodFacts
            if (product != null) {
                val said = product.sentence()
                addHistory(text, said)
                logEvent("Checked food: ${product.name.ifBlank { code }}")
                reply(said, thenListen = true)
            } else {
                AppLog.i(TAG, "Barcode $code: ${err ?: "not in Open Food Facts"}")
                if (settings.aiImageConsent) {
                    foodFromPicture(text, jpeg, myTurn, "That product isn't in the food database, so this is from the pack itself. ")
                } else {
                    reply("The barcode is $code, but that product isn't in the free food database.")
                }
            }
        }
    }

    private fun foodFromPicture(question: String, jpeg: ByteArray, myTurn: Int, prefix: String) {
        setState(State.PROCESSING, "Reading the label…")
        ai.ask(
            "The user asks: \"$question\". Look at this food or product. In two or three short spoken sentences: what it is, how " +
                "healthy it is (use the nutrition label if you can read it: calories, sugar, salt and saturated fat per 100 g), " +
                "whether it is vegetarian if that can be told, and any allergens named on the pack. If you can't tell, say what would help.",
            jpeg, emptyList(), visionPrompt(),
        ) { r ->
            if (myTurn != turn) return@ask
            when (r) {
                is VisionAi.Result.Answer -> reply(prefix + SpeechText.forSpeech(r.text), thenListen = true)
                is VisionAi.Result.Failure -> reply(r.message)
            }
        }
    }

    private fun scanDocument() {
        if (!camera.isCameraReady()) { reply("The camera isn't connected."); return }
        if (!settings.aiImageConsent) { reply("Sending camera pictures to ${ai.name} is switched off. You can allow it in Settings."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Scanning the page…")
        camera.captureForAi(true) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) { reply("I couldn't get a picture from the camera. ${error ?: ""}".trim()); return@captureForAi }
            ai.ask(SCAN_PROMPT, frame.data, emptyList(), "You transcribe documents exactly and output only their text.") { r ->
                if (myTurn != turn) return@ask
                val text = (r as? VisionAi.Result.Answer)?.text?.trim().orEmpty()
                if (r is VisionAi.Result.Failure) { reply(r.message); return@ask }
                if (text.length < 4 || text.equals("NONE", ignoreCase = true)) {
                    reply("I couldn't read any text. Hold the page flat, a little closer, in good light, and try again.")
                    return@ask
                }
                val where = saveDocument("Scan", text, frame.data, null)
                val words = text.split(Regex("\\s+")).size
                val start = SpeechText.forSpeech(text.split(Regex("\\s+")).take(12).joinToString(" "))
                reply("Scanned and saved in $where: $words words, starting: $start. Say summarise it, or read it back.", thenListen = true)
            }
        }
    }

    /** Saves text (and the photo) in Documents/DISHA; returns where, for saying it. */
    private fun saveDocument(kind: String, text: String, jpeg: ByteArray?, title: String?): String {
        val stampName = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val where = MediaSaver.saveText(appContext, text, "${kind}_$stampName.txt")
        if (jpeg != null) MediaSaver.savePhoto(appContext, jpeg, "${kind}_$stampName.jpg")
        val heading = title ?: text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(60) ?: kind
        documents.add(EntryStore.Entry(System.currentTimeMillis(), text, where.orEmpty(), "$kind: $heading"))
        logEvent("Saved ${kind.lowercase(Locale.US)}: $heading")
        return if (where == null) "the app" else if (where.startsWith("Documents")) "Documents, DISHA folder" else "the app folder"
    }

    private fun summariseDocument() {
        val doc = documents.last() ?: run { reply("There's nothing scanned or noted yet. Say scan this page, or take notes."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Summarising…")
        summarise(doc.text, "Summarise this in three short spoken sentences: what it is and its key points.") { s ->
            if (myTurn != turn) return@summarise
            reply(s?.let { SpeechText.forSpeech(it) } ?: "I couldn't summarise it right now. Try again in a minute.", thenListen = true)
        }
    }

    private fun readDocument() {
        val doc = documents.last() ?: run { reply("There's nothing scanned yet. Say scan this page."); return }
        val text = SpeechText.forSpeech(doc.text)
        if (text.length <= 900) {
            reply(text, thenListen = true)
        } else {
            reply(text.take(900).substringBeforeLast(' ') + "… That's the beginning; the whole text is saved in Documents, DISHA folder.", thenListen = true)
        }
    }

    /** One text-only request to the thinking model (no tools). null if it couldn't answer. */
    private fun summarise(text: String, instruction: String, done: (String?) -> Unit) {
        val messages = org.json.JSONArray()
            .put(org.json.JSONObject().put("role", "system").put("content", persona()))
            .put(org.json.JSONObject().put("role", "user").put("content", "$instruction\n\n---\n${text.take(24_000)}"))
        brain.chat(messages, org.json.JSONArray(), withImage = false) { r ->
            done((r as? BrainClient.Reply.Message)?.text?.takeIf { it.isNotBlank() })
        }
    }

    // ---------------------------------------------------------------------------------------
    // 0.12: pages into a PDF, walking directions, live captions and translator, QR codes and
    // business cards, slides and presentation mode
    // ---------------------------------------------------------------------------------------

    private class DocSession(val name: String, startedAt: Long) {
        val pages = ArrayList<ByteArray>()
        val watcher = PageWatcher(startedAt)
        var capturing = false
        var lastThumb: IntArray? = null
    }

    private var doc: DocSession? = null
    private var docTaskId = 0
    private var navTaskId = 0
    private var navStartedGuide = false
    private var captionsTaskId = 0

    /** "Make a document": Disha scans each page the user shows and makes one PDF at the end. */
    private fun startDocument(text: String) {
        if (!camera.isCameraReady()) { reply("The camera isn't connected, so I can't scan pages. Plug in the glasses first."); return }
        doc?.let { reply("We're already making a document: ${it.pages.size} pages so far. Show the next page, or say done."); return }
        val named = Regex("(?i)\\b(?:called|named|titled)\\s+(.+)$").find(text)?.groupValues?.get(1)?.trim()?.trimEnd('.', '!', '?')
        val docName = named?.take(60)?.ifBlank { null } ?: "Document ${SimpleDateFormat("d MMM, h.mm a", Locale.ENGLISH).format(Date())}"
        val d = DocSession(docName, System.currentTimeMillis())
        doc = d
        camera.holdStream("doc", 3)
        docTaskId = addTask("doc", "Document: no pages yet", 60 * 60_000L) { endDocument() }
        logEvent("Started a document")
        val boss = if (title.isNotEmpty()) "Okay, $title." else "Okay."
        reply("$boss Put the first page in front of the camera and hold it still; I'll scan it myself. Say next to scan right away, or done when all the pages are in.")
    }

    /** Every live-view frame (main thread): in document mode, takes a page once it lies still. */
    fun onLiveFrame(bmp: Bitmap) {
        val d = doc ?: return
        if (d.capturing || bmp.isRecycled) return
        val thumb = thumbnail(bmp) ?: return
        d.lastThumb = thumb
        d.watcher.paused = state == State.LISTENING || state == State.PREPARING_MIC
        if (d.watcher.feed(thumb, System.currentTimeMillis())) capturePage(byVoice = false)
    }

    private fun thumbnail(bmp: Bitmap): IntArray? = try {
        val s = Bitmap.createScaledBitmap(bmp, 32, 24, true)
        val px = IntArray(PageWatcher.SIZE)
        s.getPixels(px, 0, 32, 0, 0, 32, 24)
        if (s !== bmp) s.recycle()
        IntArray(px.size) { i -> val c = px[i]; ((c shr 16 and 0xFF) * 77 + (c shr 8 and 0xFF) * 150 + (c and 0xFF) * 29) shr 8 }
    } catch (_: Exception) {
        null
    }

    private fun capturePage(byVoice: Boolean) {
        val d = doc ?: return
        if (d.capturing) return
        d.capturing = true
        chime(Earcons.Sound.HEARD)
        if (byVoice) setState(State.PROCESSING, "Scanning the page…")
        camera.captureForAi(true) { frame, error ->
            if (doc !== d) return@captureForAi
            if (frame == null) {
                d.capturing = false
                val msg = "I couldn't take that page. ${error ?: ""}".trim()
                if (byVoice) reply(msg) else announce(msg)
                return@captureForAi
            }
            work.execute {
                val page = try { PdfMaker.enhance(frame.data) } catch (_: Exception) { frame.data }
                main.post {
                    if (doc !== d) return@post
                    d.pages.add(page)
                    d.capturing = false
                    d.watcher.taken(d.lastThumb)
                    val n = d.pages.size
                    tasks[docTaskId]?.label = "Document: $n ${if (n == 1) "page" else "pages"}"
                    publishTasks()
                    AppLog.i(TAG, "Document page $n (${page.size / 1024} KB)")
                    val ask = if (title.isNotEmpty()) "Next page, $title? Or say done." else "Next page? Or say done."
                    if (byVoice || state == State.IDLE) reply("Page $n scanned. $ask", thenListen = true) else announce("Page $n scanned.")
                }
            }
        }
    }

    /** While a document is being made: done / next / retake / cancel / how many. true if handled. */
    private fun handleDocument(text: String): Boolean {
        val d = doc ?: return false
        val s = " " + text.lowercase(Locale.US).replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim() + " "
        fun has(vararg p: String) = p.any { s.contains(" $it ") }
        val words = s.trim().split(' ').count { it.isNotEmpty() }
        if (words > 7 || has("slide", "slides", "ppt", "presentation")) return false
        when {
            has("cancel", "discard", "throw it away", "delete the document", "stop the document", "forget it") -> {
                endDocument()
                reply("Okay, I've thrown that document away.")
            }
            has("done", "finish", "finished", "that's all", "that is all", "that's it", "that is it", "make the pdf", "make pdf",
                "save it", "save the pdf", "create the pdf", "complete", "bas", "ho gaya", "khatam", "all done", "no more") -> finishDocument()
            has("undo", "retake", "redo", "again", "delete the last page", "remove the last page", "take it again") -> {
                if (d.pages.isNotEmpty()) d.pages.removeAt(d.pages.size - 1)
                d.watcher.retake()
                tasks[docTaskId]?.label = "Document: ${d.pages.size} pages"
                publishTasks()
                reply("Removed the last page. Show it again and hold it still.")
            }
            has("how many pages", "how many") -> reply("${d.pages.size} ${if (d.pages.size == 1) "page" else "pages"} so far.", thenListen = true)
            has("next", "scan", "scan it", "take it", "capture", "next page", "ready", "go ahead", "click", "this one", "now") -> capturePage(byVoice = true)
            else -> return false
        }
        return true
    }

    private fun endDocument() {
        doc ?: return
        doc = null
        camera.releaseStream("doc")
        if (tasks.containsKey(docTaskId)) removeTask(docTaskId, run = false)
    }

    private fun finishDocument() {
        val d = doc ?: return
        if (d.capturing) { reply("One moment, I'm still scanning the last page. Say done again in a second.", thenListen = true); return }
        endDocument()
        if (d.pages.isEmpty()) { reply("No pages were scanned, so there's no PDF."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Making the PDF…")
        work.execute {
            val where = try {
                MediaSaver.saveDocument(appContext, PdfMaker.make(d.pages), fileName(d.name) + ".pdf", "application/pdf")
            } catch (e: Exception) {
                AppLog.e(TAG, "PDF failed: ${e.message}")
                null
            }
            main.post {
                val n = d.pages.size
                if (where == null) {
                    reply("I couldn't save the PDF. The phone may be out of space.")
                    return@post
                }
                logEvent("Saved a PDF: ${d.name} ($n pages)")
                val read = settings.aiImageConsent && ai.isConfigured() && Net.online(appContext)
                val place = if (where.startsWith("Documents")) "Documents, DISHA folder" else "the app folder"
                val msg = (if (title.isNotEmpty()) "Done, $title. " else "Done. ") +
                    "Your PDF, ${d.name}, with $n ${if (n == 1) "page" else "pages"}, is saved in $place." +
                    if (read) " I'll read it too, so you can ask me to summarise it." else ""
                if (myTurn == turn) reply(msg) else announce(msg)
                if (read) readPages(d, where) else documents.add(EntryStore.Entry(System.currentTimeMillis(), "(scanned PDF, $n pages)", where, "PDF: ${d.name}"))
            }
        }
    }

    /** Reads the pages' text one by one (for "summarise it" and search), then keeps it with the PDF. */
    private fun readPages(d: DocSession, where: String) {
        val texts = ArrayList<String>()
        fun next(i: Int) {
            if (i >= d.pages.size) {
                val all = texts.joinToString("\n\n")
                documents.add(EntryStore.Entry(System.currentTimeMillis(), all.ifBlank { "(no readable text)" }, where, "PDF: ${d.name}"))
                if (all.isNotBlank()) MediaSaver.saveText(appContext, all, fileName(d.name) + ".txt")
                AppLog.i(TAG, "Read ${texts.size} of ${d.pages.size} pages of ${d.name}")
                return
            }
            ai.ask(SCAN_PROMPT, d.pages[i], emptyList(), "You transcribe documents exactly and output only their text.") { r ->
                val t = (r as? VisionAi.Result.Answer)?.text?.trim().orEmpty()
                if (t.isNotEmpty() && !t.equals("NONE", ignoreCase = true)) texts.add("--- Page ${i + 1} ---\n$t")
                next(i + 1)
            }
        }
        next(0)
    }

    private fun fileName(name: String) =
        name.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(' ', '_').take(60).ifEmpty { "Document" } +
            "_" + SimpleDateFormat("HHmmss", Locale.US).format(Date())

    /** For the web view and the screen. */
    fun documentLine(): String = doc?.let { "Document: ${it.pages.size} pages" }.orEmpty()

    fun navLine(): String = if (navigator.active) navigator.line() else ""

    fun aiLabel(): String = Boost.endpoint(settings)?.let { "AI: ${it.label}" }
        ?: if (settings.aiProvider == AppSettings.AiProvider.GEMINI) "AI: Gemini" else "AI: free"

    // ---- walking directions ----

    private inner class NavListener : Navigator.Listener {
        override fun onNavSay(text: String) = announce(text)
        override fun onNavEnded() {
            if (tasks.containsKey(navTaskId)) removeTask(navTaskId, run = false)
            stopNavGuide()
            logEvent("Arrived at ${navigator.destinationName.ifEmpty { "the destination" }}")
        }
    }

    private fun navigate(place: String) {
        if (!Net.online(appContext)) { reply("Directions need the internet, and there's no connection right now."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Finding the way to $place…")
        navigator.start(place) { sentence ->
            if (navigator.active) {
                if (tasks.containsKey(navTaskId)) removeTask(navTaskId, run = false)
                navTaskId = addTask("nav", "Walking to ${navigator.destinationName}", 3 * 3600_000L) {
                    navigator.stop()
                    stopNavGuide()
                }
                logEvent("Walking to ${navigator.destinationName}")
                // The camera watches for obstacles on the way, and speaks only about those.
                if (camera.isCameraReady() && settings.aiImageConsent && !tasks.containsKey(guideTaskId)) {
                    startGuide(hazardsOnly = true)
                    navStartedGuide = true
                }
            }
            if (myTurn == turn) reply(sentence) else announce(sentence)
        }
    }

    private fun stopNavigation(): String {
        val s = navigator.stop()
        if (tasks.containsKey(navTaskId)) removeTask(navTaskId, run = false)
        stopNavGuide()
        return s
    }

    private fun stopNavGuide() {
        if (navStartedGuide && tasks.containsKey(guideTaskId)) removeTask(guideTaskId, run = true)
        navStartedGuide = false
        guideHazardsOnly = false
    }

    // ---- live captions and the translator ----

    private inner class CaptionsListener : LiveCaptions.Listener {
        override fun translate(text: String, toLanguage: String, done: (String?) -> Unit) = translateText(text, toLanguage, done)

        override fun onCaption(line: CaptionBoard.Line) {
            CaptionBoard.add(line)
            // "Disha, stop captions" said during captions is a command for Disha.
            if (mentionsName(line.text) && VoiceCommandRouter.stripName(line.text, wakeNames()).isNotBlank() && state == State.IDLE) {
                runText(line.text)
                return
            }
            if (captions.translator) line.translation?.let { announce(it) }
        }

        override fun onCaptionsError(message: String) = announce("Captions: $message")
    }

    private fun startCaptions(translate: Boolean, text: String) {
        if (!settings.useOnlineSpeech) { reply("Live captions need online speech recognition. Allow it in Settings, under Voice."); return }
        if (!micPermission()) { reply("Microphone permission is missing. Open the app and tap the mic once to allow it."); return }
        if (notes.running) { reply("I'm taking meeting notes, which use the microphone. Say stop taking notes first."); return }
        val (mine, other) = languagesFrom(text)
        captions.start(translate, mine, other)
        if (translate) {
            settings.translatorMine = mine
            settings.translatorOther = other
        }
        CaptionBoard.clear()
        CaptionBoard.setMode(if (translate) "Translator: ${LANGUAGE_NAMES[mine]} and ${LANGUAGE_NAMES[other]}" else "Live captions")
        if (tasks.containsKey(captionsTaskId)) removeTask(captionsTaskId, run = false)
        captionsTaskId = addTask("captions", if (translate) "Translating" else "Live captions", 3 * 3600_000L) {
            captions.stop()
            CaptionBoard.setMode("")
            updateWake()
        }
        updateWake()
        logEvent(if (translate) "Started the translator" else "Started live captions")
        val shown = ui.onShowCaptions()
        val slow = if (Boost.endpoint(settings) == null) " On the free service they come a few seconds late." else ""
        reply(
            (if (translate) "Translator on, ${LANGUAGE_NAMES[mine]} and ${LANGUAGE_NAMES[other]}. I'll say each translation" +
                (if (shown) " and show it on the phone." else ".") else "Live captions on" + (if (shown) ", on the phone screen." else "; open the app to see them.")) +
                " Everything said near the phone goes to the speech service, so let people know.$slow Say $name, stop captions to end.",
        )
    }

    private fun stopCaptions(): String {
        if (!captions.running) return "Captions aren't on."
        if (tasks.containsKey(captionsTaskId)) {
            removeTask(captionsTaskId, run = true)
        } else {
            captions.stop()
            CaptionBoard.setMode("")
        }
        updateWake()
        return "Captions off."
    }

    /** Languages named in the request ("between Hindi and English", "they speak Tamil"), else the last ones used. */
    private fun languagesFrom(text: String): Pair<String, String> {
        val low = text.lowercase(Locale.US)
        val named = LANGUAGE_NAMES.entries.filter { (code, n) -> low.contains(n.lowercase(Locale.US)) || (code == "hi" && text.contains("हिंदी")) }.map { it.key }
        val myDefault = settings.speechLanguage.substringBefore('-').let { if (it in LANGUAGE_NAMES) it else settings.translatorMine }
        return when {
            named.size >= 2 -> if (myDefault in named) myDefault to named.first { it != myDefault } else named[0] to named[1]
            named.size == 1 -> if (named[0] == myDefault) myDefault to (if (myDefault == "hi") "en" else "hi") else myDefault to named[0]
            else -> settings.translatorMine to settings.translatorOther
        }
    }

    private fun translateText(text: String, to: String, done: (String?) -> Unit) {
        val lang = LANGUAGE_NAMES[to] ?: to
        val script = if (to == "hi") " Write it in Devanagari script." else ""
        val messages = org.json.JSONArray()
            .put(org.json.JSONObject().put("role", "system").put("content",
                "You are an interpreter. Translate what you are given into $lang, naturally, as it would be said aloud.$script Output only the translation."))
            .put(org.json.JSONObject().put("role", "user").put("content", text))
        brain.chat(messages, org.json.JSONArray(), withImage = false) { r ->
            done((r as? BrainClient.Reply.Message)?.text?.let { SpeechText.forSpeech(it) }?.takeIf { it.isNotBlank() })
        }
    }

    // ---- QR codes, barcodes and business cards ----

    private fun scanCode(attempt: Int = 1) {
        if (!camera.isCameraReady()) { reply("The camera isn't connected."); return }
        val myTurn = turn
        setState(State.PROCESSING, if (attempt == 1) "Looking for a code…" else "Still looking…")
        camera.captureForAi(true) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) { reply("I couldn't get a picture from the camera. ${error ?: ""}".trim()); return@captureForAi }
            work.execute {
                val code = try { QrReader.decode(frame.data) } catch (_: Exception) { null }
                main.post {
                    if (myTurn != turn) return@post
                    when {
                        code != null -> onCode(code, frame.data)
                        attempt < 3 -> main.postDelayed({ if (myTurn == turn) scanCode(attempt + 1) }, 600)
                        else -> reply("I can't find a QR code or barcode. Hold it about a hand's length from the glasses, flat and in good light, and try again.")
                    }
                }
            }
        }
    }

    private fun onCode(code: QrReader.Code, jpeg: ByteArray) {
        logEvent("Scanned a code")
        if (code.isProductBarcode) {
            val digits = Barcode.find(code.text) ?: code.text
            pending = Pending(System.currentTimeMillis() + 30_000, onYes = { lookUpProduct("Is this healthy?", digits, jpeg, turn) })
            reply("That's a product barcode, $digits. Shall I look up the product?", thenListen = true)
            return
        }
        val item = QrContent.parse(code.text)
        val (said, question) = QrContent.describe(item)
        val action: (() -> Unit)? = when (item) {
            is QrContent.Item.Link -> { { open(Intent(Intent.ACTION_VIEW, Uri.parse(item.url)), "Open ${QrContent.host(item.url)}") } }
            is QrContent.Item.Contact -> { { open(contactIntent(item.name, item.phones, item.emails, item.org, ""), "Save contact ${item.name}") } }
            is QrContent.Item.Phone -> { { open(contactIntent("", listOf(item.number), emptyList(), "", ""), "Save ${item.number}") } }
            is QrContent.Item.Place -> { { open(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${item.lat},${item.lon}?q=${item.lat},${item.lon}")), "Open the map") } }
            else -> null
        }
        if (question != null && action != null) {
            pending = Pending(System.currentTimeMillis() + 30_000, onYes = action)
            reply("$said $question", thenListen = true)
        } else {
            reply(said, thenListen = true)
        }
    }

    private fun open(intent: Intent, label: String) {
        val shown = ui.openIntent(intent, label)
        reply(if (shown) "Opening it on the phone." else "I've put it in a notification: tap it on the phone to open it.")
    }

    /** The phone's own "new contact" screen, filled in: the user checks it and taps Save. */
    private fun contactIntent(name: String, phones: List<String>, emails: List<String>, org: String, job: String): Intent =
        Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE).apply {
            if (name.isNotBlank()) putExtra(ContactsContract.Intents.Insert.NAME, name)
            phones.getOrNull(0)?.let { putExtra(ContactsContract.Intents.Insert.PHONE, it) }
            phones.getOrNull(1)?.let { putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, it) }
            emails.getOrNull(0)?.let { putExtra(ContactsContract.Intents.Insert.EMAIL, it) }
            if (org.isNotBlank()) putExtra(ContactsContract.Intents.Insert.COMPANY, org)
            if (job.isNotBlank()) putExtra(ContactsContract.Intents.Insert.JOB_TITLE, job)
        }

    private fun scanCard() {
        if (!camera.isCameraReady()) { reply("The camera isn't connected."); return }
        val myTurn = turn
        setState(State.PROCESSING, "Reading the card…")
        camera.captureForAi(true) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) { reply("I couldn't get a picture from the camera. ${error ?: ""}".trim()); return@captureForAi }
            work.execute {
                val qr = try { QrReader.decode(frame.data) } catch (_: Exception) { null }
                main.post {
                    if (myTurn != turn) return@post
                    if (qr != null && QrContent.parse(qr.text) is QrContent.Item.Contact) { onCode(qr, frame.data); return@post }
                    if (!settings.aiImageConsent) { reply("Reading a card needs the AI to see it. Allow sending camera pictures in Settings."); return@post }
                    ai.ask(CARD_PROMPT, frame.data, emptyList(), "You read business cards exactly and reply with JSON only.") { r ->
                        if (myTurn != turn) return@ask
                        if (r is VisionAi.Result.Failure) { reply(r.message); return@ask }
                        val json = (r as VisionAi.Result.Answer).text.let { t -> Regex("(?s)\\{.*\\}").find(t)?.value }
                            ?.let { try { org.json.JSONObject(it) } catch (_: Exception) { null } }
                        fun list(key: String) = json?.optJSONArray(key)?.let { a -> (0 until a.length()).map { a.optString(it).trim() }.filter { it.isNotEmpty() } }.orEmpty()
                        val person = json?.optString("name")?.trim().orEmpty()
                        val phones = list("phones")
                        val emails = list("emails")
                        val company = json?.optString("company")?.trim().orEmpty()
                        val job = json?.optString("title")?.trim().orEmpty()
                        if (person.isEmpty() && phones.isEmpty() && emails.isEmpty()) {
                            reply("I couldn't read a card. Hold it flat, a little closer, in good light.")
                            return@ask
                        }
                        val said = QrContent.describe(QrContent.Item.Contact(person, phones, emails, company)).first +
                            if (job.isNotEmpty()) " Title: $job." else ""
                        logEvent("Read a business card: ${person.ifEmpty { company }}")
                        pending = Pending(System.currentTimeMillis() + 30_000, onYes = {
                            open(contactIntent(person, phones, emails, company, job), "Save contact ${person.ifEmpty { company }}")
                        })
                        reply("$said Shall I add it to your contacts?", thenListen = true)
                    }
                }
            }
        }
    }

    // ---- slides and presentation mode ----

    /** Moves the slides (web view and PC helper); quiet apart from a chime, so it doesn't interrupt the talk. */
    private fun slide(action: String, number: Int = 0, speak: Boolean = true) {
        if (!camera.presenterRunning()) {
            val urls = camera.presenterStart()
            if (urls.isEmpty()) {
                if (speak) reply("I couldn't start presentation mode. Connect the phone to Wi-Fi or turn on its hotspot first.")
                return
            }
            camera.slide(action, number)
            if (speak) reply("Presentation mode is now on. On the laptop open the address shown on the phone, and run the Disha presenter helper for PowerPoint.")
            return
        }
        camera.slide(action, number)
        if (speak) {
            chime(Earcons.Sound.DONE)
            ui.onTranscript(name, when (action) {
                "next" -> "Next slide."
                "previous" -> "Previous slide."
                "goto" -> "Slide $number."
                "start" -> "Starting the presentation."
                "end" -> "Presentation ended."
                else -> "Screen blanked."
            })
            abandonFocus()
            setState(State.IDLE, State.IDLE.label)
        }
    }

    private fun startPresenting(): String {
        val urls = camera.presenterStart()
        if (urls.isEmpty()) return "I couldn't start presentation mode. Connect the phone to Wi-Fi, or turn on its hotspot and connect the laptop to it."
        logEvent("Started presentation mode")
        val u = urls.first()
        val host = u.substringAfter("//").substringBefore("/")
        val code = u.trimEnd('/').substringAfterLast('/')
        return "Presentation mode on. On the laptop, open ${host.replace(".", " dot ").replace(":", ", port ")}, slash $code. " +
            "The address is also on the phone screen."
    }

    // ---------------------------------------------------------------------------------------
    // Background tasks: timed recording, photo series, watching for something
    // ---------------------------------------------------------------------------------------

    private class Task(val id: Int, val kind: String, var label: String, val endsAt: Long, val stop: () -> Unit)

    private val tasks = LinkedHashMap<Int, Task>()
    private var nextTaskId = 1
    private val tasksTicker = object : Runnable {
        override fun run() {
            publishTasks()
            if (tasks.isNotEmpty()) main.postDelayed(this, 1000)
        }
    }

    private fun addTask(kind: String, label: String, durationMs: Long, stop: () -> Unit): Int {
        val id = nextTaskId++
        tasks[id] = Task(id, kind, label, System.currentTimeMillis() + durationMs, stop)
        AppLog.i(TAG, "Task started: $label")
        main.removeCallbacks(tasksTicker)
        main.post(tasksTicker)
        return id
    }

    /** run: also call the task's stop action (false when it ended by itself). */
    private fun removeTask(id: Int, run: Boolean) {
        val t = tasks.remove(id) ?: return
        if (run) t.stop()
        AppLog.i(TAG, "Task ended: ${t.label}")
        publishTasks()
    }

    private fun publishTasks() = ui.onTasks(if (tasks.isEmpty()) "" else tasksSentence())

    private fun tasksSentence(): String {
        val now = System.currentTimeMillis()
        return tasks.values.joinToString(" · ") { "${it.label}, ${TimeParse.describe(((it.endsAt - now) / 1000).toInt().coerceAtLeast(1))} left" }
    }

    /** Stop button for tasks, or "stop watching". */
    fun stopTasks(): String {
        if (tasks.isEmpty()) return "Nothing is running in the background."
        val n = tasks.size
        for (id in tasks.keys.toList()) removeTask(id, run = true)
        return if (n == 1) "Stopped." else "Stopped all $n background tasks."
    }

    /** seconds: stop by itself after that long (2 s to 30 min); null = until told to stop. */
    private fun recordVideo(seconds: Int?, done: (String) -> Unit) {
        if (!camera.isCameraReady()) {
            done("The camera isn't connected.")
            return
        }
        camera.startRecording { sentence ->
            if (seconds == null || !camera.isRecording()) {
                done(sentence)
                return@startRecording
            }
            val s = seconds.coerceIn(2, 1800)
            var id = 0
            val stopper = Runnable {
                if (!tasks.containsKey(id)) return@Runnable
                removeTask(id, run = false)
                camera.stopRecording { saved -> announce("Your ${TimeParse.describe(s)} video is done. $saved") }
            }
            id = addTask("record", "Recording ${TimeParse.describe(s)}", s * 1000L) {
                main.removeCallbacks(stopper)
                camera.stopRecording { }
            }
            main.postDelayed(stopper, s * 1000L)
            done("Recording for ${TimeParse.describe(s)}. I'll tell you when it's saved.")
        }
    }

    private fun photoSeries(count: Int, intervalSeconds: Int): String {
        if (!camera.isCameraReady()) return "The camera isn't connected."
        val n = count.coerceIn(2, 60)
        val iv = intervalSeconds.coerceIn(5, 3600)
        var taken = 0
        var id = 0
        val shot = object : Runnable {
            override fun run() {
                if (!tasks.containsKey(id)) return
                if (!camera.isCameraReady()) {
                    removeTask(id, run = false)
                    announce("The photo series stopped after $taken photos: the camera disconnected.")
                    return
                }
                camera.takePhoto { }
                taken++
                if (taken >= n) {
                    removeTask(id, run = false)
                    announce("Photo series done: $n photos.")
                } else {
                    main.postDelayed(this, iv * 1000L)
                }
            }
        }
        id = addTask("series", "Photo series", n.toLong() * iv * 1000L) { main.removeCallbacks(shot) }
        main.post(shot)
        return "Taking $n photos, one every ${TimeParse.describe(iv)}."
    }

    /**
     * Watches in the background: every 10 s a picture goes to the vision model with a yes/no
     * question; the user is alerted (and a photo saved, if asked) as soon as the answer is yes.
     * 10 s keeps within the free service's limits and leaves room for the user's own questions.
     */
    private fun watchFor(target: String, minutes: Double, photo: Boolean): String {
        if (!camera.isCameraReady()) return "The camera isn't connected."
        if (!settings.aiImageConsent) return "Sending camera pictures to ${ai.name} is switched off, so I can't watch. You can allow it in Settings."
        val ms = (minutes.coerceIn(0.5, 15.0) * 60_000).toLong()
        val end = System.currentTimeMillis() + ms
        var busy = false
        var id = 0
        val check = object : Runnable {
            override fun run() {
                if (!tasks.containsKey(id)) return
                if (System.currentTimeMillis() >= end) {
                    removeTask(id, run = false)
                    announce("I watched for ${TimeParse.describe((ms / 1000).toInt())} and didn't see $target.")
                    return
                }
                main.postDelayed(this, WATCH_FOR_INTERVAL_MS)
                if (busy || !camera.isCameraReady()) return
                busy = true
                camera.captureForAi(false) { frame, _ ->
                    if (frame == null || !tasks.containsKey(id)) {
                        busy = false
                        return@captureForAi
                    }
                    val q = "Look at this picture from my glasses. Is there $target? Answer YES or NO first, then at most one short sentence."
                    ai.ask(q, frame.data, emptyList(), visionPrompt()) { r ->
                        busy = false
                        if (!tasks.containsKey(id) || r !is VisionAi.Result.Answer) return@ask
                        val answer = SpeechText.forSpeech(r.text)
                        if (!answer.trimStart().uppercase(Locale.US).startsWith("YES")) return@ask
                        removeTask(id, run = false)
                        val detail = answer.trimStart().drop(3).trimStart(',', '.', '!', ' ')
                        if (photo) camera.takePhoto { }
                        chime(Earcons.Sound.ALERT)
                        val who = if (title.isNotEmpty()) "$title, " else ""
                        announce("${who}I see $target. $detail${if (photo) " I took a photo." else ""}".trim())
                    }
                }
            }
        }
        id = addTask("watch", "Watching for $target", ms) { main.removeCallbacks(check) }
        main.post(check)
        return "Watching for $target for the next ${TimeParse.describe((ms / 1000).toInt())}. I'll tell you as soon as I see it."
    }

    /** Several pictures over a few seconds, then one answer about what happened. */
    private fun observe(seconds: Int, question: String) {
        if (!camera.isCameraReady()) {
            reply("The camera isn't connected, so I can't watch.")
            return
        }
        if (!settings.aiImageConsent) {
            reply("Sending camera pictures to ${ai.name} is switched off. You can allow it in Settings.")
            return
        }
        val myTurn = turn
        val shots = if (seconds < 6) 3 else 4
        val frames = arrayOfNulls<ByteArray>(shots)
        var pending = shots
        setState(State.PROCESSING, "Watching for ${TimeParse.describe(seconds)}…")
        for (k in 0 until shots) {
            main.postDelayed({
                if (myTurn != turn) return@postDelayed
                camera.captureForAi(false) { f, _ ->
                    if (myTurn != turn) return@captureForAi
                    frames[k] = f?.data
                    if (--pending > 0) return@captureForAi
                    val got = frames.filterNotNull()
                    if (got.size < 2) {
                        reply("I couldn't get enough pictures from the camera.")
                        return@captureForAi
                    }
                    setState(State.PROCESSING, "Thinking about what happened…")
                    ai.askFrames(
                        "These are ${got.size} pictures from my glasses taken over $seconds seconds, oldest first. $question",
                        got, visionPrompt(),
                    ) { r ->
                        if (myTurn != turn) return@askFrames
                        when (r) {
                            is VisionAi.Result.Answer -> {
                                val said = SpeechText.forSpeech(r.text)
                                addHistory(question, said)
                                reply(said, thenListen = true)
                            }
                            is VisionAi.Result.Failure -> reply(r.message)
                        }
                    }
                }
            }, k * seconds * 1000L / (shots - 1))
        }
    }

    /** A command typed on the screen or from a quick-action button, handled as if spoken. */
    fun runText(text: String) {
        if (text.isBlank()) return
        if (state == State.LISTENING || state == State.PREPARING_MIC) stopAll()
        speaker.stop()
        listenAfterSpeaking = false
        turn++
        handle(text.trim())
    }

    // ---------------------------------------------------------------------------------------
    // Abilities
    // ---------------------------------------------------------------------------------------

    private fun setTimer(seconds: Int, label: String): String {
        // "Pasta timer" -> "pasta", so it can be said as "your pasta timer is done".
        val l = label.trim().replace(Regex("(?i)\\s*timer$"), "").replaceFirstChar { it.lowercase() }
        reminders.add(seconds, l, isTimer = true)
        return "Timer set for ${TimeParse.describe(seconds)}" + (if (l.isNotEmpty()) ", for the $l." else ".")
    }

    private fun setReminder(seconds: Int, text: String): String {
        val what = text.trim().replace(Regex("(?i)^to\\s+"), "").trimEnd('.')
        reminders.add(seconds, what, isTimer = false)
        val whenText = if (seconds >= 3600) "at ${DateFormat.getTimeFormat(appContext).format(Date(System.currentTimeMillis() + seconds * 1000L))}"
        else "in ${TimeParse.describe(seconds)}"
        return "Okay, I'll remind you $whenText" + if (what.isNotEmpty()) " to $what." else "."
    }

    private fun cancelTimers(): String {
        val n = reminders.cancelAll()
        return when (n) {
            0 -> "There are no timers or reminders running."
            1 -> "Cancelled."
            else -> "Cancelled all $n timers and reminders."
        }
    }

    private fun timersSentence(): String {
        val items = reminders.pending()
        if (items.isEmpty()) return "No timers or reminders are running."
        val now = System.currentTimeMillis()
        return items.take(4).joinToString(" ") { item ->
            val left = TimeParse.describe(((item.at - now) / 1000).toInt().coerceAtLeast(1))
            when {
                item.isTimer && item.text.isNotEmpty() -> "The ${item.text} timer has $left left."
                item.isTimer -> "A ${TimeParse.describe(item.seconds)} timer has $left left."
                else -> "Reminder${if (item.text.isNotEmpty()) " to ${item.text}" else ""} in $left."
            }
        }
    }

    private fun remember(fact: String): String {
        memory.add(fact)
        return if (title.isNotEmpty()) "Noted, $title." else "Noted."
    }

    /** Keeps the conversation for follow-up questions. */
    private fun addHistory(question: String, answer: String) {
        history.add(VisionAi.Turn(question, answer))
        while (history.size > MAX_HISTORY) history.removeAt(0)
        saveHistory()
    }

    private val historyPrefs = appContext.getSharedPreferences("disha_history", Context.MODE_PRIVATE)

    /** The conversation survives an app restart for half an hour, so follow-ups still make sense. */
    private fun saveHistory() {
        val arr = org.json.JSONArray()
        for (h in history) arr.put(org.json.JSONObject().put("u", h.user).put("a", h.assistant))
        historyPrefs.edit().putString("turns", arr.toString()).putLong("time", System.currentTimeMillis()).apply()
    }

    private fun restoreHistory() {
        if (System.currentTimeMillis() - historyPrefs.getLong("time", 0) > 30 * 60_000L) return
        try {
            val arr = org.json.JSONArray(historyPrefs.getString("turns", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(VisionAi.Turn(o.optString("u"), o.optString("a")))
            }
        } catch (_: Exception) {
        }
    }
    private fun recallSentence(): String {
        val facts = memory.all()
        if (facts.isEmpty()) return "Nothing yet. Say remember that, followed by anything you want me to keep."
        val latest = facts.takeLast(5)
        return (if (facts.size > 5) "Here are the latest five of ${facts.size} things. " else "Here's what you asked me to remember. ") +
            latest.joinToString(" ") { it.text.trimEnd('.') + "." }
    }

    /** "Remember this": describe the view and keep the description. */
    private fun rememberView(myTurn: Int) {
        if (!camera.isCameraReady() || !settings.aiImageConsent) {
            reply("I can't see right now. Tell me in words what to remember.")
            return
        }
        setState(State.PROCESSING, "Taking a picture to remember…")
        camera.captureForAi(false) { frame, error ->
            if (myTurn != turn) return@captureForAi
            if (frame == null) {
                reply("I couldn't get a picture. ${error ?: ""}".trim())
                return@captureForAi
            }
            ai.ask(
                "Describe what is in this picture in one sentence, with any details that would help me find it or recognise it later.",
                frame.data, emptyList(), visionPrompt(),
            ) { r ->
                if (myTurn != turn) return@ask
                when (r) {
                    is VisionAi.Result.Answer -> {
                        val seen = SpeechText.forSpeech(r.text)
                        memory.add("Seen at ${timeNow()} on ${SimpleDateFormat("d MMMM", Locale.ENGLISH).format(Date())}: $seen")
                        reply("Got it. $seen", thenListen = true)
                    }
                    is VisionAi.Result.Failure -> reply(r.message)
                }
            }
        }
    }

    private fun weather(text: String, myTurn: Int) {
        val city = VoiceCommandRouter.weatherCity(text) ?: settings.homeCity
        val tomorrow = text.contains("tomorrow", ignoreCase = true)
        setState(State.PROCESSING, "Checking the weather…")
        web.weather(city) { w, error ->
            if (myTurn != turn) return@weather
            if (w == null) {
                reply(error ?: "I couldn't get the weather right now.")
                return@weather
            }
            val said = w.sentence(tomorrow)
            addHistory(text, "$said (${w.forModel()})")
            reply(said, thenListen = true)
        }
    }

    private fun news(topic: String?, myTurn: Int) {
        setState(State.PROCESSING, "Getting the headlines…")
        web.headlines(topic, settings.speechLanguage) { h, error ->
            if (myTurn != turn) return@headlines
            if (h.isNullOrEmpty()) {
                reply(error ?: "I couldn't get the news right now.")
                return@headlines
            }
            val top = h.take(3).map { headline(it) }
            val said = (if (topic == null) "Here are the top headlines. " else "The latest on $topic. ") +
                top.joinToString(" ") { "$it." }
            addHistory(if (topic == null) "What's the news?" else "News about $topic", said)
            reply(said, thenListen = true)
        }
    }

    /** "Title - Source" -> "Title". */
    private fun headline(item: String) = item.substringBeforeLast(" - ").trim().trimEnd('.')

    /** FRIDAY-style morning briefing: time, weather, phone, glasses, reminders, headlines. */
    private fun briefing(myTurn: Int) {
        setState(State.PROCESSING, "Preparing your briefing…")
        var weather: String? = null
        var news: List<String>? = null
        var pending = 2
        fun finish() {
            if (--pending > 0 || myTurn != turn) return
            val sb = StringBuilder()
            sb.append(greeting()).append(" It's ").append(timeNow()).append(" on ").append(dateNow()).append(". ")
            weather?.let { sb.append(it).append(' ') }
            batteryPercent()?.let { sb.append("Phone battery is at $it percent. ") }
            sb.append(if (camera.isCameraReady()) "Glasses online" else "Glasses offline")
            sb.append(if (camera.isRecording()) " and recording. " else ". ")
            val items = reminders.pending()
            if (items.isNotEmpty()) sb.append(timersSentence()).append(' ')
            news?.take(3)?.let { if (it.isNotEmpty()) sb.append("Top headlines: ").append(it.joinToString(" ") { h -> headline(h) + "." }) }
            val said = sb.toString().trim()
            addHistory("Brief me", said)
            reply(said, thenListen = true)
        }
        web.weather(settings.homeCity) { w, _ ->
            weather = w?.sentence(false)
            finish()
        }
        web.headlines(null, settings.speechLanguage) { h, _ ->
            news = h
            finish()
        }
    }

    private fun greeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when {
            hour < 5 -> "You're up late"
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        return if (title.isNotEmpty()) "$g, $title." else "$g."
    }

    private fun timeNow() = DateFormat.getTimeFormat(appContext).format(Date())

    private fun dateNow() = SimpleDateFormat("EEEE, d MMMM", Locale.ENGLISH).format(Date())

    private fun minuteOfDay(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    private fun batteryPercent(): Int? {
        val bm = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).takeIf { it in 0..100 }
    }

    private fun batterySentence(): String {
        val pct = batteryPercent() ?: return "I can't read the battery level on this phone."
        val bm = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val charging = Build.VERSION.SDK_INT >= 23 && bm.isCharging
        return "The phone battery is at $pct percent${if (charging) " and charging" else ""}." +
            if (camera.isCameraReady()) " The glasses run on the phone's power." else ""
    }

    // ---------------------------------------------------------------------------------------
    // Vision model
    // ---------------------------------------------------------------------------------------

    /**
     * needImage: the question only makes sense with a picture (describe / read).
     * wantImage: include a picture if one can be taken, otherwise ask text-only.
     */
    private fun askAi(question: String, needImage: Boolean, wantImage: Boolean = needImage, highRes: Boolean = false) {
        if (!ai.isConfigured()) {
            reply("${ai.name.replaceFirstChar { it.uppercase() }} isn't set up yet. Open Settings in the app: choose the free AI, or paste your Gemini key.")
            return
        }
        if (!Net.online(appContext)) {
            reply(OFFLINE_ANSWER)
            return
        }
        val canUseCamera = camera.isCameraReady() && settings.aiImageConsent
        if (needImage && !settings.aiImageConsent) {
            reply("Sending camera pictures to ${ai.name} is switched off. You can allow it in Settings.")
            return
        }
        if (needImage && !camera.isCameraReady()) {
            reply("The camera isn't connected, so I can't see anything right now.")
            return
        }
        val myTurn = turn
        if (wantImage && canUseCamera) {
            setState(State.PROCESSING, "Taking a picture…")
            camera.captureForAi(highRes) { frame, error ->
                if (myTurn != turn) return@captureForAi
                if (frame == null) {
                    if (needImage) reply("I couldn't get a picture from the camera. ${error ?: ""}".trim())
                    else callAi(question, null, myTurn)
                } else {
                    callAi(question, frame.data, myTurn)
                }
            }
        } else {
            callAi(question, null, myTurn)
        }
    }

    private fun callAi(question: String, jpeg: ByteArray?, myTurn: Int) {
        setState(State.PROCESSING, if (jpeg != null) "Looking and thinking…" else "Thinking…")
        ai.ask(question, jpeg, history.toList(), visionPrompt()) { result ->
            if (myTurn != turn) return@ask
            when (result) {
                is VisionAi.Result.Answer -> {
                    val said = SpeechText.forSpeech(result.text)
                    addHistory(question, said)
                    reply(said, thenListen = true)
                }
                is VisionAi.Result.Failure -> reply(result.message)
            }
        }
    }

    /** Watch mode: every N seconds, ask the AI whether anything important is in view; speak only if so. */
    private fun watchTick() {
        val interval = settings.watchSeconds
        if (interval <= 0) return
        main.postDelayed(watchRunnable, interval * 1000L)
        if (state != State.IDLE || !ai.isConfigured() || !settings.aiImageConsent || !camera.isCameraReady()) return
        val myTurn = turn
        camera.captureForAi(false) { frame, _ ->
            if (frame == null || myTurn != turn || state != State.IDLE) return@captureForAi
            ai.ask(WATCH_PROMPT, frame.data, emptyList(), visionPrompt()) { result ->
                if (myTurn != turn || state != State.IDLE) return@ask
                if (result is VisionAi.Result.Answer && !result.text.trim().trimEnd('.').equals(NOTHING, ignoreCase = true)) {
                    AppLog.i(TAG, "Watch mode: ${result.text}")
                    reply(SpeechText.forSpeech(result.text))
                }
            }
        }
    }

    private fun earbudSentence(): String = when (router.currentRoute(settings.useEarbudMic).speakerKind) {
        AudioRouter.Kind.BLUETOOTH -> "Your earbuds are connected."
        AudioRouter.Kind.WIRED -> "A wired headset is connected."
        AudioRouter.Kind.PHONE -> "No earbuds are connected."
    }

    private fun aiSentence(): String = when {
        !ai.isConfigured() -> "The AI is not set up."
        !settings.aiImageConsent -> "The AI is ready, but sending pictures is switched off."
        else -> "The AI is ready."
    }

    // ---------------------------------------------------------------------------------------
    // Speaking
    // ---------------------------------------------------------------------------------------

    /** thenListen: in conversation mode, listen for a follow-up once this has been spoken. */
    private fun reply(text: String, thenListen: Boolean = false) {
        ui.onTranscript(name, text)
        if (!speaker.ready) {
            AppLog.w(TAG, "Text-to-speech not ready; answer shown on screen only")
            abandonFocus()
            setState(State.IDLE, "Voice output unavailable; answer shown above")
            return
        }
        listenAfterSpeaking = thenListen && settings.conversationMode
        requestFocus(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        setState(State.SPEAKING, "Speaking…")
        if (!speaker.speak(text)) {
            listenAfterSpeaking = false
            abandonFocus()
            setState(State.IDLE, State.IDLE.label)
        }
    }

    override fun onTtsReady(ok: Boolean, message: String) {
        AppLog.i(TAG, "Text-to-speech: $message (${speaker.voiceName})")
        if (state == State.STARTING) setState(State.IDLE, if (ok) State.IDLE.label else message)
    }

    override fun onSpeakDone() {
        if (state != State.SPEAKING) return
        if (listenAfterSpeaking && queued.isEmpty()) {
            listenAfterSpeaking = false
            // Bluetooth audio lags a little: let the last words play out before the earbuds switch to the mic.
            val myTurn = turn
            main.postDelayed({ if (myTurn == turn && state == State.SPEAKING) listen(followUp = true) }, FOLLOW_UP_DELAY_MS)
        } else {
            listenAfterSpeaking = false
            abandonFocus()
            setState(State.IDLE, State.IDLE.label)
        }
    }

    override fun onSpeakError(message: String) {
        AppLog.w(TAG, message)
        listenAfterSpeaking = false
        abandonFocus()
        if (state == State.SPEAKING) setState(State.IDLE, State.IDLE.label)
    }

    // ---------------------------------------------------------------------------------------
    // Audio focus: music pauses while listening and lowers while speaking
    // ---------------------------------------------------------------------------------------

    private fun requestFocus(gain: Int) {
        abandonFocus()
        if (Build.VERSION.SDK_INT >= 26) {
            val usage = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val req = AudioFocusRequest.Builder(gain)
                .setAudioAttributes(usage)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            am.requestAudioFocus(req)
            focusHandle = req
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, gain)
            focusHandle = focusListener
        }
    }

    private fun abandonFocus() {
        val handle = focusHandle ?: return
        focusHandle = null
        if (Build.VERSION.SDK_INT >= 26 && handle is AudioFocusRequest) {
            am.abandonAudioFocusRequest(handle)
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(focusListener)
        }
    }

    private fun onFocusLost() {
        // Another app (for example a phone call) took the audio: stop quietly.
        if (state == State.LISTENING || state == State.SPEAKING || state == State.PREPARING_MIC) {
            AppLog.i(TAG, "Audio taken by another app; assistant stopped")
            stopAll()
        }
    }

    // ---------------------------------------------------------------------------------------

    private fun setState(newState: State, detail: String) {
        state = newState
        // Meeting notes give the microphone to the assistant while it listens.
        if (notes.running) {
            if (newState == State.LISTENING || newState == State.PREPARING_MIC) notes.pause() else notes.resume()
        }
        // Live captions: the assistant borrows the microphone to listen, and its own voice isn't captioned.
        if (captions.running) {
            if (newState == State.LISTENING || newState == State.PREPARING_MIC) captions.pauseMic() else captions.resumeMic()
            captions.muted = newState == State.SPEAKING
        }
        updateWake()  // before the assistant opens the microphone, and again when it is idle
        val shown = if (newState == State.IDLE && detail == State.IDLE.label && wake.isRunning) {
            "Say \"$name\" or tap the mic"
        } else {
            detail
        }
        ui.onAssistantState(newState, shown)
        // Free again: say anything that was waiting (reminders, alerts).
        if (newState == State.IDLE && queued.isNotEmpty() && speaker.ready) {
            val next = queued.removeAt(0)
            main.post { if (state == State.IDLE) reply(next) else queued.add(0, next) }
        }
    }

    private fun publishRoute() {
        ui.onAudioRoute(router.currentRoute(settings.useEarbudMic))
    }
}
