package com.disha.glassos.storage

import java.io.File
import java.io.RandomAccessFile

/**
 * MJPEG-in-AVI (RIFF AVI 1.0) writer, the same layout as the firmware's AviWriter: the camera's
 * JPEG frames are stored as they are (no re-encoding). Plays in VLC (Android and PC), MX Player,
 * Windows players and ffmpeg. Many phone gallery apps do not play MJPEG AVI.
 *
 * The header is rewritten every 30 frames so an interrupted file stays playable.
 * Not thread-safe: use from one thread.
 */
class AviWriter(private val file: File, private val width: Int, private val height: Int, private val nominalFps: Int) {

    companion object {
        private const val HEADER_LEN = 224
        private const val HEADER_UPDATE_FRAMES = 30
        const val MAX_BYTES = 1000L * 1024 * 1024
    }

    private val raf = RandomAccessFile(file, "rw")
    private val offsets = ArrayList<Int>()
    private val sizes = ArrayList<Int>()
    private var moviBytes = 0L
    private var maxFrame = 0
    private var firstMs = 0L
    private var lastMs = 0L
    private var closed = false

    val frames: Int get() = sizes.size
    val bytes: Long get() = HEADER_LEN + moviBytes
    val durationMs: Long get() = if (frames > 1) lastMs - firstMs else 0
    val full: Boolean get() = bytes >= MAX_BYTES

    init {
        raf.setLength(0)
        raf.write(header(final = false))
    }

    fun addFrame(jpeg: ByteArray, timestampMs: Long) {
        check(!closed) { "closed" }
        val chunkHead = ByteArray(8)
        fcc(chunkHead, 0, "00dc")
        le32(chunkHead, 4, jpeg.size)
        offsets.add((4 + moviBytes).toInt())
        sizes.add(jpeg.size)
        raf.write(chunkHead)
        raf.write(jpeg)
        var chunk = 8L + jpeg.size
        if ((jpeg.size and 1) == 1) {  // chunks are word aligned
            raf.write(0)
            chunk++
        }
        moviBytes += chunk
        if (jpeg.size > maxFrame) maxFrame = jpeg.size
        if (frames == 1) firstMs = timestampMs
        lastMs = timestampMs
        if (frames % HEADER_UPDATE_FRAMES == 0) {
            val end = raf.filePointer
            raf.seek(0)
            raf.write(header(final = false))
            raf.seek(end)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        try {
            val idx = ByteArray(8 + frames * 16)
            fcc(idx, 0, "idx1")
            le32(idx, 4, frames * 16)
            for (i in 0 until frames) {
                val o = 8 + i * 16
                fcc(idx, o, "00dc")
                le32(idx, o + 4, 0x10)  // keyframe
                le32(idx, o + 8, offsets[i])
                le32(idx, o + 12, sizes[i])
            }
            raf.write(idx)
            raf.seek(0)
            raf.write(header(final = true))
        } finally {
            raf.close()
        }
    }

    private fun header(final: Boolean): ByteArray {
        var usPerFrame = 1_000_000 / nominalFps.coerceAtLeast(1)
        if (frames > 1 && lastMs > firstMs) usPerFrame = ((lastMs - firstMs) * 1000 / (frames - 1)).toInt()
        if (usPerFrame <= 0) usPerFrame = 1
        val idxBytes = if (final) 8 + frames * 16 else 0
        val fileSize = HEADER_LEN + moviBytes + idxBytes
        val buf = maxFrame + 8
        val b = ByteArray(HEADER_LEN)
        fcc(b, 0, "RIFF"); le32(b, 4, (fileSize - 8).toInt()); fcc(b, 8, "AVI ")
        fcc(b, 12, "LIST"); le32(b, 16, 192); fcc(b, 20, "hdrl")
        fcc(b, 24, "avih"); le32(b, 28, 56)
        le32(b, 32, usPerFrame)
        le32(b, 36, (buf.toLong() * 1_000_000 / usPerFrame).toInt())
        le32(b, 44, if (final) 0x10 else 0)
        le32(b, 48, frames)
        le32(b, 56, 1)
        le32(b, 60, buf)
        le32(b, 64, width); le32(b, 68, height)
        fcc(b, 88, "LIST"); le32(b, 92, 116); fcc(b, 96, "strl")
        fcc(b, 100, "strh"); le32(b, 104, 56)
        fcc(b, 108, "vids"); fcc(b, 112, "MJPG")
        le32(b, 128, usPerFrame); le32(b, 132, 1_000_000)
        le32(b, 140, frames)
        le32(b, 144, buf)
        le32(b, 148, -1)
        le16(b, 160, width); le16(b, 162, height)
        fcc(b, 164, "strf"); le32(b, 168, 40)
        le32(b, 172, 40); le32(b, 176, width); le32(b, 180, height)
        le16(b, 184, 1); le16(b, 186, 24)
        fcc(b, 188, "MJPG"); le32(b, 192, width * height * 3)
        fcc(b, 212, "LIST"); le32(b, 216, (4 + moviBytes).toInt()); fcc(b, 220, "movi")
        return b
    }

    private fun fcc(b: ByteArray, o: Int, s: String) {
        for (i in 0 until 4) b[o + i] = s[i].code.toByte()
    }

    private fun le32(b: ByteArray, o: Int, v: Int) {
        b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte(); b[o + 3] = (v shr 24).toByte()
    }

    private fun le16(b: ByteArray, o: Int, v: Int) {
        b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte()
    }
}
