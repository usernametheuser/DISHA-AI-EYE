package com.disha.glassos.protocol

import com.disha.glassos.protocol.DishaProtocol.HEADER_LEN
import com.disha.glassos.protocol.DishaProtocol.MAGIC0
import com.disha.glassos.protocol.DishaProtocol.MAGIC1
import com.disha.glassos.protocol.DishaProtocol.MAX_DEVICE_PAYLOAD
import com.disha.glassos.protocol.DishaProtocol.TRAILER_LEN

/**
 * Turns the raw USB byte stream into messages. Message boundaries come only from the
 * explicit length field, never from USB packet boundaries. Anything with a bad magic,
 * bad header CRC, oversized length or bad payload CRC is skipped one byte at a time until
 * the next valid header (resynchronisation). Single 0x00 bytes between messages are the
 * firmware's end-of-burst padding and are counted separately.
 *
 * Not thread-safe: feed() is called from the USB reader thread only.
 */
class MessageParser(private val onMessage: (Message) -> Unit) {

    class Message(val version: Int, val type: Int, val seq: Int, val ref: Int, val payload: ByteArray)

    private var buf = ByteArray(64 * 1024)
    private var start = 0
    private var end = 0

    @Volatile
    var messages = 0L
        private set

    @Volatile
    var headerCrcErrors = 0L
        private set

    @Volatile
    var payloadCrcErrors = 0L
        private set

    @Volatile
    var oversize = 0L
        private set

    @Volatile
    var skippedBytes = 0L
        private set

    @Volatile
    var padBytes = 0L
        private set

    fun feed(src: ByteArray, off: Int, len: Int) {
        if (len <= 0) return
        ensureRoom(len)
        System.arraycopy(src, off, buf, end, len)
        end += len
        parse()
    }

    fun reset() {
        start = 0
        end = 0
    }

    private fun ensureRoom(len: Int) {
        if (end + len <= buf.size) return
        if (start > 0) {
            System.arraycopy(buf, start, buf, 0, end - start)
            end -= start
            start = 0
        }
        if (end + len > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, end + len))
    }

    private fun u8(i: Int) = buf[i].toInt() and 0xFF

    private fun skipOne() {
        if (buf[start].toInt() == 0) padBytes++ else skippedBytes++
        start++
    }

    private fun parse() {
        while (true) {
            while (end - start >= 2 && !(u8(start) == MAGIC0 && u8(start + 1) == MAGIC1)) skipOne()
            if (end - start < HEADER_LEN) break

            if (DishaProtocol.crc16(buf, start, 14) != DishaProtocol.getU16(buf, start + 14)) {
                headerCrcErrors++
                skipOne()
                continue
            }
            val plenLong = DishaProtocol.getU32(buf, start + 8)
            if (plenLong > MAX_DEVICE_PAYLOAD) {
                oversize++
                skipOne()
                continue
            }
            val plen = plenLong.toInt()
            val total = HEADER_LEN + plen + TRAILER_LEN
            if (end - start < total) break

            val p0 = start + HEADER_LEN
            if (DishaProtocol.crc32(buf, p0, plen) != DishaProtocol.getU32(buf, p0 + plen)) {
                payloadCrcErrors++
                skipOne()
                continue
            }
            val msg = Message(
                version = u8(start + 2),
                type = u8(start + 3),
                seq = DishaProtocol.getU16(buf, start + 4),
                ref = DishaProtocol.getU16(buf, start + 6),
                payload = buf.copyOfRange(p0, p0 + plen),
            )
            start += total
            messages++
            onMessage(msg)
        }
        if (start == end) {
            start = 0
            end = 0
        }
    }
}
