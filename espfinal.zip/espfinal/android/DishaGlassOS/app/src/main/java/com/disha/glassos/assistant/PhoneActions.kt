package com.disha.glassos.assistant

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import com.disha.glassos.audio.EarbudButton
import com.disha.glassos.util.AppLog

/** Things the assistant can do on the phone itself: torch, volume, music. Each returns what to say. */
class PhoneActions(context: Context, private val earbudButton: EarbudButton) {

    private val appContext = context.applicationContext
    private val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())

    fun flashlight(on: Boolean): String {
        if (Build.VERSION.SDK_INT < 23) return "This phone's Android version doesn't let apps use the flashlight."
        return try {
            val cm = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This phone has no flashlight."
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            AppLog.w("Phone", "Torch: ${e.message}")
            "I couldn't switch the flashlight. The phone's camera may be in use."
        }
    }

    /** steps > 0 louder, < 0 quieter. Returns the new level in words. */
    fun volume(steps: Int): String {
        val stream = AudioManager.STREAM_MUSIC
        repeat(kotlin.math.abs(steps)) {
            am.adjustStreamVolume(stream, if (steps > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        }
        val max = am.getStreamMaxVolume(stream).coerceAtLeast(1)
        val pct = am.getStreamVolume(stream) * 100 / max
        return if (pct == 0) "Volume is now off. Say volume up to bring it back." else "Volume $pct percent."
    }

    /**
     * Sends a media key to the music app. The assistant's own earbud-button session is paused for a
     * moment, or Android could hand the key straight back to the assistant.
     */
    fun media(keyCode: Int): String {
        val wasEnabled = earbudButton.enabled
        earbudButton.enabled = false
        val t = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, keyCode, 0))
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, keyCode, 0))
        if (wasEnabled) main.postDelayed({ earbudButton.enabled = true }, 1500)
        return when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PAUSE -> "Paused."
            KeyEvent.KEYCODE_MEDIA_PLAY -> "Playing."
            KeyEvent.KEYCODE_MEDIA_NEXT -> "Next track."
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> "Previous track."
            else -> "Done."
        }
    }
}
