package com.disha.glassos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.BatteryManager
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.disha.glassos.assistant.AssistantController
import com.disha.glassos.audio.AudioRouter
import com.disha.glassos.camera.FpsMeter
import com.disha.glassos.core.DishaCore
import com.disha.glassos.protocol.DishaProtocol
import com.disha.glassos.service.DishaService
import com.disha.glassos.settings.AppSettings
import com.disha.glassos.settings.SettingsActivity
import com.disha.glassos.skills.CaptionBoard
import com.disha.glassos.skills.CaptionsActivity
import com.disha.glassos.skills.GalleryActivity
import com.disha.glassos.storage.MediaSaver
import com.disha.glassos.ui.DishaOrb
import com.disha.glassos.usb.CameraLinkManager
import com.disha.glassos.usb.CameraLinkManager.State
import com.disha.glassos.util.AppLog
import org.json.JSONObject
import java.util.Locale

/**
 * The screen. All work happens in DishaService/DishaCore (so it continues with the screen off);
 * this activity binds to it, shows its state and forwards taps.
 */
class MainActivity : Activity(), DishaCore.Ui {

    private companion object {
        const val TAG = "UI"
        const val REQ_MIC = 1
        const val REQ_NOTIFY = 2
    }

    private var core: DishaCore? = null
    private var bound = false
    private lateinit var settings: AppSettings

    private lateinit var statusPill: TextView
    private lateinit var statusDetail: TextView
    private lateinit var recIndicator: TextView
    private lateinit var preview: ImageView
    private lateinit var previewMessage: TextView
    private lateinit var previewOverlay: TextView
    private lateinit var frameStats: TextView
    private lateinit var linkStats: TextView
    private lateinit var deviceStatus: TextView
    private lateinit var deviceInfo: TextView
    private lateinit var logView: TextView
    private lateinit var storageLine: TextView
    private lateinit var debugPanels: View
    private lateinit var btnCapture: Button
    private lateinit var btnStream: Button
    private lateinit var btnPhoto: Button
    private lateinit var btnRecord: Button
    private lateinit var btnResolution: Button
    private lateinit var btnFps: Button
    private lateinit var btnStatus: Button
    private lateinit var btnDisconnect: Button
    private lateinit var orb: DishaOrb
    private lateinit var assistantState: TextView
    private lateinit var assistantDetail: TextView
    private lateinit var chips: LinearLayout
    private lateinit var audioRoute: TextView
    private lateinit var partialSpeech: TextView
    private lateinit var chat: LinearLayout
    private var shownLines: List<String> = emptyList()
    private var lastRoute: AudioRouter.Route? = null
    private var holding = false
    private val holdStart = Runnable { holding = true; orb.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onHoldStart() }
    private val chipTicker = object : Runnable {
        override fun run() {
            updateChips()
            main.postDelayed(this, 15_000)
        }
    }
    private lateinit var tasksRow: View
    private lateinit var tasksLine: TextView
    private var recordingSince = 0L
    private var recordingWhere = ""
    private val recTicker = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (System.currentTimeMillis() - recordingSince) / 1000
            recIndicator.text = String.format(Locale.US, "● REC %d:%02d %s", s / 60, s % 60, recordingWhere)
            main.postDelayed(this, 1000)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val displayFps = FpsMeter()
    private var linkState = State.DISCONNECTED
    private var recording = false
    private var framesShown = 0L
    private var resolutionIndex = 1
    private var logRefreshScheduled = false
    private var glassesStorage: JSONObject? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val c = (service as DishaService.LocalBinder).core
            core = c
            c.ui = this@MainActivity
            if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) c.manager.refresh()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            core = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        settings = AppSettings(this)

        statusPill = findViewById(R.id.status_pill)
        statusDetail = findViewById(R.id.status_detail)
        recIndicator = findViewById(R.id.rec_indicator)
        preview = findViewById(R.id.preview)
        previewMessage = findViewById(R.id.preview_message)
        previewOverlay = findViewById(R.id.preview_overlay)
        frameStats = findViewById(R.id.frame_stats)
        linkStats = findViewById(R.id.link_stats)
        deviceStatus = findViewById(R.id.device_status)
        deviceInfo = findViewById(R.id.device_info)
        logView = findViewById(R.id.log_view)
        storageLine = findViewById(R.id.storage_line)
        debugPanels = findViewById(R.id.debug_panels)
        btnCapture = findViewById(R.id.btn_capture)
        btnStream = findViewById(R.id.btn_stream)
        btnPhoto = findViewById(R.id.btn_photo)
        btnRecord = findViewById(R.id.btn_record)
        btnResolution = findViewById(R.id.btn_resolution)
        btnFps = findViewById(R.id.btn_fps)
        btnStatus = findViewById(R.id.btn_status)
        btnDisconnect = findViewById(R.id.btn_disconnect)
        orb = findViewById(R.id.orb)
        assistantState = findViewById(R.id.assistant_state)
        assistantDetail = findViewById(R.id.assistant_detail)
        chips = findViewById(R.id.chips)
        audioRoute = findViewById(R.id.audio_route)
        partialSpeech = findViewById(R.id.partial_speech)
        chat = findViewById(R.id.chat)

        btnCapture.setOnClickListener { core?.manager?.captureFrame(fresh = true) }
        btnStream.setOnClickListener {
            val c = core ?: return@setOnClickListener
            if (linkState == State.STREAMING) c.manager.stopStream() else c.manager.startStream(settings.streamFps)
        }
        btnPhoto.setOnClickListener { core?.takePhoto { toast(it) } }
        btnRecord.setOnClickListener {
            val c = core ?: return@setOnClickListener
            if (recording) c.stopRecording { toast(it) } else c.startRecording { toast(it) }
        }
        btnResolution.setOnClickListener {
            resolutionIndex = (resolutionIndex + 1) % AppSettings.RESOLUTIONS.size
            val (w, h) = AppSettings.RESOLUTIONS[resolutionIndex]
            updateChoiceLabels()
            core?.manager?.setResolution(w, h)
        }
        btnFps.setOnClickListener {
            val i = (AppSettings.FPS_CHOICES.indexOf(settings.streamFps) + 1) % AppSettings.FPS_CHOICES.size
            settings.streamFps = AppSettings.FPS_CHOICES[i]
            updateChoiceLabels()
            if (linkState == State.STREAMING) core?.manager?.startStream(settings.streamFps)
        }
        btnStatus.setOnClickListener {
            core?.manager?.requestStatus()
            core?.manager?.requestStorage()
        }
        findViewById<Button>(R.id.btn_reconnect).setOnClickListener { core?.manager?.reconnect() }
        btnDisconnect.setOnClickListener { core?.manager?.disconnect() }
        findViewById<Button>(R.id.btn_settings).setOnClickListener { openSettings() }
        findViewById<Button>(R.id.btn_files).setOnClickListener { showGlassesFiles() }
        findViewById<Button>(R.id.btn_gallery).setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        findViewById<Button>(R.id.btn_exit).setOnClickListener { exitApp() }
        findViewById<Button>(R.id.btn_copy_log).setOnClickListener { copyLog() }
        findViewById<Button>(R.id.btn_clear_log).setOnClickListener { AppLog.clear() }
        // Tap the orb to talk; press and hold to talk until you let go.
        orb.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    holding = false
                    orb.animate().scaleX(0.92f).scaleY(0.92f).setDuration(120).start()
                    main.postDelayed(holdStart, 450)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(holdStart)
                    orb.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3f)).setDuration(260).start()
                    if (holding) core?.assistant?.holdEnd() else if (ev.actionMasked == MotionEvent.ACTION_UP) onMicPressed()
                    holding = false
                }
            }
            true
        }
        val more = findViewById<View>(R.id.more_controls)
        val toggleMore = findViewById<TextView>(R.id.toggle_more)
        toggleMore.setOnClickListener {
            val open = more.visibility != View.VISIBLE
            more.visibility = if (open) View.VISIBLE else View.GONE
            toggleMore.setText(if (open) R.string.less_controls else R.string.more_controls)
        }
        findViewById<Button>(R.id.btn_stop_voice).setOnClickListener { core?.assistant?.stopAll() }

        // Disha without speaking: quick actions and a typed command
        tasksRow = findViewById(R.id.tasks_row)
        tasksLine = findViewById(R.id.tasks_line)
        findViewById<Button>(R.id.btn_stop_tasks).setOnClickListener { core?.assistant?.let { toast(it.stopTasks()) } }
        findViewById<Button>(R.id.btn_quick_analyse).setOnClickListener {
            core?.assistant?.runText("What am I looking at? Tell me anything important or useful about it.")
        }
        findViewById<Button>(R.id.btn_quick_brief).setOnClickListener { core?.assistant?.runText("Brief me") }
        findViewById<Button>(R.id.btn_quick_remember).setOnClickListener { core?.assistant?.runText("Remember this") }
        findViewById<Button>(R.id.btn_quick_doc).setOnClickListener { core?.assistant?.runText("Make a document") }
        findViewById<Button>(R.id.btn_quick_captions).setOnClickListener {
            if (CaptionBoard.mode.isNotEmpty()) startActivity(Intent(this, CaptionsActivity::class.java))
            else core?.assistant?.runText("Start live captions")
        }
        findViewById<Button>(R.id.btn_quick_translate).setOnClickListener { core?.assistant?.runText("Be my translator") }
        findViewById<Button>(R.id.btn_quick_qr).setOnClickListener { core?.assistant?.runText("Scan the QR code") }
        findViewById<Button>(R.id.btn_quick_replay).setOnClickListener {
            val c = core ?: return@setOnClickListener
            if (c.replay.active) c.assistant.runText("Save that") else c.assistant.runText("Turn on instant replay")
        }
        findViewById<Button>(R.id.btn_quick_present).setOnClickListener {
            val c = core ?: return@setOnClickListener
            c.assistant.runText(if (c.presenter.running) "Stop presentation mode" else "Start presentation mode")
        }
        val command = findViewById<EditText>(R.id.edit_command)
        val send = {
            val text = command.text.toString().trim()
            if (text.isNotEmpty()) {
                core?.assistant?.runText(text)
                command.setText("")
            }
        }
        findViewById<Button>(R.id.btn_send).setOnClickListener { send() }
        command.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }

        AppLog.setListener { main.post { scheduleLogRefresh() } }
        AppLog.i(
            TAG,
            "DISHA GLASS OS ${BuildConfig.VERSION_NAME} on Android ${Build.VERSION.RELEASE} " +
                "(API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}",
        )
        resolutionIndex = 0
        updateChoiceLabels()
        onLinkState(State.DISCONNECTED, "Starting…")
        askNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        main.post(chipTicker)
        DishaService.start(this)
        bound = bindService(Intent(this, DishaService::class.java), connection, Context.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        debugPanels.visibility = if (settings.showDebug) View.VISIBLE else View.GONE
        updateChoiceLabels()
        core?.manager?.refresh()
    }

    override fun onStop() {
        main.removeCallbacks(chipTicker)
        core?.ui = null
        if (bound) {
            unbindService(connection)
            bound = false
        }
        core = null
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Opened by plugging in DISHA-CAM: permission was granted through the system dialog.
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) core?.manager?.refresh()
    }

    override fun onDestroy() {
        AppLog.setListener(null)
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Permissions, settings, exit
    // ---------------------------------------------------------------------------------------

    private fun hasMicPermission(): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFY)
        }
    }

    private fun onMicPressed() {
        if (!hasMicPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        askSpeechChoiceOnce { core?.assistant?.onMicButton() }
    }

    /**
     * The first time: ask whether spoken requests may go to the free online speech service. Voice is
     * never sent before the user agrees; "Use the phone's service" keeps everything on the phone's
     * own recogniser.
     */
    private fun askSpeechChoiceOnce(then: () -> Unit) {
        if (settings.voiceConsentAsked || settings.speechEngine != AppSettings.SpeechEngine.ONLINE) {
            then()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("How should I understand your voice?")
            .setMessage(
                "On some phones the built-in speech service doesn't work (it says \"speech service disconnected\"). " +
                    "I can instead send what you say to a free online speech recogniser: Whisper on OVHcloud AI " +
                    "Endpoints (France), with no account or key.\n\nOnly the few seconds after you tap the mic, or " +
                    "right after I answer in conversation mode, are sent. I never listen all the time. You can " +
                    "change this later in Settings.",
            )
            .setPositiveButton("Allow online speech") { _, _ ->
                settings.voiceConsent = true
                settings.voiceConsentAsked = true
                then()
            }
            .setNegativeButton("Use the phone's service") { _, _ ->
                settings.speechEngine = AppSettings.SpeechEngine.PHONE
                settings.voiceConsentAsked = true
                then()
            }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_MIC -> if (granted) {
                AppLog.i(TAG, "Microphone permission granted")
                DishaService.start(this, DishaService.ACTION_REFRESH)  // adds screen-off listening to the service
                askSpeechChoiceOnce { core?.assistant?.onMicButton() }
            } else {
                toast("DISHA needs the microphone to hear you. Tap the mic again and choose Allow.")
            }
            REQ_NOTIFY -> if (!granted) AppLog.w(TAG, "Notifications off: the running-in-background notice will be hidden")
        }
    }

    private fun openSettings() {
        val hello = core?.lastHello
        startActivity(
            Intent(this, SettingsActivity::class.java)
                .putExtra(SettingsActivity.EXTRA_FIRMWARE, hello?.let { "${it.optString("fw")} ${it.optString("fwVersion")} (${it.optString("transport")})" }),
        )
    }

    private fun exitApp() {
        AlertDialog.Builder(this)
            .setTitle("Exit DISHA GLASS OS?")
            .setMessage("This stops the glasses link, the assistant and any recording.")
            .setPositiveButton("Exit") { _, _ ->
                val c = core
                if (c != null && (c.recordingPhone || c.recordingGlasses)) c.stopRecording {}
                startService(Intent(this, DishaService::class.java).setAction(DishaService.ACTION_STOP))
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showGlassesFiles() {
        val c = core ?: return
        c.manager.listFiles(40) { r ->
            val json = r.json
            if (!r.ok || json == null) {
                toast("Couldn't list the glasses card: ${r.message}")
                return@listFiles
            }
            val files = json.optJSONArray("files")
            val lines = ArrayList<String>()
            if (files != null) {
                for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    lines.add("${f.optString("name")}  ·  ${f.optInt("kb")} KB")
                }
            }
            val message = when {
                !json.optBoolean("mounted") -> "No usable microSD card in the glasses."
                lines.isEmpty() -> "No photos or videos yet in ${json.optString("dir")}."
                else -> "Newest of ${json.optInt("total")} files in ${json.optString("dir")}:\n\n" + lines.joinToString("\n") +
                    "\n\nTo copy them, put the card in a PC (videos play in VLC)."
            }
            AlertDialog.Builder(this).setTitle("Glasses microSD card").setMessage(message).setPositiveButton("OK", null).show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // DishaCore.Ui (main thread)
    // ---------------------------------------------------------------------------------------

    override fun onLinkState(state: State, detail: String) {
        linkState = state
        statusPill.text = state.label.uppercase(Locale.US)
        statusPill.background = GradientDrawable().apply {
            cornerRadius = 999f
            setColor(color(colorFor(state)))
        }
        statusDetail.text = detail
        if (!state.connected) {
            displayFps.reset()
            previewOverlay.visibility = View.GONE
        }
        updateControls()
    }

    override fun onFrame(frame: CameraLinkManager.ReceivedFrame) {
        val f = frame.frame
        preview.setImageBitmap(frame.bitmap)
        previewMessage.visibility = View.GONE
        framesShown++
        displayFps.tick()
        val fps = displayFps.fps()
        previewOverlay.visibility = View.VISIBLE
        previewOverlay.text = String.format(Locale.US, "%d×%d · %.1f fps", f.width, f.height, fps)
        frameStats.text = buildString {
            append(
                String.format(
                    Locale.US, "#%d %s · %d×%d JPEG · %,d bytes · %d chunk(s)\n",
                    f.frameId, if (f.isRequested) "capture" else "stream", f.width, f.height, f.data.size, f.chunkCount,
                ),
            )
            append("ESP32 encode ${f.encodeMs} ms · phone decode ${frame.decodeMs} ms")
            frame.requestLatencyMs?.let { append(" · request→frame $it ms") }
            append(String.format(Locale.US, "\nCRC-32 OK · frames shown %d · display %.1f fps", framesShown, fps))
        }
    }

    override fun onDeviceInfo(info: CameraLinkManager.DeviceInfo) {
        deviceInfo.text = buildString {
            append("Phone: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
            val host = packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
            append("USB host feature: ${if (host) "yes" else "not declared"}\n\n")
            append(info.usbDescription.trimEnd())
            append('\n')
            info.transport?.let { append("\nTransport: ${it.label}\n") }
            info.hello?.let { h ->
                append("\nFirmware: ${h.optString("fw")} ${h.optString("fwVersion")} · protocol v${h.optInt("proto")} · ${h.optString("transport")}\n")
                append(
                    "Chip: ${h.optString("chip")} rev ${h.optInt("chipRev")} · ${h.optInt("cpuMHz")} MHz · " +
                        "flash ${h.optInt("flashMB")} MB · PSRAM ${h.optInt("psramKB")} KB\n",
                )
                append("Last reset: ${h.optString("resetReason")} · session ${h.optInt("session")}\n")
                h.optJSONObject("camera")?.let { c ->
                    append(
                        "Camera: ${c.optString("sensor")} (PID ${c.optString("pid")}) · ${c.optString("source")} · " +
                            "sensor JPEG: ${if (c.optBoolean("sensorJpeg")) "yes" else "no"}\n",
                    )
                    syncResolution(c)
                }
                append("Resolutions: ${h.optJSONArray("resolutions")}\n")
                append("Features: ${h.optJSONObject("features")}")
            }
        }
    }

    override fun onDeviceStatus(status: JSONObject) {
        val cam = status.optJSONObject("camera")
        deviceStatus.text = String.format(
            Locale.US,
            "ESP32 %.1f °C · heap %d KB · PSRAM free %d KB · up %d s\ncamera %s · sent %d frames · %.1f fps · last JPEG %d B, encode %d ms",
            status.optDouble("tempC"), status.optLong("heapFree") / 1024, status.optLong("psramFree") / 1024,
            status.optLong("uptimeMs") / 1000, cam?.optString("state") ?: "?", cam?.optLong("framesSent") ?: 0L,
            cam?.optDouble("fpsActual") ?: 0.0, cam?.optLong("lastJpegBytes") ?: 0L, cam?.optLong("lastEncodeMs") ?: 0L,
        )
        cam?.let { syncResolution(it) }
    }

    override fun onCommandResult(result: CameraLinkManager.CommandResult) {
        val name = DishaProtocol.typeName(result.command)
        if (result.ok) {
            AppLog.i(TAG, "$name: ${result.message}")
        } else {
            AppLog.w(TAG, "$name failed (${DishaProtocol.statusName(result.status)}): ${result.message}")
            toast("$name: ${result.message}")
        }
    }

    override fun onStats(stats: CameraLinkManager.LinkStats) {
        linkStats.text = String.format(
            Locale.US,
            "in %s · out %s · %d messages · RTT %s\nframes OK %d · dropped %d · decode errors %d\n" +
                "CRC errors: header %d, payload %d, frame %d · resync %d bytes",
            human(stats.bytesIn), human(stats.bytesOut), stats.messages,
            if (stats.rttMs >= 0) "${stats.rttMs} ms" else "–",
            stats.framesCompleted, stats.framesDropped, stats.decodeFailures,
            stats.headerCrcErrors, stats.payloadCrcErrors, stats.frameCrcFailures, stats.skippedBytes,
        )
    }

    override fun onStorage(storage: JSONObject) {
        glassesStorage = storage
        updateStorageLine()
    }

    override fun onRecording(phone: Boolean, glasses: Boolean) {
        val was = recording
        recording = phone || glasses
        recIndicator.visibility = if (recording) View.VISIBLE else View.GONE
        recordingWhere = when {
            phone && glasses -> "phone + glasses"
            phone -> "phone"
            glasses -> "glasses"
            else -> ""
        }
        main.removeCallbacks(recTicker)
        if (recording) {
            if (!was) recordingSince = System.currentTimeMillis()
            recTicker.run()  // running time, updated every second
        }
        btnRecord.setText(if (recording) R.string.stop_recording else R.string.record)
        updateStorageLine()
    }

    override fun onShowGallery(query: String): Boolean {
        startActivity(Intent(this, GalleryActivity::class.java).putExtra(GalleryActivity.EXTRA_QUERY, query))
        return true
    }

    override fun onTasks(text: String) {
        tasksRow.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
        tasksLine.text = text
        val replayOn = core?.replay?.active == true
        findViewById<Button>(R.id.btn_quick_replay).setText(if (replayOn) R.string.quick_replay else R.string.quick_replay_on)
    }

    override fun onShowCaptions(): Boolean {
        startActivity(Intent(this, CaptionsActivity::class.java))
        return true
    }

    override fun onOpenIntent(intent: Intent): Boolean = try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        AppLog.w(TAG, "Nothing on this phone can open that: ${e.message}")
        false
    }

    override fun onPresenter(urls: List<String>) {
        val box = findViewById<View>(R.id.presenter_box)
        val running = core?.presenter?.running == true
        box.visibility = if (running) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.presenter_url).text =
            urls.joinToString("\n").ifEmpty { "No Wi-Fi or hotspot: connect the phone to Wi-Fi, or turn on its hotspot and connect the laptop to it." }
        findViewById<Button>(R.id.btn_quick_present).setText(if (running) R.string.quick_present_stop else R.string.quick_present)
    }

    override fun onAssistantState(state: AssistantController.State, detail: String) {
        if (assistantState.text != state.label) {
            assistantState.alpha = 0f
            assistantState.text = state.label
            assistantState.animate().alpha(1f).setDuration(220).start()
        }
        assistantDetail.text = if (detail == state.label) "" else detail
        orb.mode = when (state) {
            AssistantController.State.PREPARING_MIC -> DishaOrb.Mode.PREPARING
            AssistantController.State.LISTENING -> DishaOrb.Mode.LISTENING
            AssistantController.State.PROCESSING -> DishaOrb.Mode.THINKING
            AssistantController.State.SPEAKING -> DishaOrb.Mode.SPEAKING
            else -> if (core?.assistant?.wakeListening == true) DishaOrb.Mode.WAKE else DishaOrb.Mode.IDLE
        }
        updateChips()
    }

    override fun onMicLevel(level: Int) {
        orb.setLevel(level)
    }

    override fun onPartialSpeech(text: String) {
        partialSpeech.text = text
    }

    /** The conversation as chat bubbles: you on the right, Disha on the left; new ones slide in. */
    override fun onTranscript(lines: List<String>) {
        val shown = lines.takeLast(10)
        val fresh = if (shownLines.isEmpty()) 0 else newLines(shownLines, lines)
        shownLines = lines.toList()
        chat.removeAllViews()
        val dp = resources.displayMetrics.density
        shown.forEachIndexed { i, line ->
            val who = line.substringBefore(": ", "")
            val text = line.substringAfter(": ", line)
            val mine = who == "You"
            val bubble = TextView(this)
            bubble.text = text
            bubble.textSize = 14f
            bubble.setTextColor(color(if (mine) R.color.disha_bg else R.color.disha_text))
            bubble.setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
            bubble.background = GradientDrawable().apply {
                cornerRadii = if (mine) floatArrayOf(18 * dp, 18 * dp, 4 * dp, 4 * dp, 18 * dp, 18 * dp, 18 * dp, 18 * dp)
                else floatArrayOf(4 * dp, 4 * dp, 18 * dp, 18 * dp, 18 * dp, 18 * dp, 18 * dp, 18 * dp)
                if (mine) setColor(color(R.color.disha_cyan)) else {
                    setColor(color(R.color.disha_button))
                    setStroke((1 * dp).toInt(), color(R.color.disha_panel_stroke))
                }
            }
            bubble.setOnLongClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Disha", text))
                toast("Copied")
                true
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.gravity = if (mine) Gravity.END else Gravity.START
            lp.topMargin = (6 * dp).toInt()
            if (mine) lp.leftMargin = (48 * dp).toInt() else lp.rightMargin = (48 * dp).toInt()
            chat.addView(bubble, lp)
            if (i >= shown.size - fresh) {
                bubble.alpha = 0f
                bubble.translationY = 14 * dp
                bubble.animate().alpha(1f).translationY(0f).setDuration(260).setStartDelay(60L * (i - (shown.size - fresh))).start()
            }
        }
    }

    /** How many lines at the end of [now] are new compared with [before]. */
    private fun newLines(before: List<String>, now: List<String>): Int {
        val last = before.lastOrNull() ?: return now.size
        val at = now.lastIndexOf(last)
        return if (at < 0) minOf(now.size, 10) else now.size - 1 - at
    }

    override fun onAudioRoute(route: AudioRouter.Route) {
        audioRoute.text = route.describe()
        lastRoute = route
        updateChips()
    }

    private fun onHoldStart() {
        if (!hasMicPermission()) {
            holding = false
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        core?.assistant?.holdStart()
    }

    /** Glasses, earbuds, wake word, AI and battery at a glance. */
    private fun updateChips() {
        val ok = R.color.disha_ok
        val warn = R.color.disha_warn
        val off = R.color.disha_idle
        val bad = R.color.disha_error
        val glasses = when (linkState) {
            State.READY, State.STREAMING -> "Glasses" to ok
            State.CAMERA_ERROR, State.ERROR -> "Glasses error" to bad
            State.DISCONNECTED, State.NO_USB_HOST, State.WRONG_DEVICE -> "No glasses" to off
            else -> "Glasses…" to warn
        }
        val ears = when (lastRoute?.speakerKind) {
            AudioRouter.Kind.BLUETOOTH -> "Earbuds" to ok
            AudioRouter.Kind.WIRED -> "Headset" to ok
            else -> "Phone speaker" to off
        }
        val wake = when {
            core?.assistant?.wakeListening == true -> "Say \"${settings.assistantName}\"" to ok
            settings.wakeEnabled -> "Wake paused" to warn
            else -> "Wake off" to off
        }
        val ai = if (settings.aiImageConsent) "AI sees" to ok else "AI (no pictures)" to warn
        val pct = (getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val battery = "$pct%" to (if (pct > 40) ok else if (pct > 15) warn else bad)
        val items = listOf(glasses, ears, wake, ai, battery)
        val dp = resources.displayMetrics.density
        while (chips.childCount < items.size) {
            val c = TextView(this)
            c.textSize = 12f
            c.setPadding((10 * dp).toInt(), (4 * dp).toInt(), (10 * dp).toInt(), (4 * dp).toInt())
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = (6 * dp).toInt()
            chips.addView(c, lp)
        }
        items.forEachIndexed { i, (label, col) ->
            val c = chips.getChildAt(i) as TextView
            val s = SpannableString("● $label")
            s.setSpan(ForegroundColorSpan(color(col)), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (c.text.toString() != s.toString()) {
                c.text = s
                c.setTextColor(color(R.color.disha_text))
                c.background = GradientDrawable().apply {
                    cornerRadius = 999f
                    setColor(color(R.color.disha_panel))
                    setStroke((1 * dp).toInt(), color(col))
                }
                c.alpha = 0.4f
                c.animate().alpha(1f).setDuration(300).start()
            }
        }
    }

    // ---------------------------------------------------------------------------------------

    private fun updateStorageLine() {
        val g = glassesStorage
        val glasses = when {
            g == null -> "Glasses card: unknown"
            !g.optBoolean("mounted") -> "Glasses card: none"
            else -> String.format(
                Locale.US, "Glasses card: %.1f GB free · %d photos · %d videos",
                g.optLong("freeMB") / 1024.0, g.optInt("photos"), g.optInt("videos"),
            )
        }
        val phone = String.format(Locale.US, "Phone: %.1f GB free", MediaSaver.phoneFreeMb(this) / 1024.0)
        storageLine.text = "$glasses\n$phone · photos → ${settings.photoDestination.label} · video → ${settings.recordDestination.label}"
    }

    private fun updateControls() {
        val connected = linkState.connected
        val ready = linkState == State.READY || linkState == State.STREAMING
        btnCapture.isEnabled = ready
        btnStream.isEnabled = ready
        btnPhoto.isEnabled = ready
        btnRecord.isEnabled = ready || recording
        btnStream.setText(if (linkState == State.STREAMING) R.string.stop_stream else R.string.start_stream)
        btnResolution.isEnabled = connected && linkState != State.CAMERA_INITIALISING
        btnStatus.isEnabled = connected
        btnDisconnect.isEnabled = linkState != State.DISCONNECTED
    }

    private fun updateChoiceLabels() {
        val (w, h) = AppSettings.RESOLUTIONS[resolutionIndex]
        btnResolution.text = "$w×$h"
        btnFps.text = "${settings.streamFps} fps"
    }

    private fun syncResolution(camera: JSONObject) {
        val index = AppSettings.RESOLUTIONS.indexOf(camera.optInt("width") to camera.optInt("height"))
        if (index >= 0 && index != resolutionIndex) {
            resolutionIndex = index
            updateChoiceLabels()
        }
    }

    private fun colorFor(state: State): Int = when (state) {
        State.READY -> R.color.disha_ok
        State.STREAMING -> R.color.disha_stream
        State.CONNECTING, State.HANDSHAKING, State.CAMERA_INITIALISING, State.PERMISSION_NEEDED -> R.color.disha_warn
        State.CAMERA_ERROR, State.ERROR, State.WRONG_DEVICE, State.NO_USB_HOST -> R.color.disha_error
        State.DISCONNECTED -> R.color.disha_idle
    }

    @Suppress("DEPRECATION")
    private fun color(id: Int): Int = if (Build.VERSION.SDK_INT >= 23) getColor(id) else resources.getColor(id)

    private fun scheduleLogRefresh() {
        if (logRefreshScheduled) return
        logRefreshScheduled = true
        main.postDelayed({
            logRefreshScheduled = false
            logView.text = AppLog.snapshot(80)
        }, 250)
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("DISHA log", AppLog.snapshot()))
        toast("Log copied")
    }

    private fun human(bytes: Long): String = when {
        bytes >= 1024L * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
