package com.disha.glassos.skills

import java.util.Locale
import kotlin.math.roundToInt

/**
 * How healthy a packaged food is, in a few spoken sentences, from Open Food Facts data.
 * Levels per 100 g follow the UK "traffic light" front-of-pack thresholds. Pure logic.
 */
class FoodText(
    val name: String,
    val brand: String,
    val quantity: String,
    val nutriScore: String,      // "a".."e" or ""
    val novaGroup: Int,          // 1..4, 0 = unknown
    val kcal100g: Double?,
    val sugars100g: Double?,
    val fat100g: Double?,
    val saturatedFat100g: Double?,
    val salt100g: Double?,
    val allergens: List<String>, // tags like "en:milk"
    val isDrink: Boolean,
) {
    companion object {
        /** low / medium / high for one nutrient; drinks use half the food limits for sugar and fat. */
        fun level(value: Double?, low: Double, high: Double): String? = when {
            value == null -> null
            value <= low -> "low"
            value > high -> "high"
            else -> "medium"
        }

        private fun g(v: Double) = if (v < 10) String.format(Locale.US, "%.1f", v).removeSuffix(".0") else v.roundToInt().toString()
    }

    fun sugarLevel() = if (isDrink) level(sugars100g, 2.5, 11.25) else level(sugars100g, 5.0, 22.5)
    fun fatLevel() = if (isDrink) level(fat100g, 1.5, 8.75) else level(fat100g, 3.0, 17.5)
    fun satFatLevel() = if (isDrink) level(saturatedFat100g, 0.75, 2.5) else level(saturatedFat100g, 1.5, 5.0)
    fun saltLevel() = if (isDrink) level(salt100g, 0.3, 0.75) else level(salt100g, 0.3, 1.5)

    /** "Coca-Cola Original: Nutri-Score E, not a healthy choice. High in sugar: 10.6 g per 100 ml…" */
    fun sentence(): String {
        val per = if (isDrink) "per 100 ml" else "per 100 g"
        val parts = ArrayList<String>()
        var head = name.ifBlank { "This product" }
        val brandName = brand.split(',').first().trim()
        val brandWord = brandName.split(Regex("[^\\p{L}\\p{N}]+")).firstOrNull { it.isNotEmpty() }.orEmpty()
        if (brandWord.isNotEmpty() && !name.contains(brandWord, ignoreCase = true)) head += " by $brandName"
        parts.add("$head.")
        when (nutriScore.lowercase(Locale.US)) {
            "a" -> "Nutri-Score A, a healthy choice."
            "b" -> "Nutri-Score B, a fairly healthy choice."
            "c" -> "Nutri-Score C, okay in moderation."
            "d" -> "Nutri-Score D, better as an occasional treat."
            "e" -> "Nutri-Score E, not a healthy choice."
            else -> null
        }?.let { parts.add(it) }
        if (novaGroup == 4) parts.add("It's ultra-processed.")
        val highs = ArrayList<String>()
        val lows = ArrayList<String>()
        fun note(label: String, lvl: String?, v: Double?) {
            if (lvl == "high" && v != null) highs.add("$label ${g(v)} grams") else if (lvl == "low") lows.add(label)
        }
        note("sugar", sugarLevel(), sugars100g)
        note("fat", fatLevel(), fat100g)
        note("saturated fat", satFatLevel(), saturatedFat100g)
        note("salt", saltLevel(), salt100g)
        if (highs.isNotEmpty()) parts.add("High in ${highs.joinToString(", ")} $per.")
        if (lows.isNotEmpty()) parts.add("Low in ${lows.joinToString(", ")}.")
        kcal100g?.let { parts.add("${it.roundToInt()} calories $per.") }
        val a = allergens.map { it.substringAfter(':').replace('-', ' ') }.filter { it.isNotBlank() }.distinct()
        if (a.isNotEmpty()) parts.add("Contains ${a.joinToString(", ")}.")
        return parts.joinToString(" ")
    }
}
