package com.disha.glassos.skills

import android.graphics.BitmapFactory
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer

/** QR codes and barcodes read on the phone (ZXing), offline: nothing is sent anywhere. Call off the main thread. */
object QrReader {

    class Code(val text: String, val format: BarcodeFormat) {
        val isProductBarcode get() = format in setOf(BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E)
    }

    private val ALL = listOf(
        BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX, BarcodeFormat.AZTEC, BarcodeFormat.PDF_417,
        BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
        BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.ITF,
    )

    /** The first code found in the JPEG, or null. products = only product barcodes (food). */
    fun decode(jpeg: ByteArray, products: Boolean = false): Code? {
        val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return null
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        val formats = if (products) listOf(BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E) else ALL
        val hints = mapOf(DecodeHintType.POSSIBLE_FORMATS to formats, DecodeHintType.TRY_HARDER to true)
        val reader = MultiFormatReader().apply { setHints(hints) }
        val source = RGBLuminanceSource(w, h, px)
        for (s in listOf(source, source.invert())) {
            for (bin in listOf(HybridBinarizer(s), GlobalHistogramBinarizer(s))) {
                try {
                    val r = reader.decodeWithState(BinaryBitmap(bin))
                    return Code(r.text, r.barcodeFormat)
                } catch (_: Exception) {
                } finally {
                    reader.reset()
                }
            }
        }
        return null
    }
}
