package com.disha.glassos.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Things the user asked the assistant to remember ("my car is on level B2"). Stored only on the
 * phone; the list is given to the AI with each question so it can answer "where did I park?".
 */
class MemoryStore(context: Context) {

    class Fact(val text: String, val time: Long)

    private companion object {
        const val MAX_FACTS = 40
        val STOP_WORDS = setOf("the", "a", "an", "my", "me", "i", "about", "that", "this", "is", "are", "was", "of", "to", "on", "in", "it")
    }

    private val p = context.applicationContext.getSharedPreferences("disha_memory", Context.MODE_PRIVATE)

    fun all(): List<Fact> {
        val arr = try {
            JSONArray(p.getString("facts", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { Fact(it.optString("text"), it.optLong("time")) }
        }.filter { it.text.isNotBlank() }
    }

    fun add(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val facts = all().filter { !it.text.equals(clean, ignoreCase = true) } + Fact(clean, System.currentTimeMillis())
        save(facts.takeLast(MAX_FACTS))
    }

    /** Removes facts that share the important words of [query]; returns how many were removed. */
    fun forget(query: String): Int {
        val words = significant(query)
        if (words.isEmpty()) return 0
        val facts = all()
        val keep = facts.filter { f -> significant(f.text).intersect(words).isEmpty() }
        save(keep)
        return facts.size - keep.size
    }

    /** Removes fact number [n] as listed in [promptText] (1-based). */
    fun forgetNumber(n: Int): Fact? {
        val facts = all()
        if (n !in 1..facts.size) return null
        save(facts.filterIndexed { i, _ -> i != n - 1 })
        return facts[n - 1]
    }

    fun clear() = save(emptyList())

    /** Adds facts from a backup that are not here yet (keeping when they were saved); returns how many. */
    fun merge(facts: List<Fact>): Int {
        val have = all()
        val new = facts.filter { f -> f.text.isNotBlank() && have.none { it.text.equals(f.text, ignoreCase = true) } }
        if (new.isNotEmpty()) save((have + new).sortedBy { it.time }.takeLast(MAX_FACTS))
        return new.size
    }

    /** The facts as JSON, for a backup. */
    fun toJson(): String = p.getString("facts", "[]") ?: "[]"

    /** Facts from [toJson] output; throws if it is not that. */
    fun parse(json: String): List<Fact> {
        val arr = JSONArray(json)
        return (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Fact(it.optString("text"), it.optLong("time")) } }
    }

    /** Numbered list for the AI, oldest first, or empty. */
    fun promptText(): String {
        val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH)
        return all().mapIndexed { i, f -> "${i + 1}. ${f.text} (saved ${fmt.format(Date(f.time))})" }.joinToString("\n")
    }

    private fun significant(s: String) =
        s.lowercase(Locale.US).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in STOP_WORDS }.toSet()

    private fun save(facts: List<Fact>) {
        val arr = JSONArray()
        for (f in facts) arr.put(JSONObject().put("text", f.text).put("time", f.time))
        p.edit().putString("facts", arr.toString()).apply()
    }
}
