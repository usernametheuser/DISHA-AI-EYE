package com.disha.glassos.assistant

import android.util.Base64
import com.disha.glassos.ai.BrainClient
import com.disha.glassos.ai.VisionAi
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject

/**
 * The thinking loop: the model reads the request (with context, memory, recent conversation and,
 * when it is about what the user sees, a camera picture) and either answers, or calls tools: look
 * or observe through the camera, photos, timed video, photo series, watching in the background,
 * timers, reminders, memory, weather, news, Wikipedia, torch, volume, music. Tool results go back
 * to the model when it needs them to phrase an answer; simple actions are confirmed directly,
 * which saves a round trip. At most three model calls per request. Main thread only.
 */
class Agent(private val brain: BrainClient, private val host: Host) {

    /** What the tools do; implemented by the assistant. Callbacks on the main thread. */
    interface Host {
        fun takePhoto(done: (String) -> Unit)
        /** seconds: stop by itself after that long; null = until told to stop. */
        fun recordVideo(seconds: Int?, done: (String) -> Unit)
        fun stopRecording(done: (String) -> Unit)
        fun photoSeries(count: Int, intervalSeconds: Int): String
        fun watchFor(target: String, minutes: Double, photo: Boolean): String
        fun stopTasks(): String
        fun listTasks(): String
        fun searchMemory(query: String): String
        fun readMessages(): String
        /** Prepares a reply; it is sent only after the user says yes. Returns the question to ask. */
        fun prepareReply(to: String?, text: String): String
        fun setTimer(seconds: Int, label: String): String
        fun setReminder(seconds: Int, text: String): String
        fun cancelTimers(): String
        fun listTimers(): String
        fun remember(fact: String): String
        fun forgetMemory(number: Int): String
        fun weather(city: String, done: (data: String?, error: String?) -> Unit)
        fun news(topic: String?, done: (data: String?, error: String?) -> Unit)
        fun wikipedia(query: String, done: (data: String?, error: String?) -> Unit)
        fun flashlight(on: Boolean): String
        fun volume(steps: Int): String
        fun media(action: String): String
        fun minuteOfDay(): Int
        /** 0.12 tools that act at once and confirm: slides, replay, navigation stop, captions stop, presentation mode. */
        fun skill(name: String, args: JSONObject, done: (String) -> Unit)
    }

    sealed class Result {
        class Speak(val text: String) : Result()
        /** The model wants to look through the camera: the vision model answers this question. */
        class Look(val question: String) : Result()
        /** Watch for a few seconds (several pictures), then answer the question about what happened. */
        class Observe(val seconds: Int, val question: String) : Result()
        /** A skill that runs its own conversation (document pages, directions, captions, scanning): the assistant takes over. */
        class Handoff(val tool: String, val args: JSONObject) : Result()
        class Failure(val message: String) : Result()
    }

    /** forModel goes back to the model; spoken is said if the model is not asked again. */
    private class ToolResult(val forModel: String, val spoken: String, val needsModel: Boolean)

    private companion object {
        const val TAG = "Agent"
        const val MAX_ROUNDS = 3
        val SEVERAL = Regex("(?i)\\b(and|also|then|plus|after that)\\b|,")
        val HANDOFF = setOf("start_document", "finish_document", "navigate_to", "scan_code", "read_business_card", "live_captions")
        val SKILLS = setOf("slide_control", "save_replay", "instant_replay", "stop_navigation", "stop_captions", "presentation_mode")

        fun fn(name: String, description: String, props: JSONObject = JSONObject(), required: List<String> = emptyList()) =
            JSONObject().put("type", "function").put(
                "function",
                JSONObject().put("name", name).put("description", description).put(
                    "parameters",
                    JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(required)),
                ),
            )

        fun prop(type: String, description: String) = JSONObject().put("type", type).put("description", description)

        val TOOLS: JSONArray = JSONArray()
            .put(fn("look", "Take a picture with the camera on the user's glasses and answer a question about what they are looking at: objects, text, people, places, colours, anything they call 'this' or 'that'.",
                JSONObject().put("question", prop("string", "The question to answer from the picture")), listOf("question")))
            .put(fn("watch_briefly", "Watch through the camera NOW for a few seconds (several pictures over time), then answer what happened or changed. For: watch this for N seconds, what is happening, is it moving.",
                JSONObject().put("seconds", prop("integer", "How long to watch, 3 to 30")).put("question", prop("string", "What to answer afterwards")),
                listOf("seconds", "question")))
            .put(fn("take_photo", "Save a photo from the glasses camera."))
            .put(fn("record_video", "Start recording video from the glasses camera. With seconds, it stops by itself after that long.",
                JSONObject().put("seconds", prop("integer", "Optional length in seconds"))))
            .put(fn("stop_recording", "Stop the video recording."))
            .put(fn("photo_series", "Take a series of photos at a regular interval in the background (time-lapse).",
                JSONObject().put("count", prop("integer", "How many photos, 2 to 60")).put("interval_seconds", prop("integer", "Seconds between photos, at least 5")),
                listOf("count", "interval_seconds")))
            .put(fn("alert_when_seen", "Keep watching in the BACKGROUND for up to 15 minutes and alert the user LATER when something appears. For: tell me when you see X, keep an eye out for X, let me know if X shows up.",
                JSONObject().put("target", prop("string", "What to watch for, for example 'a bus' or 'someone at the door'"))
                    .put("minutes", prop("number", "How long to keep watching, up to 15"))
                    .put("take_photo", prop("boolean", "Also save a photo when it appears")),
                listOf("target")))
            .put(fn("stop_tasks", "Stop all background tasks: watching, photo series and timed recordings."))
            .put(fn("search_my_memory", "Search what the glasses saw (visual memory), photo captions, saved documents and the day's events. For: where did I leave my keys, what was on the whiteboard, when did I last see my bag.",
                JSONObject().put("query", prop("string", "What to look for, for example 'keys'")), listOf("query")))
            .put(fn("read_messages", "Read the user's new messages (WhatsApp, SMS and other apps) from the phone's notifications."))
            .put(fn("reply_message", "Prepare a reply to a recent message. It is sent only after the user says yes: ask them to confirm.",
                JSONObject().put("to", prop("string", "Who to reply to, as the user said it (for example Mom); empty for the latest message")).put("text", prop("string", "The reply in the user's own words; add nothing")),
                listOf("text")))
            .put(fn("list_tasks", "Say which background tasks are running."))
            .put(fn("set_timer", "Start a countdown timer that is announced in the earbuds when it ends.",
                JSONObject().put("seconds", prop("integer", "Length in seconds")).put("label", prop("string", "Optional short name, like pasta")),
                listOf("seconds")))
            .put(fn("set_reminder", "Remind the user of something later, by voice in their earbuds. Give minutes_from_now or clock_time.",
                JSONObject().put("text", prop("string", "What to remind them about"))
                    .put("minutes_from_now", prop("number", "Minutes from now"))
                    .put("clock_time", prop("string", "Local time in 24-hour HH:MM, for example 18:30")),
                listOf("text")))
            .put(fn("cancel_timers", "Cancel all timers and reminders."))
            .put(fn("list_timers", "Say which timers and reminders are pending and how long is left."))
            .put(fn("remember", "Save a fact the user asks you to remember, for later questions.",
                JSONObject().put("fact", prop("string", "The fact, written so it makes sense later")), listOf("fact")))
            .put(fn("forget_memory", "Delete one remembered fact, by its number in the memory list.",
                JSONObject().put("number", prop("integer", "The fact's number")), listOf("number")))
            .put(fn("get_weather", "Current weather and the forecast for today and tomorrow. Leave city empty for the user's own city.",
                JSONObject().put("city", prop("string", "City name, or empty"))))
            .put(fn("get_news", "Latest news headlines, optionally about a topic.",
                JSONObject().put("topic", prop("string", "Topic, or empty for top headlines"))))
            .put(fn("search_wikipedia", "Look up a person, place, thing or event in Wikipedia when you are not sure of the facts.",
                JSONObject().put("query", prop("string", "What to look up")), listOf("query")))
            .put(fn("flashlight", "Turn the phone's flashlight (torch) on or off.",
                JSONObject().put("on", prop("boolean", "true to turn on")), listOf("on")))
            .put(fn("volume", "Make the phone's media volume louder or quieter.",
                JSONObject().put("direction", JSONObject().put("type", "string").put("enum", JSONArray().put("up").put("down"))), listOf("direction")))
            .put(fn("media_control", "Control the music or video playing on the phone.",
                JSONObject().put("action", JSONObject().put("type", "string").put("enum", JSONArray().put("play").put("pause").put("next").put("previous"))),
                listOf("action")))
            .put(fn("start_document", "Start scanning several pages into one PDF document: the user shows page after page to the camera and says done at the end.",
                JSONObject().put("title", prop("string", "Optional name of the document"))))
            .put(fn("finish_document", "Finish the document being scanned and save it as a PDF."))
            .put(fn("navigate_to", "Walking directions, turn by turn in the earbuds, to a place or the nearest kind of place (for example 'nearest metro station', 'India Gate').",
                JSONObject().put("place", prop("string", "Where to go")), listOf("place")))
            .put(fn("stop_navigation", "Stop the walking directions."))
            .put(fn("slide_control", "Move the user's presentation slides (PowerPoint or PDF shown on the laptop).",
                JSONObject().put("action", JSONObject().put("type", "string").put("enum", JSONArray().put("next").put("previous").put("goto").put("start").put("end").put("black")))
                    .put("number", prop("integer", "Slide number, for goto")),
                listOf("action")))
            .put(fn("save_replay", "Save the last seconds of what the glasses saw as a video (instant replay, up to 30 seconds).",
                JSONObject().put("seconds", prop("integer", "How many of the last seconds, up to 30"))))
            .put(fn("instant_replay", "Switch instant replay on or off (always keeping the last 30 seconds of video in memory).",
                JSONObject().put("on", prop("boolean", "true to switch on")), listOf("on")))
            .put(fn("scan_code", "Read a QR code or barcode the user is showing (links, UPI payment codes, Wi-Fi, contacts, products)."))
            .put(fn("read_business_card", "Read a business or visiting card the user is holding and offer to save the contact."))
            .put(fn("live_captions", "Start live captions of what people say, or a two-way translator between the user's language and another language.",
                JSONObject().put("translate", prop("boolean", "true for the translator, false for captions only"))
                    .put("other_language", prop("string", "The other person's language, for example Hindi or Tamil"))))
            .put(fn("stop_captions", "Stop live captions or the translator."))
            .put(fn("presentation_mode", "Turn on or off the web view for a laptop or projector (live camera, conversation, slides).",
                JSONObject().put("on", prop("boolean", "true to turn on")), listOf("on")))
    }

    private var callCounter = 0

    /** image: what the glasses camera sees right now (JPEG), if the request is about it. */
    fun run(system: String, history: List<VisionAi.Turn>, user: String, image: ByteArray?, done: (Result) -> Unit) {
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for (t in history) {
            messages.put(JSONObject().put("role", "user").put("content", t.user))
            messages.put(JSONObject().put("role", "assistant").put("content", t.assistant))
        }
        if (image == null) {
            messages.put(JSONObject().put("role", "user").put("content", user))
        } else {
            val uri = "data:image/jpeg;base64," + Base64.encodeToString(image, Base64.NO_WRAP)
            messages.put(JSONObject().put("role", "user").put("content", JSONArray()
                .put(JSONObject().put("type", "text").put("text", user))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", uri)))))
        }
        step(messages, 0, SEVERAL.containsMatchIn(user), user, image != null, ArrayList(), done)
    }

    private fun step(
        messages: JSONArray,
        round: Int,
        several: Boolean,
        user: String,
        withImage: Boolean,
        spoken: ArrayList<String>,
        done: (Result) -> Unit,
    ) {
        // The last round offers no tools, so the model has to answer in words.
        brain.chat(messages, if (round < MAX_ROUNDS - 1) TOOLS else JSONArray(), withImage) { reply ->
            when (reply) {
                is BrainClient.Reply.Failure ->
                    done(if (spoken.isNotEmpty()) Result.Speak(spoken.joinToString(" ")) else Result.Failure(reply.message))
                is BrainClient.Reply.Message -> {
                    if (reply.calls.isEmpty()) {
                        val text = SpeechText.forSpeech(reply.text).ifEmpty { spoken.joinToString(" ") }
                        done(if (text.isEmpty()) Result.Failure("I didn't get an answer. Try asking another way.") else Result.Speak(text))
                        return@chat
                    }
                    reply.calls.firstOrNull { it.name == "look" }?.let {
                        done(Result.Look(it.args.optString("question").ifBlank { user }))
                        return@chat
                    }
                    reply.calls.firstOrNull { it.name == "watch_briefly" || isMisplacedWatch(it) }?.let {
                        val seconds = (number(it.args, "seconds")?.toInt() ?: 10).coerceIn(3, 30)
                        done(Result.Observe(seconds, it.args.optString("question").ifBlank { user }))
                        return@chat
                    }
                    reply.calls.firstOrNull { it.name in HANDOFF }?.let {
                        done(Result.Handoff(it.name, it.args))
                        return@chat
                    }
                    // Our own short ids: some servers' templates only accept 9-character ids, and the
                    // next round may be answered by another model.
                    val ids = reply.calls.map { "c" + (++callCounter).toString().padStart(8, '0').takeLast(8) }
                    val calls = JSONArray()
                    reply.calls.forEachIndexed { i, c ->
                        calls.put(JSONObject().put("id", ids[i]).put("type", "function").put(
                            "function", JSONObject().put("name", c.name).put("arguments", c.args.toString()),
                        ))
                    }
                    messages.put(JSONObject().put("role", "assistant").put("content", "").put("tool_calls", calls))
                    runTools(reply.calls, 0, ArrayList()) { results ->
                        results.forEachIndexed { i, r ->
                            messages.put(JSONObject().put("role", "tool").put("tool_call_id", ids[i]).put("name", reply.calls[i].name).put("content", r.forModel))
                            if (r.spoken.isNotEmpty()) spoken.add(r.spoken)
                        }
                        val askAgain = results.any { it.needsModel } || (several && round == 0)
                        if (askAgain && round + 1 < MAX_ROUNDS) {
                            step(messages, round + 1, several, user, withImage, spoken, done)
                        } else {
                            done(Result.Speak(spoken.joinToString(" ").ifEmpty { "Done." }))
                        }
                    }
                }
            }
        }
    }

    private fun runTools(calls: List<BrainClient.ToolCall>, i: Int, out: ArrayList<ToolResult>, done: (List<ToolResult>) -> Unit) {
        if (i >= calls.size) {
            done(out)
            return
        }
        execute(calls[i]) { r ->
            out.add(r)
            runTools(calls, i + 1, out, done)
        }
    }

    private fun execute(call: BrainClient.ToolCall, done: (ToolResult) -> Unit) {
        val a = call.args
        AppLog.i(TAG, "Tool ${call.name} $a")
        fun said(s: String) = done(ToolResult("Done: $s", s, false))
        fun info(data: String?, error: String?) =
            done(if (data != null) ToolResult(data, "", true) else ToolResult("Failed: $error", error ?: "That didn't work.", true))
        when (call.name) {
            "take_photo" -> host.takePhoto { said(it) }
            "record_video", "start_recording" -> host.recordVideo(number(a, "seconds")?.toInt()?.takeIf { it > 0 }) { said(it) }
            "stop_recording" -> host.stopRecording { said(it) }
            "photo_series" -> said(host.photoSeries(number(a, "count")?.toInt() ?: 5, number(a, "interval_seconds")?.toInt() ?: 10))
            "alert_when_seen" -> said(host.watchFor(a.optString("target").ifBlank { "anything unusual" }, number(a, "minutes") ?: 5.0,
                a.optBoolean("take_photo", false)))
            "stop_tasks" -> said(host.stopTasks())
            "search_my_memory" -> done(ToolResult(host.searchMemory(a.optString("query")), "", true))
            "read_messages" -> host.readMessages().let { done(ToolResult(it, it, false)) }
            "reply_message" -> host.prepareReply(a.optString("to").ifBlank { null }, a.optString("text")).let { done(ToolResult(it, it, false)) }
            "list_tasks" -> said(host.listTasks())
            "set_timer" -> {
                val s = number(a, "seconds")?.toInt()
                if (s == null || s <= 0) done(ToolResult("Failed: no duration", "How long should the timer be?", false))
                else said(host.setTimer(s, a.optString("label")))
            }
            "set_reminder" -> {
                val minutes = number(a, "minutes_from_now")
                val clock = a.optString("clock_time")
                val seconds = when {
                    minutes != null && minutes > 0 -> (minutes * 60).toInt()
                    clock.isNotBlank() -> TimeParse.secondsUntilClock("at $clock", host.minuteOfDay())
                    else -> null
                }
                if (seconds == null) done(ToolResult("Failed: no time given", "When should I remind you?", false))
                else said(host.setReminder(seconds, a.optString("text")))
            }
            "cancel_timers" -> said(host.cancelTimers())
            "list_timers" -> said(host.listTimers())
            "remember" -> said(host.remember(a.optString("fact")))
            "forget_memory" -> said(host.forgetMemory(number(a, "number")?.toInt() ?: -1))
            "get_weather" -> host.weather(a.optString("city")) { d, e -> info(d, e) }
            "get_news" -> host.news(a.optString("topic").ifBlank { null }) { d, e -> info(d, e) }
            "search_wikipedia" -> host.wikipedia(a.optString("query")) { d, e -> info(d, e) }
            "flashlight" -> said(host.flashlight(bool(a, "on")))
            "volume" -> said(host.volume(if (a.optString("direction") == "down") -2 else 2))
            "media_control" -> said(host.media(a.optString("action")))
            in SKILLS -> host.skill(call.name, a) { said(it) }
            else -> done(ToolResult("Failed: unknown tool ${call.name}", "", true))
        }
    }

    /** A background alert asked for with "seconds"/"question" and no target means watch_briefly. */
    private fun isMisplacedWatch(c: BrainClient.ToolCall) =
        c.name == "alert_when_seen" && c.args.optString("target").isBlank() && (c.args.has("seconds") || c.args.has("question"))

    /** Models sometimes send numbers as strings ("180"). */
    private fun number(o: JSONObject, key: String): Double? = when (val v = o.opt(key)) {
        is Number -> v.toDouble()
        is String -> v.trim().toDoubleOrNull()
        else -> null
    }

    private fun bool(o: JSONObject, key: String): Boolean = when (val v = o.opt(key)) {
        is Boolean -> v
        is String -> v.equals("true", ignoreCase = true) || v.equals("on", ignoreCase = true)
        else -> true
    }
}
