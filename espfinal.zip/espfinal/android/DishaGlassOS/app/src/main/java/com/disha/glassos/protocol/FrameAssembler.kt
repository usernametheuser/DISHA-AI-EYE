package com.disha.glassos.protocol

import com.disha.glassos.protocol.DishaProtocol.FRAME_CHUNK_HEADER_LEN
import com.disha.glassos.protocol.DishaProtocol.getU16
import com.disha.glassos.protocol.DishaProtocol.getU32

/**
 * Reassembles FRAME_CHUNK messages into complete frames.
 * A frame is accepted only if its chunks arrive in order, cover exactly the announced
 * length and the CRC-32 of the whole frame matches. Anything else is dropped (reported
 * through onDrop) and the next frame starts clean.
 *
 * Not thread-safe: called from the USB reader thread only.
 */
class FrameAssembler(
    private val onDrop: (String) -> Unit,
    private val maxFrameBytes: Int = 2 * 1024 * 1024,
) {

    class Frame(
        val frameId: Long,
        val width: Int,
        val height: Int,
        val format: Int,
        val flags: Int,
        val ref: Int,
        val data: ByteArray,
        val chunkCount: Int,
        val encodeMs: Int,
        val deviceCaptureMillis: Long,
        val transferMs: Long,
        val completedAtNanos: Long,
    ) {
        val isRequested: Boolean get() = (flags and DishaProtocol.FLAG_REQUESTED) != 0
        val isStream: Boolean get() = (flags and DishaProtocol.FLAG_STREAM) != 0
    }

    private class Partial(
        val frameId: Long,
        val total: Int,
        val chunkCount: Int,
        val width: Int,
        val height: Int,
        val format: Int,
        val flags: Int,
        val ref: Int,
        val encodeMs: Int,
        val captureMillis: Long,
        val frameCrc: Long,
        val startedNanos: Long,
    ) {
        val data = ByteArray(total)
        var received = 0
        var nextIndex = 0
    }

    private var current: Partial? = null

    @Volatile
    var completed = 0L
        private set

    @Volatile
    var dropped = 0L
        private set

    @Volatile
    var crcFailures = 0L
        private set

    fun reset() {
        current = null
    }

    /** Returns the frame when this chunk completes it, otherwise null. */
    fun onChunk(ref: Int, p: ByteArray): Frame? {
        if (p.size < FRAME_CHUNK_HEADER_LEN) return drop("frame chunk shorter than its header (${p.size} bytes)")
        val frameId = getU32(p, 0)
        val total = getU32(p, 4)
        val offset = getU32(p, 8)
        val index = getU16(p, 12)
        val count = getU16(p, 14)
        val width = getU16(p, 16)
        val height = getU16(p, 18)
        val format = p[20].toInt() and 0xFF
        val flags = p[21].toInt() and 0xFF
        val encodeMs = getU16(p, 22)
        val captureMillis = getU32(p, 24)
        val frameCrc = getU32(p, 28)
        val dataLen = p.size - FRAME_CHUNK_HEADER_LEN

        if (total <= 0 || total > maxFrameBytes) return drop("frame $frameId: invalid length $total")
        if (count == 0 || index >= count) return drop("frame $frameId: invalid chunk $index/$count")
        if (offset + dataLen > total) return drop("frame $frameId: chunk $index runs past the end")

        var cur = current
        if (cur == null || cur.frameId != frameId || index == 0) {
            if (cur != null) {
                dropped++
                onDrop("frame ${cur.frameId}: incomplete (${cur.received}/${cur.total} bytes) when frame $frameId started")
            }
            current = null
            if (index != 0 || offset != 0L) return drop("frame $frameId: first chunk missing (got chunk $index)")
            cur = Partial(
                frameId, total.toInt(), count, width, height, format, flags, ref,
                encodeMs, captureMillis, frameCrc, System.nanoTime(),
            )
            current = cur
        }

        if (index != cur.nextIndex || offset != cur.received.toLong() || total.toInt() != cur.total) {
            current = null
            return drop("frame $frameId: chunk $index out of order (expected ${cur.nextIndex})")
        }
        System.arraycopy(p, FRAME_CHUNK_HEADER_LEN, cur.data, cur.received, dataLen)
        cur.received += dataLen
        cur.nextIndex++

        val last = (flags and DishaProtocol.FLAG_LAST) != 0
        if (cur.received < cur.total) {
            if (last) {
                current = null
                return drop("frame $frameId: last chunk arrived with ${cur.received}/${cur.total} bytes")
            }
            return null
        }

        current = null
        if (DishaProtocol.crc32(cur.data, 0, cur.total) != cur.frameCrc) {
            crcFailures++
            return drop("frame $frameId: CRC-32 mismatch, frame discarded")
        }
        completed++
        val now = System.nanoTime()
        return Frame(
            frameId = cur.frameId,
            width = cur.width,
            height = cur.height,
            format = cur.format,
            flags = cur.flags,
            ref = cur.ref,
            data = cur.data,
            chunkCount = cur.chunkCount,
            encodeMs = cur.encodeMs,
            deviceCaptureMillis = cur.captureMillis,
            transferMs = (now - cur.startedNanos) / 1_000_000,
            completedAtNanos = now,
        )
    }

    private fun drop(reason: String): Frame? {
        dropped++
        onDrop(reason)
        return null
    }
}
