package com.disha.glassos.skills

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.disha.glassos.util.AppLog
import java.util.Locale

/**
 * Messages and calls seen through Android's notification access (granted by the user in the
 * phone's settings). Messages are kept in memory only, never written to storage. Replies use the
 * messaging app's own "Reply" button on the notification, as the user would from the shade.
 */
object MessageCenter {

    class Message(
        val key: String,
        val app: String,
        val conversation: String,
        val sender: String,
        val text: String,
        val time: Long,
        val reply: Notification.Action?,
    ) {
        var read = false
    }

    class IncomingCall(val caller: String, val answer: PendingIntent?, val decline: PendingIntent?, val time: Long)

    private const val MAX = 60
    private val messages = ArrayList<Message>()
    private val main = Handler(Looper.getMainLooper())

    /** Called (main thread) for each new message, so the assistant can announce it. */
    @Volatile var onNewMessage: ((Message) -> Unit)? = null
    @Volatile var call: IncomingCall? = null
        private set

    fun isAllowed(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
        val me = ComponentName(context, DishaNotificationListener::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    fun settingsIntent() = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @Synchronized
    fun unread(): List<Message> = messages.filter { !it.read }

    @Synchronized
    fun recent(n: Int): List<Message> = messages.takeLast(n)

    @Synchronized
    fun markRead(list: List<Message>) = list.forEach { it.read = true }

    @Synchronized
    fun conversations(): List<String> = messages.map { it.conversation }.distinct()

    /** Newest message that can be replied to, in [conversation] if given (loose name match). */
    @Synchronized
    fun replyTarget(conversation: String?): Message? {
        val withReply = messages.filter { it.reply != null }
        if (conversation.isNullOrBlank()) return withReply.lastOrNull()
        val c = conversation.lowercase(Locale.US)
        return withReply.lastOrNull { it.conversation.lowercase(Locale.US).contains(c) || c.contains(it.conversation.lowercase(Locale.US)) }
            ?: withReply.lastOrNull { it.sender.lowercase(Locale.US).contains(c) }
    }

    /** Sends [text] through the message's Reply action. */
    fun reply(context: Context, m: Message, text: String): Boolean {
        val action = m.reply ?: return false
        val inputs = action.remoteInputs ?: return false
        return try {
            val intent = Intent()
            val results = Bundle()
            for (ri in inputs) results.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, results)
            action.actionIntent.send(context, 0, intent)
            AppLog.i("Messages", "Replied in ${m.app} / ${m.conversation}")
            true
        } catch (e: Exception) {
            AppLog.e("Messages", "Reply failed: ${e.message}")
            false
        }
    }

    // ---- from the listener service ----

    internal fun posted(context: Context, sbn: StatusBarNotification) {
        if (sbn.packageName == context.packageName) return
        val n = sbn.notification
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val actions = n.actions ?: emptyArray()

        // Incoming call: the dialer's notification names the caller and has Answer / Decline buttons.
        if (n.category == Notification.CATEGORY_CALL) {
            fun find(vararg words: String) = actions.firstOrNull { a -> words.any { a.title?.toString()?.contains(it, ignoreCase = true) == true } }?.actionIntent
            call = IncomingCall(title.ifBlank { "an unknown caller" }, find("answer", "accept"), find("decline", "reject", "hang up", "end"), System.currentTimeMillis())
            return
        }
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val reply = actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        if (n.category != Notification.CATEGORY_MESSAGE && reply == null) return

        val app = appLabel(context, sbn.packageName)
        val conversation = (if (Build.VERSION.SDK_INT >= 24) extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString() else null)
            ?: title
        // Newest line of a messaging-style notification, else its text.
        var sender = title
        var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (Build.VERSION.SDK_INT >= 24) {
            @Suppress("DEPRECATION")
            val arr = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null && arr.isNotEmpty()) {
                val last = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr).lastOrNull()
                if (last != null) {
                    text = last.text?.toString().orEmpty()
                    sender = (if (Build.VERSION.SDK_INT >= 28) last.senderPerson?.name?.toString() else null)
                        ?: @Suppress("DEPRECATION") last.sender?.toString() ?: title
                }
            }
        }
        if (text.isBlank()) return
        val m = Message(sbn.key, app, conversation.ifBlank { sender }, sender.ifBlank { conversation }, text, System.currentTimeMillis(), reply)
        synchronized(this) {
            // The same notification is re-posted as messages arrive: keep only new text.
            if (messages.any { it.key == m.key && it.text == m.text }) return
            messages.add(m)
            while (messages.size > MAX) messages.removeAt(0)
        }
        main.post { onNewMessage?.invoke(m) }
    }

    internal fun removed(sbn: StatusBarNotification) {
        if (sbn.notification.category == Notification.CATEGORY_CALL) call = null
    }

    private fun appLabel(context: Context, pkg: String): String = when {
        pkg.startsWith("com.whatsapp") -> "WhatsApp"
        pkg == "org.telegram.messenger" -> "Telegram"
        pkg == "com.instagram.android" -> "Instagram"
        pkg == "com.facebook.orca" -> "Messenger"
        pkg == "org.thoughtcrime.securesms" -> "Signal"
        else -> try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            "Messages"
        }
    }
}

/** Receives notifications once the user allowed DISHA in "Notification access". */
class DishaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            MessageCenter.posted(this, sbn)
        } catch (e: Exception) {
            AppLog.w("Messages", "Skipped a notification: ${e.message}")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) = MessageCenter.removed(sbn)
}
