package com.disha.glassos.usb

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbRequest
import android.os.Build
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Raw byte pipe over the selected bulk endpoints.
 *
 * Reading uses several queued asynchronous UsbRequests on a dedicated thread instead of
 * bulkTransfer() with a timeout: on Linux/Android a synchronous bulk read that times out
 * discards the bytes it had already received, which would corrupt frames. Queued requests
 * have no timeout, so nothing is lost; close() cancels them to stop the thread.
 * Writes are small commands sent with bulkTransfer() from the caller's thread.
 */
class UsbLinkConnection private constructor(
    private val connection: UsbDeviceConnection,
    val selection: UsbDeviceInspector.LinkSelection,
    private val listener: Listener,
) {
    interface Listener {
        /** Called on the reader thread; data is reused after the call returns. */
        fun onBytes(data: ByteArray, len: Int)

        /** Called once when the reader stops. error is null after close(). */
        fun onReaderStopped(error: String?)
    }

    private val running = AtomicBoolean(true)
    private val requests = CopyOnWriteArrayList<UsbRequest>()
    private val writeLock = Any()
    private lateinit var reader: Thread

    val bytesIn = AtomicLong()
    val bytesOut = AtomicLong()

    companion object {
        private const val READ_REQUESTS = 4
        private const val READ_SIZE = 16384  // per-request limit on Android < 9
        private const val WRITE_TIMEOUT_MS = 1000

        @Throws(IOException::class)
        fun open(manager: UsbManager, selection: UsbDeviceInspector.LinkSelection, listener: Listener): UsbLinkConnection {
            val conn = manager.openDevice(selection.device)
                ?: throw IOException("openDevice failed (USB permission missing, or the device is in use)")
            // force = true detaches a kernel driver (e.g. cdc_acm) if one has claimed the interface
            if (!conn.claimInterface(selection.iface, true)) {
                conn.close()
                throw IOException("could not claim USB interface ${selection.iface.id}")
            }
            return UsbLinkConnection(conn, selection, listener).also { it.startReader() }
        }
    }

    private fun startReader() {
        reader = Thread({ readLoop() }, "disha-usb-reader").apply {
            isDaemon = true
            start()
        }
    }

    @Suppress("DEPRECATION")
    private fun queue(r: UsbRequest, b: ByteBuffer): Boolean =
        if (Build.VERSION.SDK_INT >= 26) r.queue(b) else r.queue(b, b.capacity())

    private fun readLoop() {
        val buffers = ArrayList<ByteBuffer>()
        val copy = ByteArray(READ_SIZE)
        var error: String? = null
        try {
            for (i in 0 until READ_REQUESTS) {
                val r = UsbRequest()
                if (!r.initialize(connection, selection.epIn)) throw IOException("UsbRequest.initialize failed")
                val b = ByteBuffer.allocateDirect(READ_SIZE)
                r.clientData = i
                requests.add(r)
                buffers.add(b)
                if (!queue(r, b)) throw IOException("UsbRequest.queue failed")
            }
            while (running.get()) {
                val done = connection.requestWait()
                if (done == null) {
                    if (running.get()) error = "USB read failed (device removed?)"
                    break
                }
                val index = done.clientData as? Int ?: continue
                val b = buffers[index]
                val n = b.position()
                if (n > 0 && running.get()) {
                    b.flip()
                    b.get(copy, 0, n)
                    bytesIn.addAndGet(n.toLong())
                    listener.onBytes(copy, n)
                }
                b.clear()
                if (running.get() && !queue(done, b)) {
                    error = "USB read could not be re-queued"
                    break
                }
            }
        } catch (t: Throwable) {
            if (running.get()) error = t.message ?: t.toString()
        } finally {
            running.set(false)
            for (r in requests) {
                try {
                    r.cancel()
                } catch (_: Throwable) {
                }
            }
            listener.onReaderStopped(error)
        }
    }

    @Throws(IOException::class)
    fun write(data: ByteArray) {
        synchronized(writeLock) {
            var off = 0
            while (off < data.size) {
                if (!running.get()) throw IOException("USB link closed")
                val n = minOf(data.size - off, 16384)
                val w = connection.bulkTransfer(selection.epOut, data, off, n, WRITE_TIMEOUT_MS)
                if (w <= 0) throw IOException("USB write failed (bulkTransfer returned $w)")
                off += w
            }
            bytesOut.addAndGet(data.size.toLong())
        }
    }

    /** Stops the reader and releases the device. Safe to call more than once, from any thread. */
    fun close() {
        val wasRunning = running.getAndSet(false)
        for (r in requests) {
            try {
                r.cancel()  // wakes requestWait() in the reader thread
            } catch (_: Throwable) {
            }
        }
        if (wasRunning && ::reader.isInitialized && Thread.currentThread() !== reader) {
            try {
                reader.join(700)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        synchronized(this) {
            if (closed) return
            closed = true
        }
        try {
            connection.releaseInterface(selection.iface)
        } catch (_: Throwable) {
        }
        try {
            connection.close()
        } catch (_: Throwable) {
        }
        // Free the native requests only once the reader can no longer be inside requestWait().
        if (!::reader.isInitialized || !reader.isAlive) {
            for (r in requests) {
                try {
                    r.close()
                } catch (_: Throwable) {
                }
            }
            requests.clear()
        }
    }

    private var closed = false
}
