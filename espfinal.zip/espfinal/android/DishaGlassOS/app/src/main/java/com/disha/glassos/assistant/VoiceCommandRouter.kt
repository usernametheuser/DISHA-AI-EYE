package com.disha.glassos.assistant

import com.disha.glassos.skills.ReplyParse
import java.util.Locale

/** Maps a recognised sentence to a command. Commands that need no AI run on the phone. */
object VoiceCommandRouter {

    enum class Command {
        DESCRIBE_SCENE,
        READ_TEXT,
        TAKE_PHOTO,
        START_RECORDING,
        STOP_RECORDING,
        CAMERA_STATUS,
        STORAGE_STATUS,
        STOP_SPEAKING,
        DISCONNECT_CAMERA,
        CONNECT_CAMERA,
        START_STREAM,
        STOP_STREAM,
        TIME,
        DATE,
        BATTERY,
        DISMISS,
        HELP,
        TIMER,
        REMINDER,
        CANCEL_TIMERS,
        LIST_TIMERS,
        WEATHER,
        NEWS,
        BRIEFING,
        FLASHLIGHT_ON,
        FLASHLIGHT_OFF,
        VOLUME_UP,
        VOLUME_DOWN,
        MUTE,
        MEDIA_PLAY,
        MEDIA_PAUSE,
        MEDIA_NEXT,
        MEDIA_PREVIOUS,
        REMEMBER,
        RECALL,
        FORGET,
        STOP_TASKS,
        OBSERVE,
        SOS,
        CALL_WHO,
        CALL_ANSWER,
        CALL_REJECT,
        READ_MESSAGES,
        REPLY_MESSAGE,
        GUIDE_START,
        GUIDE_STOP,
        NOTES_START,
        NOTES_STOP,
        MEMORY_LOG_ON,
        MEMORY_LOG_OFF,
        DIARY,
        FIND_OBJECT,
        GALLERY_SEARCH,
        TRANSLATE,
        FOOD,
        CURRENCY,
        SCAN_DOC,
        DOC_SUMMARY,
        DOC_READ,
        // 0.12
        DOC_START,
        DOC_DONE,
        REPLAY_SAVE,
        REPLAY_ON,
        REPLAY_OFF,
        NAVIGATE,
        NAV_STOP,
        NAV_STATUS,
        CAPTIONS_START,
        TRANSLATOR_START,
        CAPTIONS_STOP,
        QR_SCAN,
        CARD_SCAN,
        SLIDE_NEXT,
        SLIDE_PREVIOUS,
        SLIDE_GOTO,
        SLIDE_START,
        SLIDE_END,
        SLIDE_BLACK,
        PRESENT_ON,
        PRESENT_OFF,
        UNKNOWN,
    }

    private val nonWord = Regex("[^a-z0-9' ]")
    private val spaces = Regex("\\s+")

    /** How speech recognition may write the name "Disha" (including the Hindi spelling). */
    val NAME_VARIANTS = listOf("Disha", "Diha", "Deesha", "Dishaa", "Disa", "Desha", "Deeha", "Disha's", "दिशा")

    /**
     * Removes a leading wake phrase such as "Hello Disha," "Hi Disha" or "OK Disha" (names = the
     * assistant's names). Returns what is left, which is empty if only the name was said.
     */
    fun stripName(sentence: String, names: List<String>): String {
        val alternatives = names.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("|") { Regex.escape(it) }
        if (alternatives.isEmpty()) return sentence.trim()
        val wake = Regex(
            "^\\s*(?:(?:hey|hi|hii|hai|hello|helo|hallo|ok|okay|yo|namaste)[\\s,]+)?(?:$alternatives)(?![\\p{L}\\p{N}\\p{M}])[\\s,.!?:;।-]*",
            RegexOption.IGNORE_CASE,
        )
        return sentence.replaceFirst(wake, "").trim()
    }

    private fun words(sentence: String) =
        " " + sentence.lowercase(Locale.US).replace(nonWord, " ").replace(spaces, " ").trim() + " "

    fun parse(sentence: String): Command {
        val s = words(sentence)
        fun has(vararg phrases: String) = phrases.any { s.contains(" $it ") }
        fun starts(vararg phrases: String) = phrases.any { s.startsWith(" $it ") }
        val count = s.trim().split(' ').count { it.isNotEmpty() }
        val question = starts("do", "did", "what", "where", "when", "who", "how", "which", "can", "could", "is", "are")

        // Order matters: specific phrases before general words ("stop recording" before "stop").
        return when {
            count <= 4 && has("thank you", "thanks", "that's all", "that is all", "bye", "goodbye", "good bye",
                "never mind", "nevermind", "no thanks", "nothing", "that's it", "that is it") -> Command.DISMISS
            // ---- safety first: "help" on its own is an emergency (the assistant counts down before sending) ----
            (count <= 3 && has("help", "help me", "sos", "emergency", "bachao", "madad")) ||
                has("i need help", "call for help", "send help", "please help me", "someone help me", "i'm in danger",
                    "im in danger", "i am in danger", "i've fallen", "i have fallen", "i fell down") -> Command.SOS
            // ---- calls (answer / reject only mean something while the phone rings; the assistant checks) ----
            has("who's calling", "who is calling", "who's that calling", "who is on the phone", "who's ringing", "who is ringing") -> Command.CALL_WHO
            count <= 4 && has("answer", "answer it", "answer the call", "pick up", "pick it up", "accept the call", "take the call",
                "accept") -> Command.CALL_ANSWER
            count <= 4 && has("reject", "reject it", "reject the call", "decline", "decline the call", "cut the call", "cut it",
                "hang up", "end the call") -> Command.CALL_REJECT
            // ---- messages ----
            ReplyParse.parse(sentence, emptyList()) != null -> Command.REPLY_MESSAGE
            has("read my messages", "read messages", "read my whatsapp", "my messages", "new messages", "any messages",
                "whatsapp messages", "who messaged", "who texted", "did anyone message", "did anyone text", "check my messages",
                "read the message", "read the messages", "unread messages", "any whatsapp") -> Command.READ_MESSAGES
            // ---- presenting: the web view for a laptop, and slides ----
            has("stop presentation mode", "presentation mode off", "stop the dashboard", "web view off", "stop web view",
                "stop sharing to the laptop", "stop demo mode") -> Command.PRESENT_OFF
            has("presentation mode", "start the dashboard", "web view", "show on the laptop", "show it on the laptop",
                "share to the laptop", "demo mode", "judge mode", "web dashboard") -> Command.PRESENT_ON
            has("next slide", "next ppt", "change slide", "change the slide", "change ppt", "change the ppt", "slide change",
                "advance the slide", "next one please", "agla slide", "aage badho", "move to the next slide", "go to the next slide",
                "forward slide") -> Command.SLIDE_NEXT
            has("previous slide", "previous ppt", "last slide", "go back a slide", "back one slide", "pichla slide",
                "slide back", "go to the previous slide", "one slide back") -> Command.SLIDE_PREVIOUS
            slideNumber(sentence) != null -> Command.SLIDE_GOTO
            has("start the presentation", "start presentation", "start the slideshow", "start slideshow", "begin the presentation",
                "begin presentation", "start the slides", "present the slides") -> Command.SLIDE_START
            has("end the presentation", "stop the presentation", "end presentation", "end slideshow", "end the slideshow",
                "exit slideshow", "exit the slideshow", "stop slideshow", "stop the slideshow", "close the presentation") -> Command.SLIDE_END
            has("black screen", "blank the screen", "blank screen", "black out the screen") -> Command.SLIDE_BLACK
            // ---- documents: several pages into one PDF ----
            has("done making pdf", "done making the pdf", "make the pdf", "save the pdf", "create the pdf", "finish the document",
                "save the document", "finish the pdf", "that's all the pages", "that is all the pages", "pdf banao") -> Command.DOC_DONE
            has("make a document", "make document", "make a pdf", "make pdf", "create a document", "create a pdf", "start a document",
                "new document", "scan pages", "scan multiple pages", "scan many pages", "scan a book", "scan the book",
                "document mode", "make a doc", "scan into a pdf", "turn pages into a pdf") -> Command.DOC_START
            // ---- instant replay ----
            has("save that", "save this moment", "clip that", "clip this", "save what just happened", "save the last",
                "save the replay", "keep that", "record what just happened", "replay save") -> Command.REPLAY_SAVE
            has("stop instant replay", "instant replay off", "turn off instant replay", "stop the replay", "replay off") -> Command.REPLAY_OFF
            has("instant replay", "start replay", "replay mode", "keep the last 30 seconds", "replay on") -> Command.REPLAY_ON
            // ---- walking directions ----
            has("stop navigation", "stop navigating", "cancel navigation", "cancel the route", "end navigation", "stop the route",
                "stop directions", "stop the directions", "navigation off") -> Command.NAV_STOP
            navDestination(sentence) != null -> Command.NAVIGATE
            has("where now", "next turn", "where do i turn", "how much further", "how far is it", "how far now",
                "are we there yet", "which way now", "how far to go", "repeat the direction", "repeat directions") -> Command.NAV_STATUS
            // ---- live captions and translator ----
            has("stop captions", "captions off", "stop the captions", "stop subtitles", "subtitles off", "stop translating",
                "stop the translation", "stop translation", "stop the translator", "translator off", "stop interpreting",
                "stop live translation") -> Command.CAPTIONS_STOP
            has("be my translator", "translate the conversation", "translate this conversation", "translator mode",
                "interpret for me", "live translation", "translate what they say", "translate what he says", "translate what she says",
                "translate for me", "conversation mode translate", "two way translation", "translate between") -> Command.TRANSLATOR_START
            has("live captions", "start captions", "show captions", "captions on", "turn on captions", "caption this",
                "subtitles on", "show subtitles", "write what they say", "write what people say", "hearing mode") -> Command.CAPTIONS_START
            // ---- codes and cards ----
            has("business card", "visiting card", "scan this card", "scan the card", "save this contact", "add this contact",
                "read this card", "read the card") -> Command.CARD_SCAN
            has("qr code", "qr", "scan the code", "scan this code", "read the code", "read this code", "upi code", "scanner",
                "scan code") -> Command.QR_SCAN
            // ---- modes and long tasks ----
            has("stop guiding", "stop guide", "stop the guide", "guide mode off", "stop guide mode", "stop being my eyes",
                "stop walking mode") -> Command.GUIDE_STOP
            has("guide me", "guide mode", "start guiding", "help me walk", "be my eyes", "blind mode", "assist mode",
                "describe my surroundings", "walking mode") -> Command.GUIDE_START
            has("stop taking notes", "stop notes", "stop the notes", "stop transcribing", "meeting is over", "lecture is over",
                "stop recording the meeting", "stop recording the lecture", "end the notes", "finish the notes") -> Command.NOTES_STOP
            has("take notes", "start taking notes", "record the meeting", "record this meeting", "record the lecture",
                "record this lecture", "start notes", "meeting notes", "lecture notes", "transcribe this meeting",
                "transcribe the meeting", "start transcribing", "note down the meeting") -> Command.NOTES_START
            has("stop remembering", "turn off visual memory", "stop visual memory", "stop tracking my things") -> Command.MEMORY_LOG_OFF
            has("remember what i see", "start remembering", "turn on visual memory", "start visual memory",
                "keep track of my things", "remember where i put things") -> Command.MEMORY_LOG_ON
            // ---- what happened ----
            has("what did i do today", "what did i do yesterday", "what did i do this", "what have i done today", "diary",
                "summarise my day", "summarize my day", "recap my day", "how was my day", "my day today") -> Command.DIARY
            has("where did i leave", "where did i put", "where are my", "where is my", "have you seen my", "where did i keep",
                "did you see my", "when did i last see", "where i left my", "where i put my", "find my") -> Command.FIND_OBJECT
            has("show", "find", "search", "open") && has("photo", "photos", "picture", "pictures", "pics", "pic", "gallery") ->
                Command.GALLERY_SEARCH
            // ---- seeing ----
            has("translate", "translation", "in english please", "what does this say in", "what does it say in",
                "meaning of this sign") -> Command.TRANSLATE
            has("is this healthy", "is it healthy", "is that healthy", "healthy to eat", "scan the barcode", "scan barcode",
                "scan this barcode", "read the barcode", "barcode", "check this food", "food label", "is this vegetarian",
                "is it vegetarian") ||
                (has("nutrition", "calories in", "how many calories", "allergens", "allergen", "ingredients", "how much sugar") &&
                    has("this", "that", "it", "these")) -> Command.FOOD
            has("which note", "what note", "currency", "how much money", "count the money", "count this money", "which coin",
                "rupee note", "rupees is this", "how many rupees", "what denomination", "kitne rupaye", "kitne ka note") -> Command.CURRENCY
            has("scan this", "scan the page", "scan this page", "scan the document", "scan document", "scan this document",
                "scan a page", "scan page", "scan the paper", "scan this paper") -> Command.SCAN_DOC
            has("summarise", "summarize", "summary", "sum it up", "key points") && !has("day", "news", "headlines", "weather") ->
                Command.DOC_SUMMARY
            has("read it back", "read the document", "read the scan", "read back the page", "read me the document",
                "read the notes back") -> Command.DOC_READ
            !question && starts("remember", "note that", "make a note", "please remember", "save a note") -> Command.REMEMBER
            starts("forget", "please forget") -> Command.FORGET
            has("what do you remember", "what did i ask you to remember", "what did i tell you to remember",
                "what's in your memory", "what is in your memory", "read my notes", "what are my notes") -> Command.RECALL
            has("stop watching", "stop looking", "stop the watch", "cancel the watch", "stop tasks", "stop the tasks",
                "cancel tasks", "stop all tasks", "stop the photos", "stop taking photos", "stop the series",
                "stop the photo series", "stop background tasks") -> Command.STOP_TASKS
            has("watch this", "watch that", "look at this", "observe", "keep watching", "watch for") &&
                TimeParse.durationSeconds(sentence) != null &&
                !has("tell me when", "let me know when", "alert me", "keep an eye", "if you see", "when you see") -> Command.OBSERVE
            has("remind me") && TimeParse.reminder(sentence, 0) != null -> Command.REMINDER
            has("timer", "timers", "reminder", "reminders") && has("cancel", "stop", "delete", "clear", "remove") ->
                Command.CANCEL_TIMERS
            has("timer", "alarm for") && TimeParse.durationSeconds(sentence) != null -> Command.TIMER
            has("timer", "timers", "reminder", "reminders") &&
                has("how much time", "time left", "what", "any", "list", "my", "how long") -> Command.LIST_TIMERS
            has("brief me", "briefing", "good morning", "status report", "catch me up", "what's my day",
                "what is my day", "update me") -> Command.BRIEFING
            has("weather", "forecast", "temperature outside", "how hot is it", "how cold is it", "is it going to rain",
                "will it rain", "is it raining") -> Command.WEATHER
            has("news", "headlines") && !has("this", "that") -> Command.NEWS
            has("flashlight", "flash light", "torch") -> if (has("off")) Command.FLASHLIGHT_OFF else Command.FLASHLIGHT_ON
            has("unmute") -> Command.VOLUME_UP
            has("volume up", "louder", "increase the volume", "raise the volume", "turn it up", "turn up the volume",
                "volume higher") -> Command.VOLUME_UP
            has("volume down", "quieter", "softer", "decrease the volume", "lower the volume", "turn it down",
                "turn down the volume", "volume lower") -> Command.VOLUME_DOWN
            has("mute") -> Command.MUTE
            has("next song", "next track", "skip song", "skip this song", "skip the song", "skip track") -> Command.MEDIA_NEXT
            has("previous song", "previous track", "last song", "go back a song") -> Command.MEDIA_PREVIOUS
            has("pause music", "pause the music", "stop music", "stop the music", "pause the song", "pause song",
                "pause playback") -> Command.MEDIA_PAUSE
            has("play music", "play the music", "resume music", "resume the music", "resume playback", "play my music",
                "continue the music") -> Command.MEDIA_PLAY
            has("stop recording", "end recording", "stop the recording") -> Command.STOP_RECORDING
            has("start recording", "begin recording", "record video", "record a video", "start video") -> Command.START_RECORDING
            has("record", "film", "shoot") && has("video", "clip", "seconds", "minutes", "minute") -> Command.START_RECORDING
            has("stop stream", "stop streaming", "stop the stream", "stop preview", "stop the preview", "stop live") -> Command.STOP_STREAM
            has("start stream", "start streaming", "start the stream", "start preview", "live view", "show camera",
                "show the camera", "show me the camera") -> Command.START_STREAM
            has("disconnect camera", "disconnect the camera", "disconnect") -> Command.DISCONNECT_CAMERA
            has("connect camera", "connect the camera", "reconnect", "reconnect camera") -> Command.CONNECT_CAMERA
            has("take a photo", "take photo", "take a picture", "take picture", "take a pic", "click a photo",
                "click photo", "click a picture", "click picture") -> Command.TAKE_PHOTO
            has("read this", "read the text", "read text", "read it", "read that", "what does it say",
                "what does this say", "what is written", "what's written", "read") -> Command.READ_TEXT
            has("what am i looking at", "describe", "what do you see", "what can you see", "what is this",
                "what's this", "what is that", "what's that", "what is in front", "what's in front",
                "look at this") -> Command.DESCRIBE_SCENE
            has("storage", "space left", "free space", "how much space", "memory card", "sd card", "card space") ->
                Command.STORAGE_STATUS
            has("capture", "snap", "photo", "picture") -> Command.TAKE_PHOTO
            has("battery level", "battery left", "how much battery", "my battery", "phone battery", "battery percentage",
                "battery status", "charge left", "how much charge") -> Command.BATTERY
            has("status", "camera working", "is the camera", "how is the camera") -> Command.CAMERA_STATUS
            has("stop speaking", "stop talking", "be quiet", "shut up", "quiet", "silence", "stop") -> Command.STOP_SPEAKING
            has("what time", "time is it", "the time") -> Command.TIME
            has("what's the date", "what is the date", "today's date", "the date", "what day is it", "what day is today",
                "which day is it", "which day is today", "date today") -> Command.DATE
            has("what can you do", "commands", "how do i use you", "what can i say", "your features", "what are your features") -> Command.HELP
            else -> Command.UNKNOWN
        }
    }

    /** "take me to the metro station" -> "metro station"; null if it isn't a request for directions. */
    fun navDestination(sentence: String): String? {
        val m = Regex(
            "(?i)\\b(?:take me|navigate|navigation|directions|direction|route|guide me|walk me|get me|lead me|show me the way|" +
                "how do i get|how can i get|how to get|how do i go)\\s+(?:to|towards|till|for|until)\\s+(?:the\\s+|a\\s+|an\\s+)?(.+?)[?.!]*$",
        ).find(sentence.trim()) ?: return null
        val place = m.groupValues[1].trim().replace(Regex("(?i)^(?:nearest|closest)\\s+"), "nearest ")
        return place.takeIf { it.isNotEmpty() && it.length <= 80 }
    }

    private val NUMBER_WORDS = listOf(
        "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen",
        "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty",
    )

    /** "go to slide 5", "slide number twelve" -> 5 / 12; null otherwise. */
    fun slideNumber(sentence: String): Int? {
        val m = Regex("(?i)\\b(?:go to|jump to|open|show|move to|switch to)?\\s*slide\\s+(?:number\\s+|no\\.?\\s*)?([a-z]+|\\d{1,3})\\b")
            .find(sentence) ?: return null
        val token = m.groupValues[1].lowercase(Locale.US)
        val n = token.toIntOrNull() ?: (NUMBER_WORDS.indexOf(token) + 1).takeIf { it > 0 } ?: return null
        val s = words(sentence)
        // "slide 3" alone, or with a verb; not "the slide three times" etc.
        return n.takeIf { it in 1..500 && (Regex("(?i)\\b(go to|jump to|open|show|move to|switch to|number)\\b").containsMatchIn(sentence) || s.trim().split(' ').size <= 3) }
    }

    /** A spoken yes, for confirming an action ("send it", "haan"). */
    fun isYes(sentence: String): Boolean {
        val s = words(sentence)
        val count = s.trim().split(' ').size
        return count <= 6 && !isNo(sentence) && listOf("yes", "yeah", "yep", "yup", "sure", "ok", "okay", "send", "send it", "do it",
            "go ahead", "confirm", "correct", "please do", "haan", "han", "ha", "theek hai", "bhej do").any { s.contains(" $it ") }
    }

    /** A spoken no / cancel. */
    fun isNo(sentence: String): Boolean {
        val s = words(sentence)
        val count = s.trim().split(' ').size
        return count <= 6 && listOf("no", "nope", "cancel", "don't", "do not", "stop", "never mind", "nahi", "nahin", "mat",
            "false alarm", "wait", "abort").any { s.contains(" $it ") }
    }

    /** "take a photo and start recording", "torch on, then a 2 minute timer": more than one request. */
    fun hasSeveralParts(sentence: String): Boolean {
        val s = words(sentence)
        return Regex(" (and|also|then|plus|after that) ").containsMatchIn(s) && s.trim().split(' ').size >= 5
    }

    /** "remember that my car is on B2" -> "my car is on B2" (original capitalisation). */
    fun rememberText(sentence: String): String =
        sentence.trim().replaceFirst(
            Regex("(?i)^(?:please\\s+)?(?:remember(?:\\s+that)?|note\\s+that|make\\s+a\\s+note(?:\\s+that)?|save\\s+a\\s+note(?:\\s+that)?)[\\s,:]*"),
            "",
        ).trim().trimEnd('.', '!')

    /** "forget about my parking spot" -> "my parking spot". */
    fun forgetText(sentence: String): String =
        sentence.trim().replaceFirst(Regex("(?i)^(?:please\\s+)?forget(?:\\s+(?:that|about|the fact that))?[\\s,:]*"), "")
            .trim().trimEnd('.', '!', '?')

    /** City named in a weather question ("weather in New Delhi tomorrow" -> "New Delhi"), or null. */
    fun weatherCity(sentence: String): String? {
        val m = Regex("(?i)\\b(?:in|at|for)\\s+([\\p{L}][\\p{L} .'-]*?)\\s*(?:\\b(?:today|tomorrow|now|right now|this week|tonight|this evening)\\b.*)?[?.!]*$")
            .find(sentence.trim()) ?: return null
        val city = m.groupValues[1].trim()
        val low = city.lowercase(Locale.US)
        if (low.isEmpty() || low in setOf("the", "here", "the morning", "the evening", "the afternoon", "the night")) return null
        return city.split(' ').joinToString(" ") { w -> w.replaceFirstChar { it.titlecase(Locale.US) } }
    }

    /** "news about cricket" -> "cricket"; null for general headlines. */
    fun newsTopic(sentence: String): String? =
        Regex("(?i)\\b(?:news|headlines)\\s+(?:about|on|regarding|for|from)\\s+(.+?)[?.!]*$").find(sentence.trim())
            ?.groupValues?.get(1)?.trim()?.ifEmpty { null }

    /**
     * For a free-form question (UNKNOWN command) sent to the AI: does it refer to what the user is
     * looking at? Then a fresh camera image goes with it.
     */
    fun looksVisual(sentence: String): Boolean {
        val s = words(sentence)
        val cues = listOf(
            "this", "that", "these", "those", "here", "see", "look", "looking", "in front", "around me", "color",
            "colour", "read", "written", "sign", "label", "price", "screen", "who is", "how many", "count",
            "which", "where is", "identify", "recognize", "recognise", "what kind", "what type", "is it", "is there",
            "ye", "yeh", "kya hai", "dekho", "saamne", "samne",
            "analyse", "analyze", "examine", "inspect", "scan", "check this", "you see", "can you see", "in my hand",
        )
        return cues.any { s.contains(" $it ") }
    }
}
