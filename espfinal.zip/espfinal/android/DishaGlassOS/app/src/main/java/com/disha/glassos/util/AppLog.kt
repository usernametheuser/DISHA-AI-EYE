package com.disha.glassos.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** In-app debug log (also mirrored to logcat under the tag "Disha"). Thread-safe. */
object AppLog {
    private const val MAX_LINES = 400
    private val lines = ArrayDeque<String>()
    private val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Volatile
    private var listener: (() -> Unit)? = null

    fun i(tag: String, msg: String) = add('I', tag, msg)
    fun w(tag: String, msg: String) = add('W', tag, msg)
    fun e(tag: String, msg: String) = add('E', tag, msg)

    fun setListener(l: (() -> Unit)?) {
        listener = l
    }

    fun snapshot(maxLines: Int = MAX_LINES): String = synchronized(this) {
        lines.toList().takeLast(maxLines).joinToString("\n")
    }

    fun clear() {
        synchronized(this) { lines.clear() }
        listener?.invoke()
    }

    private fun add(level: Char, tag: String, msg: String) {
        when (level) {
            'E' -> Log.e("Disha", "$tag: $msg")
            'W' -> Log.w("Disha", "$tag: $msg")
            else -> Log.i("Disha", "$tag: $msg")
        }
        synchronized(this) {
            lines.addLast("${time.format(Date())} $level/$tag: $msg")
            while (lines.size > MAX_LINES) lines.removeFirst()
        }
        listener?.invoke()
    }
}
