package com.disha.glassos.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Speech features for matching a spoken phrase: MFCCs (mel-frequency cepstral coefficients) of
 * 16 kHz mono audio, 25 ms windows every 10 ms. Only 100-3800 Hz is used, so phone-mic and
 * Bluetooth-headset (narrow-band) recordings look alike. Pure logic, unit-tested on the PC.
 */
object Mfcc {
    const val RATE = 16000
    const val WINDOW = 400   // 25 ms
    const val HOP = 160      // 10 ms
    private const val NFFT = 512
    private const val MELS = 24
    const val DIMS = 12      // c1..c12 (c0, the loudness, is left out)

    private val hamming = FloatArray(WINDOW) { (0.54 - 0.46 * cos(2 * PI * it / (WINDOW - 1))).toFloat() }
    private val filters: Array<FloatArray> = melFilters(100.0, 3800.0)
    private val dct = Array(DIMS) { k -> FloatArray(MELS) { m -> cos(PI * (k + 1) * (m + 0.5) / MELS).toFloat() } }

    /**
     * Mel energies below this many dB under the segment's loudest band are raised to it: quiet
     * parts then look the same in a silent room and with background noise. 20 dB separated the
     * wake phrase from 20 other phrases best in tests from silence down to -22 dB noise.
     */
    private const val FLOOR_DB = 20.0

    /**
     * Feature frames of pcm[from, to). cmn: remove the mean of each coefficient (cancels mic
     * colouring, but also shifts with whatever else is said in the segment).
     */
    fun features(
        pcm: ShortArray,
        from: Int = 0,
        to: Int = pcm.size,
        cmn: Boolean = true,
        energy: Boolean = false,
        deltas: Float = 0f,
    ): Array<FloatArray> {
        val base = cepstra(pcm, from, to, cmn)
        val n = base.size
        val e = if (energy) energyContour(pcm, from, to, n) else null
        val dims = DIMS + (if (energy) 1 else 0)
        val withE = Array(n) { f -> FloatArray(dims) { k -> if (k < DIMS) base[f][k] else e!![f] } }
        if (deltas <= 0f) return withE
        // Deltas: slope over +-2 frames, i.e. how each coefficient is changing.
        return Array(n) { f ->
            FloatArray(dims * 2) { k ->
                if (k < dims) {
                    withE[f][k]
                } else {
                    val c = k - dims
                    var num = 0f
                    for (t in 1..2) num += t * (withE[minOf(n - 1, f + t)][c] - withE[maxOf(0, f - t)][c])
                    deltas * num / 10f
                }
            }
        }
    }

    /** Loudness of each frame in natural-log units, relative to the loudest (0 = loudest, floored). */
    private fun energyContour(pcm: ShortArray, from: Int, to: Int, n: Int): FloatArray {
        val e = FloatArray(n) { f ->
            var s = 0.0
            val start = from + f * HOP
            for (i in 0 until WINDOW) {
                val v = pcm[start + i].toDouble()
                s += v * v
            }
            ln(s / WINDOW + 1.0).toFloat()
        }
        val peak = e.maxOrNull() ?: 0f
        val floor = (FLOOR_DB / 10 * ln(10.0)).toFloat()
        for (i in e.indices) e[i] = maxOf(e[i] - peak, -floor)
        return e
    }

    private fun cepstra(pcm: ShortArray, from: Int, to: Int, cmn: Boolean): Array<FloatArray> {
        val n = if (to - from < WINDOW) 0 else 1 + (to - from - WINDOW) / HOP
        val out = Array(n) { FloatArray(DIMS) }
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        val mel = Array(n) { DoubleArray(MELS) }
        var peak = 1e-3
        for (f in 0 until n) {
            val start = from + f * HOP
            re.fill(0.0)
            im.fill(0.0)
            var prev = if (start > 0) pcm[start - 1].toDouble() else 0.0
            for (i in 0 until WINDOW) {
                val s = pcm[start + i].toDouble()
                re[i] = (s - 0.97 * prev) * hamming[i]  // pre-emphasis + window
                prev = s
            }
            fft(re, im)
            for (m in 0 until MELS) {
                var e = 0.0
                val w = filters[m]
                for (b in w.indices) if (w[b] != 0f) e += w[b] * (re[b] * re[b] + im[b] * im[b])
                mel[f][m] = e
                if (e > peak) peak = e
            }
        }
        val floor = ln(peak * Math.pow(10.0, -FLOOR_DB / 10))
        for (f in 0 until n) {
            for (k in 0 until DIMS) {
                var c = 0.0
                for (m in 0 until MELS) c += dct[k][m] * max(ln(max(mel[f][m], 1e-3)), floor)
                out[f][k] = c.toFloat()
            }
        }
        // Cepstral mean normalisation.
        if (cmn && n > 0) {
            for (k in 0 until DIMS) {
                var mean = 0f
                for (f in 0 until n) mean += out[f][k]
                mean /= n
                for (f in 0 until n) out[f][k] -= mean
            }
        }
        return out
    }

    /**
     * [from, to) of the part that is speech: the loud region, at most 35 dB below the loudest
     * 10 ms and clearly above the quietest (recordings carry silence before and after).
     */
    fun speechBounds(pcm: ShortArray, from: Int = 0, to: Int = pcm.size): IntArray {
        val frames = (to - from) / HOP
        if (frames <= 0) return intArrayOf(from, from)
        val db = DoubleArray(frames) { f ->
            var sum = 0.0
            for (i in 0 until HOP) {
                val s = pcm[from + f * HOP + i].toDouble()
                sum += s * s
            }
            10 * log10(sum / HOP + 1.0)
        }
        val peak = db.maxOrNull() ?: 0.0
        val floor = db.minOrNull() ?: 0.0
        val threshold = max(peak - 35.0, floor + 0.35 * (peak - floor))
        val first = db.indexOfFirst { it > threshold }
        val last = db.indexOfLast { it > threshold }
        if (first < 0) return intArrayOf(from, from)
        // Keep 30 ms on each side: soft consonants ("h" of "hello") sit below the threshold.
        val a = from + max(0, first - 3) * HOP
        val b = from + minOf(frames, last + 4) * HOP
        return intArrayOf(a, b)
    }

    private fun melFilters(lowHz: Double, highHz: Double): Array<FloatArray> {
        fun mel(f: Double) = 2595.0 * log10(1 + f / 700.0)
        fun hz(m: Double) = 700.0 * (Math.pow(10.0, m / 2595.0) - 1)
        val bins = NFFT / 2 + 1
        val points = DoubleArray(MELS + 2) { hz(mel(lowHz) + (mel(highHz) - mel(lowHz)) * it / (MELS + 1)) * NFFT / RATE }
        return Array(MELS) { m ->
            FloatArray(bins) { b ->
                val l = points[m]
                val c = points[m + 1]
                val r = points[m + 2]
                when {
                    b < l || b > r -> 0f
                    b <= c -> ((b - l) / (c - l)).toFloat()
                    else -> ((r - b) / (r - c)).toFloat()
                }
            }
        }
    }

    /** In-place radix-2 FFT. */
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr
                    im[i + k + len / 2] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Euclidean distance of two feature frames. */
    fun distance(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (k in a.indices) {
            val d = a[k] - b[k]
            s += d * d
        }
        return sqrt(s)
    }
}
