package com.disha.glassos.usb

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.disha.glassos.BuildConfig
import com.disha.glassos.camera.FrameDecoder
import com.disha.glassos.protocol.DishaProtocol
import com.disha.glassos.protocol.FrameAssembler
import com.disha.glassos.protocol.MessageParser
import com.disha.glassos.util.AppLog
import org.json.JSONException
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Owns the USB link to DISHA-CAM: discovery, permission, connection, handshake, keep-alive,
 * reconnection, commands and frame delivery. It has no UI code, so the camera link can be
 * tested and debugged on its own.
 *
 * Threads: all link state lives on one "control" thread; the USB reader thread parses bytes
 * and reassembles frames; a decoder thread turns JPEGs into Bitmaps; Listener callbacks run
 * on the main thread.
 */
class CameraLinkManager(context: Context, private val listener: Listener) {

    enum class State(val label: String, val connected: Boolean) {
        NO_USB_HOST("No USB host", false),
        DISCONNECTED("USB disconnected", false),
        WRONG_DEVICE("Wrong USB device", false),
        PERMISSION_NEEDED("USB permission needed", false),
        CONNECTING("Connecting", false),
        HANDSHAKING("USB connected", false),
        CAMERA_INITIALISING("Camera initialising", true),
        READY("Camera ready", true),
        STREAMING("Streaming", true),
        CAMERA_ERROR("Camera error", true),
        ERROR("Error", false),
    }

    class DeviceInfo(
        val usbDescription: String,
        val transport: UsbDeviceInspector.Transport?,
        val hello: JSONObject?,
    )

    class ReceivedFrame(
        val frame: FrameAssembler.Frame,
        val bitmap: Bitmap,
        val decodeMs: Long,
        val requestLatencyMs: Long?,
    )

    class CommandResult(val ref: Int, val command: Int, val status: Int, val message: String) {
        val ok: Boolean get() = status == DishaProtocol.OK
    }

    class LinkStats(
        val bytesIn: Long,
        val bytesOut: Long,
        val messages: Long,
        val headerCrcErrors: Long,
        val payloadCrcErrors: Long,
        val skippedBytes: Long,
        val framesCompleted: Long,
        val framesDropped: Long,
        val frameCrcFailures: Long,
        val decodeFailures: Long,
        val rttMs: Long,
    )

    /** All callbacks run on the main thread. */
    interface Listener {
        fun onLinkState(state: State, detail: String)
        fun onDeviceInfo(info: DeviceInfo)
        fun onFrame(frame: ReceivedFrame)
        fun onDeviceStatus(status: JSONObject)
        fun onCommandResult(result: CommandResult)
        fun onStats(stats: LinkStats)
        fun onStorageStatus(storage: JSONObject)
    }

    /** Answer to a request (main thread): a RESULT, a requested frame, or a JSON document. */
    class Reply(
        val status: Int,
        val message: String,
        val frame: FrameAssembler.Frame? = null,
        val json: JSONObject? = null,
    ) {
        val ok: Boolean get() = status == DishaProtocol.OK
    }

    companion object {
        private const val TAG = "USB"
        private const val ACTION_USB_PERMISSION = "com.disha.glassos.USB_PERMISSION"
        private const val HANDSHAKE_TIMEOUT_MS = 1500L
        private const val HANDSHAKE_ATTEMPTS = 4
        private const val TICK_MS = 1000L
        private const val LINK_SILENCE_MS = 4000L
        private const val ATTACH_SETTLE_MS = 1200L
        private const val MAX_RECONNECT_ATTEMPTS = 6
        private const val STREAM_STALL_MS = 4000L       // live view on, but no frame this long -> repair
        private const val STREAM_GRACE_MS = 3000L       // after (re)starting the stream, wait this long
        private const val STREAM_RESTARTS_BEFORE_RECONNECT = 2
    }

    private class Pending(
        val command: Int,
        val sentNanos: Long,
        val timeoutMs: Long,
        val onReply: ((Reply) -> Unit)? = null,
    )

    private inner class Session(val gen: Int, val selection: UsbDeviceInspector.LinkSelection) {
        lateinit var conn: UsbLinkConnection
        val assembler = FrameAssembler(onDrop = { reason -> runOnControl { onFrameDropped(this, reason) } })
        val parser = MessageParser { msg -> onMessageFromReader(this, msg) }
    }

    private val appContext = context.applicationContext
    private val usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager
    private val main = Handler(Looper.getMainLooper())
    private val control: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "disha-usb-control").apply { isDaemon = true }
    }
    private val decoder = Executors.newSingleThreadExecutor { r ->
        Thread(r, "disha-decode").apply { isDaemon = true }
    }

    // ---- control-thread state ----
    private var session: Session? = null
    private var generation = 0
    private var state = State.DISCONNECTED
    private var seq = 0
    private var helloSeq = -1
    private var helloAttempts = 0
    private var hello: JSONObject? = null
    private val pending = HashMap<Int, Pending>()
    private var ticker: ScheduledFuture<*>? = null
    private var handshakeTimer: ScheduledFuture<*>? = null
    private var scanTimer: ScheduledFuture<*>? = null
    private var reconnectAttempts = 0
    private var permissionAskedFor: String? = null
    private var userDisconnected = false
    private var receiverRegistered = false
    private var rttMs = -1L
    private var dropLogNanos = 0L
    private var dropsSuppressed = 0

    // ---- live view the app wants: kept alive through hiccups and reconnects (control thread) ----
    private var wantStream = false
    private var wantFps = 2
    private var wantQuality = 0
    private var lastStreamFrameNanos = 0L
    private var streamCommandNanos = 0L
    private var streamRestarts = 0

    // ---- shared ----
    @Volatile
    private var lastRxNanos = 0L

    @Volatile
    private var stopped = false
    private val decodeFailures = AtomicLong()
    private val decodeBusy = AtomicBoolean(false)
    private val latestStreamFrame = AtomicReference<FrameAssembler.Frame?>(null)

    /** Current camera output size as reported by the firmware (0 until known). */
    @Volatile
    var cameraWidth = 0
        private set

    @Volatile
    var cameraHeight = 0
        private set

    /** Receives every complete frame (stream and requested) on the control thread, e.g. for recording. */
    @Volatile
    var frameTap: ((FrameAssembler.Frame) -> Unit)? = null

    // =========================================================================================
    // Public API (any thread)
    // =========================================================================================

    fun start() = runOnControl {
        registerReceiver()
        AppLog.i(TAG, "USB host feature: ${hasUsbHostFeature()}")
        scan(userInitiated = false)
    }

    fun stop() {
        stopped = true
        runOnControl {
            cancelScanTimer()
            closeSession("app closed")
            unregisterReceiver()
        }
        control.shutdown()
        decoder.shutdown()
    }

    /** Re-scan when the app returns to the foreground (no permission prompt if already asked). */
    fun refresh() = runOnControl {
        if (session == null && !userDisconnected) scan(userInitiated = false)
    }

    fun reconnect() = runOnControl {
        userDisconnected = false
        reconnectAttempts = 0
        permissionAskedFor = null
        closeSession("reconnect requested")
        scan(userInitiated = true)
    }

    fun disconnect() = runOnControl {
        userDisconnected = true
        wantStream = false
        cancelScanTimer()
        closeSession("disconnected by user")
        setState(State.DISCONNECTED, "Disconnected. Tap Reconnect to connect again.")
    }

    /**
     * Requests one fresh frame. It is always shown through Listener.onFrame; onResult (main
     * thread) additionally receives the raw frame, or the reason it could not be taken.
     */
    fun captureFrame(
        fresh: Boolean = true,
        quality: Int = 0,
        onResult: ((FrameAssembler.Frame?, String?) -> Unit)? = null,
    ) = command(
        DishaProtocol.CAPTURE_FRAME, DishaProtocol.captureFramePayload(fresh, quality), 8000,
        onResult?.let { cb -> { r: Reply -> cb(r.frame, if (r.frame == null) r.message else null) } },
    )

    /**
     * Captures one fresh frame at the given size (for the AI): switches the camera to that size if
     * needed, captures, and switches back. Falls back to the current size if switching fails.
     */
    fun captureAt(width: Int, height: Int, quality: Int, onResult: (FrameAssembler.Frame?, String?) -> Unit) {
        val prevW = cameraWidth
        val prevH = cameraHeight
        if (prevW == 0 || (prevW == width && prevH == height)) {
            captureFrame(true, quality, onResult)
            return
        }
        setResolution(width, height) { r ->
            if (!r.ok) {
                AppLog.w(TAG, "Could not switch to ${width}x$height for the AI (${r.message}); using ${prevW}x$prevH")
                captureFrame(true, quality, onResult)
                return@setResolution
            }
            captureFrame(true, quality) { frame, error ->
                setResolution(prevW, prevH)
                onResult(frame, error)
            }
        }
    }

    /** Starts the live stream and keeps it running: it is restarted by itself if it ever stalls. */
    fun startStream(fps: Int, quality: Int = 0, onReply: ((Reply) -> Unit)? = null) {
        runOnControl {
            wantStream = true
            wantFps = fps.coerceAtLeast(1)
            wantQuality = quality
            val now = System.nanoTime()
            streamCommandNanos = now
            lastStreamFrameNanos = now
            streamRestarts = 0
        }
        command(DishaProtocol.START_STREAM, DishaProtocol.startStreamPayload(fps, quality), 4000, onReply)
    }

    fun stopStream(onReply: ((Reply) -> Unit)? = null) {
        runOnControl { wantStream = false }
        command(DishaProtocol.STOP_STREAM, DishaProtocol.EMPTY, 4000, onReply)
    }

    fun setResolution(width: Int, height: Int, onReply: ((Reply) -> Unit)? = null) =
        command(DishaProtocol.SET_RESOLUTION, DishaProtocol.resolutionPayload(width, height), 8000, onReply)

    fun setOrientation(vflip: Boolean, hmirror: Boolean) =
        command(DishaProtocol.SET_ORIENTATION, DishaProtocol.orientationPayload(vflip, hmirror), 4000)

    fun requestStatus() = command(DishaProtocol.GET_STATUS, DishaProtocol.EMPTY, 3000)

    /** Photo saved on the glasses' microSD card. */
    fun takeSdPhoto(quality: Int = 0, onReply: (Reply) -> Unit) =
        command(DishaProtocol.TAKE_PHOTO, DishaProtocol.takePhotoPayload(quality), 10000, onReply)

    fun startSdRecording(fps: Int, quality: Int = 0, onReply: (Reply) -> Unit) =
        command(DishaProtocol.START_RECORDING, DishaProtocol.startRecordingPayload(fps, quality), 8000, onReply)

    fun stopSdRecording(onReply: (Reply) -> Unit) =
        command(DishaProtocol.STOP_RECORDING, DishaProtocol.EMPTY, 10000, onReply)

    fun requestStorage(onReply: ((Reply) -> Unit)? = null) =
        command(DishaProtocol.GET_STORAGE_STATUS, DishaProtocol.EMPTY, 8000, onReply)

    fun listFiles(maxFiles: Int, onReply: (Reply) -> Unit) =
        command(DishaProtocol.LIST_FILES, DishaProtocol.listFilesPayload(maxFiles), 10000, onReply)

    // =========================================================================================
    // Discovery, permission, connection (control thread)
    // =========================================================================================

    private fun hasUsbHostFeature() = appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    private fun scan(userInitiated: Boolean) {
        if (session != null || stopped) return
        cancelScanTimer()
        val devices = usbManager.deviceList.values.toList()
        if (devices.isEmpty()) {
            if (hasUsbHostFeature()) {
                setState(
                    State.DISCONNECTED,
                    "No USB device. Connect the board's USB-OTG port to the phone with an OTG cable or adapter.",
                )
            } else {
                setState(
                    State.NO_USB_HOST,
                    "This phone does not report USB host (OTG) support. Some phones need OTG switched on in Settings.",
                )
            }
            postDeviceInfo(DeviceInfo("No USB device attached.", null, null))
            return
        }

        val candidates = devices.mapNotNull { UsbDeviceInspector.select(it) }
            .sortedBy { if (it.transport == UsbDeviceInspector.Transport.VENDOR_BULK) 0 else 1 }
        if (candidates.isEmpty()) {
            val why = devices.firstNotNullOfOrNull { UsbDeviceInspector.diagnose(it) }
                ?: "The attached USB device is not a DISHA-CAM."
            setState(State.WRONG_DEVICE, why)
            postDeviceInfo(DeviceInfo(devices.joinToString("\n") { UsbDeviceInspector.describe(it) }, null, null))
            return
        }

        val sel = candidates.first()
        postDeviceInfo(DeviceInfo(UsbDeviceInspector.describe(sel.device), sel.transport, null))
        if (!usbManager.hasPermission(sel.device)) {
            if (userInitiated || permissionAskedFor != sel.device.deviceName) {
                permissionAskedFor = sel.device.deviceName
                AppLog.i(TAG, "Requesting USB permission for ${UsbDeviceInspector.hex4(sel.device.vendorId)}:${UsbDeviceInspector.hex4(sel.device.productId)}")
                usbManager.requestPermission(sel.device, permissionIntent())
                setState(State.PERMISSION_NEEDED, "Allow DISHA GLASS OS to use the USB device in the dialog.")
            } else {
                setState(State.PERMISSION_NEEDED, "USB permission not granted. Tap Reconnect to ask again.")
            }
            return
        }
        open(sel)
    }

    private fun open(sel: UsbDeviceInspector.LinkSelection) {
        setState(State.CONNECTING, "Opening ${sel.transport.label}")
        val s = Session(++generation, sel)
        try {
            s.conn = UsbLinkConnection.open(usbManager, sel, object : UsbLinkConnection.Listener {
                override fun onBytes(data: ByteArray, len: Int) = s.parser.feed(data, 0, len)
                override fun onReaderStopped(error: String?) = runOnControl {
                    if (session === s) linkLost(error ?: "USB reader stopped")
                }
            })
        } catch (e: Exception) {
            setState(State.ERROR, "Could not open the USB device: ${e.message}")
            scheduleReconnect()
            return
        }
        session = s
        hello = null
        pending.clear()
        helloAttempts = 0
        seq = 0
        rttMs = -1
        lastRxNanos = System.nanoTime()
        AppLog.i(
            TAG,
            String.format(
                java.util.Locale.US, "Opened %s:%s interface %d (%s), bulk IN 0x%02X / OUT 0x%02X, max packet %d",
                UsbDeviceInspector.hex4(sel.device.vendorId), UsbDeviceInspector.hex4(sel.device.productId),
                sel.iface.id, sel.transport.label, sel.epIn.address, sel.epOut.address, sel.epIn.maxPacketSize,
            ),
        )
        setState(State.HANDSHAKING, "USB connected. Waiting for the DISHA-CAM firmware to answer…")
        sendHello()
        ticker = control.scheduleWithFixedDelay({ tick() }, TICK_MS, TICK_MS, TimeUnit.MILLISECONDS)
    }

    private fun sendHello() {
        val s = session ?: return
        helloAttempts++
        helloSeq = send(DishaProtocol.HELLO, "DishaGlassOS ${BuildConfig.VERSION_NAME}".toByteArray()) ?: return
        handshakeTimer?.cancel(false)
        val gen = s.gen
        handshakeTimer = control.schedule({ onHandshakeTimeout(gen) }, HANDSHAKE_TIMEOUT_MS, TimeUnit.MILLISECONDS)
    }

    private fun onHandshakeTimeout(gen: Int) {
        val s = session ?: return
        if (s.gen != gen || hello != null) return
        if (helloAttempts < HANDSHAKE_ATTEMPTS) {
            AppLog.w(TAG, "No HELLO_ACK yet (attempt $helloAttempts), retrying")
            sendHello()
            return
        }
        closeSession("handshake failed")
        setState(
            State.ERROR,
            "The USB device did not answer the DISHA protocol. Flash DISHA-CAM " +
                "(Tools > USB Mode: USB-OTG (TinyUSB)) and press RST.",
        )
        scheduleReconnect()
    }

    private fun tick() {
        val s = session ?: return
        val now = System.nanoTime()
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val (ref, p) = it.next()
            if ((now - p.sentNanos) / 1_000_000 > p.timeoutMs) {
                it.remove()
                val why = "No reply from DISHA-CAM within ${p.timeoutMs / 1000} s"
                postResult(CommandResult(ref, p.command, DishaProtocol.ERR_TIMEOUT, why))
                notifyReply(p, Reply(DishaProtocol.ERR_TIMEOUT, why))
            }
        }
        if (hello == null) return  // still handshaking
        if ((now - lastRxNanos) / 1_000_000 > LINK_SILENCE_MS) {
            linkLost("No data from DISHA-CAM for ${LINK_SILENCE_MS / 1000} s")
            return
        }
        val ping = ByteArray(8)
        DishaProtocol.putU32(ping, 0, now and 0xFFFFFFFFL)
        DishaProtocol.putU32(ping, 4, (now ushr 32) and 0xFFFFFFFFL)
        send(DishaProtocol.PING, ping)
        if (state == State.CAMERA_INITIALISING) send(DishaProtocol.GET_STATUS)
        checkStream(now)
        postStats(s)
    }

    /**
     * Stream watchdog. The link can stay alive (pings answered) while frames stop: the firmware
     * stops streaming after a USB hiccup, a session restart forgets it, or frames get lost. Then the
     * stream is restarted; if that does not help twice, the whole link is reconnected.
     */
    private fun checkStream(now: Long) {
        if (!wantStream || hello == null) return
        if (state != State.READY && state != State.STREAMING) return  // camera starting or in error: wait
        if ((now - streamCommandNanos) / 1_000_000 < STREAM_GRACE_MS) return
        if (state == State.READY) {
            AppLog.w(TAG, "Live view had stopped on the glasses; starting it again")
            restartStream(now, stopFirst = false)
            return
        }
        val stallMs = maxOf(STREAM_STALL_MS, 4000L / wantFps)
        val silentMs = (now - lastStreamFrameNanos) / 1_000_000
        if (silentMs < stallMs) return
        if (streamRestarts < STREAM_RESTARTS_BEFORE_RECONNECT) {
            streamRestarts++
            AppLog.w(TAG, "No live frames for ${silentMs / 1000} s; restarting the stream (attempt $streamRestarts)")
            restartStream(now, stopFirst = true)
        } else {
            streamRestarts = 0
            linkLost("Live view stalled for ${silentMs / 1000} s")
        }
    }

    private fun restartStream(now: Long, stopFirst: Boolean) {
        streamCommandNanos = now
        lastStreamFrameNanos = now
        if (stopFirst) send(DishaProtocol.STOP_STREAM)
        send(DishaProtocol.START_STREAM, DishaProtocol.startStreamPayload(wantFps, wantQuality))
    }

    private fun linkLost(reason: String) {
        val s = session ?: return
        val deviceName = s.selection.device.deviceName
        AppLog.w(TAG, "Link lost: $reason")
        closeSession(reason)
        val stillAttached = usbManager.deviceList.values.any { it.deviceName == deviceName }
        if (stillAttached && !userDisconnected) {
            setState(State.ERROR, "$reason. Reconnecting…")
            scheduleReconnect()
        } else {
            setState(State.DISCONNECTED, "USB disconnected.")
        }
    }

    private fun closeSession(reason: String) {
        val s = session ?: return
        ticker?.cancel(false)
        ticker = null
        handshakeTimer?.cancel(false)
        handshakeTimer = null
        if (state == State.STREAMING) {
            try {
                s.conn.write(DishaProtocol.encode(DishaProtocol.STOP_STREAM, nextSeq()))
            } catch (_: Exception) {
            }
        }
        session = null
        hello = null
        for ((ref, p) in pending) {
            postResult(CommandResult(ref, p.command, DishaProtocol.ERR_NOT_CONNECTED, "USB link closed ($reason)"))
            notifyReply(p, Reply(DishaProtocol.ERR_NOT_CONNECTED, "The USB link closed ($reason)."))
        }
        pending.clear()
        s.conn.close()
        latestStreamFrame.set(null)
        AppLog.i(TAG, "USB link closed ($reason)")
    }

    private fun scheduleReconnect() {
        if (userDisconnected || scanTimer != null) return
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            AppLog.w(TAG, "Automatic reconnect stopped after $reconnectAttempts attempts. Tap Reconnect.")
            return
        }
        val delayMs = 1000L * (1 shl reconnectAttempts).coerceAtMost(8)
        reconnectAttempts++
        scheduleScan(delayMs)
    }

    private fun scheduleScan(delayMs: Long) {
        cancelScanTimer()
        scanTimer = control.schedule({
            scanTimer = null
            scan(userInitiated = false)
        }, delayMs, TimeUnit.MILLISECONDS)
    }

    private fun cancelScanTimer() {
        scanTimer?.cancel(false)
        scanTimer = null
    }

    // =========================================================================================
    // Messages
    // =========================================================================================

    private fun nextSeq(): Int {
        seq = (seq + 1) and 0xFFFF
        if (seq == 0) seq = 1
        return seq
    }

    /** Sends a message; returns its seq, or null if the link failed (the link is then closed). */
    private fun send(type: Int, payload: ByteArray = DishaProtocol.EMPTY, ref: Int = 0): Int? {
        val s = session ?: return null
        val n = nextSeq()
        return try {
            s.conn.write(DishaProtocol.encode(type, n, ref, payload))
            n
        } catch (e: Exception) {
            linkLost("USB write failed: ${e.message}")
            null
        }
    }

    private fun command(
        type: Int,
        payload: ByteArray,
        timeoutMs: Long,
        onReply: ((Reply) -> Unit)? = null,
    ) = runOnControl {
        val p = Pending(type, System.nanoTime(), timeoutMs, onReply)
        if (session == null || !state.connected) {
            postResult(CommandResult(0, type, DishaProtocol.ERR_NOT_CONNECTED, "Camera not connected"))
            notifyReply(p, Reply(DishaProtocol.ERR_NOT_CONNECTED, "The camera is not connected."))
            return@runOnControl
        }
        val n = send(type, payload)
        if (n == null) {
            notifyReply(p, Reply(DishaProtocol.ERR_USB, "Sending to the camera failed."))
            return@runOnControl
        }
        pending[n] = p
    }

    private fun notifyReply(p: Pending?, reply: Reply) {
        val cb = p?.onReply ?: return
        post { cb(reply) }
    }

    /** Reader thread. Frame chunks are reassembled here; everything else goes to the control thread. */
    private fun onMessageFromReader(s: Session, msg: MessageParser.Message) {
        lastRxNanos = System.nanoTime()
        if (msg.type == DishaProtocol.FRAME_CHUNK && msg.version == DishaProtocol.VERSION) {
            val frame = s.assembler.onChunk(msg.ref, msg.payload) ?: return
            runOnControl { onFrameAssembled(s, frame) }
        } else {
            runOnControl { handleMessage(s, msg) }
        }
    }

    private fun handleMessage(s: Session, msg: MessageParser.Message) {
        if (session !== s) return
        if (msg.version != DishaProtocol.VERSION) {
            AppLog.e(TAG, "Protocol version mismatch: firmware v${msg.version}, app v${DishaProtocol.VERSION}")
            closeSession("protocol mismatch")
            setState(State.ERROR, "Firmware speaks protocol v${msg.version}; this app needs v${DishaProtocol.VERSION}.")
            return
        }
        when (msg.type) {
            DishaProtocol.HELLO_ACK -> onHelloAck(msg)
            DishaProtocol.PONG -> onPong(msg)
            DishaProtocol.STATUS -> onStatus(msg)
            DishaProtocol.RESULT -> onResult(msg)
            DishaProtocol.STORAGE -> parseJson(msg.payload)?.let { json ->
                notifyReply(pending.remove(msg.ref), Reply(DishaProtocol.OK, "", json = json))
                post { listener.onStorageStatus(json) }
            }
            DishaProtocol.FILE_LIST -> parseJson(msg.payload)?.let { json ->
                notifyReply(pending.remove(msg.ref), Reply(DishaProtocol.OK, "", json = json))
            }
            DishaProtocol.LOG -> AppLog.i("ESP32", String(msg.payload, Charsets.UTF_8))
            else -> AppLog.w(TAG, "Unexpected message ${DishaProtocol.typeName(msg.type)}")
        }
    }

    private fun parseJson(bytes: ByteArray): JSONObject? = try {
        JSONObject(String(bytes, Charsets.UTF_8))
    } catch (e: JSONException) {
        AppLog.e(TAG, "Invalid JSON from DISHA-CAM: ${e.message}")
        null
    }

    private fun onHelloAck(msg: MessageParser.Message) {
        val s = session ?: return
        if (msg.ref != helloSeq) return  // answer to an earlier HELLO attempt
        handshakeTimer?.cancel(false)
        handshakeTimer = null
        val json = parseJson(msg.payload) ?: return
        val proto = json.optInt("proto", -1)
        if (proto != DishaProtocol.VERSION) {
            closeSession("protocol mismatch")
            setState(State.ERROR, "Firmware protocol $proto, app protocol ${DishaProtocol.VERSION}. Update both together.")
            return
        }
        hello = json
        reconnectAttempts = 0
        AppLog.i(
            TAG,
            "Handshake OK: ${json.optString("fw")} ${json.optString("fwVersion")}, transport " +
                "${json.optString("transport")}, session ${json.optInt("session")}, last reset: ${json.optString("resetReason")}",
        )
        if (json.optString("resetReason").startsWith("brownout")) {
            AppLog.w(TAG, "The board's last reset was a brownout: USB power from the phone may be insufficient, or the cable is poor.")
        }
        postDeviceInfo(DeviceInfo(UsbDeviceInspector.describe(s.selection.device), s.selection.transport, json))
        applyCameraState(json.optJSONObject("camera"))
        json.optJSONObject("storage")?.let { storage -> post { listener.onStorageStatus(storage) } }
    }

    private fun onPong(msg: MessageParser.Message) {
        if (msg.payload.size < 8) return
        val sent = DishaProtocol.getU32(msg.payload, 0) or (DishaProtocol.getU32(msg.payload, 4) shl 32)
        rttMs = (System.nanoTime() - sent) / 1_000_000
    }

    private fun onStatus(msg: MessageParser.Message) {
        val json = parseJson(msg.payload) ?: return
        notifyReply(pending.remove(msg.ref), Reply(DishaProtocol.OK, "", json = json))
        post { listener.onDeviceStatus(json) }
        applyCameraState(json.optJSONObject("camera"))
        json.optJSONObject("storage")?.let { storage -> post { listener.onStorageStatus(storage) } }
    }

    private fun applyCameraState(cam: JSONObject?) {
        if (cam == null) return
        if (cam.optInt("width") > 0) {
            cameraWidth = cam.optInt("width")
            cameraHeight = cam.optInt("height")
        }
        when (val st = cam.optString("state")) {
            "ready" -> {
                val desc = "${cam.optString("sensor")} ${cam.optInt("width")}×${cam.optInt("height")} JPEG q${cam.optInt("quality")}" +
                    " · ${session?.selection?.transport?.label ?: ""}"
                setState(if (cam.optBoolean("streaming")) State.STREAMING else State.READY, desc)
            }
            "initializing", "off" -> setState(State.CAMERA_INITIALISING, "USB link up; the camera is starting…")
            "error" -> setState(State.CAMERA_ERROR, cam.optString("problem").ifEmpty { "Camera error" })
            else -> setState(State.CAMERA_ERROR, "Unknown camera state \"$st\"")
        }
    }

    private fun onResult(msg: MessageParser.Message) {
        if (msg.payload.size < 2) return
        val status = msg.payload[0].toInt() and 0xFF
        val command = msg.payload[1].toInt() and 0xFF
        val text = String(msg.payload, 2, msg.payload.size - 2, Charsets.UTF_8)
        notifyReply(pending.remove(msg.ref), Reply(status, text))

        if (status == DishaProtocol.ERR_NO_SESSION) {
            if (hello != null) {
                AppLog.w(TAG, "DISHA-CAM has no session (did it restart?). Handshaking again.")
                hello = null
                helloAttempts = 0
                setState(State.HANDSHAKING, "Re-establishing the session…")
                sendHello()
            }
            return
        }
        if (status == DishaProtocol.OK) {
            when (command) {
                DishaProtocol.START_STREAM -> setState(State.STREAMING, text)
                DishaProtocol.STOP_STREAM -> if (state == State.STREAMING) setState(State.READY, text)
                DishaProtocol.SET_RESOLUTION, DishaProtocol.SET_ORIENTATION -> send(DishaProtocol.GET_STATUS)
            }
        }
        postResult(CommandResult(msg.ref, command, status, text))
    }

    private fun onFrameAssembled(s: Session, frame: FrameAssembler.Frame) {
        if (session !== s) return
        if (!frame.isRequested) {
            lastStreamFrameNanos = System.nanoTime()
            streamRestarts = 0
        }
        var latency: Long? = null
        if (frame.isRequested) {
            pending.remove(frame.ref)?.let {
                latency = (frame.completedAtNanos - it.sentNanos) / 1_000_000
                notifyReply(it, Reply(DishaProtocol.OK, "", frame = frame))
            }
        }
        frameTap?.let { tap ->
            try {
                tap(frame)
            } catch (e: Exception) {
                AppLog.e(TAG, "Frame consumer failed: ${e.message}")
            }
        }
        submitDecode(frame, latency)
    }

    private fun onFrameDropped(s: Session, reason: String) {
        if (session !== s) return
        val now = System.nanoTime()
        if (now - dropLogNanos < 1_000_000_000L) {
            dropsSuppressed++
            return
        }
        val extra = if (dropsSuppressed > 0) " (+$dropsSuppressed more in the last second)" else ""
        dropsSuppressed = 0
        dropLogNanos = now
        AppLog.w(TAG, "Frame dropped: $reason$extra")
    }

    // =========================================================================================
    // Decoding: requested frames are always decoded; stream frames keep only the newest.
    // =========================================================================================

    private fun submitDecode(frame: FrameAssembler.Frame, latencyMs: Long?) {
        try {
            if (frame.isRequested) {
                decoder.execute { decodeAndPost(frame, latencyMs) }
                return
            }
            latestStreamFrame.set(frame)
            if (decodeBusy.compareAndSet(false, true)) decoder.execute { drainStreamFrames() }
        } catch (_: RejectedExecutionException) {
            // shutting down
        }
    }

    private fun drainStreamFrames() {
        while (true) {
            val f = latestStreamFrame.getAndSet(null)
            if (f == null) {
                decodeBusy.set(false)
                if (latestStreamFrame.get() != null && decodeBusy.compareAndSet(false, true)) continue
                return
            }
            decodeAndPost(f, null)
        }
    }

    private fun decodeAndPost(frame: FrameAssembler.Frame, latencyMs: Long?) {
        try {
            val d = FrameDecoder.decode(frame)
            post { listener.onFrame(ReceivedFrame(frame, d.bitmap, d.decodeMs, latencyMs)) }
        } catch (e: FrameDecoder.DecodeException) {
            decodeFailures.incrementAndGet()
            AppLog.e(TAG, "Frame ${frame.frameId} rejected: ${e.message}")
        } catch (e: OutOfMemoryError) {
            decodeFailures.incrementAndGet()
            AppLog.e(TAG, "Out of memory decoding frame ${frame.frameId}")
        }
    }

    // =========================================================================================
    // Broadcasts
    // =========================================================================================

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device = intent.usbDevice()
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    runOnControl { onPermissionResult(device, granted) }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> runOnControl { onAttached(device) }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> runOnControl { onDetached(device) }
            }
        }
    }

    private fun onPermissionResult(device: UsbDevice?, granted: Boolean) {
        if (granted) {
            AppLog.i(TAG, "USB permission granted")
            scan(userInitiated = false)
        } else {
            AppLog.w(TAG, "USB permission denied")
            setState(State.PERMISSION_NEEDED, "USB permission denied. Tap Reconnect to ask again.")
        }
        if (device == null) AppLog.w(TAG, "Permission result without a device")
    }

    private fun onAttached(device: UsbDevice?) {
        AppLog.i(TAG, "USB attached: ${device?.let { "${UsbDeviceInspector.hex4(it.vendorId)}:${UsbDeviceInspector.hex4(it.productId)}" } ?: "?"}")
        userDisconnected = false
        reconnectAttempts = 0
        // At boot the ESP32-S3 first shows its USB Serial/JTAG device, then the DISHA-CAM device.
        // Wait for it to settle so we connect to the right one.
        if (session == null) scheduleScan(ATTACH_SETTLE_MS)
    }

    private fun onDetached(device: UsbDevice?) {
        AppLog.i(TAG, "USB detached: ${device?.let { "${UsbDeviceInspector.hex4(it.vendorId)}:${UsbDeviceInspector.hex4(it.productId)}" } ?: "?"}")
        permissionAskedFor = null
        val s = session
        if (s != null && device != null && device.deviceName == s.selection.device.deviceName) {
            closeSession("cable removed")
            setState(State.DISCONNECTED, "USB cable removed.")
        } else if (s == null) {
            scheduleScan(300)
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private fun registerReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            appContext.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            appContext.registerReceiver(receiver, filter)
        }
        receiverRegistered = true
    }

    private fun unregisterReceiver() {
        if (!receiverRegistered) return
        try {
            appContext.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        receiverRegistered = false
    }

    private fun permissionIntent(): PendingIntent {
        // Explicit (package-scoped) and mutable: the system adds the device and the result as extras.
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(appContext.packageName)
        val flags = if (Build.VERSION.SDK_INT >= 31) {
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getBroadcast(appContext, 0, intent, flags)
    }

    // =========================================================================================
    // Helpers
    // =========================================================================================

    private fun setState(newState: State, detail: String) {
        if (newState != state) AppLog.i(TAG, "${newState.label}: $detail")
        state = newState
        post { listener.onLinkState(newState, detail) }
    }

    private fun postDeviceInfo(info: DeviceInfo) = post { listener.onDeviceInfo(info) }

    private fun postResult(r: CommandResult) = post { listener.onCommandResult(r) }

    private fun postStats(s: Session) {
        val stats = LinkStats(
            bytesIn = s.conn.bytesIn.get(),
            bytesOut = s.conn.bytesOut.get(),
            messages = s.parser.messages,
            headerCrcErrors = s.parser.headerCrcErrors,
            payloadCrcErrors = s.parser.payloadCrcErrors,
            skippedBytes = s.parser.skippedBytes,
            framesCompleted = s.assembler.completed,
            framesDropped = s.assembler.dropped,
            frameCrcFailures = s.assembler.crcFailures,
            decodeFailures = decodeFailures.get(),
            rttMs = rttMs,
        )
        post { listener.onStats(stats) }
    }

    private fun post(block: () -> Unit) {
        main.post { if (!stopped) block() }
    }

    private fun runOnControl(block: () -> Unit) {
        try {
            control.execute(block)
        } catch (_: RejectedExecutionException) {
            // shutting down
        }
    }
}

@Suppress("DEPRECATION")
private fun Intent.usbDevice(): UsbDevice? =
    if (Build.VERSION.SDK_INT >= 34) {
        getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
    } else {
        getParcelableExtra(UsbManager.EXTRA_DEVICE)
    }
