package com.disha.glassos.skills

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.disha.glassos.skills.NavMath.Point
import com.disha.glassos.util.AppLog
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Walking directions in the earbuds, from OpenStreetMap without any key: the place is found with
 * Overpass (nearest metro station, ATM, hospital…) or Nominatim (named places), the walking route
 * with the FOSSGIS OSRM foot router, and the phone's GPS follows the walk: "In 40 metres, turn
 * left onto MG Road". Leaving the route asks for a new one. Coordinates are sent to those
 * services only while navigating.
 */
class Navigator(context: Context, private val places: Places, private val listener: Listener) {

    interface Listener {
        /** Something to say now (main thread). */
        fun onNavSay(text: String)
        fun onNavEnded()
    }

    private companion object {
        const val TAG = "Nav"
        const val UA = "DISHA-GLASS-OS/0.12 (smart-glasses walking directions; personal use)"
        const val ROUTER = "https://routing.openstreetmap.de/routed-foot/route/v1/driving"
        const val MAX_WALK_M = 15_000.0
        const val REROUTE_GAP_MS = 30_000L

        /** Kinds of place found by "nearest" search: spoken words -> Overpass filters. */
        val CATEGORIES = listOf(
            Regex("(?i)\\b(metro|subway)\\b") to listOf("node[\"station\"=\"subway\"]", "node[\"railway\"=\"station\"][\"subway\"=\"yes\"]"),
            Regex("(?i)\\b(railway|train) station\\b") to listOf("node[\"railway\"=\"station\"]"),
            Regex("(?i)\\bbus (stop|stand|station)\\b") to listOf("node[\"highway\"=\"bus_stop\"]", "nwr[\"amenity\"=\"bus_station\"]"),
            Regex("(?i)\\b(hospital|emergency room)\\b") to listOf("nwr[\"amenity\"=\"hospital\"]"),
            Regex("(?i)\\b(pharmacy|chemist|medical store|medical shop)\\b") to listOf("nwr[\"amenity\"=\"pharmacy\"]"),
            Regex("(?i)\\batm\\b") to listOf("nwr[\"amenity\"=\"atm\"]"),
            Regex("(?i)\\bbank\\b") to listOf("nwr[\"amenity\"=\"bank\"]"),
            Regex("(?i)\\b(petrol pump|fuel|gas station|petrol station)\\b") to listOf("nwr[\"amenity\"=\"fuel\"]"),
            Regex("(?i)\\b(toilet|washroom|restroom|bathroom)\\b") to listOf("nwr[\"amenity\"=\"toilets\"]"),
            Regex("(?i)\\bpolice\\b") to listOf("nwr[\"amenity\"=\"police\"]"),
            Regex("(?i)\\b(cafe|coffee)\\b") to listOf("nwr[\"amenity\"=\"cafe\"]"),
            Regex("(?i)\\b(restaurant|food|dhaba|eat)\\b") to listOf("nwr[\"amenity\"~\"restaurant|fast_food\"]"),
            Regex("(?i)\\bparking\\b") to listOf("nwr[\"amenity\"=\"parking\"]"),
            Regex("(?i)\\b(temple|mandir|mosque|masjid|church|gurudwara|gurdwara)\\b") to listOf("nwr[\"amenity\"=\"place_of_worship\"]"),
            Regex("(?i)\\b(supermarket|grocery|kirana|store)\\b") to listOf("nwr[\"shop\"~\"supermarket|convenience\"]"),
            Regex("(?i)\\bmall\\b") to listOf("nwr[\"shop\"=\"mall\"]"),
            Regex("(?i)\\bpark\\b") to listOf("nwr[\"leisure\"=\"park\"]"),
        )
    }

    private class Dest(val name: String, val at: Point)
    private class Route(val steps: List<NavMath.Step>, val path: List<Point>, val metres: Double, val seconds: Double)

    private val appContext = context.applicationContext
    private val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "disha-nav").apply { isDaemon = true } }
    private var guide: NavMath.Guide? = null
    private var dest: Dest? = null
    private var last: Point? = null
    private var gpsListener: LocationListener? = null
    private var lastReroute = 0L
    private var session = 0

    val active get() = dest != null
    val destinationName get() = dest?.name.orEmpty()

    /** Finds [what], plans the walk and starts guiding. done(first sentence) on the main thread. */
    fun start(what: String, done: (String) -> Unit) {
        stopTracking()
        val mySession = ++session
        if (!places.hasPermission()) {
            done("I need location permission for directions. Allow it in Settings, Skills, Remember places, or in the phone's app settings.")
            return
        }
        places.current(15_000) { fix ->
            if (mySession != session) return@current
            if (fix == null) {
                done("I can't find where you are. Turn on location and try again outdoors.")
                return@current
            }
            val from = Point(fix.lat, fix.lon)
            executor.execute {
                val result: Pair<String, Pair<Dest, Route>?> = try {
                    val d = find(what, from) ?: throw NavError("I couldn't find $what near you.")
                    val straight = NavMath.distance(from, d.at)
                    if (straight > MAX_WALK_M) throw NavError("${d.name} is ${NavMath.spoken(straight)} away. That's too far to walk; take a cab or bus.")
                    val r = route(from, d.at)
                    val minutes = (r.seconds / 60).toInt().coerceAtLeast(1)
                    val g = NavMath.Guide(r.steps, r.path)
                    "${d.name} is ${NavMath.spoken(r.metres)} away, about $minutes minutes on foot. ${g.opening(from)}" to (d to r)
                } catch (e: NavError) {
                    (e.message ?: "I couldn't plan the route.") to null
                } catch (e: Exception) {
                    AppLog.w(TAG, "Planning failed: ${e.message}")
                    "I couldn't reach the map service. Check the internet connection and try again." to null
                }
                main.post {
                    if (mySession != session) return@post
                    val (sentence, plan) = result
                    if (plan != null) {
                        dest = plan.first
                        guide = NavMath.Guide(plan.second.steps, plan.second.path)
                        last = from
                        startTracking()
                        AppLog.i(TAG, "Navigating to ${plan.first.name}: ${plan.second.steps.size} steps, ${plan.second.metres.toInt()} m")
                    }
                    done(sentence)
                }
            }
        }
    }

    fun stop(): String {
        val was = dest?.name
        session++
        stopTracking()
        dest = null
        guide = null
        return if (was != null) "Navigation to $was stopped." else "I'm not navigating."
    }

    fun statusSentence(): String {
        val g = guide ?: return "I'm not navigating. Say take me to, and a place."
        val p = last ?: return "Waiting for your location."
        val d = dest ?: return ""
        return "${g.nextSentence(p)} ${d.name} is ${NavMath.spoken(NavMath.distance(p, d.at))} away in a straight line."
    }

    /** Short line for the screen and the web view. */
    fun line(): String = dest?.let { d -> last?.let { p -> "To ${d.name}: ${guide?.nextSentence(p) ?: ""}" } ?: "To ${d.name}" }.orEmpty()

    @SuppressLint("MissingPermission")
    private fun startTracking() {
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) = onFix(location)
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
            override fun onProviderEnabled(provider: String) = Unit
            override fun onProviderDisabled(provider: String) = Unit
        }
        gpsListener = l
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 2000L, 2f, l, Looper.getMainLooper())
            } catch (e: Exception) {
                AppLog.w(TAG, "$p: ${e.message}")
            }
        }
    }

    private fun stopTracking() {
        gpsListener?.let { try { lm.removeUpdates(it) } catch (_: Exception) {} }
        gpsListener = null
    }

    private fun onFix(loc: Location) {
        if (loc.hasAccuracy() && loc.accuracy > 45f) return  // too vague to follow turns
        val g = guide ?: return
        val p = Point(loc.latitude, loc.longitude)
        last = p
        val u = g.update(p)
        u.say?.let { listener.onNavSay(it) }
        when {
            u.arrived -> {
                AppLog.i(TAG, "Arrived")
                if (u.say == null) listener.onNavSay("You have arrived at ${dest?.name ?: "your destination"}.")
                stopTracking()
                dest = null
                guide = null
                listener.onNavEnded()
            }
            u.offRoute && System.currentTimeMillis() - lastReroute > REROUTE_GAP_MS -> reroute(p)
        }
    }

    private fun reroute(from: Point) {
        val d = dest ?: return
        lastReroute = System.currentTimeMillis()
        val mySession = session
        listener.onNavSay("You're off the route. Finding a new way.")
        executor.execute {
            val r = try { route(from, d.at) } catch (e: Exception) { null }
            main.post {
                if (mySession != session || dest == null) return@post
                if (r == null) {
                    listener.onNavSay("I couldn't get a new route right now; I'll keep trying.")
                    return@post
                }
                val g = NavMath.Guide(r.steps, r.path)
                guide = g
                listener.onNavSay(g.opening(from))
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Map services (background thread)
    // ---------------------------------------------------------------------------------------

    private class NavError(message: String) : Exception(message)

    private fun find(what: String, from: Point): Dest? {
        val clean = what.trim().trimEnd('.', '?', '!').replace(Regex("(?i)^(the|a|an)\\s+"), "")
        val category = CATEGORIES.firstOrNull { it.first.containsMatchIn(clean) }?.second
        if (category != null) {
            try {
                overpass(category, from, clean)?.let { return it }
            } catch (e: Exception) {
                AppLog.w(TAG, "Overpass: ${e.message}")
            }
        }
        val name = clean.replace(Regex("(?i)^(nearest|closest)\\s+"), "")
        return nominatim(name, from, bounded = true) ?: nominatim(name, from, bounded = false)
    }

    private fun overpass(filters: List<String>, from: Point, label: String): Dest? {
        val around = "(around:3000,${from.lat},${from.lon})"
        val q = "[out:json][timeout:20];(" + filters.joinToString("") { "$it$around;" } + ");out center 25;"
        val json = JSONObject(post("https://overpass-api.de/api/interpreter", "data=" + URLEncoder.encode(q, "UTF-8")))
        val els = json.optJSONArray("elements") ?: return null
        var best: Dest? = null
        var bestD = Double.MAX_VALUE
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val lat = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: continue
            val lon = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: continue
            val p = Point(lat, lon)
            val d = NavMath.distance(from, p)
            if (d < bestD) {
                bestD = d
                val tags = e.optJSONObject("tags")
                val n = tags?.optString("name:en")?.ifEmpty { null } ?: tags?.optString("name")?.ifEmpty { null }
                best = Dest(n ?: "the nearest ${label.replace(Regex("(?i)^(nearest|closest)\\s+"), "")}", p)
            }
        }
        return best
    }

    private fun nominatim(q: String, from: Point, bounded: Boolean): Dest? {
        val box = if (bounded) "&viewbox=${from.lon - 0.15},${from.lat + 0.15},${from.lon + 0.15},${from.lat - 0.15}&bounded=1" else ""
        val arr = JSONArray(get("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&accept-language=en&q=" +
            URLEncoder.encode(q, "UTF-8") + box))
        var best: Dest? = null
        var bestD = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val p = Point(o.optDouble("lat"), o.optDouble("lon"))
            val d = NavMath.distance(from, p)
            if (d < bestD) {
                bestD = d
                best = Dest(o.optString("name").ifEmpty { o.optString("display_name").substringBefore(',') }, p)
            }
        }
        return best
    }

    private fun route(from: Point, to: Point): Route {
        val url = "$ROUTER/${from.lon},${from.lat};${to.lon},${to.lat}?steps=true&overview=full&geometries=geojson"
        val json = JSONObject(get(url))
        if (json.optString("code") != "Ok") throw NavError("I couldn't find a walking route there.")
        val r = json.getJSONArray("routes").getJSONObject(0)
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val path = (0 until coords.length()).map { i -> coords.getJSONArray(i).let { Point(it.getDouble(1), it.getDouble(0)) } }
        val steps = ArrayList<NavMath.Step>()
        val legs = r.getJSONArray("legs")
        for (l in 0 until legs.length()) {
            val arr = legs.getJSONObject(l).getJSONArray("steps")
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                val m = s.getJSONObject("maneuver")
                val type = m.optString("type")
                val loc = m.getJSONArray("location")
                val text = NavMath.instruction(type, m.optString("modifier"), s.optString("name"), m.optInt("exit", 0), m.optDouble("bearing_after", 0.0))
                val prev = steps.lastOrNull()
                // Small kinks with no turn ("continue straight" on the same road) are not worth saying.
                if (prev != null && type in setOf("new name", "continue") && m.optString("modifier") in setOf("straight", "")) continue
                steps.add(NavMath.Step(text, Point(loc.getDouble(1), loc.getDouble(0)), arrive = type == "arrive"))
            }
        }
        return Route(steps, path, r.optDouble("distance"), r.optDouble("duration"))
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12000
            c.readTimeout = 25000
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12000
            c.readTimeout = 30000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    }
}
