package com.disha.glassos.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class SpeechTextTest {

    @Test
    fun removesMarkdownAndSymbols() {
        assertEquals(
            "The average distance is about 384,400 km. Light takes about 1.28 seconds.",
            SpeechText.forSpeech("The average distance is about **384,400 km**. Light takes ≈ 1.28 seconds."),
        )
        assertEquals("Steps: Open the box. Take out the charger.", SpeechText.forSpeech("## Steps:\n- Open the box\n- Take out the charger"))
        assertEquals("See the docs for details.", SpeechText.forSpeech("See [the docs](https://example.com) for details 🙂"))
        assertEquals("It is 31 degrees outside.", SpeechText.forSpeech("It is 31°C outside."))
        assertEquals("Use snake_case names.", SpeechText.forSpeech("Use snake_case names."))
        assertEquals("यह एक किताब है।", SpeechText.forSpeech("यह एक *किताब* है।"))
    }
}
