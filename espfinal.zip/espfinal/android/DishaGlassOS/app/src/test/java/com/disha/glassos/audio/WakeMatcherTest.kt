package com.disha.glassos.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Synthetic "speech": a sequence of vowel-like sounds (a 120 Hz voice with two formants each).
 * The real-voice check (Windows TTS, 20 other phrases, four noise levels) is in the README.
 */
class WakeMatcherTest {

    private val vowels = mapOf(
        'a' to (800.0 to 1200.0), 'e' to (500.0 to 1900.0), 'i' to (300.0 to 2300.0),
        'o' to (500.0 to 900.0), 'u' to (320.0 to 800.0),
    )

    /** Each letter lasts msPer milliseconds; 300 ms of silence before and after. */
    private fun say(word: String, msPer: Int, pitch: Double = 120.0, noise: Int = 30, seed: Int = 1): ShortArray {
        val rnd = Random(seed)
        val pad = 4800
        val per = msPer * 16
        val out = ShortArray(pad * 2 + per * word.length)
        for ((k, ch) in word.withIndex()) {
            val (f1, f2) = vowels.getValue(ch)
            for (i in 0 until per) {
                val t = (k * per + i) / 16000.0
                var s = 0.0
                for (h in 1..25) {
                    val f = pitch * h
                    val g = 1.0 / (1 + ((f - f1) / 90).let { it * it }) + 0.6 / (1 + ((f - f2) / 120).let { it * it })
                    s += g * sin(2 * PI * f * t)
                }
                out[pad + k * per + i] = (s * 2500).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        for (i in out.indices) out[i] = (out[i] + rnd.nextInt(-noise, noise + 1)).coerceIn(-32768, 32767).toShort()
        return out
    }

    private val matcher = WakeMatcher(listOf(say("eaio", 140, seed = 1), say("eaio", 160, 125.0, seed = 2), say("eaio", 125, 115.0, seed = 3)))

    @Test
    fun identicalFeaturesHaveZeroDistance() {
        val f = Mfcc.features(say("eaio", 140))
        assertEquals(0f, WakeMatcher.dtw(f, f, openEnd = false), 1e-4f)
    }

    @Test
    fun recognisesThePhraseAtOtherSpeedsAndWithNoise() {
        assertTrue(matcher.ready)
        assertTrue(matcher.matches(say("eaio", 115, seed = 9)))
        assertTrue(matcher.matches(say("eaio", 175, 118.0, seed = 10)))
        assertTrue(matcher.matches(say("eaio", 145, noise = 600, seed = 11)))
    }

    @Test
    fun recognisesThePhraseFollowedByARequest() {
        assertTrue(matcher.matches(say("eaiouaeiou", 145, seed = 12)))
    }

    @Test
    fun rejectsOtherSounds() {
        assertEquals(false, matcher.matches(say("ouua", 145, seed = 13)))
        assertEquals(false, matcher.matches(say("ieoa", 145, seed = 14)))
        assertEquals(false, matcher.matches(say("ea", 145, seed = 15)))  // only the start: too short
        assertEquals(false, matcher.matches(ShortArray(16000)))          // silence
    }
}
