package com.disha.glassos.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TranscriptCleanerTest {

    @Test
    fun keepsRealSpeech() {
        assertEquals("Hey Friday, what am I looking at right now?", TranscriptCleaner.clean(" Hey Friday, what am I looking at right now?"))
        assertEquals("यह क्या है?", TranscriptCleaner.clean(" यह क्या है?"))
        assertEquals("Thank you.", TranscriptCleaner.clean("Thank you."))
    }

    @Test
    fun dropsPhantomPhrases() {
        assertNull(TranscriptCleaner.clean(""))
        assertNull(TranscriptCleaner.clean("  "))
        assertNull(TranscriptCleaner.clean(" Thanks for watching!"))
        assertNull(TranscriptCleaner.clean("[Music]"))
        assertNull(TranscriptCleaner.clean("♪ ♪"))
        assertNull(TranscriptCleaner.clean("Subtitles by the Amara.org community"))
        assertNull(TranscriptCleaner.clean(" you"))
        assertEquals("take a photo", TranscriptCleaner.clean("(background noise) take a photo"))
    }
}
