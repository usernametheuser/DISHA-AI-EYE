package com.disha.glassos.storage

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class AviWriterTest {

    private fun u32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    private fun fcc(b: ByteArray, o: Int) = String(b, o, 4, Charsets.US_ASCII)

    @Test
    fun writesAValidMjpegAvi() {
        val file = File.createTempFile("disha", ".avi")
        try {
            val frames = listOf(ByteArray(1001) { 1 }, ByteArray(2000) { 2 }, ByteArray(1500) { 3 })
            val w = AviWriter(file, 320, 240, 5)
            frames.forEachIndexed { i, f -> w.addFrame(f, 1000L + i * 200L) }  // 5 fps real time
            w.close()

            val b = file.readBytes()
            assertEquals("RIFF", fcc(b, 0))
            assertEquals(b.size - 8L, u32(b, 4))
            assertEquals("AVI ", fcc(b, 8))
            assertEquals("hdrl", fcc(b, 20))
            assertEquals(200_000L, u32(b, 32))  // microseconds per frame from the timestamps
            assertEquals(3L, u32(b, 48))        // total frames
            assertEquals(320L, u32(b, 64))
            assertEquals(240L, u32(b, 68))
            assertEquals("vids", fcc(b, 108))
            assertEquals("MJPG", fcc(b, 112))
            assertEquals("MJPG", fcc(b, 188))
            assertEquals("movi", fcc(b, 220))

            // Walk the frame chunks.
            var p = 224
            for (f in frames) {
                assertEquals("00dc", fcc(b, p))
                assertEquals(f.size.toLong(), u32(b, p + 4))
                p += 8 + f.size + (f.size and 1)
            }
            assertEquals(u32(b, 216), (p - 220).toLong())  // movi list size
            assertEquals("idx1", fcc(b, p))
            assertEquals(3 * 16L, u32(b, p + 4))
            // First index entry points at the first chunk, relative to the 'movi' fourcc.
            assertEquals(4L, u32(b, p + 8 + 8))
            assertEquals(1001L, u32(b, p + 8 + 12))
            assertTrue((u32(b, 44) and 0x10L) != 0L)  // AVIF_HASINDEX
        } finally {
            file.delete()
        }
    }
}
