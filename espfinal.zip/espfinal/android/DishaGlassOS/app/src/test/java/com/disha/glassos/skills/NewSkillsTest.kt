package com.disha.glassos.skills

import com.disha.glassos.assistant.VoiceCommandRouter
import com.disha.glassos.assistant.VoiceCommandRouter.Command
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NewSkillsTest {

    private fun p(lat: Double, lon: Double) = NavMath.Point(lat, lon)

    @Test
    fun distancesAndWording() {
        val d = NavMath.distance(p(28.6139, 77.2090), p(28.6239, 77.2090))  // 0.01 degree of latitude
        assertTrue(d in 1100.0..1125.0)
        assertEquals("50 metres", NavMath.spoken(48.0))
        assertEquals("250 metres", NavMath.spoken(260.0))
        assertEquals("1.2 kilometres", NavMath.spoken(1230.0))
        assertEquals("Turn left onto MG Road", NavMath.instruction("turn", "left", "MG Road"))
        assertEquals("Head north on Janpath", NavMath.instruction("depart", "", "Janpath", bearingAfter = 5.0))
        assertEquals("At the roundabout, take the second exit", NavMath.instruction("roundabout", "", "", exit = 2))
        assertEquals("Your destination is on the right", NavMath.instruction("arrive", "right", ""))
        assertEquals("Keep left onto Ring Road", NavMath.instruction("fork", "slight left", "Ring Road"))
        // 10 m off a north-south path
        val path = listOf(p(28.6000, 77.2000), p(28.6100, 77.2000))
        assertTrue(NavMath.distanceToPath(p(28.6050, 77.2001), path) in 8.0..12.0)
    }

    @Test
    fun guidanceSaysTurnsInTime() {
        // Walk north 200 m, turn right, walk east 100 m.
        val corner = p(28.6018, 77.2000)
        val end = p(28.6018, 77.2010)
        val steps = listOf(
            NavMath.Step("Head north on Lane 1", p(28.6000, 77.2000)),
            NavMath.Step("Turn right onto Lane 2", corner),
            NavMath.Step("You have arrived", end, arrive = true),
        )
        val g = NavMath.Guide(steps, listOf(steps[0].at, corner, end))
        assertTrue(g.opening(steps[0].at).startsWith("Head north on Lane 1. In 200 metres, turn right onto Lane 2"))
        assertEquals(null, g.update(p(28.6005, 77.2000)).say)                       // 145 m before: quiet
        assertTrue(g.update(p(28.6015, 77.2000)).say!!.startsWith("In 30 metres, turn right"))
        assertEquals(null, g.update(p(28.6016, 77.2000)).say)                       // said once only
        assertTrue(g.update(p(28.6018, 77.2000)).say!!.contains("destination is 100 metres ahead"))
        val off = (1..3).map { g.update(p(28.6030, 77.2005)) }                        // 130 m away from the route
        assertTrue(off.last().offRoute)
        val arrive = g.update(p(28.6018, 77.20098))
        assertTrue(arrive.arrived && arrive.say == "You have arrived.")
    }

    @Test
    fun qrCodes() {
        val upi = QrContent.parse("upi://pay?pa=ramstores@okaxis&pn=Ram%20Stores&am=150.00&cu=INR")
        val (said, ask) = QrContent.describe(upi)
        assertTrue(said.contains("Ram Stores") && said.contains("ramstores@okaxis") && said.contains("150 rupees") && said.contains("only read"))
        assertEquals(null, ask)                                                       // never offers to pay
        val link = QrContent.describe(QrContent.parse("https://www.isro.gov.in/missions?x=1"))
        assertEquals("It's a link to isro.gov.in.", link.first)
        assertEquals("Shall I open it?", link.second)
        val wifi = QrContent.parse("WIFI:S:Cafe\\;Net;T:WPA;P:secret;;") as QrContent.Item.Wifi
        assertEquals("Cafe;Net", wifi.ssid)
        assertTrue(!QrContent.describe(wifi).first.contains("secret"))               // the password is not read out
        val card = QrContent.parse("BEGIN:VCARD\nVERSION:3.0\nFN:Asha Rao\nORG:Infosys\nTEL;TYPE=CELL:9876543210\nEMAIL:asha@x.in\nEND:VCARD") as QrContent.Item.Contact
        assertEquals("Asha Rao", card.name)
        assertTrue(QrContent.describe(card).first.contains("98765 43210"))
        val me = QrContent.parse("MECARD:N:Rao,Asha;TEL:+919876543210;EMAIL:a@b.in;;") as QrContent.Item.Contact
        assertEquals("Asha Rao", me.name)
        assertTrue(QrContent.parse("hello world") is QrContent.Item.Text)
        assertEquals("98765 43210", QrContent.spaced("+91 98765 43210"))
        assertEquals("98765 43210", QrContent.spaced("098765-43210"))
    }

    @Test
    fun pagesAreTakenWhenStillAndNew() {
        fun thumb(v: Int) = IntArray(PageWatcher.SIZE) { v }
        val w = PageWatcher(0)
        var t = 0L
        fun feed(v: Int, ms: Long): Boolean { t += ms; return w.feed(thumb(v), t) }
        assertEquals(false, feed(40, 100))               // empty desk
        assertEquals(false, feed(40, 500))
        assertEquals(false, feed(200, 500))              // page placed: moving
        assertEquals(false, feed(200, 500))              // steady 0.5 s
        assertEquals(true, feed(200, 900))               // steady 1.4 s, differs from the start -> page 1
        assertEquals(false, feed(200, 2000))             // same page stays: not again
        assertEquals(false, feed(120, 300))              // hand turns the page
        assertEquals(false, feed(150, 300))
        assertEquals(false, feed(150, 600))
        assertEquals(true, feed(150, 800))               // page 2
        // first page already there at the start: taken after a few steady seconds
        val w2 = PageWatcher(0)
        assertEquals(false, w2.feed(thumb(90), 100))
        assertEquals(false, w2.feed(thumb(90), 2000))
        assertEquals(true, w2.feed(thumb(90), 5200))
    }

    @Test
    fun captionsCutLongSpeechInsteadOfDroppingIt() {
        fun frames(ms: Int, amp: Double) = (0 until ms / 20).map { f ->
            ShortArray(320) { i -> (amp * Math.sin((f * 320 + i) * 2 * Math.PI * 220 / 16000)).toInt().toShort() }
        }
        val audio = frames(600, 40.0) + frames(12_000, 4000.0) + frames(1500, 40.0)
        val captions = com.disha.glassos.audio.SpeechSegmenter(endSilenceMs = 600, maxSpeechMs = 8000)
        val cut = audio.mapNotNull { captions.feed(it) }
        assertTrue(cut.isNotEmpty())
        assertTrue(cut[0].speechMs in 7500..8100)              // cut at 8 s, not thrown away
        val wake = com.disha.glassos.audio.SpeechSegmenter()   // the wake word still ignores long speech
        assertEquals(0, audio.mapNotNull { wake.feed(it) }.size)
    }

    @Test
    fun newVoiceCommands() {
        fun cmd(s: String) = VoiceCommandRouter.parse(s)
        assertEquals(Command.DOC_START, cmd("I want to make a document"))
        assertEquals(Command.DOC_START, cmd("Disha make a PDF"))
        assertEquals(Command.DOC_DONE, cmd("done making pdf"))
        assertEquals(Command.SLIDE_NEXT, cmd("next slide"))
        assertEquals(Command.SLIDE_NEXT, cmd("change ppt"))
        assertEquals(Command.SLIDE_PREVIOUS, cmd("previous slide please"))
        assertEquals(Command.SLIDE_GOTO, cmd("go to slide five"))
        assertEquals(5, VoiceCommandRouter.slideNumber("go to slide five"))
        assertEquals(12, VoiceCommandRouter.slideNumber("slide 12"))
        assertEquals(Command.SLIDE_START, cmd("start the presentation"))
        assertEquals(Command.PRESENT_ON, cmd("start presentation mode"))
        assertEquals(Command.REPLAY_SAVE, cmd("save that"))
        assertEquals(Command.REPLAY_ON, cmd("turn on instant replay"))
        assertEquals(Command.NAVIGATE, cmd("take me to the metro station"))
        assertEquals("metro station", VoiceCommandRouter.navDestination("take me to the metro station"))
        assertEquals("nearest ATM", VoiceCommandRouter.navDestination("navigate to the nearest ATM"))
        assertEquals(null, VoiceCommandRouter.navDestination("is there a way to fix this"))
        assertEquals(Command.NAV_STOP, cmd("stop navigation"))
        assertEquals(Command.TRANSLATOR_START, cmd("be my translator"))
        assertEquals(Command.TRANSLATOR_START, cmd("translate between Hindi and English"))
        assertEquals(Command.TRANSLATE, cmd("translate this sign"))
        assertEquals(Command.CAPTIONS_START, cmd("start live captions"))
        assertEquals(Command.CAPTIONS_STOP, cmd("stop translating"))
        assertEquals(Command.QR_SCAN, cmd("scan this QR code"))
        assertEquals(Command.CARD_SCAN, cmd("scan this business card"))
        assertEquals(Command.SCAN_DOC, cmd("scan this page"))
        assertEquals(Command.GUIDE_START, cmd("guide me"))
    }
}
