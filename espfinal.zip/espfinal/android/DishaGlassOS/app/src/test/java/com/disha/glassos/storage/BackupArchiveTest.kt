package com.disha.glassos.storage

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BackupArchiveTest {

    private fun wav(seconds: Double): ByteArray {
        val b = ByteArray(44 + (seconds * 32000).toInt())
        "RIFF".toByteArray().copyInto(b, 0)
        "WAVE".toByteArray().copyInto(b, 8)
        return b
    }

    private fun zip(vararg files: Pair<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> for ((n, d) in files) { z.putNextEntry(ZipEntry(n)); z.write(d); z.closeEntry() } }
        return out.toByteArray()
    }

    private fun fails(bytes: ByteArray): Boolean = try {
        BackupArchive.read(ByteArrayInputStream(bytes))
        false
    } catch (_: IOException) {
        true
    }

    @Test
    fun aBackupComesBackTheSame() {
        val files = linkedMapOf(
            BackupArchive.MANIFEST to "{\"format\":1}".toByteArray(),
            BackupArchive.SETTINGS to "{}".toByteArray(),
            "wake/phrase_0_1.wav" to wav(0.8),
            "wake/phrase_2_6.wav" to wav(1.1),
            "stores/places.json" to "[]".toByteArray(),
        )
        val out = ByteArrayOutputStream()
        BackupArchive.write(out, files)
        val back = BackupArchive.read(ByteArrayInputStream(out.toByteArray()))
        assertEquals(files.keys, back.keys)
        for ((k, v) in files) assertTrue(v.contentEquals(back.getValue(k)))
    }

    @Test
    fun onlyKnownNamesAreRead() {
        val back = BackupArchive.read(ByteArrayInputStream(zip(
            BackupArchive.MANIFEST to "{}".toByteArray(),
            "../shared_prefs/disha.xml" to "x".toByteArray(),
            "wake/../../evil.wav" to wav(1.0),
            "wake/phrase_0_1.wav/../x" to wav(1.0),
            "stores/secrets.json" to "[]".toByteArray(),
            "stores/events.json" to "[]".toByteArray(),
            "wake/sample_3.wav" to wav(1.0),          // the 0.7 recordings
            "future_feature.json" to "{}".toByteArray(), // a later version's file: skipped
        )))
        assertEquals(setOf(BackupArchive.MANIFEST, "stores/events.json", "wake/sample_3.wav"), back.keys)
    }

    @Test
    fun otherFilesAreRefused() {
        assertTrue(fails("just some text, not a zip".toByteArray()))
        assertTrue(fails(zip("stores/events.json" to "[]".toByteArray())))  // no manifest
        assertTrue(fails(zip(BackupArchive.MANIFEST to "{}".toByteArray(), "wake/phrase_0_1.wav" to ByteArray(9 * 1024 * 1024))))
        val refused = try {
            BackupArchive.write(ByteArrayOutputStream(), mapOf("../x" to ByteArray(1)))
            false
        } catch (_: IllegalArgumentException) {
            true
        }
        assertTrue(refused)
    }

    @Test
    fun recordingsMustBeRealWavs() {
        assertTrue(BackupArchive.isWav(wav(0.5)))
        assertEquals(false, BackupArchive.isWav(wav(0.01)))
        assertEquals(false, BackupArchive.isWav(ByteArray(20000)))
    }

    @Test
    fun secretsAndConsentsStayOnThePhone() {
        for (k in listOf("geminiKey", "voiceConsent", "aiImageConsent", "aiImageConsentFree", "notesAllowed")) {
            assertTrue(k in BackupArchive.PRIVATE_SETTINGS)
        }
    }
}
