package com.disha.glassos.skills

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class SkillsLogicTest {

    @Test
    fun barcodesWithCheckDigits() {
        assertEquals("5449000000996", Barcode.find("5 449000 000996"))      // Coca-Cola
        assertEquals("5449000000996", Barcode.find("The number is 5449000000996."))
        assertEquals("036000291452", Barcode.find("0 36000 29145 2"))       // UPC-A
        assertEquals("96385074", Barcode.find("9638 5074"))                 // EAN-8
        assertNull(Barcode.find("5449000000997"))                           // one digit misread
        assertNull(Barcode.find("NONE"))
        assertTrue(Barcode.valid("8901719110016"))
    }

    @Test
    fun foodVerdict() {
        // Coca-Cola Original as Open Food Facts reports it (2026-10-10)
        val coke = FoodText("Coca-Cola Original", "COCA-COLA SERVICES SA/NV", "330 ml", "e", 4, 42.4, 10.6, 0.0, 0.0, 0.0, emptyList(), isDrink = true)
        assertEquals(
            "Coca-Cola Original. Nutri-Score E, not a healthy choice. It's ultra-processed. Low in fat, saturated fat, salt. 42 calories per 100 ml.",
            coke.sentence(),
        )
        assertEquals("medium", coke.sugarLevel())  // 10.6 g: just under the 11.25 g drink limit
        val biscuit = FoodText("Glucose biscuits", "Parle", "", "", 0, 450.0, 25.0, 13.0, 6.0, 0.6, listOf("en:gluten", "en:milk"), isDrink = false)
        assertEquals(
            "Glucose biscuits by Parle. High in sugar 25 grams, saturated fat 6 grams per 100 g. 450 calories per 100 g. Contains gluten, milk.",
            biscuit.sentence(),
        )
    }

    private fun at(day: Int, hour: Int): Long {
        val c = Calendar.getInstance()
        c.set(2026, Calendar.OCTOBER, day, hour, 0, 0)  // 10 Oct 2026 is a Saturday
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    @Test
    fun timeRanges() {
        val now = at(10, 15)
        val today = TimeRange.parse("show the whiteboard photos from today", now)!!
        assertTrue(at(10, 9) in today)
        assertTrue(at(9, 23) !in today)
        val yesterday = TimeRange.parse("what did I do yesterday?", now)!!
        assertTrue(at(9, 12) in yesterday && at(10, 1) !in yesterday)
        val morning = TimeRange.parse("photos from this morning", now)!!
        assertTrue(at(10, 9) in morning && at(10, 13) !in morning)
        val week = TimeRange.parse("this week", now)!!
        assertTrue(at(5, 10) in week && at(4, 10) !in week)  // Monday 5 Oct is the first day
        val three = TimeRange.parse("last 3 days", now)!!
        assertTrue(at(8, 1) in three && at(7, 23) !in three)
        assertNull(TimeRange.parse("where are my keys", now))
    }

    @Test
    fun searchFindsByMeaningfulWords() {
        val items = listOf(
            TextSearch.Item(at(10, 9), "A whiteboard with a project timeline and sticky notes in a meeting room"),
            TextSearch.Item(at(10, 11), "Keys and a wallet on a wooden desk next to a laptop"),
            TextSearch.Item(at(9, 18), "A whiteboard covered with maths equations"),
            TextSearch.Item(at(10, 12), "A kitchen counter with a kettle and two cups"),
        )
        val now = at(10, 15)
        val keys = TextSearch.search(items, "where did I leave my keys?", null)
        assertEquals(1, keys.size)
        assertTrue(keys[0].text.startsWith("Keys"))
        val boards = TextSearch.search(items, "show the whiteboard photos from today", TimeRange.parse("today", now))
        assertEquals(1, boards.size)
        val allBoards = TextSearch.search(items, "whiteboards", null)
        assertEquals(2, allBoards.size)
        assertTrue(allBoards[0].time > allBoards[1].time)  // newest first
        assertEquals(3, TextSearch.search(items, "show today's photos", TimeRange.parse("today", now)).size)
    }
}
