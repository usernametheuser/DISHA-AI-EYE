package com.disha.glassos.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeParseTest {

    @Test
    fun durations() {
        assertEquals(300, TimeParse.durationSeconds("set a timer for 5 minutes"))
        assertEquals(300, TimeParse.durationSeconds("Set a timer for five minutes."))
        assertEquals(45, TimeParse.durationSeconds("timer for forty five seconds"))
        assertEquals(1800, TimeParse.durationSeconds("timer for half an hour"))
        assertEquals(5400, TimeParse.durationSeconds("an hour and a half"))
        assertEquals(5400, TimeParse.durationSeconds("1 hour 30 minutes"))
        assertEquals(90, TimeParse.durationSeconds("a minute and a half"))
        assertEquals(90, TimeParse.durationSeconds("one and a half minutes"))
        assertEquals(3600, TimeParse.durationSeconds("timer for an hour"))
        assertEquals(1200, TimeParse.durationSeconds("20 mins"))
        assertEquals(9000, TimeParse.durationSeconds("2.5 hours"))
        assertNull(TimeParse.durationSeconds("set a timer"))
        assertNull(TimeParse.durationSeconds("remind me at 6 pm"))
        assertNull(TimeParse.durationSeconds("I'm ready"))
    }

    @Test
    fun clockTimes() {
        val tenAm = 10 * 60
        assertEquals(8 * 3600, TimeParse.secondsUntilClock("at 6 pm", tenAm))
        assertEquals(8 * 3600 + 1800, TimeParse.secondsUntilClock("at 6:30 p.m.", tenAm))
        assertEquals(8 * 3600 + 1800, TimeParse.secondsUntilClock("at 18:30", tenAm))
        assertEquals(15 * 60, TimeParse.secondsUntilClock("at 10.15", tenAm))
        assertEquals(8 * 3600, TimeParse.secondsUntilClock("at 6", tenAm))          // 6 pm comes before 6 am
        assertEquals(20 * 3600, TimeParse.secondsUntilClock("at 6 am", tenAm))      // tomorrow morning
        assertEquals(2 * 3600, TimeParse.secondsUntilClock("at 12 pm", tenAm))
        assertNull(TimeParse.secondsUntilClock("in five minutes", tenAm))
    }

    @Test
    fun reminders() {
        val tenAm = 10 * 60
        var r = TimeParse.reminder("Remind me in 10 minutes to call Mom.", tenAm)!!
        assertEquals(600, r.seconds); assertEquals("call Mom", r.text)
        r = TimeParse.reminder("remind me to drink water in 20 minutes", tenAm)!!
        assertEquals(1200, r.seconds); assertEquals("drink water", r.text)
        r = TimeParse.reminder("Remind me at 6 pm to stretch for 5 minutes", tenAm)!!
        assertEquals(8 * 3600, r.seconds); assertEquals("stretch for 5 minutes", r.text)
        r = TimeParse.reminder("remind me to take my medicine at 6:30 p.m.", tenAm)!!
        assertEquals(8 * 3600 + 1800, r.seconds); assertEquals("take my medicine", r.text)
        r = TimeParse.reminder("remind me in an hour about the meeting", tenAm)!!
        assertEquals(3600, r.seconds); assertEquals("the meeting", r.text)
        r = TimeParse.reminder("remind me in five minutes", tenAm)!!
        assertEquals(300, r.seconds); assertEquals("", r.text)
        assertNull(TimeParse.reminder("remind me to buy milk", tenAm))
        assertNull(TimeParse.reminder("what time is it", tenAm))
    }

    @Test
    fun describes() {
        assertEquals("5 minutes", TimeParse.describe(300))
        assertEquals("1 hour and 30 minutes", TimeParse.describe(5400))
        assertEquals("1 minute and 30 seconds", TimeParse.describe(90))
        assertEquals("2 hours", TimeParse.describe(7200))
    }
}
