package com.disha.glassos.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SpeechSegmenterTest {

    private val rnd = Random(3)

    private fun stream(vararg parts: Pair<Boolean, Int>): ShortArray {
        val out = ArrayList<Short>()
        for ((loud, ms) in parts) {
            repeat(ms * 16) { i ->
                val v = (if (loud) 4000 * sin(2 * PI * 220 * i / 16000.0) else 0.0) + rnd.nextInt(-60, 61)
                out.add(v.toInt().toShort())
            }
        }
        return out.toShortArray()
    }

    private fun segments(pcm: ShortArray): List<SpeechSegmenter.Segment> {
        val seg = SpeechSegmenter()
        val frame = ShortArray(SpeechSegmenter.FRAME)
        val out = ArrayList<SpeechSegmenter.Segment>()
        var i = 0
        while (i + frame.size <= pcm.size) {
            System.arraycopy(pcm, i, frame, 0, frame.size)
            seg.feed(frame)?.let { out.add(it) }
            i += frame.size
        }
        return out
    }

    @Test
    fun cutsUtterancesWithSilenceAround() {
        val got = segments(stream(false to 1500, true to 800, false to 1500, true to 1200, false to 1500))
        assertEquals(2, got.size)
        assertTrue(got[0].speechMs in 700..820)
        assertTrue(got[1].speechMs in 1100..1220)
        // 300 ms before + speech + 250 ms after
        assertTrue(got[0].pcm.size / 16 in 1250..1450)
    }

    @Test
    fun ignoresClicksAndSilence() {
        assertEquals(0, segments(stream(false to 1500, true to 100, false to 1500)).size)
        assertEquals(0, segments(stream(false to 5000)).size)
    }
}
