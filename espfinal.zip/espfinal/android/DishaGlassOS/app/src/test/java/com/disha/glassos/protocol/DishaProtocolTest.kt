package com.disha.glassos.protocol

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Random

/** JVM tests for the protocol code (run with: gradlew test). Vectors match docs/PROTOCOL.md. */
class DishaProtocolTest {

    private fun hex(s: String): ByteArray = s.split("-").map { it.toInt(16).toByte() }.toByteArray()

    @Test
    fun crcCheckValues() {
        val check = "123456789".toByteArray()
        assertEquals(0x29B1, DishaProtocol.crc16(check, 0, check.size))
        assertEquals(0xCBF43926L, DishaProtocol.crc32(check, 0, check.size))
    }

    @Test
    fun captureFrameGoldenVector() {
        val msg = DishaProtocol.encode(DishaProtocol.CAPTURE_FRAME, 3, 0, DishaProtocol.captureFramePayload(true, 0))
        assertArrayEquals(hex("D1-5A-01-10-03-00-00-00-02-00-00-00-00-00-02-C9-01-00-BE-23-C2-58"), msg)
    }

    private fun deviceMessage(type: Int, seq: Int, ref: Int, payload: ByteArray): ByteArray {
        // encode() caps payloads at the phone->device limit; build larger device messages by hand.
        val out = ByteArray(DishaProtocol.HEADER_LEN + payload.size + DishaProtocol.TRAILER_LEN)
        out[0] = 0xD1.toByte(); out[1] = 0x5A; out[2] = 1; out[3] = type.toByte()
        DishaProtocol.putU16(out, 4, seq)
        DishaProtocol.putU16(out, 6, ref)
        DishaProtocol.putU32(out, 8, payload.size.toLong())
        DishaProtocol.putU16(out, 14, DishaProtocol.crc16(out, 0, 14))
        System.arraycopy(payload, 0, out, 16, payload.size)
        DishaProtocol.putU32(out, 16 + payload.size, DishaProtocol.crc32(payload, 0, payload.size))
        return out
    }

    private fun chunks(frameId: Long, jpeg: ByteArray, ref: Int, chunk: Int = 8192): List<ByteArray> {
        val crc = DishaProtocol.crc32(jpeg, 0, jpeg.size)
        val count = (jpeg.size + chunk - 1) / chunk
        return (0 until count).map { i ->
            val off = i * chunk
            val n = minOf(chunk, jpeg.size - off)
            val p = ByteArray(32 + n)
            DishaProtocol.putU32(p, 0, frameId)
            DishaProtocol.putU32(p, 4, jpeg.size.toLong())
            DishaProtocol.putU32(p, 8, off.toLong())
            DishaProtocol.putU16(p, 12, i)
            DishaProtocol.putU16(p, 14, count)
            DishaProtocol.putU16(p, 16, 320)
            DishaProtocol.putU16(p, 18, 240)
            p[20] = DishaProtocol.FORMAT_JPEG.toByte()
            var flags = DishaProtocol.FLAG_REQUESTED
            if (i == 0) flags = flags or DishaProtocol.FLAG_FIRST
            if (i == count - 1) flags = flags or DishaProtocol.FLAG_LAST
            p[21] = flags.toByte()
            DishaProtocol.putU16(p, 22, 45)
            DishaProtocol.putU32(p, 24, 1234)
            DishaProtocol.putU32(p, 28, crc)
            System.arraycopy(jpeg, off, p, 32, n)
            deviceMessage(DishaProtocol.FRAME_CHUNK, 10 + i, ref, p)
        }
    }

    @Test
    fun parserResyncsAndAssemblerRebuildsFrame() {
        val jpeg = ByteArray(20000).also { Random(42).nextBytes(it) }
        jpeg[0] = 0xFF.toByte(); jpeg[1] = 0xD8.toByte(); jpeg[19998] = 0xFF.toByte(); jpeg[19999] = 0xD9.toByte()

        val stream = ByteArrayOutputStream()
        stream.write(byteArrayOf(0x41, 0x42, 0xD1.toByte(), 0x00, 0x5A, 0xFF.toByte()))  // noise
        stream.write(deviceMessage(DishaProtocol.HELLO_ACK, 1, 7, "{\"proto\":1}".toByteArray()))
        stream.write(0)  // end-of-burst pad
        val bad = deviceMessage(DishaProtocol.STATUS, 2, 0, "{\"x\":1}".toByteArray())
        bad[20] = (bad[20].toInt() xor 0xFF).toByte()  // corrupt the payload
        stream.write(bad)
        chunks(5, jpeg, ref = 9).forEach { stream.write(it) }
        stream.write(0)
        val all = stream.toByteArray()

        val frames = ArrayList<FrameAssembler.Frame>()
        val types = ArrayList<Int>()
        val assembler = FrameAssembler(onDrop = {})
        val parser = MessageParser { m ->
            types.add(m.type)
            if (m.type == DishaProtocol.FRAME_CHUNK) assembler.onChunk(m.ref, m.payload)?.let { frames.add(it) }
        }
        var pos = 0
        val sizes = intArrayOf(1, 7, 13, 64, 3, 1000, 5000)
        var k = 0
        while (pos < all.size) {
            val n = minOf(sizes[k++ % sizes.size], all.size - pos)
            parser.feed(all, pos, n)
            pos += n
        }

        assertEquals(DishaProtocol.HELLO_ACK, types.first())
        assertTrue(DishaProtocol.STATUS !in types)
        assertTrue(parser.payloadCrcErrors >= 1)
        assertTrue(parser.padBytes >= 2)
        assertEquals(1, frames.size)
        assertArrayEquals(jpeg, frames[0].data)
        assertEquals(9, frames[0].ref)
        assertEquals(3, frames[0].chunkCount)
        assertTrue(frames[0].isRequested)
    }

    @Test
    fun outOfOrderChunkIsDropped() {
        val jpeg = ByteArray(20000).also { Random(1).nextBytes(it) }
        val payloads = chunks(6, jpeg, ref = 1).map { it.copyOfRange(16, it.size - 4) }
        val drops = ArrayList<String>()
        val assembler = FrameAssembler(onDrop = { drops.add(it) })
        assertNull(assembler.onChunk(1, payloads[0]))
        assertNull(assembler.onChunk(1, payloads[2]))
        assertEquals(1, drops.size)
    }
}
