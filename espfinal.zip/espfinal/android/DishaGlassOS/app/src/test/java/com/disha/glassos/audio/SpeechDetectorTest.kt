package com.disha.glassos.audio

import com.disha.glassos.audio.SpeechDetector.Result
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechDetectorTest {

    /** Feeds ms of frames at one loudness; returns the last result. */
    private fun SpeechDetector.run(ms: Int, rms: Double): Result {
        var r = Result.WAITING
        repeat(ms / SpeechDetector.FRAME_MS) { r = feed(rms) }
        return r
    }

    @Test
    fun findsASentenceInAQuietRoom() {
        val d = SpeechDetector(8000)
        assertEquals(Result.WAITING, d.run(600, 60.0))
        assertEquals(Result.SPEAKING, d.run(1500, 3000.0))
        assertEquals(Result.SPEAKING, d.run(300, 80.0))   // short pause between words
        assertEquals(Result.SPEAKING, d.run(800, 2500.0))
        assertEquals(Result.ENDED, d.run(1200, 70.0))     // 1 s of quiet ends it
        assertTrue(d.enoughSpeech)
        assertTrue(d.speechMs in 2500..2700)
        assertEquals(31, d.speechStartFrame)              // first loud frame after 600 ms
    }

    @Test
    fun speakingRightAfterTheBeepIsStillFound() {
        val d = SpeechDetector(8000)
        d.run(200, 3000.0)                                // during the ignored start
        var r = Result.WAITING
        for (i in 0 until 6) {                            // words with short gaps
            r = d.run(400, 3000.0)
            if (r == Result.ENDED) break
            d.run(100, 90.0)
        }
        assertEquals(Result.ENDED, d.run(1100, 90.0))
        assertTrue(d.enoughSpeech)
    }

    @Test
    fun silenceAndSteadyNoiseAreNotSpeech() {
        assertEquals(Result.NO_SPEECH, SpeechDetector(6000).run(6000, 60.0))
        assertEquals(Result.NO_SPEECH, SpeechDetector(6000).run(6000, 1500.0))  // fan or traffic
    }

    @Test
    fun aClickIsNotEnoughSpeech() {
        val d = SpeechDetector(8000)
        d.run(500, 60.0)
        d.run(120, 4000.0)
        assertEquals(Result.ENDED, d.run(1100, 60.0))
        assertEquals(false, d.enoughSpeech)
    }

    @Test
    fun tapToFinish() {
        val d = SpeechDetector(8000)
        d.run(400, 60.0)
        d.run(800, 3000.0)
        assertEquals(Result.ENDED, d.feed(3000.0, finish = true))
        val quiet = SpeechDetector(8000)
        quiet.run(400, 60.0)
        assertEquals(Result.NO_SPEECH, quiet.feed(60.0, finish = true))
    }

    @Test
    fun responseSpeedSetsTheEndingPause() {
        val quick = SpeechDetector(8000, endSilenceMs = 600)
        quick.run(400, 60.0)
        quick.run(1000, 3000.0)
        assertEquals(Result.SPEAKING, quick.run(560, 60.0))
        assertEquals(Result.ENDED, quick.run(60, 60.0))      // ends after 0.6 s of quiet
        val hold = SpeechDetector(60_000, endSilenceMs = 60_000, maxSpeechMs = 60_000)
        hold.run(400, 60.0)
        hold.run(1000, 3000.0)
        assertEquals(Result.SPEAKING, hold.run(5000, 60.0))  // hold to talk: pauses don't end it
        assertEquals(Result.ENDED, hold.feed(60.0, finish = true))
    }

    @Test
    fun longSpeechIsCutAt15Seconds() {
        val d = SpeechDetector(8000)
        d.run(400, 60.0)
        assertEquals(Result.ENDED, d.run(16000, 3000.0))
    }
}
