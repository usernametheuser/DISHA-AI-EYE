package com.disha.glassos.skills

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ReplyParseTest {

    private val names = listOf("Rahul", "Mom", "Office Group")

    private fun check(sentence: String, who: String?, text: String) {
        val r = ReplyParse.parse(sentence, names)!!
        assertEquals("$sentence (who)", who, r.conversation)
        assertEquals("$sentence (text)", text, r.text)
    }

    @Test
    fun parsesReplies() {
        check("Reply I'm on my way.", null, "I'm on my way")
        check("reply saying I'll call you later", null, "I'll call you later")
        check("Reply to Rahul saying I'm on my way", "Rahul", "I'm on my way")
        check("reply to Rahul: I'm on my way", "Rahul", "I'm on my way")
        check("reply to rahul I think that works", "Rahul", "I think that works")
        check("respond to Mom with see you soon", "Mom", "see you soon")
        check("reply to office group running late", "Office Group", "running late")
        check("reply to him I'm coming", null, "I'm coming")
        check("reply to Priya saying ok", "Priya", "ok")
        check("text back yes I'll be there", null, "yes I'll be there")
        check("reply", null, "")
        check("reply to Mom", "Mom", "")
        assertNull(ReplyParse.parse("what's the weather", names))
    }
}
