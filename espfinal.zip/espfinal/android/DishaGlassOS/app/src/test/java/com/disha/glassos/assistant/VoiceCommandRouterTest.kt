package com.disha.glassos.assistant

import com.disha.glassos.assistant.VoiceCommandRouter.Command
import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceCommandRouterTest {

    private val cases = listOf(
        "What am I looking at?" to Command.DESCRIBE_SCENE,
        "Describe what you see." to Command.DESCRIBE_SCENE,
        "what's this" to Command.DESCRIBE_SCENE,
        "Read this text." to Command.READ_TEXT,
        "what does it say" to Command.READ_TEXT,
        "Take a photo." to Command.TAKE_PHOTO,
        "take a picture of this" to Command.TAKE_PHOTO,
        "capture" to Command.TAKE_PHOTO,
        "Start recording." to Command.START_RECORDING,
        "Stop recording." to Command.STOP_RECORDING,
        "What is the status of my camera?" to Command.CAMERA_STATUS,
        "Stop speaking." to Command.STOP_SPEAKING,
        "stop" to Command.STOP_SPEAKING,
        "Disconnect camera." to Command.DISCONNECT_CAMERA,
        "connect the camera" to Command.CONNECT_CAMERA,
        "start live view" to Command.START_STREAM,
        "stop the stream" to Command.STOP_STREAM,
        "what time is it" to Command.TIME,
        "help" to Command.SOS,  // "Disha, help" (the assistant counts down and can be cancelled)
        "order me a pizza" to Command.UNKNOWN,
        "I'm ready" to Command.UNKNOWN,  // "ready" must not match "read"
        "how much storage is left" to Command.STORAGE_STATUS,
        "how many photos are on the SD card" to Command.STORAGE_STATUS,
        "who wrote Hamlet" to Command.UNKNOWN,
        "what's the date today" to Command.DATE,
        "what day is it" to Command.DATE,
        "how much battery is left" to Command.BATTERY,
        "Thank you." to Command.DISMISS,
        "that's all" to Command.DISMISS,
        "thanks, now read this sign for me please" to Command.READ_TEXT,  // long sentences are not dismissals
        "Nothing." to Command.DISMISS,
        "Set a timer for 5 minutes." to Command.TIMER,
        "timer for half an hour" to Command.TIMER,
        "Cancel the timer." to Command.CANCEL_TIMERS,
        "stop the timer" to Command.CANCEL_TIMERS,
        "How much time is left on my timer?" to Command.LIST_TIMERS,
        "Remind me in 10 minutes to call Mom." to Command.REMINDER,
        "remind me to buy milk" to Command.UNKNOWN,  // no time: the AI asks when
        "What's the weather in Delhi tomorrow?" to Command.WEATHER,
        "Is it going to rain today?" to Command.WEATHER,
        "What's the news?" to Command.NEWS,
        "read me the headlines" to Command.NEWS,
        "Good morning, brief me." to Command.BRIEFING,
        "Turn on the flashlight." to Command.FLASHLIGHT_ON,
        "torch off" to Command.FLASHLIGHT_OFF,
        "Volume up." to Command.VOLUME_UP,
        "a bit quieter please" to Command.VOLUME_DOWN,
        "Pause the music." to Command.MEDIA_PAUSE,
        "next song" to Command.MEDIA_NEXT,
        "Remember that my car is on level B2." to Command.REMEMBER,
        "Do you remember where I parked?" to Command.UNKNOWN,
        "What do you remember?" to Command.RECALL,
        "Forget about my parking spot." to Command.FORGET,
        "Stop watching." to Command.STOP_TASKS,
        "stop the photo series" to Command.STOP_TASKS,
        "Record a 10 second video." to Command.START_RECORDING,
        "Watch this for 10 seconds and tell me what happens." to Command.OBSERVE,
        "Tell me when you see a bus." to Command.UNKNOWN,  // background alert: the thinking model
        "Help me!" to Command.SOS,
        "I need help" to Command.SOS,
        "help me with my homework please" to Command.UNKNOWN,
        "What can you do?" to Command.HELP,
        "Who's calling?" to Command.CALL_WHO,
        "Answer." to Command.CALL_ANSWER,
        "reject the call" to Command.CALL_REJECT,
        "Read my WhatsApp messages" to Command.READ_MESSAGES,
        "Reply I'm on my way." to Command.REPLY_MESSAGE,
        "reply to Rahul saying ok" to Command.REPLY_MESSAGE,
        "Guide me." to Command.GUIDE_START,
        "stop guiding" to Command.GUIDE_STOP,
        "Take notes." to Command.NOTES_START,
        "Stop taking notes." to Command.NOTES_STOP,
        "stop recording the meeting" to Command.NOTES_STOP,
        "Start remembering what I see." to Command.MEMORY_LOG_ON,
        "What did I do today?" to Command.DIARY,
        "Where did I leave my keys?" to Command.FIND_OBJECT,
        "Show the whiteboard photos from today." to Command.GALLERY_SEARCH,
        "Translate this." to Command.TRANSLATE,
        "What does this say in English?" to Command.TRANSLATE,
        "Is this healthy?" to Command.FOOD,
        "scan the barcode" to Command.FOOD,
        "how many calories in this" to Command.FOOD,
        "what are the ingredients of biryani" to Command.UNKNOWN,
        "Which note is this?" to Command.CURRENCY,
        "Scan this page." to Command.SCAN_DOC,
        "Summarise it." to Command.DOC_SUMMARY,
        "read it back" to Command.DOC_READ,
    )

    @Test
    fun yesAndNo() {
        assertEquals(true, VoiceCommandRouter.isYes("Yes, send it."))
        assertEquals(true, VoiceCommandRouter.isYes("haan"))
        assertEquals(false, VoiceCommandRouter.isYes("No, don't send it"))
        assertEquals(true, VoiceCommandRouter.isNo("No, don't send it"))
        assertEquals(true, VoiceCommandRouter.isNo("Cancel!"))
        assertEquals(false, VoiceCommandRouter.isYes("what's the weather like in Delhi today and tomorrow okay"))
    }

    @Test
    fun parsesTheRequiredCommands() {
        for ((sentence, expected) in cases) {
            assertEquals(sentence, expected, VoiceCommandRouter.parse(sentence))
        }
    }

    @Test
    fun noticesSeveralRequests() {
        assertEquals(true, VoiceCommandRouter.hasSeveralParts("can you snap a pic and also start recording"))
        assertEquals(true, VoiceCommandRouter.hasSeveralParts("turn the torch on and set a 2 minute timer"))
        assertEquals(false, VoiceCommandRouter.hasSeveralParts("take a photo"))
        assertEquals(false, VoiceCommandRouter.hasSeveralParts("rock and roll"))
    }

    @Test
    fun extractsDetails() {
        assertEquals("my car is on level B2", VoiceCommandRouter.rememberText("Remember that my car is on level B2."))
        assertEquals("the wifi password is on the fridge", VoiceCommandRouter.rememberText("make a note that the wifi password is on the fridge"))
        assertEquals("my parking spot", VoiceCommandRouter.forgetText("Forget about my parking spot."))
        assertEquals("Delhi", VoiceCommandRouter.weatherCity("What's the weather in Delhi tomorrow?"))
        assertEquals("New York", VoiceCommandRouter.weatherCity("weather in new york"))
        assertEquals(null, VoiceCommandRouter.weatherCity("what's the weather like"))
        assertEquals(null, VoiceCommandRouter.weatherCity("what's the weather in the morning"))
        assertEquals("cricket", VoiceCommandRouter.newsTopic("Any news about cricket?"))
        assertEquals(null, VoiceCommandRouter.newsTopic("what's the news"))
    }

    @Test
    fun stripsTheWakeName() {
        val names = listOf("Friday", "Disha")
        assertEquals("what am I looking at?", VoiceCommandRouter.stripName("Hey Friday, what am I looking at?", names))
        assertEquals("take a photo", VoiceCommandRouter.stripName("OK Disha take a photo", names))
        assertEquals("read this", VoiceCommandRouter.stripName("friday. read this", names))
        assertEquals("", VoiceCommandRouter.stripName("Hey Friday!", names))
        assertEquals("Is it Friday today?", VoiceCommandRouter.stripName("Is it Friday today?", names))
        assertEquals("Fridays are fun", VoiceCommandRouter.stripName("Fridays are fun", names))
        assertEquals("hello there", VoiceCommandRouter.stripName("hello there", names))
        val disha = VoiceCommandRouter.NAME_VARIANTS
        assertEquals("", VoiceCommandRouter.stripName("Hello Disha.", disha))
        assertEquals("", VoiceCommandRouter.stripName("Hi, Disha!", disha))
        assertEquals("take a photo", VoiceCommandRouter.stripName("Diha, take a photo", disha))
        assertEquals("what is this?", VoiceCommandRouter.stripName("Hey Deesha what is this?", disha))
        assertEquals("यह क्या है?", VoiceCommandRouter.stripName("दिशा, यह क्या है?", disha))
        assertEquals("Dishonest people", VoiceCommandRouter.stripName("Dishonest people", disha))
    }

    @Test
    fun visualQuestionsGetAPicture() {
        assertEquals(true, VoiceCommandRouter.looksVisual("what colour is this shirt"))
        assertEquals(true, VoiceCommandRouter.looksVisual("how many people are in front of me"))
        assertEquals(true, VoiceCommandRouter.looksVisual("is there a step here"))
        assertEquals(false, VoiceCommandRouter.looksVisual("who wrote Hamlet"))
        assertEquals(false, VoiceCommandRouter.looksVisual("tell me a joke"))
        assertEquals(true, VoiceCommandRouter.looksVisual("analyse what's in my hand"))
    }
}
