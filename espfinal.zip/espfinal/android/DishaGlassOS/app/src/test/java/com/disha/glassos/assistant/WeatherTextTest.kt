package com.disha.glassos.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class WeatherTextTest {

    // Values from a real Open-Meteo answer for New Delhi (2026-10-10).
    private val w = WeatherText("New Delhi", 31.1, 33.2, 2, 8.2, 32.9, 23.8, 35, 33.4, 24.1, 10, 61)

    @Test
    fun saysTodayAndTomorrow() {
        assertEquals(
            "In New Delhi it's 31 degrees, with partly cloudy skies. Today's high is 33 degrees and there's a 35 percent chance of rain.",
            w.sentence(tomorrow = false),
        )
        assertEquals("Tomorrow in New Delhi: light rain, between 24 degrees and 33 degrees.", w.sentence(tomorrow = true))
    }

    @Test
    fun mentionsFeelsLikeOnlyWhenDifferent() {
        val humid = WeatherText("Chennai", 30.0, 36.0, 0, 5.0, 33.0, 27.0, 0, 33.0, 27.0, 0, 0)
        assertEquals("In Chennai it's 30 degrees, feels like 36 degrees, with clear skies. Today's high is 33 degrees.", humid.sentence(false))
    }
}
