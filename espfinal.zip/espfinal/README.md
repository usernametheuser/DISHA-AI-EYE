# DISHA GLASS OS

**AI smart glasses for everyone: an ESP32-S3 camera on a pair of glasses, wired by USB to an Android phone, with a voice assistant called Disha that sees, reads, translates, guides and remembers. No API key needed.**

Say *"Disha, what am I looking at?"* and the answer comes in your earbuds. The camera talks to the phone over a USB cable (no Wi-Fi or Bluetooth needed). The AI runs on free services that need no account, and a free Groq key can be added to make it faster.

---

## What Disha can do

| Area | Examples |
|---|---|
| **See and read** | "What am I looking at?", "read this", "translate this sign", "which note is this?", "is this healthy?" (barcode → Open Food Facts) |
| **Documents** | "Make a document": scans page after page by itself, then "done" → one PDF. "Summarise it", "read it back" |
| **Camera** | Photos and video to the phone or the glasses' microSD card, "record 30 seconds", "save that" (last 30 s instant replay), time-lapse, "tell me when you see a bus" |
| **Getting around** | "Take me to the nearest metro station": turn-by-turn walking directions with OpenStreetMap, plus obstacle warnings from the camera. Guide mode for blind and low-vision users |
| **People** | Live captions for the hard of hearing, a two-way translator (Hindi, English, Tamil and more), business card → contact, QR codes (UPI codes are only read out, never paid) |
| **Phone** | Read and reply to WhatsApp/SMS (only after you say yes), answer or reject calls, timers, reminders, weather, news, Wikipedia, torch, volume, music |
| **Memory** | "Remember my car is on B2", "where did I leave my keys?", a spoken diary of your day, a searchable smart gallery |
| **Safety** | "Disha, help": an SOS SMS with your location after a 10-second countdown you can cancel |
| **Presenting** | "Next slide", "go to slide 5" move PowerPoint or PDF slides; a live web dashboard for a laptop or projector |
| **Hands-free** | Wakes on your own voice saying "Disha" / "Hello Disha" (trained on the phone, never uploaded) |

Two ways to run it:
1. **Glasses + Android phone over USB** (main): the full assistant.
2. **Glasses alone over Wi-Fi** (optional demo mode, off by default): live view and a Disha page in any browser.

## Hardware

- ESP32-S3-WROOM CAM board (N16R8: 16 MB flash, 8 MB PSRAM) with a GC2145 camera, microSD slot
- An Android phone with USB OTG (tested setup: Tecno Pova Curve 2, Android 16) and a USB-C OTG adapter
- Bluetooth earbuds (optional; the phone's speaker and microphone also work)

## Get started

1. **Flash the glasses.** Open `firmware/DISHA-CAM/DISHA-CAM.ino` in Arduino IDE 2 (esp32 core 3.3.12, board *ESP32S3 Dev Module*, USB Mode *USB-OTG (TinyUSB)*, PSRAM *OPI*, Flash *16MB*, Partition *16M Flash (3MB APP/9.9MB FATFS)*), or run:
   ```bash
   powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM9
   ```
2. **Install the app.** Download `DishaGlassOS-debug.apk` from this repository's **Releases** page and install it on the phone (allow "Install unknown apps").
3. **Connect.** Phone → OTG adapter → USB cable → the board's **USB-OTG** port. Wait for **CAMERA READY**, tap the orb and talk.

The full user guide, with every command, the test checklist and troubleshooting, is in **[docs/GUIDE.md](docs/GUIDE.md)**. The USB protocol is described in [docs/PROTOCOL.md](docs/PROTOCOL.md).

## Build it yourself

| Part | How |
|---|---|
| Firmware | Arduino IDE 2 or `tools/flash_firmware.ps1 -CompileOnly` |
| Android app (Android Studio) | Open `android/DishaGlassOS`, let Gradle sync, Run |
| Android app (no Android Studio) | `tools/build_apk.ps1` (needs JDK 17, Android SDK 34, Kotlin 2.0.21 and ZXing core 3.5.3; paths at the top of the script). The first time on a new PC, add `-NewSigningKey` |
| Slide helper for PowerPoint | `tools/disha_presenter.ps1 -Url <address shown in the app>` |

The signing key is not in this repository (`tools/signing/README.txt` explains why it matters for updates). Keep your own copy of it outside the repository.

## Repository layout

```
firmware/DISHA-CAM/     ESP32-S3 camera firmware (Arduino): USB link, camera, microSD, Wi-Fi web mode
android/DishaGlassOS/   Android app (Kotlin): USB link, voice assistant, AI, skills, web dashboard
docs/                   User guide (GUIDE.md) and USB protocol (PROTOCOL.md)
tools/                  Build, flash and test scripts, PowerPoint slide helper
```

## Privacy

- Nothing is sent anywhere until you allow it in the app: camera pictures to the AI, voice to the speech service, meeting notes. Each permission is asked separately.
- The wake word, memory, notes and backups stay on the phone.
- API keys you paste stay on the phone and are never included in backups.
- An LED on the glasses lights whenever pictures leave the camera.

## Status

This is a hackathon/DIY project under active development. The camera link and photos have been checked on the real board and phone; many newer features have so far only been tested on a PC. See the *Verification status* table in [docs/GUIDE.md](docs/GUIDE.md).
