<#
  Builds DishaGlassOS-debug.apk without Gradle / Android Studio:
  aapt2 (resources) -> javac (R, BuildConfig) -> kotlinc (app) -> d8 (dex) -> zipalign -> apksigner.

  Needs (defaults are the folders already on this PC):
    -Jdk      JDK 17                         %LOCALAPPDATA%\TiFinalBuild\jdk
    -Sdk      Android SDK: platforms\android-34, build-tools\34.0.0
                                             %LOCALAPPDATA%\TiFinalBuild\sdk
    -Kotlinc  Kotlin 2.0.21 compiler          %LOCALAPPDATA%\DishaBuild\kotlinc-2.0.21\kotlinc

  Usage:  powershell -ExecutionPolicy Bypass -File tools\build_apk.ps1
  Output: build\DishaGlassOS-debug.apk (signed with tools\signing\disha-debug.keystore)

  KEEPING THE USER'S DATA ON UPDATES: Android installs an update over the app, and keeps its data
  (wake-word training, memory, settings), only if the new APK has the same signing key and a
  higher versionCode. So every build is signed with tools\signing\disha-debug.keystore (keep a
  copy of it somewhere safe) and $versionCode below must go up with every release. The script
  will not make a new key on its own: a new key means the phone must uninstall the app first,
  which deletes the training. Pass -NewSigningKey only for a brand-new installation.

  Android Studio / Gradle (android\DishaGlassOS) signs with the same key file.
#>
param(
  [string]$Jdk = "$env:LOCALAPPDATA\TiFinalBuild\jdk",
  [string]$Sdk = "$env:LOCALAPPDATA\TiFinalBuild\sdk",
  [string]$Kotlinc = "$env:LOCALAPPDATA\DishaBuild\kotlinc-2.0.21\kotlinc",
  [string]$Keystore = '',
  [switch]$NewSigningKey
)
$ErrorActionPreference = 'Continue'  # the tools print progress on stderr; failures are checked via $LASTEXITCODE
$root = Split-Path -Parent $PSScriptRoot
$app = Join-Path $root 'android\DishaGlassOS\app\src\main'
$out = Join-Path $root 'build\android'
$apk = Join-Path $root 'build\DishaGlassOS-debug.apk'
$bt = Join-Path $Sdk 'build-tools\34.0.0'
$jar = Join-Path $Sdk 'platforms\android-34\android.jar'
$stdlib = Join-Path $Kotlinc 'lib\kotlin-stdlib.jar'
# Libraries bundled in the app: ZXing core (QR codes and barcodes, read on the phone, offline).
$libs = @("$env:LOCALAPPDATA\DishaBuild\libs\zxing-core-3.5.3.jar")
if (-not $Keystore) { $Keystore = Join-Path $root 'tools\signing\disha-debug.keystore' }
$oldKeystore = "$env:LOCALAPPDATA\DishaBuild\disha-debug.keystore"  # where builds before 0.11 kept it

$versionCode = 12
$versionName = '0.12.0'
$appId = 'com.disha.glassos'

foreach ($p in @("$Jdk\bin\javac.exe", $jar, "$bt\aapt2.exe", "$bt\d8.bat", "$Kotlinc\bin\kotlinc.bat", $stdlib) + $libs) {
  if (-not (Test-Path $p)) { throw "Missing $p (ZXing: https://repo1.maven.org/maven2/com/google/zxing/core/3.5.3/core-3.5.3.jar)" }
}
$env:JAVA_HOME = $Jdk
$env:PATH = "$Jdk\bin;$bt;$env:PATH"

function Step($n, $text) { Write-Host "[$n/7] $text" -ForegroundColor Cyan }
function Check($what) { if ($LASTEXITCODE) { throw "$what failed (exit $LASTEXITCODE)" } }

if (Test-Path $out) {
  for ($i = 0; $i -lt 10; $i++) {  # antivirus can hold new files for a moment
    try { Remove-Item $out -Recurse -Force -ErrorAction Stop; break } catch { Start-Sleep -Milliseconds 500 }
  }
}
New-Item -ItemType Directory -Force "$out\gen", "$out\classes", "$out\dex" | Out-Null

Step 1 'resources (aapt2)'
# AGP injects package, versions and uses-sdk into the manifest; do the same here.
$manifest = [IO.File]::ReadAllText("$app\AndroidManifest.xml")
$manifest = $manifest.Replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
  "<manifest xmlns:android=`"http://schemas.android.com/apk/res/android`" package=`"$appId`" android:versionCode=`"$versionCode`" android:versionName=`"$versionName`">`n    <uses-sdk android:minSdkVersion=`"21`" android:targetSdkVersion=`"34`" />")
[IO.File]::WriteAllText("$out\AndroidManifest.xml", $manifest)
& aapt2 compile --dir "$app\res" -o "$out\res.zip"; Check 'aapt2 compile'
& aapt2 link -o "$out\base.apk" -I $jar --manifest "$out\AndroidManifest.xml" --java "$out\gen" "$out\res.zip"; Check 'aapt2 link'

Step 2 'R and BuildConfig (javac)'
$bcDir = "$out\gen\com\disha\glassos"
New-Item -ItemType Directory -Force $bcDir | Out-Null
@"
package com.disha.glassos;
public final class BuildConfig {
  public static final boolean DEBUG = true;
  public static final String APPLICATION_ID = "$appId";
  public static final String BUILD_TYPE = "debug";
  public static final int VERSION_CODE = $versionCode;
  public static final String VERSION_NAME = "$versionName";
}
"@ | Set-Content -Path "$bcDir\BuildConfig.java" -Encoding ascii
$javaFiles = @(Get-ChildItem "$out\gen" -Recurse -Filter *.java | ForEach-Object { $_.FullName })
& javac -nowarn -Xlint:-options --release 8 -encoding UTF-8 -classpath $jar -d "$out\classes" @javaFiles; Check 'javac'

Step 3 'Kotlin (kotlinc)'
function Fwd($p) { "`"$($p -replace '\\', '/')`"" }  # quoted, forward slashes (argfile-safe)
$ktFiles = @(Get-ChildItem "$app\java" -Recurse -Filter *.kt | ForEach-Object { Fwd $_.FullName })
# Arguments go through a file: kotlinc.bat is a batch file, and cmd would split the classpath at ';'.
$ktArgs = @('-no-jdk', '-jvm-target', '1.8', '-classpath', (Fwd ((@($jar, "$out\classes") + $libs) -join ';')), '-d', (Fwd "$out\classes")) + $ktFiles
[IO.File]::WriteAllLines("$out\kotlinc.args", [string[]]$ktArgs)
& "$Kotlinc\bin\kotlinc.bat" "@$out\kotlinc.args"; Check 'kotlinc'

Step 4 'dex (d8)'
& jar --create --file "$out\classes.jar" -C "$out\classes" .; Check 'jar'
# d8 from build-tools 34 predates Kotlin 2.0 and warns (with stack traces) that it cannot parse
# Kotlin 2.0 metadata annotations. It leaves them untouched; they only matter for kotlin-reflect,
# which the app does not use. Those warnings are summarised; anything else is printed.
$metaWarnings = 0
& "$bt\d8.bat" --release --min-api 21 --lib $jar --output "$out\dex" "$out\classes.jar" $stdlib @libs 2>&1 | ForEach-Object {
  $line = "$_"
  if ($line -match 'kotlin metadata|kotlin\.Metadata|Should never be called|R8_\d|^\s+at |RemoteException|kotlin-d8-r8-versions') {
    if ($line -match 'malformed kotlin\.Metadata') { $metaWarnings++ }
  } elseif ($line.Trim()) { Write-Host $line }
}
Check 'd8'
if ($metaWarnings) { Write-Host "  (d8: $metaWarnings 'cannot parse Kotlin 2.0 metadata' warnings - harmless, see comment above)" }

Step 5 'package'
Copy-Item "$out\base.apk" "$out\unsigned.apk"
& jar --update --file "$out\unsigned.apk" --no-manifest -C "$out\dex" .; Check 'adding dex files'
& zipalign -f -p 4 "$out\unsigned.apk" "$out\aligned.apk"; Check 'zipalign'

Step 6 'sign'
if (-not (Test-Path $Keystore)) {
  New-Item -ItemType Directory -Force (Split-Path $Keystore) | Out-Null
  if (Test-Path $oldKeystore) {
    Copy-Item $oldKeystore $Keystore  # the key the installed app was signed with
  } elseif ($NewSigningKey) {
    & keytool -genkeypair -keystore $Keystore -alias disha -keyalg RSA -keysize 2048 -validity 10000 `
      -storepass disha-debug -keypass disha-debug -dname 'CN=DISHA GLASS OS debug' 2>&1 | Out-Null
    Check 'keytool'
    Write-Host "  New signing key $Keystore - back it up; every later build must use it." -ForegroundColor Yellow
  } else {
    throw ("Signing key $Keystore not found. Put the backed-up disha-debug.keystore there: an APK signed " +
      "with a different key cannot update the installed app, and uninstalling it deletes the wake-word " +
      "training. Use -NewSigningKey only for a brand-new installation.")
  }
}
New-Item -ItemType Directory -Force (Split-Path $apk) | Out-Null
& "$bt\apksigner.bat" sign --ks $Keystore --ks-pass pass:disha-debug --key-pass pass:disha-debug --out $apk "$out\aligned.apk"; Check 'apksigner'

Step 7 'verify'
& "$bt\apksigner.bat" verify $apk; Check 'apksigner verify'
& zipalign -c -p 4 $apk; Check 'zipalign check'
Write-Host ('Built {0} ({1:N0} KB)' -f $apk, ((Get-Item $apk).Length / 1KB)) -ForegroundColor Green
