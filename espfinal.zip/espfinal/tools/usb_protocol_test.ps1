<#
  Phase 3 bench test: talks the DISHA USB protocol to the board from a PC, so the firmware's
  USB side can be checked without Android.

  Works with the FALLBACK firmware build only (Arduino Tools > USB Mode: "Hardware CDC and
  JTAG"): that build appears on Windows as a COM port on the board's USB-OTG connector.
  The primary build (USB-OTG / TinyUSB vendor interface) has no Windows driver; test it on
  the phone instead.

  Usage:
    powershell -ExecutionPolicy Bypass -File tools\usb_protocol_test.ps1 -Port COM7
  Options: -Frames 3  -StreamSeconds 5  -StreamFps 5
#>
param(
  [Parameter(Mandatory = $true)][string]$Port,
  [int]$Frames = 3,
  [int]$StreamSeconds = 5,
  [int]$StreamFps = 5,
  [string]$OutDir = [Environment]::GetFolderPath('MyPictures')
)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'DishaProtocol.cs')

$HELLO = 0x01; $PING = 0x02; $GET_STATUS = 0x03; $CAPTURE_FRAME = 0x10; $START_STREAM = 0x11; $STOP_STREAM = 0x12
$RESULT = 0x80; $HELLO_ACK = 0x81; $STATUS = 0x83; $FRAME_CHUNK = 0x90; $LOG = 0xA0

$sp = New-Object System.IO.Ports.SerialPort $Port, 115200
$sp.DtrEnable = $false  # certain DTR/RTS sequences reset the ESP32-S3 through USB Serial/JTAG
$sp.RtsEnable = $false
$sp.Open()
$parser = New-Object DishaParser
$assembler = New-Object DishaFrameAssembler
$readBuf = New-Object byte[] 16384
$script:seq = 0

function Send-Msg([int]$type, [byte[]]$payload) {
  $script:seq = ($script:seq + 1) -band 0xFFFF
  if ($script:seq -eq 0) { $script:seq = 1 }
  $m = [DishaCodec]::Encode($type, $script:seq, 0, $payload)
  $sp.Write($m, 0, $m.Length)
  return $script:seq
}

# Reads for up to $ms milliseconds and returns the messages received (LOG lines are printed).
function Read-Msgs([int]$ms) {
  $list = New-Object 'System.Collections.Generic.List[DishaMessage]'
  $sw = [Diagnostics.Stopwatch]::StartNew()
  do {
    $avail = $sp.BytesToRead
    if ($avail -gt 0) {
      $n = $sp.Read($readBuf, 0, [Math]::Min($readBuf.Length, $avail))
      foreach ($m in $parser.Feed($readBuf, $n)) {
        if ($m.Type -eq $LOG) { Write-Host ('  board: ' + [Text.Encoding]::UTF8.GetString($m.Payload)) -ForegroundColor DarkGray }
        else { $list.Add($m) }
      }
      if ($list.Count -gt 0) { break }
    } else {
      Start-Sleep -Milliseconds 2
    }
  } while ($sw.ElapsedMilliseconds -lt $ms)
  return ,$list
}

function Show-Result($m) {
  $status = $m.Payload[0]; $cmd = $m.Payload[1]
  $text = [Text.Encoding]::UTF8.GetString($m.Payload, 2, $m.Payload.Length - 2)
  $color = if ($status -eq 0) { 'Green' } else { 'Yellow' }
  Write-Host ('  RESULT for 0x{0:X2}: status {1} - {2}' -f $cmd, $status, $text) -ForegroundColor $color
  return $status
}

function Wait-Json([int]$type, [int]$ref, [int]$timeoutMs) {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while ($sw.ElapsedMilliseconds -lt $timeoutMs) {
    foreach ($m in (Read-Msgs 100)) {
      if ($m.Type -eq $RESULT -and $m.Ref -eq $ref) { [void](Show-Result $m); return $null }
      if ($m.Type -eq $type -and $m.Ref -eq $ref) { return ([Text.Encoding]::UTF8.GetString($m.Payload) | ConvertFrom-Json) }
    }
  }
  return $null
}

function Wait-Frame([int]$ref, [int]$timeoutMs) {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while ($sw.ElapsedMilliseconds -lt $timeoutMs) {
    foreach ($m in (Read-Msgs 100)) {
      if ($m.Type -eq $FRAME_CHUNK) {
        $f = $assembler.OnChunk($m.Ref, $m.Payload)
        if ($f -and $f.Ref -eq $ref) { return $f }
      } elseif ($m.Type -eq $RESULT -and $m.Ref -eq $ref) {
        [void](Show-Result $m)
        return $null
      }
    }
  }
  return $null
}

function Test-Jpeg([byte[]]$d) {
  return $d.Length -ge 4 -and $d[0] -eq 0xFF -and $d[1] -eq 0xD8 -and $d[$d.Length - 2] -eq 0xFF -and $d[$d.Length - 1] -eq 0xD9
}

try {
  Write-Host "1) HELLO on $Port"
  $hello = $null
  for ($i = 1; $i -le 3 -and -not $hello; $i++) {
    $s = Send-Msg $HELLO ([Text.Encoding]::UTF8.GetBytes('PC protocol test'))
    $hello = Wait-Json $HELLO_ACK $s 2000
  }
  if (-not $hello) { throw 'No HELLO_ACK. Is the HW CDC build of DISHA-CAM running, and is this the USB-OTG port?' }
  Write-Host ('  {0} {1}, protocol {2}, transport {3}, camera {4} {5}x{6}, last reset: {7}' -f $hello.fw, $hello.fwVersion,
    $hello.proto, $hello.transport, $hello.camera.state, $hello.camera.width, $hello.camera.height, $hello.resetReason) -ForegroundColor Green

  $state = $hello.camera.state
  for ($i = 0; $i -lt 10 -and $state -ne 'ready'; $i++) {
    Start-Sleep -Milliseconds 1000
    $st = Wait-Json $STATUS (Send-Msg $GET_STATUS $null) 2000
    if ($st) { $state = $st.camera.state; Write-Host "  camera: $state $($st.camera.problem)" }
  }
  if ($state -ne 'ready') { throw "Camera not ready ($state)" }

  Write-Host "2) CAPTURE_FRAME x $Frames"
  for ($i = 1; $i -le $Frames; $i++) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $s = Send-Msg $CAPTURE_FRAME ([byte[]](1, 0))
    $f = Wait-Frame $s 8000
    if (-not $f) { throw "No frame for capture $i ($($assembler.LastDrop))" }
    $ms = $sw.ElapsedMilliseconds
    if (-not (Test-Jpeg $f.Data)) { throw "Frame $($f.FrameId) is not a complete JPEG" }
    $file = Join-Path $OutDir ('DISHA_usb_{0}_{1}.jpg' -f (Get-Date -Format 'yyyyMMdd_HHmmss'), $f.FrameId)
    [IO.File]::WriteAllBytes($file, $f.Data)
    Write-Host ('  frame #{0}: {1}x{2} JPEG {3} bytes in {4} chunk(s), CRC OK, encode {5} ms, request->frame {6} ms -> {7}' -f
      $f.FrameId, $f.Width, $f.Height, $f.Data.Length, $f.Chunks, $f.EncodeMs, $ms, $file) -ForegroundColor Green
  }

  if ($StreamSeconds -gt 0) {
    Write-Host "3) START_STREAM $StreamFps fps for $StreamSeconds s"
    $s = Send-Msg $START_STREAM ([byte[]]($StreamFps, 0))
    $count = 0; $bytes = 0
    $sw = [Diagnostics.Stopwatch]::StartNew(); $lastPing = 0
    while ($sw.ElapsedMilliseconds -lt $StreamSeconds * 1000) {
      if ($sw.ElapsedMilliseconds - $lastPing -ge 1000) { [void](Send-Msg $PING ([byte[]](1, 2, 3, 4))); $lastPing = $sw.ElapsedMilliseconds }
      foreach ($m in (Read-Msgs 50)) {
        if ($m.Type -eq $FRAME_CHUNK) {
          $f = $assembler.OnChunk($m.Ref, $m.Payload)
          if ($f -and ($f.Flags -band 0x08)) { $count++; $bytes += $f.Data.Length }
        } elseif ($m.Type -eq $RESULT) { [void](Show-Result $m) }
      }
    }
    $secs = $sw.ElapsedMilliseconds / 1000.0
    $s = Send-Msg $STOP_STREAM $null
    [void](Read-Msgs 500)
    Write-Host ('  {0} stream frames in {1:N1} s = {2:N1} fps, {3:N1} KB/s of JPEG data' -f $count, $secs, ($count / $secs), ($bytes / 1024.0 / $secs)) -ForegroundColor Green
  }

  Write-Host '4) PING round trip'
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $s = Send-Msg $PING ([byte[]](9, 9))
  $pong = $null
  while (-not $pong -and $sw.ElapsedMilliseconds -lt 2000) {
    foreach ($m in (Read-Msgs 50)) { if ($m.Type -eq 0x82 -and $m.Ref -eq $s) { $pong = $m } }
  }
  if ($pong) { Write-Host "  RTT $($sw.ElapsedMilliseconds) ms" -ForegroundColor Green } else { Write-Host '  no PONG' -ForegroundColor Yellow }
} finally {
  Write-Host ('Parser: {0} messages, {1} header CRC errors, {2} payload CRC errors, {3} resync bytes, {4} pad bytes; frames OK {5}, dropped {6}' -f
    $parser.Messages, $parser.HeaderCrcErrors, $parser.PayloadCrcErrors, $parser.SkippedBytes, $parser.PadBytes, $assembler.Completed, $assembler.Dropped)
  $sp.Close()
}
