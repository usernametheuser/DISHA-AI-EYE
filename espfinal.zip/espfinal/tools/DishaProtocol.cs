// DISHA USB protocol v1 for the PC test tools (C# 5, compiled by Windows PowerShell's Add-Type).
// Mirrors firmware/DISHA-CAM/src/protocol and the Android app. See docs/PROTOCOL.md.
using System;
using System.Collections.Generic;

public static class DishaCrc
{
    static readonly uint[] Table = MakeTable();

    static uint[] MakeTable()
    {
        uint[] t = new uint[256];
        for (uint i = 0; i < 256; i++)
        {
            uint c = i;
            for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            t[i] = c;
        }
        return t;
    }

    // CRC-16/CCITT-FALSE. "123456789" -> 0x29B1
    public static int Crc16(byte[] d, int off, int len)
    {
        int crc = 0xFFFF;
        for (int i = off; i < off + len; i++)
        {
            crc ^= d[i] << 8;
            for (int b = 0; b < 8; b++) crc = (crc & 0x8000) != 0 ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
        }
        return crc;
    }

    // CRC-32/ISO-HDLC (zlib). "123456789" -> 0xCBF43926
    public static uint Crc32(byte[] d, int off, int len)
    {
        uint c = 0xFFFFFFFFu;
        for (int i = off; i < off + len; i++) c = Table[(c ^ d[i]) & 0xFF] ^ (c >> 8);
        return c ^ 0xFFFFFFFFu;
    }
}

public class DishaMessage
{
    public int Version;
    public int Type;
    public int Seq;
    public int Ref;
    public byte[] Payload;
}

public static class DishaCodec
{
    public const int HeaderLen = 16;
    public const int TrailerLen = 4;
    public const int MaxDevicePayload = 16384;

    public static int U16(byte[] b, int o) { return b[o] | (b[o + 1] << 8); }
    public static uint U32(byte[] b, int o) { return (uint)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)); }
    static void Put16(byte[] b, int o, int v) { b[o] = (byte)v; b[o + 1] = (byte)(v >> 8); }
    static void Put32(byte[] b, int o, uint v) { b[o] = (byte)v; b[o + 1] = (byte)(v >> 8); b[o + 2] = (byte)(v >> 16); b[o + 3] = (byte)(v >> 24); }

    public static byte[] Encode(int type, int seq, int refSeq, byte[] payload)
    {
        if (payload == null) payload = new byte[0];
        byte[] m = new byte[HeaderLen + payload.Length + TrailerLen];
        m[0] = 0xD1; m[1] = 0x5A; m[2] = 1; m[3] = (byte)type;
        Put16(m, 4, seq); Put16(m, 6, refSeq); Put32(m, 8, (uint)payload.Length); Put16(m, 12, 0);
        Put16(m, 14, DishaCrc.Crc16(m, 0, 14));
        Array.Copy(payload, 0, m, HeaderLen, payload.Length);
        Put32(m, HeaderLen + payload.Length, DishaCrc.Crc32(payload, 0, payload.Length));
        return m;
    }
}

// Same resynchronising parser as the Android app.
public class DishaParser
{
    byte[] buf = new byte[65536];
    int start, end;
    public long Messages, HeaderCrcErrors, PayloadCrcErrors, SkippedBytes, PadBytes;

    public List<DishaMessage> Feed(byte[] data, int n)
    {
        if (end + n > buf.Length)
        {
            Array.Copy(buf, start, buf, 0, end - start); end -= start; start = 0;
            if (end + n > buf.Length) Array.Resize(ref buf, Math.Max(buf.Length * 2, end + n));
        }
        Array.Copy(data, 0, buf, end, n);
        end += n;
        List<DishaMessage> output = new List<DishaMessage>();
        while (true)
        {
            while (end - start >= 2 && !(buf[start] == 0xD1 && buf[start + 1] == 0x5A)) Skip();
            if (end - start < DishaCodec.HeaderLen) break;
            if (DishaCrc.Crc16(buf, start, 14) != DishaCodec.U16(buf, start + 14)) { HeaderCrcErrors++; Skip(); continue; }
            uint plen = DishaCodec.U32(buf, start + 8);
            if (plen > DishaCodec.MaxDevicePayload) { Skip(); continue; }
            int total = DishaCodec.HeaderLen + (int)plen + DishaCodec.TrailerLen;
            if (end - start < total) break;
            int p0 = start + DishaCodec.HeaderLen;
            if (DishaCrc.Crc32(buf, p0, (int)plen) != DishaCodec.U32(buf, p0 + (int)plen)) { PayloadCrcErrors++; Skip(); continue; }
            DishaMessage m = new DishaMessage();
            m.Version = buf[start + 2];
            m.Type = buf[start + 3];
            m.Seq = DishaCodec.U16(buf, start + 4);
            m.Ref = DishaCodec.U16(buf, start + 6);
            m.Payload = new byte[plen];
            Array.Copy(buf, p0, m.Payload, 0, (int)plen);
            start += total;
            Messages++;
            output.Add(m);
        }
        if (start == end) { start = 0; end = 0; }
        return output;
    }

    void Skip()
    {
        if (buf[start] == 0) PadBytes++; else SkippedBytes++;
        start++;
    }
}

public class DishaFrame
{
    public uint FrameId;
    public int Width, Height, Format, Flags, Ref, EncodeMs, Chunks;
    public byte[] Data;
}

// Same rules as the Android FrameAssembler: in-order chunks, exact length, whole-frame CRC-32.
public class DishaFrameAssembler
{
    public const int ChunkHeaderLen = 32;
    bool active;
    uint frameId, frameCrc;
    int total, received, nextIndex, chunks, width, height, format, flags, refSeq, encodeMs;
    byte[] data;
    public long Completed, Dropped;
    public string LastDrop = "";

    public DishaFrame OnChunk(int refSeq, byte[] p)
    {
        if (p.Length < ChunkHeaderLen) return Drop("chunk shorter than its header");
        uint id = DishaCodec.U32(p, 0);
        uint tot = DishaCodec.U32(p, 4);
        uint off = DishaCodec.U32(p, 8);
        int index = DishaCodec.U16(p, 12);
        int count = DishaCodec.U16(p, 14);
        int n = p.Length - ChunkHeaderLen;
        if (tot == 0 || tot > 4 * 1024 * 1024) return Drop("invalid frame length " + tot);
        if (count == 0 || index >= count || off + n > tot) return Drop("invalid chunk " + index + "/" + count);
        if (!active || id != frameId || index == 0)
        {
            if (active) { Dropped++; LastDrop = "frame " + frameId + " incomplete"; }
            active = false;
            if (index != 0 || off != 0) return Drop("frame " + id + ": first chunk missing");
            active = true; frameId = id; total = (int)tot; received = 0; nextIndex = 0; chunks = count;
            width = DishaCodec.U16(p, 16); height = DishaCodec.U16(p, 18); format = p[20]; flags = p[21];
            encodeMs = DishaCodec.U16(p, 22); frameCrc = DishaCodec.U32(p, 28); this.refSeq = refSeq;
            data = new byte[total];
        }
        if (index != nextIndex || off != received || tot != total) { active = false; return Drop("frame " + id + ": chunk out of order"); }
        Array.Copy(p, ChunkHeaderLen, data, received, n);
        received += n;
        nextIndex++;
        bool last = (p[21] & 0x02) != 0;
        if (received < total) { if (last) { active = false; return Drop("frame " + id + ": short"); } return null; }
        active = false;
        if (DishaCrc.Crc32(data, 0, total) != frameCrc) return Drop("frame " + id + ": CRC-32 mismatch");
        Completed++;
        DishaFrame f = new DishaFrame();
        f.FrameId = frameId; f.Width = width; f.Height = height; f.Format = format; f.Flags = flags;
        f.Ref = this.refSeq; f.EncodeMs = encodeMs; f.Chunks = chunks; f.Data = data;
        return f;
    }

    DishaFrame Drop(string why)
    {
        Dropped++;
        LastDrop = why;
        return null;
    }
}
