disha-debug.keystore - the key every DISHA GLASS OS APK is signed with.

KEEP A COPY OF THIS FILE SOMEWHERE SAFE (Google Drive, a USB stick).

Android installs an update over the app - and keeps its data: your "Disha" wake-word
training, memory, notes and settings - only when the new APK is signed with this same key
and has a higher versionCode. An APK signed with any other key can't update the app; the
phone would have to uninstall it first, which deletes the training.

  alias: disha    passwords: disha-debug (store and key)
  SHA-256: DC:33:05:D6:2D:F3:89:4D:25:2D:D3:1D:CC:39:12:04:4D:DA:94:27:DF:87:78:94:9E:88:EB:2E:96:F1:59:BB

tools\build_apk.ps1 and the Gradle build (android\DishaGlassOS) both use this file.
build_apk.ps1 stops with an error rather than make a new key when this file is missing.
