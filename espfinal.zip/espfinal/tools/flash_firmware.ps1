<#
  Compiles DISHA-CAM with the exact board settings and uploads it through the USB-UART port,
  using the arduino-cli bundled with Arduino IDE 2. Same result as the Tools menu settings in
  firmware\DISHA-CAM\DISHA-CAM.ino.

  Usage:
    powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM5
    powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM5 -UsbMode hwcdc   # fallback transport
    powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -CompileOnly

  If the upload cannot connect: hold BOOT, press and release RST, release BOOT, run again.
  Close the Arduino Serial Monitor first (it holds the COM port).
#>
param(
  [string]$Port,
  [ValidateSet('tinyusb', 'hwcdc')][string]$UsbMode = 'tinyusb',
  [switch]$CompileOnly
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$sketch = Join-Path $root 'firmware\DISHA-CAM'

$cli = (Get-Command arduino-cli -ErrorAction SilentlyContinue).Source
if (-not $cli) { $cli = "$env:LOCALAPPDATA\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe" }
if (-not (Test-Path $cli)) { throw 'arduino-cli not found. Install Arduino IDE 2 or put arduino-cli on PATH.' }

$mode = if ($UsbMode -eq 'hwcdc') { 'hwcdc' } else { 'default' }  # 'default' = USB-OTG (TinyUSB)
$fqbn = "esp32:esp32:esp32s3:USBMode=$mode,CDCOnBoot=default,PSRAM=opi,FlashSize=16M," +
        'PartitionScheme=app3M_fat9M_16MB,CPUFreq=240,FlashMode=qio,UploadMode=default,UploadSpeed=921600,DebugLevel=none'

$core = & $cli core list | Select-String 'esp32:esp32'
Write-Host "Core: $core"
if ($core -notmatch '3\.3\.12') { Write-Warning 'DISHA-CAM was built and checked with esp32 core 3.3.12.' }

if ($CompileOnly) {
  & $cli compile --fqbn $fqbn --warnings default $sketch
} else {
  if (-not $Port) { throw 'Give the USB-UART COM port, e.g. -Port COM5 (Device Manager > Ports).' }
  & $cli compile --fqbn $fqbn --warnings default --upload --port $Port $sketch
}
if ($LASTEXITCODE) { throw "arduino-cli failed (exit $LASTEXITCODE)" }
Write-Host 'Done. Open the Serial Monitor at 115200 baud and press RST to see the boot log.' -ForegroundColor Green
