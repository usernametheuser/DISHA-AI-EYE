<#
  Phase 2 test: capture ONE camera image on DISHA-CAM and save it on this PC.
  Uses the board's USB-UART port (debug serial, 115200 baud). No Android, no native USB.

  Usage (close the Arduino Serial Monitor first - only one program can open the port):
    powershell -ExecutionPolicy Bypass -File tools\serial_snap.ps1 -Port COM5

  Expected: "OK 320x240 JPEG ... CRC-32 match", a .jpg in your Pictures folder that opens.
#>
param(
  [Parameter(Mandatory = $true)][string]$Port,
  [int]$Baud = 115200,
  [string]$OutDir = [Environment]::GetFolderPath('MyPictures')
)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'DishaProtocol.cs')

$sp = New-Object System.IO.Ports.SerialPort $Port, $Baud, ([System.IO.Ports.Parity]::None), 8, ([System.IO.Ports.StopBits]::One)
$sp.NewLine = "`n"
$sp.ReadTimeout = 20000
$sp.DtrEnable = $false  # DTR/RTS drive EN and IO0 through the auto-reset circuit: leave both off
$sp.RtsEnable = $false
$sp.Open()
$header = $null
$b64 = New-Object System.Text.StringBuilder
try {
  Start-Sleep -Milliseconds 300
  $sp.DiscardInBuffer()
  $sp.WriteLine('snapb64')
  $deadline = (Get-Date).AddSeconds(20)
  while (-not $header) {
    if ((Get-Date) -gt $deadline) { throw "No answer within 20 s. Is DISHA-CAM running and is $Port the USB-UART port?" }
    $line = $sp.ReadLine().Trim()
    if ($line -eq 'SNAP-FAIL') { throw 'The board could not capture a frame. Read its log in the Serial Monitor.' }
    if ($line.StartsWith('SNAP-BEGIN')) { $header = $line } elseif ($line) { Write-Host "  board: $line" }
  }
  while ($true) {
    $line = $sp.ReadLine().Trim()
    if ($line -eq 'SNAP-END') { break }
    [void]$b64.Append($line)
  }
} finally {
  $sp.Close()
}

if ($header -notmatch '^SNAP-BEGIN (\d+)x(\d+) (\d+) bytes crc32=([0-9a-fA-F]{8})$') { throw "Unexpected header: $header" }
$w = [int]$Matches[1]; $h = [int]$Matches[2]; $len = [int]$Matches[3]; $crc = [Convert]::ToUInt32($Matches[4], 16)
$bytes = [Convert]::FromBase64String($b64.ToString())
if ($bytes.Length -ne $len) { throw "Length mismatch: board said $len bytes, received $($bytes.Length)" }
$got = [DishaCrc]::Crc32($bytes, 0, $bytes.Length)
if ($got -ne $crc) { throw ('CRC-32 mismatch: board {0:x8}, received {1:x8}' -f $crc, $got) }
$soi = $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xD8
$eoi = $bytes[$len - 2] -eq 0xFF -and $bytes[$len - 1] -eq 0xD9
if (-not ($soi -and $eoi)) { throw 'Received data is not a complete JPEG (SOI/EOI markers missing)' }

$file = Join-Path $OutDir ('DISHA_snap_{0}.jpg' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
[IO.File]::WriteAllBytes($file, $bytes)
Write-Host ('OK {0}x{1} JPEG {2} bytes, CRC-32 match, SOI/EOI valid' -f $w, $h, $len)
Write-Host "Saved $file"
Start-Process $file
