<#
  Disha slide control for PowerPoint on this laptop.

  1. On the phone say "Disha, presentation mode" (or tap Present in the app). It shows an address
     like http://192.168.43.1:8080/482913/ . The laptop must be on the same Wi-Fi or on the
     phone's hotspot.
  2. Run:   powershell -ExecutionPolicy Bypass -File tools\disha_presenter.ps1 -Url http://192.168.43.1:8080/482913/
  3. Open your presentation in PowerPoint. Then say: "Disha, start the presentation", "next slide",
     "change slide", "previous slide", "go to slide 5", "black screen", "end the presentation".

  PowerPoint is driven through its own automation interface (no window focus needed). If that is
  not available (PowerPoint not running, or another viewer such as Google Slides in a browser or
  a PDF reader), the arrow keys are sent to the window in front instead.
  Stop with Ctrl+C. Nothing is sent from the laptop except these requests to the phone.
#>
param(
  [Parameter(Mandatory = $true)][string]$Url
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$base = $Url.TrimEnd('/')

function Get-Show {
  try {
    $ppt = [Runtime.InteropServices.Marshal]::GetActiveObject('PowerPoint.Application')
    return $ppt
  } catch { return $null }
}

function Send-Key([string]$keys) {
  [System.Windows.Forms.SendKeys]::SendWait($keys)
}

function Invoke-Slide($ev) {
  $ppt = Get-Show
  $view = $null
  if ($ppt -and $ppt.SlideShowWindows.Count -gt 0) { $view = $ppt.SlideShowWindows.Item(1).View }
  switch ($ev.action) {
    'start' {
      if ($ppt -and $ppt.Presentations.Count -gt 0) { [void]$ppt.ActivePresentation.SlideShowSettings.Run() } else { Send-Key '{F5}' }
    }
    'next'     { if ($view) { $view.Next() } else { Send-Key '{RIGHT}' } }
    'previous' { if ($view) { $view.Previous() } else { Send-Key '{LEFT}' } }
    'goto'     { if ($view) { $view.GotoSlide([int]$ev.number) } else { Send-Key "$($ev.number){ENTER}" } }
    'end'      { if ($view) { $view.Exit() } else { Send-Key '{ESC}' } }
    'black'    {
      if ($view) { if ($view.State -eq 3) { $view.State = 1 } else { $view.State = 3 } } else { Send-Key 'b' }
    }
  }
  $where = if ($view -or ($ppt -and $ev.action -eq 'start')) { 'PowerPoint' } else { 'front window (keys)' }
  Write-Host ("{0:HH:mm:ss}  {1} {2} -> {3}" -f (Get-Date), $ev.action, $(if ($ev.number) { $ev.number } else { '' }), $where)
}

Write-Host "Disha slide control: listening to $base" -ForegroundColor Cyan
$after = -1
while ($true) {
  try {
    $wait = if ($after -lt 0) { 0 } else { 25 }
    $r = Invoke-RestMethod "$base/events?after=$([Math]::Max($after, 0))&wait=$wait" -TimeoutSec 40
    if ($after -ge 0) { foreach ($e in $r.events) { try { Invoke-Slide $e } catch { Write-Host "  failed: $($_.Exception.Message)" -ForegroundColor Yellow } } }
    else { Write-Host 'Connected to the phone. Say "Disha, next slide".' -ForegroundColor Green }
    $after = [int]$r.last
  } catch {
    Write-Host "Phone not reachable ($($_.Exception.Message)); retrying..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
  }
}
