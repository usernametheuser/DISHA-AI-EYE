// Commands typed in the Serial Monitor (USB-UART port, 115200 baud, newline):
//   help | status | snap | snapb64 | fps | res 320|640|800 | flip | sd | photo | rec | ls | reboot
#pragma once
#include <Arduino.h>

namespace SerialConsole {

void poll();  // call from loop(); never blocks

}  // namespace SerialConsole
