#include "serial_console.h"
#include "log.h"
#include "../camera/camera_service.h"
#include "../status/status_report.h"
#include "../storage/sd_storage.h"
#include "../web/web_mode.h"

namespace SerialConsole {

namespace {
char s_line[64];
size_t s_len = 0;
char s_json[2560];

void run(char *cmd) {
  while (*cmd == ' ') cmd++;
  if (!*cmd) return;

  if (!strcmp(cmd, "help")) {
    Log::printf("commands: status | snap | snapb64 | fps | res 320|640|800 | flip | sd | photo | rec | ls | wifi [on|off] | reboot");
  } else if (!strcmp(cmd, "wifi")) {
    Log::printf("[wifi] web mode %s%s%s", WebMode::enabled() ? "ON" : "OFF", WebMode::address()[0] ? ": " : "", WebMode::address());
  } else if (!strcmp(cmd, "wifi on") || !strcmp(cmd, "wifi off")) {
    const bool on = !strcmp(cmd, "wifi on");
    WebMode::setEnabled(on);
    Log::printf("[wifi] web mode %s: restarting", on ? "ON" : "OFF");
    Serial.flush();
    delay(200);
    ESP.restart();
  } else if (!strcmp(cmd, "sd")) {
    SdStorage::statusJson(s_json, sizeof(s_json));
    Serial.println(s_json);
  } else if (!strcmp(cmd, "photo")) {
    CameraService::requestPhoto(0, 0, true);
  } else if (!strcmp(cmd, "rec")) {
    CameraService::toggleRecordingLocal();
  } else if (!strcmp(cmd, "ls")) {
    CameraService::requestFileList(0, 40, true);
  } else if (!strcmp(cmd, "status")) {
    StatusReport::status(s_json, sizeof(s_json));
    Serial.println(s_json);
  } else if (!strcmp(cmd, "snap")) {
    CameraService::requestLocalTest(CameraService::LocalTest::Snap);
  } else if (!strcmp(cmd, "snapb64")) {
    CameraService::requestLocalTest(CameraService::LocalTest::SnapBase64);
  } else if (!strcmp(cmd, "fps")) {
    CameraService::requestLocalTest(CameraService::LocalTest::Fps);
  } else if (!strcmp(cmd, "flip")) {
    CameraService::requestLocalTest(CameraService::LocalTest::Flip);
  } else if (!strncmp(cmd, "res ", 4)) {
    CameraService::requestLocalResolution((uint16_t)atoi(cmd + 4));
  } else if (!strcmp(cmd, "reboot")) {
    Log::printf("rebooting");
    Serial.flush();
    ESP.restart();
  } else {
    Log::printf("unknown command '%s' (type help)", cmd);
  }
}
}  // namespace

void poll() {
  while (Serial.available()) {
    const int c = Serial.read();
    if (c < 0) break;
    if (c == '\n' || c == '\r') {
      s_line[s_len] = 0;
      run(s_line);
      s_len = 0;
    } else if (s_len < sizeof(s_line) - 1) {
      s_line[s_len++] = (char)c;
    }
  }
}

}  // namespace SerialConsole
