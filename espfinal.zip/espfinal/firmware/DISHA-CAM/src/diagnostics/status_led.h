// Board lights.
//   RGB LED "48": yellow = starting / camera initialising, green = ready (no phone session),
//                 cyan = phone connected, blue = streaming, purple = recording to microSD,
//                 red = camera error.
//                 A short white blink every 2 s = Wi-Fi web mode is on.
//   LED "IO2"   : on while camera frames leave the camera (to the phone, the card or a browser): privacy indicator.
#pragma once
#include <Arduino.h>

namespace StatusLed {

enum class Mode : uint8_t { Boot, CameraError, WaitingForPhone, Connected, Streaming, Recording };

void begin();

// Call from one task only (the Arduino loop). wifiBlink: show white instead of the mode colour.
void show(Mode mode, bool framesLeaving, bool wifiBlink = false);

}  // namespace StatusLed
