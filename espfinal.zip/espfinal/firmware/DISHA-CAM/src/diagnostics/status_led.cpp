#include "status_led.h"
#include "../config/disha_config.h"

namespace StatusLed {

namespace {
// 0xRRGGBB, kept dim: these LEDs are very bright and sit near the eyes when worn.
uint32_t colorFor(Mode m) {
  switch (m) {
    case Mode::Boot:            return 0x100A00;
    case Mode::CameraError:     return 0x140000;
    case Mode::WaitingForPhone: return 0x000C00;
    case Mode::Connected:       return 0x000A0A;
    case Mode::Streaming:       return 0x000014;
    case Mode::Recording:       return 0x100010;
  }
  return 0;
}

uint32_t s_shown = 0xFFFFFFFF;
int s_io2 = -1;
}  // namespace

void begin() {
  pinMode(Pins::LED_IO2, OUTPUT);
  digitalWrite(Pins::LED_IO2, LOW);
  show(Mode::Boot, false);
}

void show(Mode mode, bool framesLeaving, bool wifiBlink) {
  uint32_t c = wifiBlink ? 0x0C0C0C : colorFor(mode);
  if (c != s_shown) {
    rgbLedWrite(Pins::RGB_LED, (c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF);
    s_shown = c;
  }
  int io2 = framesLeaving ? HIGH : LOW;
  if (io2 != s_io2) {
    digitalWrite(Pins::LED_IO2, io2);
    s_io2 = io2;
  }
}

}  // namespace StatusLed
