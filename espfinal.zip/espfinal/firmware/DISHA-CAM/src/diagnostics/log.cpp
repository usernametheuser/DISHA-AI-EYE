#include "log.h"
#include <stdarg.h>

namespace Log {

namespace {
struct Line {
  char text[kLineMax + 1];
};
QueueHandle_t s_hostQueue = nullptr;
volatile bool s_forward = false;
}  // namespace

void begin(uint32_t baud) {
  Serial.begin(baud);
  s_hostQueue = xQueueCreate(16, sizeof(Line));
}

void printf(const char *fmt, ...) {
  char buf[256];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf) - 1, fmt, ap);
  va_end(ap);
  if (n < 0) return;
  size_t len = strnlen(buf, sizeof(buf) - 2);
  if (len == 0 || buf[len - 1] != '\n') {
    buf[len++] = '\n';
    buf[len] = 0;
  }
  Serial.write((const uint8_t *)buf, len);  // one write per line: lines from different tasks never mix

  if (s_forward && s_hostQueue) {
    Line l;
    size_t copy = len - 1 < kLineMax ? len - 1 : kLineMax;  // without the newline
    memcpy(l.text, buf, copy);
    l.text[copy] = 0;
    xQueueSend(s_hostQueue, &l, 0);  // drop the line if the queue is full; never block a caller
  }
}

void setHostForwarding(bool on) {
  s_forward = on;
  if (!on && s_hostQueue) xQueueReset(s_hostQueue);
}

bool popForHost(char *out, size_t cap) {
  Line l;
  if (!s_hostQueue || cap == 0 || xQueueReceive(s_hostQueue, &l, 0) != pdTRUE) return false;
  strlcpy(out, l.text, cap);
  return true;
}

}  // namespace Log
