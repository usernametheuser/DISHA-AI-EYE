// Debug log: printed on the USB-UART port (Serial / UART0) and, while the phone has a
// session open, also forwarded to the app as LOG messages.
#pragma once
#include <Arduino.h>

namespace Log {

constexpr size_t kLineMax = 120;

void begin(uint32_t baud);

// printf-style; one call = one line (a trailing newline is added if missing).
void printf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));

// Lines are queued for the phone only while forwarding is on (session active).
void setHostForwarding(bool on);

// Takes the next queued line for the phone. Non-blocking.
bool popForHost(char *out, size_t cap);

}  // namespace Log
