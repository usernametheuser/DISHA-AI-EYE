#include "web_mode.h"

#include <ESPmDNS.h>
#include <Preferences.h>
#include <WiFi.h>

#include "esp_heap_caps.h"
#include "esp_http_server.h"

#include "../camera/camera_service.h"
#include "../config/disha_config.h"
#include "../diagnostics/log.h"
#include "../status/status_report.h"
#include "web_page.h"

namespace WebMode {

namespace {
bool s_active = false;
bool s_ap = false;
bool s_announced = false;
uint32_t s_joinStarted = 0;
char s_address[40] = "";
httpd_handle_t s_main = nullptr;
httpd_handle_t s_stream = nullptr;
uint8_t *s_bufMain = nullptr;    // main server task only
uint8_t *s_bufStream = nullptr;  // stream server task only
char s_status[1536];

esp_err_t sendJson(httpd_req_t *req, const char *json) {
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, json, HTTPD_RESP_USE_STRLEN);
}

esp_err_t onIndex(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, WEB_PAGE, HTTPD_RESP_USE_STRLEN);
}

esp_err_t onCapture(httpd_req_t *req) {
  const size_t n = CameraService::grabForWeb(s_bufMain, Cfg::JPEG_BUF_BYTES, Cfg::JPEG_QUALITY_DEFAULT, 4000);
  if (!n) {
    httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "The camera is not ready");
    return ESP_FAIL;
  }
  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, (const char *)s_bufMain, n);
}

esp_err_t onStatus(httpd_req_t *req) {
  StatusReport::status(s_status, sizeof(s_status));
  return sendJson(req, s_status);
}

esp_err_t onPhoto(httpd_req_t *req) {
  const bool ok = CameraService::requestPhoto(0, 0, true);
  return sendJson(req, ok ? "{\"ok\":true,\"message\":\"Photo saved on the glasses card\"}" : "{\"ok\":false,\"message\":\"Busy\"}");
}

esp_err_t onRecord(httpd_req_t *req) {
  const bool ok = CameraService::toggleRecordingLocal();
  return sendJson(req, ok ? "{\"ok\":true,\"message\":\"Recording on the glasses card switched\"}" : "{\"ok\":false,\"message\":\"Busy\"}");
}

// MJPEG live view on port 81 (its own server, so the page and pictures keep answering meanwhile).
esp_err_t onStream(httpd_req_t *req) {
  httpd_resp_set_type(req, "multipart/x-mixed-replace;boundary=dishaframe");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  char head[96];
  const uint32_t period = 1000 / Cfg::WEB_STREAM_FPS;
  int misses = 0;
  Log::printf("[web] live view opened");
  for (;;) {
    const uint32_t t0 = millis();
    const size_t n = CameraService::grabForWeb(s_bufStream, Cfg::JPEG_BUF_BYTES, Cfg::WEB_QUALITY, 3000);
    if (!n) {
      if (++misses > 20) break;  // camera gone for a long time
      vTaskDelay(pdMS_TO_TICKS(250));
      continue;
    }
    misses = 0;
    const int hl = snprintf(head, sizeof(head), "--dishaframe\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n", (unsigned)n);
    if (httpd_resp_send_chunk(req, head, hl) != ESP_OK) break;
    if (httpd_resp_send_chunk(req, (const char *)s_bufStream, n) != ESP_OK) break;
    if (httpd_resp_send_chunk(req, "\r\n", 2) != ESP_OK) break;
    const uint32_t spent = millis() - t0;
    if (spent < period) vTaskDelay(pdMS_TO_TICKS(period - spent));
  }
  Log::printf("[web] live view closed");
  return ESP_OK;
}

void route(httpd_handle_t h, const char *uri, esp_err_t (*fn)(httpd_req_t *)) {
  httpd_uri_t u = {};
  u.uri = uri;
  u.method = HTTP_GET;
  u.handler = fn;
  httpd_register_uri_handler(h, &u);
}

bool startServers() {
  httpd_config_t c = HTTPD_DEFAULT_CONFIG();
  c.server_port = 80;
  c.ctrl_port = 32768;
  c.stack_size = 6144;
  if (httpd_start(&s_main, &c) != ESP_OK) return false;
  route(s_main, "/", onIndex);
  route(s_main, "/capture.jpg", onCapture);
  route(s_main, "/status", onStatus);
  route(s_main, "/photo", onPhoto);
  route(s_main, "/record", onRecord);

  httpd_config_t s = HTTPD_DEFAULT_CONFIG();
  s.server_port = 81;
  s.ctrl_port = 32769;
  s.stack_size = 6144;
  if (httpd_start(&s_stream, &s) != ESP_OK) return false;
  route(s_stream, "/stream", onStream);
  return true;
}

void startOwnHotspot() {
  WiFi.disconnect(true);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(DISHA_AP_SSID, DISHA_AP_PASSWORD);
  s_ap = true;
  snprintf(s_address, sizeof(s_address), "http://%s", WiFi.softAPIP().toString().c_str());
  Log::printf("[wifi] own hotspot \"%s\" (password \"%s\"): connect the laptop to it and open %s", DISHA_AP_SSID, DISHA_AP_PASSWORD, s_address);
  s_announced = true;
}
}  // namespace

bool enabled() {
  Preferences p;
  p.begin("disha", true);
  const bool on = p.getBool("wifi", false);
  p.end();
  return on;
}

void setEnabled(bool on) {
  Preferences p;
  p.begin("disha", false);
  p.putBool("wifi", on);
  p.end();
}

void begin() {
  if (!enabled()) return;
  s_bufMain = (uint8_t *)heap_caps_malloc(Cfg::JPEG_BUF_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  s_bufStream = (uint8_t *)heap_caps_malloc(Cfg::JPEG_BUF_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!s_bufMain || !s_bufStream) {
    Log::printf("[wifi] not enough PSRAM for web mode");
    return;
  }
  WiFi.persistent(false);
  WiFi.setHostname("disha-cam");
  if (strlen(DISHA_WIFI_SSID) > 0) {
    WiFi.mode(WIFI_STA);
    WiFi.begin(DISHA_WIFI_SSID, DISHA_WIFI_PASSWORD);
    s_joinStarted = millis();
    Log::printf("[wifi] web mode ON: joining \"%s\"...", DISHA_WIFI_SSID);
  } else {
    startOwnHotspot();
  }
  if (!startServers()) {
    Log::printf("[wifi] could not start the web servers");
    return;
  }
  s_active = true;
}

void poll() {
  if (!s_active || s_announced) return;
  if (WiFi.status() == WL_CONNECTED) {
    snprintf(s_address, sizeof(s_address), "http://%s", WiFi.localIP().toString().c_str());
    if (MDNS.begin("disha")) MDNS.addService("http", "tcp", 80);
    Log::printf("[wifi] web mode: open %s (or http://disha.local) on a laptop on the same network", s_address);
    s_announced = true;
  } else if (millis() - s_joinStarted > Cfg::WIFI_JOIN_TIMEOUT_MS) {
    Log::printf("[wifi] could not join \"%s\"; making the board's own hotspot instead", DISHA_WIFI_SSID);
    startOwnHotspot();
  }
}

bool active() { return s_active; }

const char *address() { return s_address; }

}  // namespace WebMode
