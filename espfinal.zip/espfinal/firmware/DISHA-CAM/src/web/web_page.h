// The page served in Wi-Fi web mode. The AI runs from the browser: pictures go from the laptop to
// the free no-key OVHcloud AI (or the service of a key the user pastes; that key stays in this
// browser only, never on the board).
#pragma once

static const char WEB_PAGE[] = R"HTML(<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DISHA-CAM · Wi-Fi web mode</title>
<style>
:root{--bg:#000;--panel:#0b0b0d;--line:#1d1f24;--text:#e8eef6;--dim:#8a93a3;--cyan:#22d3ee;--violet:#a78bfa;--blue:#60a5fa;--green:#34d399}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
header{display:flex;align-items:center;gap:12px;padding:14px 20px;border-bottom:1px solid var(--line)}
.logo{font-weight:800;letter-spacing:.18em;color:var(--cyan);font-size:18px}.sub{color:var(--dim);font-size:13px}
.pill{margin-left:auto;border:1px solid var(--green);border-radius:999px;padding:3px 11px;font-size:12px}
main{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(300px,1fr);gap:16px;padding:16px 20px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px}
.title{font-size:11px;letter-spacing:.2em;color:var(--cyan);font-weight:700;margin:0 0 10px}
.live{aspect-ratio:4/3;background:#050505;border-radius:12px;overflow:hidden;display:flex;align-items:center;justify-content:center}
.live img{width:100%;height:100%;object-fit:contain}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}
button{background:#141519;color:var(--text);border:1px solid var(--line);border-radius:12px;padding:9px 14px;font-size:14px;cursor:pointer;transition:border-color .2s,transform .1s}
button:hover{border-color:var(--cyan)}button:active{transform:scale(.97)}button.on{border-color:var(--green);color:var(--green)}
.who{display:flex;align-items:center;gap:16px}
.orb{width:84px;height:84px;flex:none;border-radius:50%;--c:var(--cyan);background:radial-gradient(circle at 38% 34%,#fff 0,var(--c) 46%,#063 100%);
box-shadow:0 0 36px var(--c);animation:b 3.4s ease-in-out infinite;transition:box-shadow .4s}
.orb.think{--c:var(--violet);animation:b .8s ease-in-out infinite}.orb.talk{--c:var(--blue);animation:t .3s ease-in-out infinite alternate}
@keyframes b{50%{transform:scale(1.05)}}@keyframes t{to{transform:scale(1.09)}}
.state{font-size:19px;font-weight:700}.detail{color:var(--dim);font-size:13px}
.chat{height:min(44vh,400px);overflow-y:auto;display:flex;flex-direction:column;gap:8px;margin-top:12px}
.b{max-width:88%;padding:8px 13px;border-radius:16px;animation:p .28s ease-out;white-space:pre-wrap}
.me{align-self:flex-end;background:var(--cyan);color:#001018}.her{align-self:flex-start;background:#141519;border:1px solid var(--line)}
@keyframes p{from{opacity:0;transform:translateY(10px)}}
form{display:flex;gap:8px;margin-top:10px}input{flex:1;background:#0f1013;border:1px solid var(--line);color:var(--text);border-radius:12px;padding:10px 12px;font-size:15px;outline:none}
input:focus{border-color:var(--cyan)}details{margin-top:12px;color:var(--dim);font-size:13px}details input{width:100%;margin-top:6px}
@media(max-width:860px){main{grid-template-columns:1fr}}
</style></head><body>
<header><div><div class="logo">DISHA</div><div class="sub">Smart glasses · Wi-Fi web mode (the Android app over USB is the main way)</div></div><span class="pill" id="pill">● Glasses online</span></header>
<main>
<section class="card"><p class="title">WHAT THE GLASSES SEE</p>
<div class="live"><img id="live" alt="Live view"></div>
<div class="row">
<button data-q="What am I looking at? Mention anything important or useful.">👁 What's this?</button>
<button data-q="Read all the text in this picture exactly.">📖 Read</button>
<button data-q="Translate any text in this picture into Hindi (Devanagari) and English.">🌐 Translate</button>
<button data-q="Is there any hazard or obstacle ahead? Answer in one short sentence.">⚠ Hazards?</button>
<button id="photo">📷 Photo to card</button><button id="rec">⏺ Record on card</button><button id="auto">🔁 Describe every 15 s</button>
</div></section>
<section class="card">
<div class="who"><div class="orb" id="orb"></div><div><div class="state" id="state">Ready</div><div class="detail" id="detail">Ask about what the glasses see.</div></div></div>
<div class="chat" id="chat"></div>
<form id="f"><input id="q" placeholder="Ask Disha about the view…" autocomplete="off"><button id="mic" type="button">🎤</button><button>Send</button></form>
<details><summary>AI settings (optional key)</summary>
Free AI without a key is used by default. A key (for example a free Groq key) is stored only in this browser.
<input id="kbase" placeholder="https://api.groq.com/openai/v1"><input id="kkey" placeholder="API key" type="password"><input id="kmodel" placeholder="meta-llama/llama-4-scout-17b-16e-instruct">
</details></section>
</main>
<script>
const $=id=>document.getElementById(id);
const host=location.hostname;
const live=$('live');let retry=0;
function startLive(){live.src='http://'+host+':81/stream?'+Date.now()}
live.onerror=()=>{setTimeout(startLive,Math.min(5000,500*(++retry)))};startLive();
const FREE='https://oai.endpoints.kepler.ai.cloud.ovh.net/v1';
const MODELS=['Qwen2.5-VL-72B-Instruct','Mistral-Small-3.2-24B-Instruct-2506','Qwen3.8-27B','Qwen3.6-27B'];
const SYS="You are Disha, the AI in a pair of smart glasses, calm and sharp like JARVIS. The image is what the glasses see right now. Answer in one to three short spoken sentences, no markdown. Mention a hazard first if you see one. The user is in India.";
['kbase','kkey','kmodel'].forEach(k=>{try{$(k).value=localStorage.getItem(k)||''}catch(e){} $(k).onchange=()=>{try{localStorage.setItem(k,$(k).value.trim())}catch(e){}}});
const history=[];
function say(who,t){const d=document.createElement('div');d.className='b '+(who==='me'?'me':'her');d.textContent=t;$('chat').appendChild(d);$('chat').scrollTop=1e9}
function setState(s,d,c){$('state').textContent=s;$('detail').textContent=d||'';$('orb').className='orb '+(c||'')}
function speak(t){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);const v=speechSynthesis.getVoices().find(v=>/en-(IN|GB|IE)/.test(v.lang));if(v)u.voice=v;
u.onstart=()=>setState('Speaking…','','talk');u.onend=()=>setState('Ready','Ask about what the glasses see.');speechSynthesis.speak(u)}catch(e){setState('Ready')}}
async function frame(){const r=await fetch('/capture.jpg?'+Date.now(),{cache:'no-store'});if(!r.ok)throw new Error('camera busy');const b=await r.blob();
return await new Promise(ok=>{const fr=new FileReader();fr.onload=()=>ok(fr.result);fr.readAsDataURL(b)})}
async function call(base,key,model,img,q){const body={model,max_tokens:1024,temperature:.4,messages:[{role:'system',content:SYS},...history.slice(-6),
{role:'user',content:[{type:'text',text:q},{type:'image_url',image_url:{url:img}}]}]};
const h={'Content-Type':'application/json'};if(key)h.Authorization='Bearer '+key;
const r=await fetch(base+'/chat/completions',{method:'POST',headers:h,body:JSON.stringify(body)});if(!r.ok)throw new Error(model+': '+r.status);
const j=await r.json();const t=((j.choices||[])[0]||{}).message;const s=(t&&t.content||'').replace(/<think>[\s\S]*?<\/think>/g,'').trim();if(!s)throw new Error('empty');return s}
let busy=false;
async function ask(q,quiet){if(busy)return;busy=true;if(!quiet)say('me',q);setState('Thinking…','Looking through the glasses','think');
try{const img=await frame();let ans=null,errs=[];const kb=$('kbase').value.trim(),kk=$('kkey').value.trim(),km=$('kmodel').value.trim();
if(kk&&kb&&km){try{ans=await call(kb,kk,km,img,q)}catch(e){errs.push(e.message)}}
for(const m of MODELS){if(ans)break;try{ans=await call(FREE,null,m,img,q)}catch(e){errs.push(e.message)}}
if(!ans)throw new Error('AI busy ('+errs.join(', ')+'). Try again in a minute.');
history.push({role:'user',content:q},{role:'assistant',content:ans});say('her',ans);speak(ans)}
catch(e){say('her',e.message);setState('Ready',e.message)}busy=false}
document.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>ask(b.dataset.q));
$('f').onsubmit=e=>{e.preventDefault();const q=$('q').value.trim();if(q){$('q').value='';ask(q)}};
$('photo').onclick=async()=>{const j=await (await fetch('/photo')).json();say('her',j.message)};
$('rec').onclick=async()=>{const j=await (await fetch('/record')).json();say('her',j.message)};
let timer=null;$('auto').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('auto').classList.remove('on');return}
$('auto').classList.add('on');const go=()=>ask('In one short sentence: what is happening in front of me now? Mention changes or hazards.',true);go();timer=setInterval(go,15000)};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
$('mic').onclick=()=>{if(!SR){say('her','Voice input needs Chrome or Edge.');return}const r=new SR();r.lang='en-IN';
r.onresult=e=>ask(e.results[0][0].transcript);r.onerror=e=>say('her',e.error==='not-allowed'?'The browser blocks the microphone on a plain http address. Type instead, or allow this address in chrome://flags (insecure origins treated as secure).':'Voice: '+e.error);
r.onstart=()=>setState('Listening…','Speak now','');r.start()};
async function status(){try{const s=await (await fetch('/status',{cache:'no-store'})).json();const c=s.camera||{};
$('pill').textContent='● '+(c.state||'camera')+' · '+(s.tempC?Math.round(s.tempC)+' °C':'')}catch(e){$('pill').textContent='● Glasses unreachable'}setTimeout(status,5000)}
status();
</script></body></html>)HTML";
