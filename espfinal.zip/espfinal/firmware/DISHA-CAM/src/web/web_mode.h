// Wi-Fi web mode (optional, off by default): the glasses' live view and a small Disha page in
// any browser, as a second way to show the project besides the Android app over USB.
//
// Only the user switches it on (BOOT held 5 s, or "wifi on" on the serial console); the choice
// is kept across restarts. The USB link keeps working at the same time. While it is on, the RGB
// LED blinks white and the IO2 LED lights whenever pictures leave the board.
#pragma once
#include <Arduino.h>

namespace WebMode {

bool enabled();              // the user's saved choice
void setEnabled(bool on);    // saved; takes effect after a restart

void begin();                // starts Wi-Fi and the web servers if enabled
void poll();                 // from loop(): finishes joining the network, or opens the board's own hotspot
bool active();
const char *address();       // "http://192.168.43.57" once known, else ""

}  // namespace WebMode
