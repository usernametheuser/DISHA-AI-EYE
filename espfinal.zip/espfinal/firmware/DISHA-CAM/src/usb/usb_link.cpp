#include "usb_link.h"
#include "../config/disha_config.h"

#if !ARDUINO_USB_MODE
// ===========================================================================
// Tools > USB Mode: "USB-OTG (TinyUSB)"  -> vendor-class bulk interface
// ===========================================================================
#include "USB.h"
#include "esp32-hal-tinyusb.h"

namespace {
constexpr uint8_t ITF = 0;  // index of our (only) vendor interface
SemaphoreHandle_t s_txSpace = nullptr;

// Adds the vendor interface to the configuration descriptor. Arduino's USBVendor class is
// deliberately not used: in core 3.3.12 its RX callback has the pre-TinyUSB-0.21 signature
// and is never called, so we talk to TinyUSB's vendor API directly.
uint16_t loadDescriptor(uint8_t *dst, uint8_t *itf) {
  uint8_t str = tinyusb_add_string_descriptor(DISHA_LINK_INTERFACE_NAME);
  uint8_t ep = tinyusb_get_free_duplex_endpoint();
  if (ep == 0) return 0;
  uint8_t desc[TUD_VENDOR_DESC_LEN] = {TUD_VENDOR_DESCRIPTOR(*itf, str, ep, (uint8_t)(0x80 | ep), 64)};
  *itf += 1;
  memcpy(dst, desc, TUD_VENDOR_DESC_LEN);
  return TUD_VENDOR_DESC_LEN;
}
}  // namespace

// TinyUSB (its own task) finished an IN transfer: the TX FIFO has room again.
extern "C" void tud_vendor_tx_cb(uint8_t idx, uint32_t sent_bytes) {
  (void)idx;
  (void)sent_bytes;
  if (s_txSpace) xSemaphoreGive(s_txSpace);
}

namespace UsbLink {

bool begin() {
  s_txSpace = xSemaphoreCreateBinary();
  if (tinyusb_enable_interface(USB_INTERFACE_VENDOR, TUD_VENDOR_DESC_LEN, loadDescriptor) != ESP_OK) return false;
  uint64_t mac = ESP.getEfuseMac();
  char serial[20];
  snprintf(serial, sizeof(serial), "DC%04X%08X", (unsigned)(mac >> 32) & 0xFFFF, (unsigned)(mac & 0xFFFFFFFF));
  USB.manufacturerName("DISHA");
  USB.productName("DISHA-CAM");
  USB.serialNumber(serial);
  return USB.begin();
}

bool mounted() {
  return tud_vendor_n_mounted(ITF);
}

const char *transportName() {
  return "tinyusb-vendor";
}

size_t read(uint8_t *buf, size_t max) {
  if (!tud_vendor_n_mounted(ITF)) return 0;
  uint32_t n = tud_vendor_n_available(ITF);
  if (n == 0) return 0;
  if (n > max) n = max;
  return tud_vendor_n_read(ITF, buf, n);
}

bool write(const uint8_t *data, size_t len) {
  uint32_t lastProgress = millis();
  while (len) {
    if (!tud_vendor_n_mounted(ITF)) return false;
    uint32_t n = tud_vendor_n_write(ITF, data, len);
    if (n) {
      data += n;
      len -= n;
      lastProgress = millis();
      continue;
    }
    // FIFO full (it is only 64 bytes in this core build): start a transfer and wait for
    // tud_vendor_tx_cb, with a short timeout so a stall is still noticed.
    tud_vendor_n_write_flush(ITF);
    xSemaphoreTake(s_txSpace, pdMS_TO_TICKS(2));
    if (millis() - lastProgress > Cfg::TX_STALL_MS) return false;
  }
  return true;
}

bool endBurst() {
  uint32_t t0 = millis();
  tud_vendor_n_write_flush(ITF);
  // Wait until everything queued has been handed to the endpoint ...
  while (tud_vendor_n_write_available(ITF) < CFG_TUD_VENDOR_TX_BUFSIZE) {
    if (!tud_vendor_n_mounted(ITF) || millis() - t0 > Cfg::TX_STALL_MS) return false;
    tud_vendor_n_write_flush(ITF);
    xSemaphoreTake(s_txSpace, pdMS_TO_TICKS(2));
  }
  // ... then send one pad byte on its own. It always forms a short packet, which completes
  // the phone's pending bulk read even if the previous packet was exactly 64 bytes.
  static const uint8_t pad = 0;
  if (tud_vendor_n_write(ITF, &pad, 1) != 1) return false;
  tud_vendor_n_write_flush(ITF);
  return true;
}

void discardPending() {
  tud_vendor_n_write_clear(ITF);
}

}  // namespace UsbLink

#else
// ===========================================================================
// Tools > USB Mode: "Hardware CDC and JTAG"  -> USB Serial/JTAG CDC-ACM (fallback)
// ===========================================================================
#include "HWCDC.h"
#include "esp_log.h"

namespace {
HWCDC s_cdc;
}

namespace UsbLink {

bool begin() {
  // ESP-IDF mirrors its console onto the USB Serial/JTAG port. Silence it, otherwise
  // log text would be injected into the binary stream. Our own Log goes to UART0 only.
  esp_log_level_set("*", ESP_LOG_NONE);
  s_cdc.setRxBufferSize(2048);
  s_cdc.setTxBufferSize(16384);
  s_cdc.begin();
  s_cdc.setTxTimeoutMs(20);
  return true;
}

bool mounted() {
  return HWCDC::isPlugged();
}

const char *transportName() {
  return "hw-cdc";
}

size_t read(uint8_t *buf, size_t max) {
  int n = s_cdc.available();
  if (n <= 0) return 0;
  if ((size_t)n > max) n = (int)max;
  return s_cdc.read(buf, (size_t)n);
}

bool write(const uint8_t *data, size_t len) {
  uint32_t lastProgress = millis();
  while (len) {
    if (!HWCDC::isPlugged()) return false;
    size_t n = s_cdc.write(data, len);
    if (n) {
      data += n;
      len -= n;
      lastProgress = millis();
      continue;
    }
    if (millis() - lastProgress > Cfg::TX_STALL_MS) return false;
    vTaskDelay(1);
  }
  return true;
}

bool endBurst() {
  // No s_cdc.flush() here: in core 3.3.x it gives up after tx_timeout_ms (20 ms) without progress,
  // then marks the port disconnected and THROWS AWAY everything still queued. A phone that pauses
  // for a moment then loses half a frame and later messages ("camera stuck"). The driver's
  // interrupt sends the queue by itself; the pad byte just ends the burst with a short packet.
  static const uint8_t pad = 0;
  return s_cdc.write(&pad, 1) == 1;
}

void discardPending() {
  // HWCDC has no API to drop queued bytes; the phone's parser resynchronises instead.
}

}  // namespace UsbLink
#endif
