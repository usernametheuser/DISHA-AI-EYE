// Native USB data link to the phone (board port labelled "USB-OTG", GPIO19/20).
//
// Selected by Arduino IDE > Tools > USB Mode:
//   "USB-OTG (TinyUSB)"     -> vendor-class interface "DISHA-CAM Link" with one bulk IN and
//                              one bulk OUT endpoint (primary transport).
//   "Hardware CDC and JTAG" -> the chip's fixed USB Serial/JTAG CDC-ACM port (fallback).
// The protocol on top is identical; the Android app detects which one it is talking to.
//
// This layer moves raw bytes only. It is not thread-safe for writes: ProtocolIO serialises
// all writers with its own mutex.
#pragma once
#include <Arduino.h>

namespace UsbLink {

bool begin();
bool mounted();              // a USB host has configured the device
const char *transportName(); // "tinyusb-vendor" or "hw-cdc"

// Non-blocking read of bytes sent by the phone.
size_t read(uint8_t *buf, size_t max);

// Blocking write; false if the link is down or made no progress for Cfg::TX_STALL_MS.
bool write(const uint8_t *data, size_t len);

// Ends a burst: pushes buffered bytes out and terminates the USB transfer with a short
// packet (one 0x00 pad byte, ignored by the phone's parser) so the phone receives the
// data immediately instead of waiting for more.
bool endBurst();

// Drops bytes still queued for sending (after an aborted message or a new session).
void discardPending();

}  // namespace UsbLink
