#include "command_handler.h"
#include "esp_task_wdt.h"
#include "../config/disha_config.h"
#include "../camera/camera_service.h"
#include "../diagnostics/log.h"
#include "../protocol/disha_protocol.h"
#include "../protocol/protocol_io.h"
#include "../status/status_report.h"
#include "../usb/usb_link.h"

namespace CommandHandler {

using namespace Proto;

namespace {
volatile bool s_session = false;
volatile uint32_t s_sessionNo = 0;
uint32_t s_lastHostMsgAt = 0;  // link task only
volatile bool s_endRequested = false;
const char *volatile s_endReason = nullptr;
char s_json[2560];  // link task only

void reply(const ProtocolIO::HostMessage &m, Status st, const char *text) {
  ProtocolIO::sendResult(m.seq, m.type, st, text);
}

void endSession(const char *reason) {
  if (!s_session) return;
  s_session = false;
  Log::setHostForwarding(false);
  CameraService::stopStreamingSilently();
  Log::printf("[usb] session %u ended: %s", (unsigned)s_sessionNo, reason);
}

void startSession(const ProtocolIO::HostMessage &m) {
  if (s_session) Log::printf("[usb] HELLO during session %u: starting a new one", (unsigned)s_sessionNo);
  Log::setHostForwarding(false);
  CameraService::stopStreamingSilently();
  s_sessionNo = s_sessionNo + 1;
  s_session = true;
  StatusReport::hello(s_json, sizeof(s_json), s_sessionNo);
  ProtocolIO::sendText(HELLO_ACK, m.seq, s_json);
  Log::setHostForwarding(true);
  Log::printf("[usb] phone connected over %s (session %u)", UsbLink::transportName(), (unsigned)s_sessionNo);
}

void onMessage(const ProtocolIO::HostMessage &m) {
  s_lastHostMsgAt = millis();
  if (m.version != VERSION) {
    reply(m, ERR_BAD_VERSION, "DISHA-CAM speaks protocol version 1");
    return;
  }
  if (m.type == HELLO) {
    startSession(m);
    return;
  }
  if (!s_session) {
    reply(m, ERR_NO_SESSION, "No session: send HELLO first");
    return;
  }

  switch (m.type) {
    case PING:
      ProtocolIO::send(PONG, m.seq, m.payload, m.len < 64 ? m.len : 64);
      break;

    case GET_STATUS:
      StatusReport::status(s_json, sizeof(s_json));
      ProtocolIO::sendText(Proto::STATUS, m.seq, s_json);  // qualified: the ROM headers define a global STATUS
      break;

    case CAPTURE_FRAME: {
      if (m.len != 0 && m.len != 2) {
        reply(m, ERR_BAD_PAYLOAD, "CAPTURE_FRAME payload: u8 fresh, u8 quality");
        break;
      }
      const bool fresh = m.len ? m.payload[0] != 0 : true;
      const uint8_t quality = m.len ? m.payload[1] : 0;
      if (!CameraService::requestCapture(m.seq, fresh, quality)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;
    }

    case START_STREAM: {
      if (m.len != 2) {
        reply(m, ERR_BAD_PAYLOAD, "START_STREAM payload: u8 fps, u8 quality");
        break;
      }
      const uint8_t fps = m.payload[0];
      if (fps < 1 || fps > Cfg::STREAM_FPS_MAX) {
        reply(m, ERR_BAD_PAYLOAD, "fps must be 1-15");
        break;
      }
      if (!CameraService::requestStream(m.seq, true, fps, m.payload[1])) reply(m, ERR_BUSY, "Camera busy, try again");
      break;
    }

    case STOP_STREAM:
      if (m.len != 0) {
        reply(m, ERR_BAD_PAYLOAD, "STOP_STREAM has no payload");
        break;
      }
      if (!CameraService::requestStream(m.seq, false, 0, 0)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;

    case SET_RESOLUTION: {
      if (m.len != 4) {
        reply(m, ERR_BAD_PAYLOAD, "SET_RESOLUTION payload: u16 width, u16 height");
        break;
      }
      const uint16_t w = get16(m.payload), h = get16(m.payload + 2);
      if (!CameraService::sizeSupported(w, h)) {
        reply(m, ERR_UNSUPPORTED, "Supported: 320x240, 640x480, 800x600");
        break;
      }
      if (!CameraService::requestResolution(m.seq, w, h)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;
    }

    case SET_ORIENTATION:
      if (m.len != 2) {
        reply(m, ERR_BAD_PAYLOAD, "SET_ORIENTATION payload: u8 vflip, u8 hmirror");
        break;
      }
      if (!CameraService::requestOrientation(m.seq, m.payload[0] != 0, m.payload[1] != 0)) {
        reply(m, ERR_BUSY, "Camera busy, try again");
      }
      break;

    case TAKE_PHOTO:
      if (m.len > 1) {
        reply(m, ERR_BAD_PAYLOAD, "TAKE_PHOTO payload: optional u8 quality");
        break;
      }
      if (!CameraService::requestPhoto(m.seq, m.len ? m.payload[0] : 0, false)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;

    case START_RECORDING:
      if (m.len != 0 && m.len != 2) {
        reply(m, ERR_BAD_PAYLOAD, "START_RECORDING payload: u8 fps, u8 quality");
        break;
      }
      if (!CameraService::requestRecording(m.seq, true, m.len ? m.payload[0] : 0, m.len ? m.payload[1] : 0, false)) {
        reply(m, ERR_BUSY, "Camera busy, try again");
      }
      break;

    case STOP_RECORDING:
      if (!CameraService::requestRecording(m.seq, false, 0, 0, false)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;

    case GET_STORAGE_STATUS:
      if (!CameraService::requestStorageStatus(m.seq)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;

    case LIST_FILES:
      if (!CameraService::requestFileList(m.seq, m.len ? m.payload[0] : 30, false)) reply(m, ERR_BUSY, "Camera busy, try again");
      break;

    default: {
      char text[48];
      snprintf(text, sizeof(text), "Unknown command 0x%02x", m.type);
      reply(m, ERR_UNKNOWN_COMMAND, text);
      break;
    }
  }
}

ProtocolIO::Parser s_parser(onMessage);

void linkTask(void *) {
  const bool wdt = esp_task_wdt_add(nullptr) == ESP_OK;
  uint8_t rx[256];
  char line[Log::kLineMax + 1];
  bool wasMounted = false;
  for (;;) {
    if (wdt) esp_task_wdt_reset();

    const bool mounted = UsbLink::mounted();
    if (mounted != wasMounted) {
      wasMounted = mounted;
      if (mounted) {
        Log::printf("[usb] USB host attached; waiting for the DISHA GLASS OS app");
      } else {
        endSession("USB host detached");
        s_parser.reset();
        Log::printf("[usb] USB host detached");
      }
    }
    if (s_endRequested) {
      s_endRequested = false;
      endSession(s_endReason ? s_endReason : "requested");
    }

    const size_t n = mounted ? UsbLink::read(rx, sizeof(rx)) : 0;
    if (n) s_parser.feed(rx, n);

    if (s_session) {
      for (int k = 0; k < 4 && Log::popForHost(line, sizeof(line)); k++) ProtocolIO::sendText(LOG, 0, line);
      if (millis() - s_lastHostMsgAt > Cfg::SESSION_TIMEOUT_MS) endSession("no message from the phone for 5 s");
    }
    if (!n) vTaskDelay(1);
  }
}
}  // namespace

bool begin() {
  return xTaskCreatePinnedToCore(linkTask, "disha_link", 8192, nullptr, 5, nullptr, tskNO_AFFINITY) == pdPASS;
}

bool sessionActive() {
  return s_session;
}

uint32_t sessionNumber() {
  return s_sessionNo;
}

void requestSessionEnd(const char *reason) {
  s_endReason = reason;
  s_endRequested = true;
}

}  // namespace CommandHandler
