// Phone session and command dispatch.
//
// A "link" task reads bytes from the USB link, parses messages, answers quick commands
// itself (HELLO, PING, GET_STATUS) and queues camera work for the camera task.
// A session starts with HELLO and ends when USB goes away, the phone is silent for
// Cfg::SESSION_TIMEOUT_MS, or sending stalls. Streaming only runs inside a session.
#pragma once
#include <Arduino.h>

namespace CommandHandler {

bool begin();
bool sessionActive();
uint32_t sessionNumber();

// Thread-safe: the link task ends the session on its next loop.
void requestSessionEnd(const char *reason);

}  // namespace CommandHandler
