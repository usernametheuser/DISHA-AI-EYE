#include "protocol_io.h"
#include "crc.h"
#include "../config/disha_config.h"
#include "../usb/usb_link.h"

static_assert(Cfg::CHUNK_DATA_BYTES + Proto::FRAME_CHUNK_HEADER_LEN <= Proto::MAX_DEVICE_PAYLOAD,
              "frame chunk does not fit in one message");
static_assert(Cfg::JPEG_BUF_BYTES / Cfg::CHUNK_DATA_BYTES < 65535, "chunk count must fit in u16");

namespace ProtocolIO {

using namespace Proto;

namespace {
SemaphoreHandle_t s_txLock = nullptr;
uint16_t s_txSeq = 0;
portMUX_TYPE s_statsMux = portMUX_INITIALIZER_UNLOCKED;
Stats s_stats = {};

void countSend(bool ok, size_t bytes) {
  taskENTER_CRITICAL(&s_statsMux);
  if (ok) {
    s_stats.messagesSent++;
    s_stats.bytesSent += bytes;
  } else {
    s_stats.sendFailures++;
  }
  taskEXIT_CRITICAL(&s_statsMux);
}

void countRx(uint32_t messages, uint32_t crcErrors, uint32_t dropped, uint32_t oversize) {
  taskENTER_CRITICAL(&s_statsMux);
  s_stats.rxMessages += messages;
  s_stats.rxCrcErrors += crcErrors;
  s_stats.rxDroppedBytes += dropped;
  s_stats.rxOversize += oversize;
  taskEXIT_CRITICAL(&s_statsMux);
}
}  // namespace

void begin() {
  s_txLock = xSemaphoreCreateMutex();
}

Stats stats() {
  taskENTER_CRITICAL(&s_statsMux);
  Stats s = s_stats;
  taskEXIT_CRITICAL(&s_statsMux);
  return s;
}

bool send(uint8_t type, uint16_t ref, const uint8_t *a, size_t aLen, const uint8_t *b, size_t bLen, bool endOfBurst) {
  const size_t plen = aLen + bLen;
  if (plen > MAX_DEVICE_PAYLOAD || !s_txLock) {
    countSend(false, 0);
    return false;
  }

  // Payload CRC is computed before taking the lock so other senders wait less.
  uint32_t c = Crc::crc32Begin();
  if (aLen) c = Crc::crc32Update(c, a, aLen);
  if (bLen) c = Crc::crc32Update(c, b, bLen);
  uint8_t trailer[TRAILER_LEN];
  put32(trailer, Crc::crc32End(c));

  uint8_t hdr[HEADER_LEN];
  xSemaphoreTake(s_txLock, portMAX_DELAY);
  if (++s_txSeq == 0) s_txSeq = 1;
  hdr[0] = MAGIC0;
  hdr[1] = MAGIC1;
  hdr[2] = VERSION;
  hdr[3] = type;
  put16(hdr + 4, s_txSeq);
  put16(hdr + 6, ref);
  put32(hdr + 8, (uint32_t)plen);
  put16(hdr + 12, 0);
  put16(hdr + 14, Crc::crc16(hdr, 14));

  bool ok = UsbLink::mounted() && UsbLink::write(hdr, HEADER_LEN) && (aLen == 0 || UsbLink::write(a, aLen)) &&
            (bLen == 0 || UsbLink::write(b, bLen)) && UsbLink::write(trailer, TRAILER_LEN);
  if (ok && endOfBurst) ok = UsbLink::endBurst();
  if (!ok) UsbLink::discardPending();  // never leave half a message queued
  xSemaphoreGive(s_txLock);

  countSend(ok, HEADER_LEN + plen + TRAILER_LEN);
  return ok;
}

bool sendResult(uint16_t ref, uint8_t command, Status status, const char *message) {
  const uint8_t head[2] = {(uint8_t)status, command};
  const size_t mlen = message ? strnlen(message, 200) : 0;
  return send(RESULT, ref, head, sizeof(head), (const uint8_t *)message, mlen);
}

bool sendText(uint8_t type, uint16_t ref, const char *text) {
  const size_t len = strnlen(text, MAX_DEVICE_PAYLOAD);
  return send(type, ref, (const uint8_t *)text, len);
}

bool sendJpegFrame(uint32_t frameId, const uint8_t *jpeg, size_t len, uint16_t width, uint16_t height, uint8_t flags,
                   uint16_t ref, uint16_t encodeMs, uint32_t captureMillis) {
  if (!jpeg || len == 0 || len > Cfg::JPEG_BUF_BYTES) return false;
  const uint32_t frameCrc = Crc::crc32(jpeg, len);
  const uint32_t chunk = Cfg::CHUNK_DATA_BYTES;
  const uint16_t count = (uint16_t)((len + chunk - 1) / chunk);

  uint8_t h[FRAME_CHUNK_HEADER_LEN];
  for (uint16_t i = 0; i < count; i++) {
    const uint32_t off = (uint32_t)i * chunk;
    const uint32_t n = (len - off) < chunk ? (uint32_t)(len - off) : chunk;
    uint8_t f = flags;
    if (i == 0) f |= FF_FIRST;
    if (i == count - 1) f |= FF_LAST;
    put32(h + 0, frameId);
    put32(h + 4, (uint32_t)len);
    put32(h + 8, off);
    put16(h + 12, i);
    put16(h + 14, count);
    put16(h + 16, width);
    put16(h + 18, height);
    h[20] = FMT_JPEG;
    h[21] = f;
    put16(h + 22, encodeMs);
    put32(h + 24, captureMillis);
    put32(h + 28, frameCrc);
    if (!send(FRAME_CHUNK, ref, h, sizeof(h), jpeg + off, n, i == count - 1)) return false;
  }
  return true;
}

// ----------------------------------------------------------------------------
// Parser
// ----------------------------------------------------------------------------
void Parser::feed(const uint8_t *data, size_t len) {
  while (len) {
    const size_t room = sizeof(buf_) - used_;
    const size_t take = len < room ? len : room;
    memcpy(buf_ + used_, data, take);
    used_ += take;
    data += take;
    len -= take;
    process();
  }
}

void Parser::count(uint32_t messages, uint32_t crcErrors, uint32_t dropped, uint32_t oversize) {
  if (countStats_) countRx(messages, crcErrors, dropped, oversize);
}

void Parser::discard(size_t n) {
  if (n >= used_) {
    used_ = 0;
    return;
  }
  memmove(buf_, buf_ + n, used_ - n);
  used_ -= n;
}

void Parser::process() {
  for (;;) {
    // Find the magic pair.
    size_t i = 0;
    while (i + 1 < used_ && !(buf_[i] == MAGIC0 && buf_[i + 1] == MAGIC1)) i++;
    if (i + 1 >= used_) {
      // None yet. Keep a trailing MAGIC0, it may be the start of the next message.
      const size_t keep = (used_ > 0 && buf_[used_ - 1] == MAGIC0) ? 1 : 0;
      count(0, 0, (uint32_t)(used_ - keep), 0);
      discard(used_ - keep);
      return;
    }
    if (i) {
      count(0, 0, (uint32_t)i, 0);
      discard(i);
    }
    if (used_ < HEADER_LEN) return;

    if (Crc::crc16(buf_, 14) != get16(buf_ + 14)) {
      count(0, 1, 1, 0);
      discard(1);
      continue;
    }
    const uint32_t plen = get32(buf_ + 8);
    if (plen > MAX_HOST_PAYLOAD) {
      count(0, 0, 1, 1);
      discard(1);
      continue;
    }
    const size_t total = HEADER_LEN + plen + TRAILER_LEN;
    if (used_ < total) return;
    if (Crc::crc32(buf_ + HEADER_LEN, plen) != get32(buf_ + HEADER_LEN + plen)) {
      count(0, 1, 1, 0);
      discard(1);
      continue;
    }

    HostMessage m;
    m.version = buf_[2];
    m.type = buf_[3];
    m.seq = get16(buf_ + 4);
    m.ref = get16(buf_ + 6);
    m.len = plen;
    m.payload = buf_ + HEADER_LEN;
    count(1, 0, 0, 0);
    handler_(m);
    discard(total);
  }
}

namespace {
bool s_selfTestOk = false;
void selfTestHandler(const HostMessage &m) {
  s_selfTestOk = m.version == VERSION && m.type == CAPTURE_FRAME && m.seq == 3 && m.ref == 0 && m.len == 2 &&
                 m.payload[0] == 1 && m.payload[1] == 0;
}
}  // namespace

bool selfTest() {
  // CAPTURE_FRAME, seq 3, ref 0, payload 01 00 (docs/PROTOCOL.md "Test vector").
  static const uint8_t golden[] = {0xD1, 0x5A, 0x01, 0x10, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00,
                                   0x00, 0x00, 0x00, 0x02, 0xC9, 0x01, 0x00, 0xBE, 0x23, 0xC2, 0x58};
  s_selfTestOk = false;
  Parser p(selfTestHandler, false);
  p.feed(golden, 9);  // split mid-header to exercise reassembly
  p.feed(golden + 9, sizeof(golden) - 9);
  return s_selfTestOk;
}

}  // namespace ProtocolIO
