#include "crc.h"

namespace Crc {

namespace {
struct Table {
  uint32_t v[256];
};

constexpr Table makeTable() {
  Table t{};
  for (uint32_t i = 0; i < 256; i++) {
    uint32_t c = i;
    for (int k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
    t.v[i] = c;
  }
  return t;
}

// Built at compile time, stored in flash.
constexpr Table kTable = makeTable();
}  // namespace

uint16_t crc16(const uint8_t *data, size_t len, uint16_t crc) {
  while (len--) {
    crc ^= (uint16_t)(*data++) << 8;
    for (int b = 0; b < 8; b++) crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
  }
  return crc;
}

uint32_t crc32Update(uint32_t state, const uint8_t *data, size_t len) {
  while (len--) state = kTable.v[(state ^ *data++) & 0xFF] ^ (state >> 8);
  return state;
}

uint32_t crc32(const uint8_t *data, size_t len) {
  return crc32End(crc32Update(crc32Begin(), data, len));
}

bool selfTest() {
  static const uint8_t check[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
  return crc16(check, sizeof(check)) == 0x29B1 && crc32(check, sizeof(check)) == 0xCBF43926u;
}

}  // namespace Crc
