// DISHA USB protocol v1 - shared constants.
// Must match android/DishaGlassOS/app/src/main/java/com/disha/glassos/protocol/DishaProtocol.kt
// and docs/PROTOCOL.md.
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace Proto {

constexpr uint8_t MAGIC0  = 0xD1;
constexpr uint8_t MAGIC1  = 0x5A;
constexpr uint8_t VERSION = 1;

// Message = 16-byte header | payload | CRC-32 of payload (4 bytes). All integers little-endian.
//   0  u8  magic0 (0xD1)      1  u8  magic1 (0x5A)
//   2  u8  version (1)        3  u8  type
//   4  u16 seq   sender's message counter
//   6  u16 ref   seq of the request this message answers, 0 if unsolicited
//   8  u32 payload length
//  12  u16 reserved (0)
//  14  u16 CRC-16/CCITT-FALSE of bytes 0..13
constexpr size_t HEADER_LEN  = 16;
constexpr size_t TRAILER_LEN = 4;

constexpr uint32_t MAX_DEVICE_PAYLOAD = 16384;  // device -> phone
constexpr uint32_t MAX_HOST_PAYLOAD   = 512;    // phone -> device

enum MsgType : uint8_t {
  // phone -> device
  HELLO              = 0x01,
  PING               = 0x02,
  GET_STATUS         = 0x03,
  CAPTURE_FRAME      = 0x10,
  START_STREAM       = 0x11,
  STOP_STREAM        = 0x12,
  SET_RESOLUTION     = 0x13,
  SET_ORIENTATION    = 0x14,
  TAKE_PHOTO         = 0x20,  // save a photo on the microSD card
  START_RECORDING    = 0x21,  // record MJPEG AVI video on the microSD card
  STOP_RECORDING     = 0x22,
  GET_STORAGE_STATUS = 0x23,  // answered with STORAGE
  LIST_FILES         = 0x24,  // answered with FILE_LIST

  // device -> phone
  RESULT      = 0x80,
  HELLO_ACK   = 0x81,
  PONG        = 0x82,
  STATUS      = 0x83,
  STORAGE     = 0x84,  // JSON storage status (also sent unsolicited when recording stops by itself)
  FILE_LIST   = 0x85,  // JSON list of recent files on the card
  FRAME_CHUNK = 0x90,
  LOG         = 0xA0,
};

// RESULT payload: u8 status | u8 command type | UTF-8 message
enum Status : uint8_t {
  OK                  = 0,
  ERR_UNKNOWN_COMMAND = 1,
  ERR_BAD_PAYLOAD     = 2,
  ERR_BUSY            = 3,
  ERR_CAMERA          = 4,
  ERR_ENCODE          = 5,
  ERR_UNSUPPORTED     = 6,
  ERR_NO_SESSION      = 7,
  ERR_TOO_LARGE       = 8,
  ERR_INTERNAL        = 9,
  ERR_BAD_VERSION     = 10,
  ERR_NOT_IMPLEMENTED = 11,
  ERR_USB             = 12,
  ERR_STORAGE         = 13,  // no card, card full, write failed
};

// FRAME_CHUNK payload = 32-byte chunk header | image bytes
//   0  u32 frame id            4  u32 total frame length
//   8  u32 byte offset of this chunk
//  12  u16 chunk index        14  u16 chunk count
//  16  u16 width              18  u16 height
//  20  u8  pixel format       21  u8  flags
//  22  u16 encode time (ms)   24  u32 device uptime (ms) at capture
//  28  u32 CRC-32 of the whole frame
constexpr size_t FRAME_CHUNK_HEADER_LEN = 32;

enum PixelFormat : uint8_t {
  FMT_JPEG = 1,
};

enum FrameFlags : uint8_t {
  FF_FIRST     = 0x01,
  FF_LAST      = 0x02,
  FF_REQUESTED = 0x04,  // answer to CAPTURE_FRAME (ref = request seq)
  FF_STREAM    = 0x08,  // continuous stream frame (ref = 0)
};

inline void put16(uint8_t *p, uint16_t v) {
  p[0] = (uint8_t)v;
  p[1] = (uint8_t)(v >> 8);
}
inline void put32(uint8_t *p, uint32_t v) {
  p[0] = (uint8_t)v;
  p[1] = (uint8_t)(v >> 8);
  p[2] = (uint8_t)(v >> 16);
  p[3] = (uint8_t)(v >> 24);
}
inline uint16_t get16(const uint8_t *p) {
  return (uint16_t)(p[0] | (p[1] << 8));
}
inline uint32_t get32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

}  // namespace Proto
