// Builds and sends protocol messages, and parses messages coming from the phone.
#pragma once
#include <Arduino.h>
#include "disha_protocol.h"

namespace ProtocolIO {

void begin();

// Sends one complete message (atomic with respect to other senders). The payload is the
// concatenation of a[aLen] and b[bLen]. endOfBurst=false lets a multi-message transfer
// (the chunks of one frame) stream without the per-burst drain.
// Returns false if USB is down or stalled; the message is then dropped.
bool send(uint8_t type, uint16_t ref, const uint8_t *a, size_t aLen, const uint8_t *b = nullptr, size_t bLen = 0,
          bool endOfBurst = true);

bool sendResult(uint16_t ref, uint8_t command, Proto::Status status, const char *message);
bool sendText(uint8_t type, uint16_t ref, const char *text);  // JSON documents and log lines

// Splits one JPEG into FRAME_CHUNK messages.
bool sendJpegFrame(uint32_t frameId, const uint8_t *jpeg, size_t len, uint16_t width, uint16_t height, uint8_t flags,
                   uint16_t ref, uint16_t encodeMs, uint32_t captureMillis);

struct Stats {
  uint32_t messagesSent;
  uint32_t sendFailures;
  uint64_t bytesSent;
  uint32_t rxMessages;
  uint32_t rxCrcErrors;
  uint32_t rxDroppedBytes;
  uint32_t rxOversize;
};
Stats stats();

struct HostMessage {
  uint8_t version;
  uint8_t type;
  uint16_t seq;
  uint16_t ref;
  uint32_t len;
  const uint8_t *payload;
};

// Stream parser for phone -> device bytes. Resynchronises on the magic bytes and drops
// anything with a bad header CRC, bad payload CRC or an oversized length.
class Parser {
public:
  using Handler = void (*)(const HostMessage &msg);
  explicit Parser(Handler handler, bool countStats = true) : handler_(handler), countStats_(countStats) {}
  void feed(const uint8_t *data, size_t len);
  void reset() { used_ = 0; }

private:
  void process();
  void discard(size_t n);
  void count(uint32_t messages, uint32_t crcErrors, uint32_t dropped, uint32_t oversize);

  Handler handler_;
  bool countStats_;
  uint8_t buf_[Proto::HEADER_LEN + Proto::MAX_HOST_PAYLOAD + Proto::TRAILER_LEN];
  size_t used_ = 0;
};

// Parses the protocol test vector from docs/PROTOCOL.md (fed in two pieces). Same vector as the
// Android unit test and the PC tools, so all three implementations are checked against it.
bool selfTest();

}  // namespace ProtocolIO
