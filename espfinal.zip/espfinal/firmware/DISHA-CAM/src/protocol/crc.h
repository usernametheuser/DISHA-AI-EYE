// CRCs used by the DISHA USB protocol.
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace Crc {

// CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF, no reflection, no final XOR.
// Check value: "123456789" -> 0x29B1
uint16_t crc16(const uint8_t *data, size_t len, uint16_t crc = 0xFFFF);

// CRC-32/ISO-HDLC (zlib, java.util.zip.CRC32). Check value: "123456789" -> 0xCBF43926
// Incremental: s = crc32Begin(); s = crc32Update(s, a, n); ...; crc = crc32End(s);
inline uint32_t crc32Begin() { return 0xFFFFFFFFu; }
uint32_t crc32Update(uint32_t state, const uint8_t *data, size_t len);
inline uint32_t crc32End(uint32_t state) { return state ^ 0xFFFFFFFFu; }
uint32_t crc32(const uint8_t *data, size_t len);

// Verifies both check values; returns false if the implementation is broken.
bool selfTest();

}  // namespace Crc
