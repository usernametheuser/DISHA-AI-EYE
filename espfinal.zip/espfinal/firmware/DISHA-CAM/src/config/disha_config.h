// DISHA-CAM - board pins and firmware defaults
#pragma once
#include <Arduino.h>

#define DISHA_FW_NAME    "DISHA-CAM"
#define DISHA_FW_VERSION "0.3.0"

// ---------------------------------------------------------------------------
// Wi-Fi web mode (optional, OFF by default). The USB link to the phone stays the camera's
// transport; this extra mode is only for showing the glasses in a browser (for example to
// judges). It is switched on and off by the user only: hold BOOT 5 s, or type "wifi on" /
// "wifi off" on the serial console. The choice is remembered; the RGB LED blinks white
// while Wi-Fi is on. Nothing falls back to Wi-Fi by itself.
//
// Join an existing network (best: the phone's or laptop's hotspot, 2.4 GHz, so the browser
// also has internet for the AI). Leave the name empty to make the board's own hotspot
// "DISHA-CAM" (password below) instead; the page is then at http://192.168.4.1
// ---------------------------------------------------------------------------
#define DISHA_WIFI_SSID     ""
#define DISHA_WIFI_PASSWORD ""
#define DISHA_AP_SSID       "DISHA-CAM"
#define DISHA_AP_PASSWORD   "dishacam123"   // at least 8 characters

// Name of the USB vendor interface. The Android app identifies the link by this string.
#define DISHA_LINK_INTERFACE_NAME "DISHA-CAM Link"

// ---------------------------------------------------------------------------
// Board: "ESP32-S3-WROOM" CAM board (Freenove ESP32-S3 WROOM CAM layout),
// ESP32-S3-N16R8 module (16 MB flash, 8 MB octal PSRAM), GC2145 sensor on the
// "RHYX M21-45" camera module. Pins copied from the working S3_CAM.ino.
// ---------------------------------------------------------------------------
namespace Pins {
constexpr int CAM_PWDN  = -1;
constexpr int CAM_RESET = -1;
constexpr int CAM_XCLK  = 15;
constexpr int CAM_SDA   = 4;
constexpr int CAM_SCL   = 5;
constexpr int CAM_D7    = 16;
constexpr int CAM_D6    = 17;
constexpr int CAM_D5    = 18;
constexpr int CAM_D4    = 12;
constexpr int CAM_D3    = 10;
constexpr int CAM_D2    = 8;
constexpr int CAM_D1    = 9;
constexpr int CAM_D0    = 11;
constexpr int CAM_VSYNC = 6;
constexpr int CAM_HREF  = 7;
constexpr int CAM_PCLK  = 13;

// microSD slot (SD_MMC 1-bit mode: only D0 is wired), same as the working S3_CAM.ino.
constexpr int SD_CLK = 39;
constexpr int SD_CMD = 38;
constexpr int SD_D0  = 40;

constexpr int LED_IO2 = 2;    // small LED marked IO2: on while camera frames leave the board
constexpr int RGB_LED = 48;   // WS2812 marked 48: overall state
constexpr int BOOT_BTN = 0;   // BOOT button: short press = photo to SD, hold 1.5 s = start/stop SD video, hold 5 s = Wi-Fi web mode on/off
// Native USB (USB-OTG port): GPIO19 (D-) / GPIO20 (D+), owned by the USB peripheral.
// USB-UART port: CH343/CH340 bridge on UART0 (GPIO43 TX / GPIO44 RX): flashing + debug log.
}  // namespace Pins

namespace Cfg {
constexpr uint32_t SERIAL_BAUD = 115200;   // debug log on the USB-UART port

constexpr uint32_t CAM_XCLK_HZ = 20000000;  // as in the working S3_CAM.ino

constexpr uint8_t JPEG_QUALITY_DEFAULT = 80;  // software JPEG quality, 1-100
constexpr uint8_t JPEG_QUALITY_MIN     = 10;
constexpr uint8_t JPEG_QUALITY_MAX     = 95;

constexpr uint8_t STREAM_FPS_DEFAULT = 2;
constexpr uint8_t STREAM_FPS_MAX     = 15;

// One encoded JPEG frame lives here (PSRAM). 800x600 at quality 95 stays well below this.
constexpr size_t JPEG_BUF_BYTES = 512 * 1024;

// Image bytes per FRAME_CHUNK message. Must be <= Proto::MAX_DEVICE_PAYLOAD - 32.
constexpr uint32_t CHUNK_DATA_BYTES = 8192;

constexpr uint32_t SESSION_TIMEOUT_MS = 5000;   // phone silent this long -> session ends, streaming stops
constexpr uint32_t TX_STALL_MS        = 1500;   // no USB progress this long -> message aborted
constexpr int STREAM_SEND_FAILS_BEFORE_STOP = 3;  // stream frames in a row the phone doesn't take -> session ends
constexpr uint32_t CAMERA_RETRY_MS    = 5000;   // camera init retry interval after a failure
constexpr int CAPTURE_FAILS_BEFORE_REINIT = 3;

constexpr uint32_t WATCHDOG_TIMEOUT_MS = 10000;  // camera/link task hang -> panic -> reboot

// microSD
constexpr const char *SD_DIR = "/DISHA";             // photos IMG_nnnnn.jpg and videos VID_nnnnn.avi
constexpr uint8_t PHOTO_QUALITY_DEFAULT = 90;
constexpr uint8_t RECORD_FPS_DEFAULT = 5;
constexpr uint8_t RECORD_QUALITY_DEFAULT = 75;
constexpr uint64_t SD_MIN_FREE_PHOTO = 2ULL << 20;   // refuse a photo below 2 MB free
constexpr uint64_t SD_MIN_FREE_RECORD = 50ULL << 20; // refuse to start recording below 50 MB free
constexpr uint64_t SD_STOP_RECORD_FREE = 20ULL << 20;// stop recording when free space falls below 20 MB
constexpr uint32_t AVI_MAX_FRAMES = 36000;           // per file (2 h at 5 fps); then a new file starts
constexpr uint64_t AVI_MAX_BYTES = 1000ULL << 20;    // per file (AVI 1.0 players handle < 1 GB best)
constexpr uint32_t AVI_HEADER_UPDATE_FRAMES = 30;    // keep the file playable if power is cut

// Wi-Fi web mode
constexpr uint8_t WEB_STREAM_FPS = 8;               // live view in the browser
constexpr uint8_t WEB_QUALITY = 70;                 // JPEG quality of the browser stream
constexpr uint32_t WIFI_JOIN_TIMEOUT_MS = 15000;     // then the board makes its own hotspot
constexpr uint32_t BOOT_HOLD_WIFI_MS = 5000;
}  // namespace Cfg
