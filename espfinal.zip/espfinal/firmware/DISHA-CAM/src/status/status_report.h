// JSON documents sent to the phone (HELLO_ACK and STATUS) and printed on the serial console.
#pragma once
#include <Arduino.h>

namespace StatusReport {

size_t hello(char *out, size_t cap, uint32_t session);
size_t status(char *out, size_t cap);
const char *resetReason();

}  // namespace StatusReport
