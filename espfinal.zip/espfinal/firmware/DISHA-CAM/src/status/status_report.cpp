#include "status_report.h"
#include "esp_system.h"
#include "../config/disha_config.h"
#include "../camera/camera_service.h"
#include "../command/command_handler.h"
#include "../protocol/disha_protocol.h"
#include "../protocol/protocol_io.h"
#include "../storage/sd_storage.h"
#include "../usb/usb_link.h"

namespace StatusReport {

namespace {
size_t cameraJson(char *out, size_t cap) {
  CameraService::Info c;
  CameraService::getInfo(c);
  int n = snprintf(out, cap,
                   "{\"state\":\"%s\",\"problem\":\"%s\",\"err\":\"0x%x\",\"sensor\":\"%s\",\"pid\":\"0x%04x\","
                   "\"sensorJpeg\":%s,\"source\":\"RGB565, JPEG encoded on ESP32-S3\",\"format\":\"jpeg\","
                   "\"width\":%u,\"height\":%u,\"quality\":%u,\"vflip\":%d,\"hmirror\":%d,"
                   "\"streaming\":%s,\"recording\":%s,\"fpsTarget\":%u,\"fpsActual\":%.1f,\"framesSent\":%u,"
                   "\"captureFailures\":%u,\"encodeFailures\":%u,\"sendFailures\":%u,\"reinits\":%u,"
                   "\"lastJpegBytes\":%u,\"lastEncodeMs\":%u,\"lastCaptureMs\":%u}",
                   CameraService::stateName(c.state), c.problem, (unsigned)c.lastError, c.sensorName, c.sensorPid,
                   c.sensorHasJpeg ? "true" : "false", c.width, c.height, c.quality, c.vflip ? 1 : 0, c.hmirror ? 1 : 0,
                   c.streaming ? "true" : "false", c.recording ? "true" : "false", c.fpsTarget, c.fpsActual,
                   (unsigned)c.framesSent,
                   (unsigned)c.captureFailures, (unsigned)c.encodeFailures, (unsigned)c.sendFailures,
                   (unsigned)c.reinitCount, (unsigned)c.lastJpegBytes, (unsigned)c.lastEncodeMs,
                   (unsigned)c.lastCaptureMs);
  return n < 0 ? 0 : ((size_t)n < cap ? (size_t)n : cap - 1);
}
}  // namespace

const char *resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:   return "power-on";
    case ESP_RST_EXT:       return "reset pin";
    case ESP_RST_SW:        return "software restart";
    case ESP_RST_PANIC:     return "crash (panic)";
    case ESP_RST_INT_WDT:   return "interrupt watchdog";
    case ESP_RST_TASK_WDT:  return "task watchdog";
    case ESP_RST_WDT:       return "other watchdog";
    case ESP_RST_DEEPSLEEP: return "deep sleep wake";
    case ESP_RST_BROWNOUT:  return "brownout (supply voltage dropped)";
    case ESP_RST_SDIO:      return "SDIO";
    default:                return "other";
  }
}

size_t hello(char *out, size_t cap, uint32_t session) {
  char cam[760];
  cameraJson(cam, sizeof(cam));
  char sd[512];
  SdStorage::statusJson(sd, sizeof(sd));
  char sizes[96];
  CameraService::supportedSizesJson(sizes, sizeof(sizes));
  int n = snprintf(out, cap,
                   "{\"fw\":\"%s\",\"fwVersion\":\"%s\",\"proto\":%u,\"transport\":\"%s\",\"session\":%u,"
                   "\"chip\":\"%s\",\"chipRev\":%u,\"cpuMHz\":%u,\"flashMB\":%u,\"psramKB\":%u,"
                   "\"resetReason\":\"%s\",\"maxChunk\":%u,\"maxPayload\":%u,\"resolutions\":%s,"
                   "\"features\":{\"capture\":true,\"stream\":true,\"orientation\":true,\"sd\":true,\"recording\":true},"
                   "\"camera\":%s,\"storage\":%s}",
                   DISHA_FW_NAME, DISHA_FW_VERSION, Proto::VERSION, UsbLink::transportName(), (unsigned)session,
                   ESP.getChipModel(), (unsigned)ESP.getChipRevision(), (unsigned)ESP.getCpuFreqMHz(),
                   (unsigned)(ESP.getFlashChipSize() >> 20), (unsigned)(ESP.getPsramSize() >> 10), resetReason(),
                   (unsigned)Cfg::CHUNK_DATA_BYTES, (unsigned)Proto::MAX_DEVICE_PAYLOAD, sizes, cam, sd);
  return n < 0 ? 0 : ((size_t)n < cap ? (size_t)n : cap - 1);
}

size_t status(char *out, size_t cap) {
  char cam[760];
  cameraJson(cam, sizeof(cam));
  char sd[512];
  SdStorage::statusJson(sd, sizeof(sd));
  const ProtocolIO::Stats u = ProtocolIO::stats();
  int n = snprintf(out, cap,
                   "{\"uptimeMs\":%lu,\"session\":%u,\"sessionActive\":%s,\"transport\":\"%s\",\"usbMounted\":%s,"
                   "\"usb\":{\"messagesSent\":%u,\"kbSent\":%u,\"sendFailures\":%u,\"rxMessages\":%u,"
                   "\"rxCrcErrors\":%u,\"rxDroppedBytes\":%u},"
                   "\"heapFree\":%u,\"heapMin\":%u,\"psramFree\":%u,\"tempC\":%.1f,\"resetReason\":\"%s\","
                   "\"camera\":%s,\"storage\":%s}",
                   (unsigned long)millis(), (unsigned)CommandHandler::sessionNumber(),
                   CommandHandler::sessionActive() ? "true" : "false", UsbLink::transportName(),
                   UsbLink::mounted() ? "true" : "false", (unsigned)u.messagesSent, (unsigned)(u.bytesSent / 1024),
                   (unsigned)u.sendFailures, (unsigned)u.rxMessages, (unsigned)u.rxCrcErrors,
                   (unsigned)u.rxDroppedBytes, (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMinFreeHeap(),
                   (unsigned)ESP.getFreePsram(), temperatureRead(), resetReason(), cam, sd);
  return n < 0 ? 0 : ((size_t)n < cap ? (size_t)n : cap - 1);
}

}  // namespace StatusReport
