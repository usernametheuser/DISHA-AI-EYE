// Camera ownership, capture, software JPEG encoding and streaming.
//
// One FreeRTOS task ("disha_cam") owns the camera: it initialises it, serves capture and
// stream requests, changes resolution and recovers from failures. Other tasks only queue
// requests and read a snapshot of the state, so the camera driver is never used from two
// tasks at once.
//
// The GC2145 has no JPEG engine: frames are captured as RGB565 into PSRAM and encoded to
// JPEG on the ESP32-S3 (esp32-camera's frame2jpg_cb), into a 512 KB PSRAM buffer.
#pragma once
#include <Arduino.h>

namespace CameraService {

enum class State : uint8_t { Off, Initializing, Ready, Error };

struct Info {
  State state;
  int32_t lastError;     // esp_err_t of the last init failure (0 = none)
  char problem[112];     // human-readable reason when state == Error (JSON-safe text)
  uint16_t sensorPid;
  char sensorName[16];
  bool sensorHasJpeg;    // from the driver's sensor table; the GC2145 has none
  uint16_t width;
  uint16_t height;
  uint8_t quality;
  bool vflip;
  bool hmirror;
  bool streaming;
  uint8_t fpsTarget;
  float fpsActual;
  bool recording;      // MJPEG AVI to the microSD card
  uint8_t recFps;
  uint8_t recQuality;
  uint32_t framesSent;
  uint32_t captureFailures;
  uint32_t encodeFailures;
  uint32_t sendFailures;
  uint32_t reinitCount;
  uint32_t lastJpegBytes;
  uint32_t lastEncodeMs;
  uint32_t lastCaptureMs;
  uint32_t lastFrameSentAt;  // millis()
};

bool begin();
void getInfo(Info &out);
const char *stateName(State s);

// Output sizes offered in this stage.
bool sizeSupported(uint16_t width, uint16_t height);
size_t supportedSizesJson(char *out, size_t cap);  // e.g. [[320,240],[640,480],[800,600]]

// Requests from the phone. The camera task sends the reply (frame or RESULT) with ref.
// Each returns false if the request queue is full.
bool requestCapture(uint16_t ref, bool fresh, uint8_t quality);
bool requestStream(uint16_t ref, bool on, uint8_t fps, uint8_t quality);
bool requestResolution(uint16_t ref, uint16_t width, uint16_t height);
bool requestOrientation(uint16_t ref, bool vflip, bool hmirror);
void stopStreamingSilently();  // session ended: stop without sending a reply

// microSD. local = from the BOOT button or serial console: result is logged, nothing is sent.
bool requestPhoto(uint16_t ref, uint8_t quality, bool local);
bool requestRecording(uint16_t ref, bool on, uint8_t fps, uint8_t quality, bool local);
bool toggleRecordingLocal();
bool requestStorageStatus(uint16_t ref);
bool requestFileList(uint16_t ref, uint8_t maxFiles, bool local);

// Wi-Fi web mode: captures one fresh JPEG into out (cap bytes), waiting up to timeoutMs.
// Returns its size, or 0. Any task; one request at a time.
size_t grabForWeb(uint8_t *out, size_t cap, uint8_t quality, uint32_t timeoutMs);

// Serial-console tests; results are printed on the USB-UART port.
enum class LocalTest : uint8_t { Snap, SnapBase64, Fps, Flip };
bool requestLocalTest(LocalTest test);
bool requestLocalResolution(uint16_t width);

}  // namespace CameraService
