#include "camera_service.h"
#include <stdarg.h>
#include "esp_camera.h"
#include "img_converters.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_task_wdt.h"
#include "../config/disha_config.h"
#include "../diagnostics/log.h"
#include "../protocol/crc.h"
#include "../protocol/disha_protocol.h"
#include "../protocol/protocol_io.h"
#include "../command/command_handler.h"
#include "../storage/sd_storage.h"

namespace CameraService {

namespace {

enum class ReqType : uint8_t {
  Capture,
  StreamOn,
  StreamOff,
  Resolution,
  Orientation,
  Local,
  LocalResolution,
  Photo,
  RecordOn,
  RecordOff,
  RecordToggle,
  Storage,
  FileList,
  WebFrame,  // Wi-Fi web mode: one JPEG copied out for the browser
};

struct Request {
  ReqType type;
  uint16_t ref;
  uint8_t a;  // Capture: fresh   StreamOn: fps   Orientation: vflip   Local: LocalTest
  uint8_t b;  // Capture/StreamOn: quality (0 = current)               Orientation: hmirror
  uint16_t w;
  uint16_t h;
  bool silent;
};

struct SizeEntry {
  framesize_t fs;
  uint16_t w;
  uint16_t h;
};
// Stage 1 whitelist: the sizes the working S3_CAM sketch used on this board.
const SizeEntry kSizes[] = {
  {FRAMESIZE_QVGA, 320, 240},
  {FRAMESIZE_VGA, 640, 480},
  {FRAMESIZE_SVGA, 800, 600},
};

struct Encoded {
  size_t len;
  uint16_t width;
  uint16_t height;
  uint16_t encodeMs;
  uint32_t captureMs;
  uint32_t capturedAt;
};

struct JpegSink {
  uint8_t *buf;
  size_t cap;
  size_t len;
  bool overflow;
};

QueueHandle_t s_queue = nullptr;
portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
Info s_info;  // written by the camera task only; other tasks copy it under s_mux
uint8_t *s_jpeg = nullptr;
uint32_t s_frameId = 0;
framesize_t s_frameSize = FRAMESIZE_QVGA;
int s_consecutiveFails = 0;
bool s_needReinit = false;
uint32_t s_nextInitAttempt = 0;
uint32_t s_nextStreamAt = 0;
uint32_t s_lastStreamFrameAt = 0;
int s_sendFailStreak = 0;  // stream frames in a row the phone did not take
uint32_t s_nextRecAt = 0;
bool s_wdt = false;
char s_json[2048];  // camera task only: storage and file-list replies

// Wi-Fi web mode: one request at a time hands its buffer to the camera task and waits.
SemaphoreHandle_t s_webLock = nullptr;
SemaphoreHandle_t s_webDone = nullptr;
uint8_t *s_webOut = nullptr;
size_t s_webCap = 0;
volatile size_t s_webLen = 0;

template <typename F>
void update(F f) {
  taskENTER_CRITICAL(&s_mux);
  f(s_info);
  taskEXIT_CRITICAL(&s_mux);
}

void feedWdt() {
  if (s_wdt) esp_task_wdt_reset();
}

bool lookupSize(uint16_t w, uint16_t h, framesize_t *out) {
  for (const SizeEntry &e : kSizes) {
    if (e.w == w && e.h == h) {
      if (out) *out = e.fs;
      return true;
    }
  }
  return false;
}

void setProblem(esp_err_t err, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void setProblem(esp_err_t err, const char *fmt, ...) {
  char text[sizeof(s_info.problem)];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(text, sizeof(text), fmt, ap);
  va_end(ap);
  update([&](Info &i) {
    i.state = State::Error;
    i.lastError = err;
    memcpy(i.problem, text, sizeof(i.problem));
    i.streaming = false;
  });
  Log::printf("[cam] ERROR: %s", text);
}

esp_err_t initDriver(framesize_t size) {
  camera_config_t c = {};
  c.pin_pwdn = Pins::CAM_PWDN;
  c.pin_reset = Pins::CAM_RESET;
  c.pin_xclk = Pins::CAM_XCLK;
  c.pin_sccb_sda = Pins::CAM_SDA;
  c.pin_sccb_scl = Pins::CAM_SCL;
  c.pin_d7 = Pins::CAM_D7;
  c.pin_d6 = Pins::CAM_D6;
  c.pin_d5 = Pins::CAM_D5;
  c.pin_d4 = Pins::CAM_D4;
  c.pin_d3 = Pins::CAM_D3;
  c.pin_d2 = Pins::CAM_D2;
  c.pin_d1 = Pins::CAM_D1;
  c.pin_d0 = Pins::CAM_D0;
  c.pin_vsync = Pins::CAM_VSYNC;
  c.pin_href = Pins::CAM_HREF;
  c.pin_pclk = Pins::CAM_PCLK;
  c.xclk_freq_hz = Cfg::CAM_XCLK_HZ;
  c.ledc_timer = LEDC_TIMER_0;
  c.ledc_channel = LEDC_CHANNEL_0;
  // The GC2145 cannot output JPEG. Capture RGB565 (buffers sized exactly for this frame size)
  // and encode on the ESP32. Two PSRAM buffers: the sensor fills one while we encode the other.
  c.pixel_format = PIXFORMAT_RGB565;
  c.frame_size = size;
  c.jpeg_quality = 12;  // unused in RGB565 mode
  c.fb_count = 2;
  c.fb_location = CAMERA_FB_IN_PSRAM;
  c.grab_mode = CAMERA_GRAB_LATEST;
  return esp_camera_init(&c);
}

bool startCamera(framesize_t size) {
  update([](Info &i) { i.state = State::Initializing; });
  if (!psramFound()) {
    setProblem(ESP_ERR_NO_MEM, "PSRAM not found. Arduino IDE: Tools > PSRAM > OPI PSRAM, then upload again.");
    return false;
  }
  esp_err_t err = initDriver(size);
  feedWdt();
  if (err != ESP_OK) {
    setProblem(err, "Camera init failed (0x%x). Reseat the camera ribbon (contacts down, latch closed), then press RST.",
               (unsigned)err);
    return false;
  }
  sensor_t *s = esp_camera_sensor_get();
  if (!s) {
    esp_camera_deinit();
    setProblem(ESP_FAIL, "Camera driver started but no sensor answered. Reseat the ribbon cable, press RST.");
    return false;
  }
  camera_sensor_info_t *si = esp_camera_sensor_get_info(&s->id);
  Info cur;
  getInfo(cur);
  s->set_vflip(s, cur.vflip ? 1 : 0);
  s->set_hmirror(s, cur.hmirror ? 1 : 0);

  s_frameSize = size;
  const uint16_t w = resolution[size].width;
  const uint16_t h = resolution[size].height;
  update([&](Info &i) {
    i.state = State::Ready;
    i.lastError = ESP_OK;
    i.problem[0] = 0;
    i.sensorPid = s->id.PID;
    strlcpy(i.sensorName, si ? si->name : "unknown", sizeof(i.sensorName));
    i.sensorHasJpeg = si ? si->support_jpeg : false;
    i.width = w;
    i.height = h;
  });
  Log::printf("[cam] %s (PID 0x%04x) ready: %ux%u RGB565, sensor JPEG: %s -> JPEG encoded on the ESP32-S3",
              si ? si->name : "unknown sensor", s->id.PID, w, h, (si && si->support_jpeg) ? "yes" : "no");
  if (s->id.PID != GC2145_PID) {
    Log::printf("[cam] note: this firmware was written for the GC2145; detected PID 0x%04x", s->id.PID);
  }
  return true;
}

bool jpegLooksComplete(const uint8_t *b, size_t n) {
  return n >= 4 && b[0] == 0xFF && b[1] == 0xD8 && b[n - 2] == 0xFF && b[n - 1] == 0xD9;
}

size_t sinkWrite(void *arg, size_t index, const void *data, size_t len) {
  JpegSink *s = static_cast<JpegSink *>(arg);
  if (s->overflow || index + len > s->cap) {
    s->overflow = true;  // frame2jpg_cb does not stop on a short write, so remember it
    return 0;
  }
  memcpy(s->buf + index, data, len);
  if (index + len > s->len) s->len = index + len;
  return len;
}

uint8_t effectiveQuality(uint8_t requested) {
  if (requested == 0) {
    Info i;
    getInfo(i);
    return i.quality;
  }
  if (requested < Cfg::JPEG_QUALITY_MIN) return Cfg::JPEG_QUALITY_MIN;
  if (requested > Cfg::JPEG_QUALITY_MAX) return Cfg::JPEG_QUALITY_MAX;
  return requested;
}

// Captures one frame and encodes it into s_jpeg.
// fresh: drop two queued frames first so the result was exposed after the request arrived.
Proto::Status captureJpeg(bool fresh, uint8_t quality, Encoded &e) {
  Info cur;
  getInfo(cur);
  if (cur.state != State::Ready || !s_jpeg) return Proto::ERR_CAMERA;

  const uint32_t t0 = millis();
  if (fresh) {
    for (int k = 0; k < 2; k++) {
      camera_fb_t *old = esp_camera_fb_get();
      if (old) esp_camera_fb_return(old);
      feedWdt();
    }
  }
  camera_fb_t *fb = esp_camera_fb_get();
  feedWdt();
  if (!fb) {
    update([](Info &i) { i.captureFailures++; });
    if (++s_consecutiveFails >= Cfg::CAPTURE_FAILS_BEFORE_REINIT) s_needReinit = true;
    Log::printf("[cam] frame capture failed (%d in a row)", s_consecutiveFails);
    return Proto::ERR_CAMERA;
  }
  s_consecutiveFails = 0;
  e.capturedAt = millis();
  e.captureMs = e.capturedAt - t0;
  e.width = fb->width;
  e.height = fb->height;

  JpegSink sink = {s_jpeg, Cfg::JPEG_BUF_BYTES, 0, false};
  const uint32_t t1 = millis();
  bool ok;
  if (fb->format == PIXFORMAT_JPEG) {  // only if a JPEG-capable sensor is fitted and configured
    ok = sinkWrite(&sink, 0, fb->buf, fb->len) == fb->len;
  } else {
    ok = frame2jpg_cb(fb, quality, sinkWrite, &sink);
  }
  esp_camera_fb_return(fb);  // hand the buffer back before sending: the sensor keeps capturing
  e.encodeMs = (uint16_t)(millis() - t1);
  feedWdt();

  if (!ok || sink.overflow || !jpegLooksComplete(s_jpeg, sink.len)) {
    update([](Info &i) { i.encodeFailures++; });
    Log::printf("[cam] JPEG encoding failed (%s)", sink.overflow ? "frame larger than 512 KB buffer" : "encoder error");
    return Proto::ERR_ENCODE;
  }
  e.len = sink.len;
  update([&](Info &i) {
    i.lastJpegBytes = e.len;
    i.lastEncodeMs = e.encodeMs;
    i.lastCaptureMs = e.captureMs;
  });
  return Proto::OK;
}

bool sendEncoded(const Encoded &e, uint8_t flags, uint16_t ref) {
  const bool ok = ProtocolIO::sendJpegFrame(++s_frameId, s_jpeg, e.len, e.width, e.height, flags, ref, e.encodeMs,
                                            e.capturedAt);
  const uint32_t now = millis();
  update([&](Info &i) {
    if (ok) {
      i.framesSent++;
      i.lastFrameSentAt = now;
    } else {
      i.sendFailures++;
    }
  });
  return ok;
}

void onSendFailure() {
  update([](Info &i) { i.streaming = false; });
  Log::printf("[cam] USB send failed or stalled; streaming stopped");
  CommandHandler::requestSessionEnd("USB send failed or stalled");
}

void reinit(framesize_t size) {
  esp_camera_deinit();
  feedWdt();
  update([](Info &i) { i.reinitCount++; });
  startCamera(size);
}

// Restarts the driver at a new size (RGB565 buffers are sized at init). Falls back to the
// previous size if the new one fails.
bool restartAt(framesize_t size) {
  const framesize_t old = s_frameSize;
  esp_camera_deinit();
  feedWdt();
  if (startCamera(size)) return true;
  Log::printf("[cam] %ux%u failed, going back to %ux%u", resolution[size].width, resolution[size].height,
              resolution[old].width, resolution[old].height);
  startCamera(old);
  return false;
}

void printBase64(const uint8_t *d, size_t n) {
  static const char tbl[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  char line[80];
  for (size_t off = 0; off < n; off += 57) {
    const size_t m = (n - off) < 57 ? (n - off) : 57;
    size_t o = 0;
    for (size_t i = 0; i < m; i += 3) {
      uint32_t v = (uint32_t)d[off + i] << 16;
      if (i + 1 < m) v |= (uint32_t)d[off + i + 1] << 8;
      if (i + 2 < m) v |= d[off + i + 2];
      line[o++] = tbl[(v >> 18) & 63];
      line[o++] = tbl[(v >> 12) & 63];
      line[o++] = (i + 1 < m) ? tbl[(v >> 6) & 63] : '=';
      line[o++] = (i + 2 < m) ? tbl[v & 63] : '=';
    }
    line[o++] = '\n';
    Serial.write((const uint8_t *)line, o);
    feedWdt();
  }
}

void runLocalTest(LocalTest t) {
  Info cur;
  getInfo(cur);
  if (t == LocalTest::Flip) {
    sensor_t *s = cur.state == State::Ready ? esp_camera_sensor_get() : nullptr;
    const bool v = !cur.vflip;
    if (s) s->set_vflip(s, v ? 1 : 0);
    update([&](Info &i) { i.vflip = v; });
    Log::printf("[cam] vflip = %d", v ? 1 : 0);
    return;
  }
  if (cur.state != State::Ready) {
    Log::printf("[test] camera not ready (%s): %s", stateName(cur.state), cur.problem);
    return;
  }
  if (t == LocalTest::Fps) {
    const int frames = 20;
    size_t bytes = 0;
    const uint32_t t0 = millis();
    for (int k = 0; k < frames; k++) {
      Encoded e;
      if (captureJpeg(false, cur.quality, e) != Proto::OK) {
        Log::printf("[fps] failed at frame %d", k);
        return;
      }
      bytes += e.len;
    }
    const uint32_t ms = millis() - t0;
    Log::printf("[fps] %d frames: %.1f fps capture+encode at %ux%u q%u, avg %u bytes/frame (USB not included)", frames,
                frames * 1000.0f / (float)ms, cur.width, cur.height, cur.quality, (unsigned)(bytes / frames));
    return;
  }

  Encoded e;
  const Proto::Status st = captureJpeg(true, cur.quality, e);
  if (st != Proto::OK) {
    Log::printf("[snap] FAILED (%s)", st == Proto::ERR_CAMERA ? "capture" : "JPEG encode");
    if (t == LocalTest::SnapBase64) Serial.print("SNAP-FAIL\n");
    return;
  }
  const uint32_t crc = Crc::crc32(s_jpeg, e.len);
  if (t == LocalTest::Snap) {
    Log::printf("[snap] OK %ux%u JPEG %u bytes q%u | capture %u ms, encode %u ms | SOI/EOI valid | crc32 %08x", e.width,
                e.height, (unsigned)e.len, cur.quality, (unsigned)e.captureMs, (unsigned)e.encodeMs, (unsigned)crc);
    return;
  }
  char head[96];
  int n = snprintf(head, sizeof(head), "SNAP-BEGIN %ux%u %u bytes crc32=%08x\n", e.width, e.height, (unsigned)e.len,
                   (unsigned)crc);
  Serial.write((const uint8_t *)head, n);
  printBase64(s_jpeg, e.len);
  Serial.print("SNAP-END\n");
}

// Replies to the phone, or logs when the request came from the BOOT button / serial console.
void reply(const Request &r, uint8_t command, Proto::Status st, const char *msg) {
  if (r.silent) Log::printf("[sd] %s", msg);
  else ProtocolIO::sendResult(r.ref, command, st, msg);
}

void sendStorageUnsolicited() {
  if (!CommandHandler::sessionActive()) return;
  SdStorage::statusJson(s_json, sizeof(s_json));
  ProtocolIO::sendText(Proto::STORAGE, 0, s_json);
}

void startRecording(const Request &r) {
  Info cur;
  getInfo(cur);
  if (cur.state != State::Ready) {
    reply(r, Proto::START_RECORDING, Proto::ERR_CAMERA, cur.problem[0] ? cur.problem : "Camera not ready");
    return;
  }
  const uint8_t fps = r.a < 1 ? Cfg::RECORD_FPS_DEFAULT : (r.a > Cfg::STREAM_FPS_MAX ? Cfg::STREAM_FPS_MAX : r.a);
  const uint8_t q = r.b ? effectiveQuality(r.b) : Cfg::RECORD_QUALITY_DEFAULT;
  char name[24], err[80];
  if (!SdStorage::startRecording(cur.width, cur.height, fps, name, sizeof(name), err, sizeof(err))) {
    reply(r, Proto::START_RECORDING, Proto::ERR_STORAGE, err);
    return;
  }
  update([&](Info &i) {
    i.recording = true;
    i.recFps = fps;
    i.recQuality = q;
  });
  s_nextRecAt = millis();
  char msg[72];
  snprintf(msg, sizeof(msg), "Recording %s at up to %u fps", name, fps);
  reply(r, Proto::START_RECORDING, Proto::OK, msg);
}

void stopRecording(const Request &r) {
  char summary[160];
  SdStorage::stopRecording(summary, sizeof(summary));
  update([](Info &i) { i.recording = false; });
  reply(r, Proto::STOP_RECORDING, Proto::OK, summary);
}

void handle(const Request &r) {
  switch (r.type) {
    case ReqType::Capture: {
      Encoded e;
      const Proto::Status st = captureJpeg(r.a != 0, effectiveQuality(r.b), e);
      if (st != Proto::OK) {
        Info cur;
        getInfo(cur);
        ProtocolIO::sendResult(r.ref, Proto::CAPTURE_FRAME, st,
                               st == Proto::ERR_ENCODE ? "JPEG encoding failed"
                               : cur.state == State::Ready ? "Camera capture failed"
                                                           : (cur.problem[0] ? cur.problem : "Camera not ready"));
      } else if (!sendEncoded(e, Proto::FF_REQUESTED, r.ref)) {
        onSendFailure();
      }
      break;
    }
    case ReqType::StreamOn: {
      const uint8_t fps = r.a < 1 ? 1 : (r.a > Cfg::STREAM_FPS_MAX ? Cfg::STREAM_FPS_MAX : r.a);
      const uint8_t q = effectiveQuality(r.b);
      Info cur;
      getInfo(cur);
      if (cur.state != State::Ready) {
        ProtocolIO::sendResult(r.ref, Proto::START_STREAM, Proto::ERR_CAMERA,
                               cur.problem[0] ? cur.problem : "Camera not ready");
        break;
      }
      update([&](Info &i) {
        i.streaming = true;
        i.fpsTarget = fps;
        i.quality = q;
        i.fpsActual = 0;
      });
      s_nextStreamAt = millis();
      s_lastStreamFrameAt = 0;
      s_sendFailStreak = 0;
      Log::printf("[cam] streaming %u fps, JPEG q%u", fps, q);
      char msg[48];
      snprintf(msg, sizeof(msg), "Streaming at up to %u fps", fps);
      ProtocolIO::sendResult(r.ref, Proto::START_STREAM, Proto::OK, msg);
      break;
    }
    case ReqType::StreamOff: {
      Info cur;
      getInfo(cur);
      update([](Info &i) {
        i.streaming = false;
        i.fpsActual = 0;
      });
      if (cur.streaming) Log::printf("[cam] streaming stopped");
      if (!r.silent) ProtocolIO::sendResult(r.ref, Proto::STOP_STREAM, Proto::OK, "Stream stopped");
      break;
    }
    case ReqType::Resolution: {
      framesize_t fs;
      if (!lookupSize(r.w, r.h, &fs)) {
        if (r.silent) Log::printf("[cam] %ux%u is not offered (use 320, 640 or 800)", r.w, r.h);
        else ProtocolIO::sendResult(r.ref, Proto::SET_RESOLUTION, Proto::ERR_UNSUPPORTED, "Supported: 320x240, 640x480, 800x600");
        break;
      }
      Info cur;
      getInfo(cur);
      bool ok = true;
      if (fs != s_frameSize || cur.state != State::Ready) ok = restartAt(fs);
      char msg[64];
      if (ok) snprintf(msg, sizeof(msg), "Resolution %ux%u", r.w, r.h);
      else snprintf(msg, sizeof(msg), "Could not switch to %ux%u", r.w, r.h);
      Log::printf("[cam] %s", msg);
      if (!r.silent) ProtocolIO::sendResult(r.ref, Proto::SET_RESOLUTION, ok ? Proto::OK : Proto::ERR_CAMERA, msg);
      break;
    }
    case ReqType::Orientation: {
      Info cur;
      getInfo(cur);
      sensor_t *s = cur.state == State::Ready ? esp_camera_sensor_get() : nullptr;
      if (s) {
        s->set_vflip(s, r.a ? 1 : 0);
        s->set_hmirror(s, r.b ? 1 : 0);
      }
      update([&](Info &i) {
        i.vflip = r.a != 0;
        i.hmirror = r.b != 0;
      });
      ProtocolIO::sendResult(r.ref, Proto::SET_ORIENTATION, Proto::OK, "Orientation set");
      break;
    }
    case ReqType::Local:
      runLocalTest((LocalTest)r.a);
      break;
    case ReqType::LocalResolution: {
      Request rr = r;
      rr.type = ReqType::Resolution;
      rr.silent = true;
      handle(rr);
      break;
    }
    case ReqType::Photo: {
      Encoded e;
      const uint8_t q = r.b ? effectiveQuality(r.b) : Cfg::PHOTO_QUALITY_DEFAULT;
      const Proto::Status st = captureJpeg(true, q, e);
      if (st != Proto::OK) {
        reply(r, Proto::TAKE_PHOTO, st, st == Proto::ERR_ENCODE ? "JPEG encoding failed" : "Camera capture failed");
        break;
      }
      char name[24], err[80];
      if (!SdStorage::savePhoto(s_jpeg, e.len, name, sizeof(name), err, sizeof(err))) {
        reply(r, Proto::TAKE_PHOTO, Proto::ERR_STORAGE, err);
        break;
      }
      const uint32_t now = millis();
      update([&](Info &i) { i.lastFrameSentAt = now; });  // privacy LED blinks for photos too
      char msg[72];
      snprintf(msg, sizeof(msg), "Saved %s (%u KB, %ux%u)", name, (unsigned)((e.len + 1023) / 1024), e.width, e.height);
      reply(r, Proto::TAKE_PHOTO, Proto::OK, msg);
      break;
    }
    case ReqType::RecordOn:
      startRecording(r);
      break;
    case ReqType::RecordOff:
      stopRecording(r);
      break;
    case ReqType::RecordToggle:
      if (SdStorage::isRecording()) stopRecording(r);
      else startRecording(r);
      break;
    case ReqType::Storage:
      SdStorage::ensureMounted();
      SdStorage::statusJson(s_json, sizeof(s_json));
      ProtocolIO::sendText(Proto::STORAGE, r.ref, s_json);
      break;
    case ReqType::FileList:
      SdStorage::listJson(s_json, sizeof(s_json), r.a ? r.a : 30);
      if (r.silent) Serial.println(s_json);
      else ProtocolIO::sendText(Proto::FILE_LIST, r.ref, s_json);
      break;
    case ReqType::WebFrame: {
      Encoded e;
      size_t n = 0;
      if (captureJpeg(false, effectiveQuality(r.b), e) == Proto::OK && s_webOut && e.len <= s_webCap) {
        memcpy(s_webOut, s_jpeg, e.len);
        n = e.len;
        const uint32_t now = millis();
        update([&](Info &i) { i.lastFrameSentAt = now; });  // privacy LED: pictures are leaving the board
      }
      s_webLen = n;
      if (s_webDone) xSemaphoreGive(s_webDone);
      break;
    }
  }
}

void advance(uint32_t &next, uint8_t fps, uint32_t now) {
  const uint32_t period = 1000 / (fps ? fps : 1);
  next += period;
  if ((int32_t)(now - next) > (int32_t)period) next = now + period;  // running late: don't burst
}

// One capture serves both the live stream and the SD recording when both are due.
void frameTick() {
  Info cur;
  getInfo(cur);
  if (cur.streaming && !CommandHandler::sessionActive()) {
    update([](Info &i) {
      i.streaming = false;
      i.fpsActual = 0;
    });
    cur.streaming = false;
    Log::printf("[cam] streaming stopped: no phone session");
  }
  if (!cur.streaming && !cur.recording) return;

  const uint32_t now = millis();
  const bool streamDue = cur.streaming && (int32_t)(now - s_nextStreamAt) >= 0;
  const bool recDue = cur.recording && (int32_t)(now - s_nextRecAt) >= 0;
  if (!streamDue && !recDue) return;
  if (streamDue) advance(s_nextStreamAt, cur.fpsTarget, now);
  if (recDue) advance(s_nextRecAt, cur.recFps, now);

  Encoded e;
  if (captureJpeg(false, cur.recording ? cur.recQuality : cur.quality, e) != Proto::OK) return;

  if (recDue) {
    char err[80];
    if (!SdStorage::addFrame(s_jpeg, e.len, e.width, e.height, e.capturedAt, err, sizeof(err))) {
      char summary[160];
      SdStorage::stopRecording(summary, sizeof(summary));
      update([](Info &i) { i.recording = false; });
      Log::printf("[sd] recording stopped: %s %s", err, summary);
      sendStorageUnsolicited();  // tell the phone it stopped
    }
  }

  if (streamDue) {
    if (!sendEncoded(e, Proto::FF_STREAM, 0)) {
      // A phone can pause reading for a moment (busy, screen turning off). Drop this frame (the
      // protocol layer already discarded its unsent part), back off a little and keep streaming;
      // only a phone that stays unresponsive ends the session.
      if (++s_sendFailStreak >= Cfg::STREAM_SEND_FAILS_BEFORE_STOP) {
        s_sendFailStreak = 0;
        onSendFailure();
      } else {
        Log::printf("[cam] stream frame not taken by the phone (%d in a row); continuing", s_sendFailStreak);
        s_nextStreamAt = millis() + 300;
      }
      return;
    }
    s_sendFailStreak = 0;
    const uint32_t sent = millis();
    if (s_lastStreamFrameAt) {
      const float inst = 1000.0f / (float)((sent - s_lastStreamFrameAt) ? (sent - s_lastStreamFrameAt) : 1);
      update([&](Info &i) { i.fpsActual = i.fpsActual > 0 ? i.fpsActual * 0.8f + inst * 0.2f : inst; });
    }
    s_lastStreamFrameAt = sent;
  }
}

TickType_t waitTicks(const Info &cur) {
  int32_t ms = 250;
  const uint32_t now = millis();
  if (cur.streaming) {
    const int32_t d = (int32_t)(s_nextStreamAt - now);
    if (d < ms) ms = d;
  }
  if (cur.recording) {
    const int32_t d = (int32_t)(s_nextRecAt - now);
    if (d < ms) ms = d;
  }
  return ms > 0 ? pdMS_TO_TICKS(ms) : 0;
}

void cameraTask(void *) {
  s_wdt = esp_task_wdt_add(nullptr) == ESP_OK;

  // The driver task's frame-drop warnings can overflow its small stack (seen with S3_CAM).
  esp_log_level_set("cam_hal", ESP_LOG_NONE);

  if (startCamera(FRAMESIZE_QVGA)) {
    // Phase 2 single-frame test, visible on the Serial Monitor at every boot.
    Encoded e;
    const Proto::Status st = captureJpeg(true, Cfg::JPEG_QUALITY_DEFAULT, e);
    if (st == Proto::OK) {
      Log::printf("[cam] self-test frame OK: %ux%u JPEG %u bytes, capture %u ms, encode %u ms, SOI/EOI valid", e.width,
                  e.height, (unsigned)e.len, (unsigned)e.captureMs, (unsigned)e.encodeMs);
    } else {
      Log::printf("[cam] self-test frame FAILED (%s). Reseat the ribbon cable and press RST.",
                  st == Proto::ERR_CAMERA ? "no frame from sensor" : "JPEG encode");
    }
  }
  s_nextInitAttempt = millis() + Cfg::CAMERA_RETRY_MS;

  // microSD: mounted from this task, which is the only one that touches the card.
  feedWdt();
  SdStorage::mount();
  feedWdt();

  for (;;) {
    feedWdt();
    Info cur;
    getInfo(cur);

    Request r;
    if (xQueueReceive(s_queue, &r, waitTicks(cur)) == pdTRUE) {
      handle(r);
      continue;
    }

    if (s_needReinit) {
      s_needReinit = false;
      Log::printf("[cam] %d capture failures in a row: restarting the camera", Cfg::CAPTURE_FAILS_BEFORE_REINIT);
      reinit(s_frameSize);
      continue;
    }
    if (cur.state == State::Error && (int32_t)(millis() - s_nextInitAttempt) >= 0) {
      s_nextInitAttempt = millis() + Cfg::CAMERA_RETRY_MS;
      Log::printf("[cam] retrying camera init");
      reinit(s_frameSize);
      continue;
    }
    frameTick();
  }
}

bool post(const Request &r) {
  if (!s_queue) return false;
  return xQueueSend(s_queue, &r, 0) == pdTRUE;
}

}  // namespace

// ----------------------------------------------------------------------------

bool begin() {
  memset(&s_info, 0, sizeof(s_info));
  s_info.state = State::Off;
  s_info.quality = Cfg::JPEG_QUALITY_DEFAULT;
  s_info.fpsTarget = Cfg::STREAM_FPS_DEFAULT;
  s_info.vflip = true;  // the working S3_CAM.ino flips this board's image vertically
  s_info.hmirror = false;
  s_info.width = 320;
  s_info.height = 240;
  s_info.recFps = Cfg::RECORD_FPS_DEFAULT;
  s_info.recQuality = Cfg::RECORD_QUALITY_DEFAULT;
  strlcpy(s_info.sensorName, "none", sizeof(s_info.sensorName));
  SdStorage::begin();

  s_queue = xQueueCreate(8, sizeof(Request));
  s_webLock = xSemaphoreCreateMutex();
  s_webDone = xSemaphoreCreateBinary();
  s_jpeg = (uint8_t *)heap_caps_malloc(Cfg::JPEG_BUF_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!s_jpeg) {
    setProblem(ESP_ERR_NO_MEM, "No PSRAM for the JPEG buffer. Tools > PSRAM > OPI PSRAM, then upload again.");
  }
  return xTaskCreatePinnedToCore(cameraTask, "disha_cam", 16384, nullptr, 4, nullptr, 1) == pdPASS;
}

void getInfo(Info &out) {
  taskENTER_CRITICAL(&s_mux);
  out = s_info;
  taskEXIT_CRITICAL(&s_mux);
}

const char *stateName(State s) {
  switch (s) {
    case State::Off:          return "off";
    case State::Initializing: return "initializing";
    case State::Ready:        return "ready";
    case State::Error:        return "error";
  }
  return "unknown";
}

bool sizeSupported(uint16_t width, uint16_t height) {
  return lookupSize(width, height, nullptr);
}

size_t supportedSizesJson(char *out, size_t cap) {
  size_t used = 0;
  used += snprintf(out + used, cap - used, "[");
  for (size_t k = 0; k < sizeof(kSizes) / sizeof(kSizes[0]) && used < cap; k++) {
    used += snprintf(out + used, cap - used, "%s[%u,%u]", k ? "," : "", kSizes[k].w, kSizes[k].h);
  }
  if (used < cap) used += snprintf(out + used, cap - used, "]");
  return used;
}

bool requestCapture(uint16_t ref, bool fresh, uint8_t quality) {
  return post({ReqType::Capture, ref, (uint8_t)(fresh ? 1 : 0), quality, 0, 0, false});
}

bool requestStream(uint16_t ref, bool on, uint8_t fps, uint8_t quality) {
  return post({on ? ReqType::StreamOn : ReqType::StreamOff, ref, fps, quality, 0, 0, false});
}

bool requestResolution(uint16_t ref, uint16_t width, uint16_t height) {
  return post({ReqType::Resolution, ref, 0, 0, width, height, false});
}

bool requestOrientation(uint16_t ref, bool vflip, bool hmirror) {
  return post({ReqType::Orientation, ref, (uint8_t)(vflip ? 1 : 0), (uint8_t)(hmirror ? 1 : 0), 0, 0, false});
}

void stopStreamingSilently() {
  // Called when a session starts or ends: requests queued for the old session are dropped
  // (their replies would carry stale refs), and streaming stops before the next HELLO_ACK
  // reports the camera state. The camera task checks the flag before every stream frame.
  if (s_queue) xQueueReset(s_queue);
  update([](Info &i) {
    i.streaming = false;
    i.fpsActual = 0;
  });
}

bool requestPhoto(uint16_t ref, uint8_t quality, bool local) {
  return post({ReqType::Photo, ref, 0, quality, 0, 0, local});
}

bool requestRecording(uint16_t ref, bool on, uint8_t fps, uint8_t quality, bool local) {
  return post({on ? ReqType::RecordOn : ReqType::RecordOff, ref, fps, quality, 0, 0, local});
}

bool toggleRecordingLocal() {
  return post({ReqType::RecordToggle, 0, 0, 0, 0, 0, true});
}

bool requestStorageStatus(uint16_t ref) {
  return post({ReqType::Storage, ref, 0, 0, 0, 0, false});
}

bool requestFileList(uint16_t ref, uint8_t maxFiles, bool local) {
  return post({ReqType::FileList, ref, (uint8_t)(maxFiles > 40 ? 40 : maxFiles), 0, 0, 0, local});
}

size_t grabForWeb(uint8_t *out, size_t cap, uint8_t quality, uint32_t timeoutMs) {
  if (!s_queue || !s_webLock || !s_webDone || !out) return 0;
  if (xSemaphoreTake(s_webLock, pdMS_TO_TICKS(timeoutMs)) != pdTRUE) return 0;
  xSemaphoreTake(s_webDone, 0);  // drop a late answer to an earlier, timed-out request
  s_webOut = out;
  s_webCap = cap;
  s_webLen = 0;
  size_t n = 0;
  if (post({ReqType::WebFrame, 0, 0, quality, 0, 0, true}) && xSemaphoreTake(s_webDone, pdMS_TO_TICKS(timeoutMs)) == pdTRUE) {
    n = s_webLen;
  }
  xSemaphoreGive(s_webLock);
  return n;
}

bool requestLocalTest(LocalTest test) {
  return post({ReqType::Local, 0, (uint8_t)test, 0, 0, 0, true});
}

bool requestLocalResolution(uint16_t width) {
  for (const SizeEntry &e : kSizes) {
    if (e.w == width) return post({ReqType::LocalResolution, 0, 0, 0, e.w, e.h, true});
  }
  Log::printf("[cam] width %u not offered (use 320, 640 or 800)", width);
  return false;
}

}  // namespace CameraService
