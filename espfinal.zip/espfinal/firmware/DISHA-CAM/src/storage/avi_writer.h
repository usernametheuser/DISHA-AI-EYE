// MJPEG-in-AVI (RIFF AVI 1.0) writer: one video stream, each frame a complete JPEG.
// Plays in VLC, Windows Media Player / Films & TV, ffmpeg and most PC players.
//
// Power-cut safety: the header is rewritten with the current frame count every
// Cfg::AVI_HEADER_UPDATE_FRAMES frames and the file is flushed, so an interrupted file is
// still playable up to that point (it only lacks the final index; VLC offers to fix it).
#pragma once
#include <Arduino.h>
#include <FS.h>

class AviWriter {
public:
  // stage: internal (DMA-capable) RAM buffer used to copy PSRAM data to the card quickly.
  bool open(fs::FS &fs, const char *path, uint16_t width, uint16_t height, uint8_t fps, uint8_t *stage, size_t stageCap);
  bool addFrame(const uint8_t *jpeg, size_t len, uint32_t captureMs);
  bool close();  // writes the index and the final header

  bool isOpen() const { return open_; }
  bool full() const;  // file reached its frame or size limit: close and start the next one
  uint32_t frames() const { return frames_; }
  uint64_t fileBytes() const { return 224 + moviBytes_; }
  uint32_t durationMs() const { return frames_ > 1 ? lastMs_ - firstMs_ : 0; }

private:
  bool writeAll(const uint8_t *data, size_t len);
  bool writeHeader(bool final);
  void freeIndex();

  fs::File f_;
  bool open_ = false;
  uint16_t w_ = 0, h_ = 0;
  uint8_t fps_ = 1;
  uint32_t *index_ = nullptr;  // pairs: offset (from the 'movi' fourcc), size
  uint32_t frames_ = 0;
  uint64_t moviBytes_ = 0;     // bytes of frame chunks after the 'movi' fourcc
  uint32_t maxFrame_ = 0;
  uint32_t firstMs_ = 0, lastMs_ = 0;
  uint8_t *stage_ = nullptr;
  size_t stageCap_ = 0;
};
