#include "sd_storage.h"
#include <FS.h>
#include <SD_MMC.h>
#include <stdlib.h>
#include "esp_heap_caps.h"
#include "esp_task_wdt.h"
#include "avi_writer.h"
#include "../config/disha_config.h"
#include "../diagnostics/log.h"

namespace SdStorage {

namespace {
constexpr size_t STAGE_BYTES = 16384;
constexpr uint32_t REMOUNT_INTERVAL_MS = 3000;

portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
Status s_status;  // guarded by s_mux
uint8_t *s_stage = nullptr;
AviWriter s_avi;
uint32_t s_nextPhoto = 1;
uint32_t s_nextVideo = 1;
uint32_t s_lastMountTry = 0;
// current recording
uint16_t s_recW = 0, s_recH = 0;
uint8_t s_recFps = 5;
uint32_t s_recStartMs = 0;
uint64_t s_recBytesDone = 0;   // closed files of this recording
uint32_t s_recFramesDone = 0;
uint64_t s_bytesSinceRefresh = 0;

template <typename F>
void update(F f) {
  taskENTER_CRITICAL(&s_mux);
  f(s_status);
  taskEXIT_CRITICAL(&s_mux);
}

void feedWdt() {
  esp_task_wdt_reset();  // no effect if the calling task is not watched
}

const char *cardTypeName(uint8_t t) {
  switch (t) {
    case CARD_MMC:  return "MMC";
    case CARD_SD:   return "SDSC";
    case CARD_SDHC: return "SDHC";
    default:        return "unknown";
  }
}

void setProblem(const char *text) {
  update([&](Status &s) { strlcpy(s.problem, text, sizeof(s.problem)); });
}

void refreshSpace() {
  const uint64_t total = SD_MMC.totalBytes();
  const uint64_t used = SD_MMC.usedBytes();
  s_bytesSinceRefresh = 0;
  update([&](Status &s) {
    s.totalBytes = total;
    s.usedBytes = used;
  });
}

uint64_t freeBytes() {
  const Status s = status();
  const uint64_t used = s.usedBytes + s_bytesSinceRefresh;
  return s.totalBytes > used ? s.totalBytes - used : 0;
}

// The card stopped working (removed, or a write failed): unmount so the next request remounts.
void cardFailed(const char *why) {
  SD_MMC.end();
  update([&](Status &s) {
    s.mounted = false;
    strlcpy(s.problem, why, sizeof(s.problem));
  });
  Log::printf("[sd] %s", why);
}

bool writeAll(fs::File &f, const uint8_t *data, size_t len) {
  while (len) {
    const size_t n = len < STAGE_BYTES ? len : STAGE_BYTES;
    memcpy(s_stage, data, n);  // PSRAM -> internal RAM, so the SD driver can write whole blocks
    if (f.write(s_stage, n) != n) return false;
    data += n;
    len -= n;
  }
  return true;
}

const char *baseName(const char *path) {
  const char *slash = strrchr(path, '/');
  return slash ? slash + 1 : path;
}

void scanFolder() {
  uint32_t photos = 0, videos = 0, maxPhoto = 0, maxVideo = 0;
  File dir = SD_MMC.open(Cfg::SD_DIR);
  if (dir && dir.isDirectory()) {
    for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
      unsigned n = 0;
      const char *name = baseName(f.name());
      if (sscanf(name, "IMG_%u.jpg", &n) == 1) {
        photos++;
        if (n > maxPhoto) maxPhoto = n;
      } else if (sscanf(name, "VID_%u.avi", &n) == 1) {
        videos++;
        if (n > maxVideo) maxVideo = n;
      }
      f.close();
      feedWdt();
    }
  }
  if (dir) dir.close();
  s_nextPhoto = maxPhoto + 1;
  s_nextVideo = maxVideo + 1;
  update([&](Status &s) {
    s.photos = photos;
    s.videos = videos;
  });
}

// Next unused name; never overwrites an existing file.
void freePath(char *path, size_t cap, const char *prefix, const char *ext, uint32_t &next) {
  for (int tries = 0; tries < 10000; tries++) {
    snprintf(path, cap, "%s/%s_%05u.%s", Cfg::SD_DIR, prefix, (unsigned)next, ext);
    if (!SD_MMC.exists(path)) return;
    next++;
  }
}

bool openNextVideo(char *name, size_t cap) {
  char path[48];
  freePath(path, sizeof(path), "VID", "avi", s_nextVideo);
  if (!s_avi.open(SD_MMC, path, s_recW, s_recH, s_recFps, s_stage, STAGE_BYTES)) return false;
  s_nextVideo++;
  if (name) strlcpy(name, baseName(path), cap);
  update([&](Status &s) {
    strlcpy(s.recFile, baseName(path), sizeof(s.recFile));
    s.videos++;
    s.recFiles++;
  });
  return true;
}

void publishRecording() {
  const uint32_t frames = s_recFramesDone + s_avi.frames();
  const uint64_t bytes = s_recBytesDone + (s_avi.isOpen() ? s_avi.fileBytes() : 0);
  update([&](Status &s) {
    s.recFrames = frames;
    s.recBytes = bytes;
  });
}
}  // namespace

// ----------------------------------------------------------------------------

bool begin() {
  memset(&s_status, 0, sizeof(s_status));
  strlcpy(s_status.cardType, "none", sizeof(s_status.cardType));
  strlcpy(s_status.problem, "Not checked yet", sizeof(s_status.problem));
  s_stage = (uint8_t *)heap_caps_malloc(STAGE_BYTES, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
  if (!s_stage) Log::printf("[sd] no internal RAM for the write buffer");
  return s_stage != nullptr;
}

bool mount() {
  s_lastMountTry = millis();
  if (status().mounted) return true;
  if (!s_stage) {
    setProblem("Out of internal memory for the card buffer.");
    return false;
  }
  SD_MMC.setPins(Pins::SD_CLK, Pins::SD_CMD, Pins::SD_D0);
  // 1-bit mode (only D0 is wired). format_if_mount_failed = false: never erase the card.
  if (!SD_MMC.begin("/sdcard", true, false)) {
    SD_MMC.end();
    setProblem("No microSD card, or it is not FAT32 (exFAT/NTFS cannot be read). Copy your files to a PC, "
               "then format the card as FAT32. This firmware never formats cards.");
    return false;
  }
  const uint8_t type = SD_MMC.cardType();
  if (type == CARD_NONE) {
    SD_MMC.end();
    setProblem("No microSD card inserted.");
    return false;
  }
  if (!SD_MMC.exists(Cfg::SD_DIR) && !SD_MMC.mkdir(Cfg::SD_DIR)) {
    SD_MMC.end();
    setProblem("The card is read-only or full: the DISHA folder could not be created.");
    return false;
  }
  feedWdt();
  refreshSpace();  // can take a few seconds on a large card the first time
  feedWdt();
  scanFolder();
  update([&](Status &s) {
    s.mounted = true;
    strlcpy(s.cardType, cardTypeName(type), sizeof(s.cardType));
    s.problem[0] = 0;
  });
  const Status s = status();
  Log::printf("[sd] %s card mounted: %u MB total, %u MB free | %u photos, %u videos in %s", s.cardType,
              (unsigned)(s.totalBytes >> 20), (unsigned)((s.totalBytes - s.usedBytes) >> 20), (unsigned)s.photos,
              (unsigned)s.videos, Cfg::SD_DIR);
  return true;
}

bool ensureMounted() {
  if (status().mounted) return true;
  if (millis() - s_lastMountTry < REMOUNT_INTERVAL_MS) return false;
  return mount();
}

Status status() {
  taskENTER_CRITICAL(&s_mux);
  Status s = s_status;
  taskEXIT_CRITICAL(&s_mux);
  return s;
}

size_t statusJson(char *out, size_t cap) {
  const Status s = status();
  const uint64_t freeB = s.totalBytes > s.usedBytes ? s.totalBytes - s.usedBytes : 0;
  int n = snprintf(out, cap,
                   "{\"mounted\":%s,\"cardType\":\"%s\",\"totalMB\":%u,\"usedMB\":%u,\"freeMB\":%u,\"photos\":%u,"
                   "\"videos\":%u,\"lastFile\":\"%s\",\"dir\":\"%s\",\"problem\":\"%s\","
                   "\"recording\":{\"active\":%s,\"file\":\"%s\",\"frames\":%u,\"seconds\":%u,\"kb\":%u,\"files\":%u}}",
                   s.mounted ? "true" : "false", s.cardType, (unsigned)(s.totalBytes >> 20),
                   (unsigned)(s.usedBytes >> 20), (unsigned)(freeB >> 20), (unsigned)s.photos, (unsigned)s.videos,
                   s.lastFile, Cfg::SD_DIR, s.problem, s.recording ? "true" : "false", s.recFile,
                   (unsigned)s.recFrames, (unsigned)(s.recMs / 1000), (unsigned)(s.recBytes >> 10),
                   (unsigned)s.recFiles);
  return n < 0 ? 0 : ((size_t)n < cap ? (size_t)n : cap - 1);
}

bool savePhoto(const uint8_t *jpeg, size_t len, char *name, size_t nameCap, char *err, size_t errCap) {
  if (!ensureMounted()) {
    strlcpy(err, "There is no usable microSD card in the glasses.", errCap);
    return false;
  }
  if (freeBytes() < Cfg::SD_MIN_FREE_PHOTO + len) {
    strlcpy(err, "The microSD card is full.", errCap);
    return false;
  }
  char path[48];
  freePath(path, sizeof(path), "IMG", "jpg", s_nextPhoto);
  fs::File f = SD_MMC.open(path, FILE_WRITE);
  const bool ok = f && writeAll(f, jpeg, len);
  if (f) f.close();
  if (!ok) {
    SD_MMC.remove(path);
    cardFailed("Writing to the microSD card failed. Was it removed?");
    strlcpy(err, "Writing to the microSD card failed.", errCap);
    return false;
  }
  s_nextPhoto++;
  update([&](Status &s) {
    s.photos++;
    strlcpy(s.lastFile, baseName(path), sizeof(s.lastFile));
    s.usedBytes += len;
  });
  strlcpy(name, baseName(path), nameCap);
  return true;
}

bool isRecording() {
  return status().recording;
}

bool startRecording(uint16_t width, uint16_t height, uint8_t fps, char *name, size_t nameCap, char *err, size_t errCap) {
  if (status().recording) {
    strlcpy(err, "Already recording.", errCap);
    return false;
  }
  if (!ensureMounted()) {
    strlcpy(err, "There is no usable microSD card in the glasses.", errCap);
    return false;
  }
  if (freeBytes() < Cfg::SD_MIN_FREE_RECORD) {
    strlcpy(err, "Less than 50 MB free on the microSD card.", errCap);
    return false;
  }
  s_recW = width;
  s_recH = height;
  s_recFps = fps ? fps : 1;
  s_recStartMs = 0;
  s_recBytesDone = 0;
  s_recFramesDone = 0;
  update([&](Status &s) {
    s.recording = true;
    s.recFrames = 0;
    s.recMs = 0;
    s.recBytes = 0;
    s.recFiles = 0;
  });
  if (!openNextVideo(name, nameCap)) {
    update([&](Status &s) { s.recording = false; });
    cardFailed("Could not create a video file on the microSD card.");
    strlcpy(err, "Could not create the video file.", errCap);
    return false;
  }
  Log::printf("[sd] recording %s: %ux%u at up to %u fps", name, width, height, (unsigned)s_recFps);
  return true;
}

bool addFrame(const uint8_t *jpeg, size_t len, uint16_t width, uint16_t height, uint32_t captureMs, char *err,
              size_t errCap) {
  if (!s_avi.isOpen()) {
    strlcpy(err, "No video file is open.", errCap);
    return false;
  }
  // A resolution change or a full file continues the recording in a new file.
  if (s_avi.full() || width != s_recW || height != s_recH) {
    s_recFramesDone += s_avi.frames();
    s_recBytesDone += s_avi.fileBytes();
    s_avi.close();
    s_recW = width;
    s_recH = height;
    char name[24];
    if (!openNextVideo(name, sizeof(name))) {
      cardFailed("Could not create the next video file.");
      strlcpy(err, "Could not create the next video file.", errCap);
      return false;
    }
    Log::printf("[sd] recording continues in %s", name);
  }
  if (s_recStartMs == 0) s_recStartMs = captureMs;
  if (!s_avi.addFrame(jpeg, len, captureMs)) {
    cardFailed("Writing the video failed. Was the card removed?");
    strlcpy(err, "Writing the video to the microSD card failed.", errCap);
    return false;
  }
  s_bytesSinceRefresh += len + 8;
  publishRecording();
  update([&](Status &s) { s.recMs = captureMs - s_recStartMs; });
  if (freeBytes() < Cfg::SD_STOP_RECORD_FREE) {
    strlcpy(err, "The microSD card is full.", errCap);
    return false;
  }
  return true;
}

bool stopRecording(char *summary, size_t cap) {
  Status s = status();
  if (!s.recording) {
    strlcpy(summary, "Not recording.", cap);
    return false;
  }
  const uint32_t frames = s_recFramesDone + s_avi.frames();
  const uint64_t bytes = s_recBytesDone + (s_avi.isOpen() ? s_avi.fileBytes() : 0);
  const bool ok = s_avi.isOpen() ? s_avi.close() : true;
  update([&](Status &st) {
    st.recording = false;
    st.recFrames = frames;
    st.recBytes = bytes;
    strlcpy(st.lastFile, st.recFile, sizeof(st.lastFile));
  });
  s = status();
  if (s.mounted) refreshSpace();
  snprintf(summary, cap, "Saved %s: %u frames, %u s, %.1f MB%s", s.recFile, (unsigned)frames, (unsigned)(s.recMs / 1000),
           (double)bytes / 1048576.0, ok ? "" : " (the card failed while closing the file; VLC can still play it)");
  Log::printf("[sd] %s", summary);
  return ok;
}

size_t listJson(char *out, size_t cap, int maxFiles) {
  struct Entry {
    char name[20];
    uint32_t kb;
  };
  constexpr int MAX_SCAN = 2000;
  if (!ensureMounted()) return snprintf(out, cap, "{\"dir\":\"%s\",\"mounted\":false,\"files\":[]}", Cfg::SD_DIR);
  Entry *list = (Entry *)heap_caps_malloc(sizeof(Entry) * MAX_SCAN, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!list) return snprintf(out, cap, "{\"dir\":\"%s\",\"mounted\":true,\"files\":[],\"error\":\"no memory\"}", Cfg::SD_DIR);
  int count = 0;
  File dir = SD_MMC.open(Cfg::SD_DIR);
  if (dir && dir.isDirectory()) {
    for (File f = dir.openNextFile(); f && count < MAX_SCAN; f = dir.openNextFile()) {
      if (!f.isDirectory()) {
        strlcpy(list[count].name, baseName(f.name()), sizeof(list[count].name));
        list[count].kb = (uint32_t)((f.size() + 1023) / 1024);
        count++;
      }
      f.close();
      feedWdt();
    }
  }
  if (dir) dir.close();
  // Reverse name order: videos (VID_) first, then photos (IMG_), each newest first because the
  // numbers are zero-padded.
  qsort(list, count, sizeof(Entry), [](const void *a, const void *b) {
    return strcmp(((const Entry *)b)->name, ((const Entry *)a)->name);
  });
  size_t used = snprintf(out, cap, "{\"dir\":\"%s\",\"mounted\":true,\"total\":%d,\"files\":[", Cfg::SD_DIR, count);
  for (int i = 0; i < count && i < maxFiles && used < cap; i++) {
    used += snprintf(out + used, cap - used, "%s{\"name\":\"%s\",\"kb\":%u}", i ? "," : "", list[i].name,
                     (unsigned)list[i].kb);
  }
  if (used < cap) used += snprintf(out + used, cap - used, "]}");
  heap_caps_free(list);
  return used < cap ? used : cap - 1;
}

}  // namespace SdStorage
