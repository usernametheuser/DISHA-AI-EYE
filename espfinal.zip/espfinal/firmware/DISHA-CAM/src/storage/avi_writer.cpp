#include "avi_writer.h"
#include "esp_heap_caps.h"
#include "../config/disha_config.h"

namespace {
constexpr uint32_t HEADER_LEN = 224;  // RIFF + hdrl + LIST movi header; frames start here
constexpr uint32_t AVIF_HASINDEX = 0x10;
constexpr uint32_t AVIIF_KEYFRAME = 0x10;

void p16(uint8_t *b, size_t o, uint16_t v) {
  b[o] = (uint8_t)v;
  b[o + 1] = (uint8_t)(v >> 8);
}
void p32(uint8_t *b, size_t o, uint32_t v) {
  b[o] = (uint8_t)v;
  b[o + 1] = (uint8_t)(v >> 8);
  b[o + 2] = (uint8_t)(v >> 16);
  b[o + 3] = (uint8_t)(v >> 24);
}
void fcc(uint8_t *b, size_t o, const char *s) {
  memcpy(b + o, s, 4);
}
}  // namespace

bool AviWriter::open(fs::FS &fs, const char *path, uint16_t width, uint16_t height, uint8_t fps, uint8_t *stage,
                     size_t stageCap) {
  if (open_) close();
  w_ = width;
  h_ = height;
  fps_ = fps ? fps : 1;
  stage_ = stage;
  stageCap_ = stageCap;
  frames_ = 0;
  moviBytes_ = 0;
  maxFrame_ = 0;
  firstMs_ = lastMs_ = 0;
  index_ = (uint32_t *)heap_caps_malloc(Cfg::AVI_MAX_FRAMES * 2 * sizeof(uint32_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!index_) return false;
  f_ = fs.open(path, FILE_WRITE);
  if (!f_) {
    freeIndex();
    return false;
  }
  open_ = true;
  if (!writeHeader(false)) {
    f_.close();
    open_ = false;
    freeIndex();
    return false;
  }
  return true;
}

bool AviWriter::full() const {
  return frames_ >= Cfg::AVI_MAX_FRAMES || fileBytes() >= Cfg::AVI_MAX_BYTES;
}

bool AviWriter::writeAll(const uint8_t *data, size_t len) {
  while (len) {
    const size_t n = len < stageCap_ ? len : stageCap_;
    memcpy(stage_, data, n);  // PSRAM -> internal RAM: the SD driver writes whole blocks from there
    if (f_.write(stage_, n) != n) return false;
    data += n;
    len -= n;
  }
  return true;
}

bool AviWriter::addFrame(const uint8_t *jpeg, size_t len, uint32_t captureMs) {
  if (!open_ || full()) return false;
  uint8_t hdr[8];
  fcc(hdr, 0, "00dc");
  p32(hdr, 4, (uint32_t)len);
  const uint32_t offset = 4 + (uint32_t)moviBytes_;  // relative to the 'movi' fourcc
  if (f_.write(hdr, 8) != 8 || !writeAll(jpeg, len)) return false;
  uint64_t chunk = 8 + len;
  if (len & 1) {  // chunks are word aligned
    static const uint8_t pad = 0;
    if (f_.write(&pad, 1) != 1) return false;
    chunk++;
  }
  index_[frames_ * 2] = offset;
  index_[frames_ * 2 + 1] = (uint32_t)len;
  frames_++;
  moviBytes_ += chunk;
  if (len > maxFrame_) maxFrame_ = (uint32_t)len;
  if (frames_ == 1) firstMs_ = captureMs;
  lastMs_ = captureMs;

  if (frames_ % Cfg::AVI_HEADER_UPDATE_FRAMES == 0) {
    // Keep sizes in the header current, then continue appending at the end.
    const size_t end = f_.position();
    if (!writeHeader(false) || !f_.seek(end)) return false;
    f_.flush();
  }
  return true;
}

bool AviWriter::close() {
  if (!open_) return false;
  bool ok = true;
  // idx1: 16 bytes per frame, written through the stage buffer in batches.
  uint8_t h[8];
  fcc(h, 0, "idx1");
  p32(h, 4, frames_ * 16);
  ok = f_.write(h, 8) == 8;
  uint32_t i = 0;
  while (ok && i < frames_) {
    size_t used = 0;
    while (i < frames_ && used + 16 <= stageCap_) {
      fcc(stage_, used, "00dc");
      p32(stage_, used + 4, AVIIF_KEYFRAME);
      p32(stage_, used + 8, index_[i * 2]);
      p32(stage_, used + 12, index_[i * 2 + 1]);
      used += 16;
      i++;
    }
    ok = f_.write(stage_, used) == used;
  }
  ok = ok && writeHeader(true);
  f_.close();
  open_ = false;
  freeIndex();
  return ok;
}

bool AviWriter::writeHeader(bool final) {
  // Real frame rate from the capture timestamps, so playback runs at real speed.
  uint32_t usPerFrame = 1000000u / fps_;
  if (frames_ > 1 && lastMs_ > firstMs_) usPerFrame = (uint32_t)((uint64_t)(lastMs_ - firstMs_) * 1000u / (frames_ - 1));
  if (usPerFrame == 0) usPerFrame = 1;
  const uint32_t idxBytes = final ? 8 + frames_ * 16 : 0;
  const uint64_t fileSize = HEADER_LEN + moviBytes_ + idxBytes;
  const uint32_t bufSize = maxFrame_ + 8;

  uint8_t b[HEADER_LEN];
  memset(b, 0, sizeof(b));
  fcc(b, 0, "RIFF");
  p32(b, 4, (uint32_t)(fileSize - 8));
  fcc(b, 8, "AVI ");
  fcc(b, 12, "LIST");
  p32(b, 16, 192);  // 'hdrl' + avih chunk + strl list
  fcc(b, 20, "hdrl");
  fcc(b, 24, "avih");
  p32(b, 28, 56);
  p32(b, 32, usPerFrame);
  p32(b, 36, (uint32_t)((uint64_t)bufSize * 1000000u / usPerFrame));  // max bytes per second
  p32(b, 40, 0);
  p32(b, 44, final ? AVIF_HASINDEX : 0);
  p32(b, 48, frames_);
  p32(b, 52, 0);
  p32(b, 56, 1);  // streams
  p32(b, 60, bufSize);
  p32(b, 64, w_);
  p32(b, 68, h_);
  fcc(b, 88, "LIST");
  p32(b, 92, 116);  // 'strl' + strh + strf
  fcc(b, 96, "strl");
  fcc(b, 100, "strh");
  p32(b, 104, 56);
  fcc(b, 108, "vids");
  fcc(b, 112, "MJPG");
  p32(b, 116, 0);         // flags
  p16(b, 120, 0);         // priority
  p16(b, 122, 0);         // language
  p32(b, 124, 0);         // initial frames
  p32(b, 128, usPerFrame);  // scale  } rate / scale = frames per second
  p32(b, 132, 1000000);     // rate   }
  p32(b, 136, 0);         // start
  p32(b, 140, frames_);   // length
  p32(b, 144, bufSize);
  p32(b, 148, 0xFFFFFFFF);  // quality: default
  p32(b, 152, 0);         // sample size: varies
  p16(b, 156, 0);
  p16(b, 158, 0);
  p16(b, 160, w_);
  p16(b, 162, h_);
  fcc(b, 164, "strf");
  p32(b, 168, 40);
  p32(b, 172, 40);  // BITMAPINFOHEADER
  p32(b, 176, w_);
  p32(b, 180, h_);
  p16(b, 184, 1);   // planes
  p16(b, 186, 24);  // bits per pixel
  fcc(b, 188, "MJPG");
  p32(b, 192, (uint32_t)w_ * h_ * 3);
  fcc(b, 212, "LIST");
  p32(b, 216, (uint32_t)(4 + moviBytes_));
  fcc(b, 220, "movi");

  return f_.seek(0) && f_.write(b, HEADER_LEN) == HEADER_LEN && (final || f_.seek(HEADER_LEN + moviBytes_));
}

void AviWriter::freeIndex() {
  if (index_) heap_caps_free(index_);
  index_ = nullptr;
}
