// microSD card: photos and MJPEG AVI videos in /DISHA.
//
// The card is never formatted or erased by this firmware. If it cannot be mounted, the status
// explains why and how to fix it on a PC.
// Every function that touches the card must run on the camera task (the only SD user), so card
// writes never overlap camera DMA work from another task. status() is safe from any task.
#pragma once
#include <Arduino.h>

namespace SdStorage {

struct Status {
  bool mounted;
  char cardType[8];
  uint64_t totalBytes;
  uint64_t usedBytes;
  uint32_t photos;
  uint32_t videos;
  char lastFile[24];
  char problem[140];  // why the card is unusable (JSON-safe text)
  bool recording;
  char recFile[24];
  uint32_t recFrames;
  uint32_t recMs;
  uint64_t recBytes;
  uint32_t recFiles;  // files in this recording (it splits at 1 GB)
};

bool begin();          // allocate buffers; then call mount()
bool mount();          // camera task
bool ensureMounted();  // camera task: mount if a card was inserted after boot
Status status();       // any task (cached copy)
size_t statusJson(char *out, size_t cap);  // any task

// Camera task only. On failure, err holds a short spoken-friendly reason.
bool savePhoto(const uint8_t *jpeg, size_t len, char *name, size_t nameCap, char *err, size_t errCap);
bool startRecording(uint16_t width, uint16_t height, uint8_t fps, char *name, size_t nameCap, char *err, size_t errCap);
// Returns false if recording had to stop (card full or removed); err says why.
bool addFrame(const uint8_t *jpeg, size_t len, uint16_t width, uint16_t height, uint32_t captureMs, char *err,
              size_t errCap);
bool stopRecording(char *summary, size_t cap);
bool isRecording();
size_t listJson(char *out, size_t cap, int maxFiles);

}  // namespace SdStorage
