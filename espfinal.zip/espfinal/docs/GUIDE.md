# DISHA GLASS OS: USB camera glasses + voice + vision AI

An ESP32-S3 camera on your glasses sends pictures over a **USB cable** (no Wi-Fi, no Bluetooth) to a native Android app. The app listens through your **Bluetooth earbuds**, answers in your earbuds, and uses a **free vision AI that needs no API key** (OVHcloud AI Endpoints; Google Gemini with your own key is optional) to say what you are looking at. Photos and MJPEG videos can be saved on the phone, on the glasses' microSD card, or both.

| | |
|---|---|
| Firmware to upload | `firmware/DISHA-CAM/DISHA-CAM.ino` (version 0.3.0, Arduino, esp32 core 3.3.12) |
| App to install | `build/DishaGlassOS-debug.apk` (version 0.12.0) |
| Laptop slide helper | `tools/disha_presenter.ps1` (moves PowerPoint when you say "Disha, next slide") |
| Signing key (back it up!) | `tools/signing/disha-debug.keystore`: every update must be signed with it, or it can't install over the app and keep your training |
| Android Studio project | `android/DishaGlassOS/` (Kotlin) |
| Protocol specification | `docs/PROTOCOL.md` |
| PC tools | `tools/` (flash, serial snapshot, USB protocol bench test, APK build) |

Your existing projects (`S3_CAM`, `ESP32CAM_GC2145_no6`, `tifinal os`, `DISHA_AI_EYE_V1`) were only read, never modified.

## Quick start (full system)

1. **Flash the firmware.** Plug the board's **USB-UART** connector into the PC, then run (replace `COM9` with your port):
   ```bash
   powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM9
   ```
   If you use Arduino IDE instead, set **Tools > USB Mode = USB-OTG (TinyUSB)**: the IDE remembers the old setting and the default is wrong (table in 7.1). The boot log should show `[sd] SDHC card mounted …` with the card inserted.
2. **Install the app.** Install `build/DishaGlassOS-debug.apk` over the old one, through Google Drive as before. Open it and allow **notifications** and, on the first mic tap, the **microphone**.
3. **AI: nothing to set up.** The AI service is **Free AI, no key (OVHcloud)** by default. In the app, open **Settings** and tap **Test AI**. The app sends a test picture it draws itself (not a camera picture) and should say "Working: it read the test picture". The phone needs internet (mobile data or Wi-Fi). This is only for the AI; the glasses still use the USB cable.
4. In Settings, turn on **Allow sending camera pictures to this AI** (it explains where pictures go and asks you to confirm), and choose where photos and videos go.
5. **Connect the glasses:** phone → OTG adapter → USB cable → the board's **USB-OTG** connector. Wait for **CAMERA READY**.
6. **Talk.** Tap **MIC**, tap the earbuds, or tap **Talk** in the notification. The first time, the app asks how to understand your voice. Choose **Allow online speech**, because the Tecno's built-in speech service fails with "speech service disconnected". Then try:
   - "Disha, what am I looking at?" (starting with the name is optional) / "read this" / "analyse this"
   - "Record a 30 second video", "take a photo every minute for 10 minutes", "tell me when you see a bus" (it keeps watching and alerts you), "watch this for 10 seconds and tell me what happens", "stop watching"
   - "If you see a price tag, remember it" (Disha sees the picture and acts on it in one go)
   - "Good morning" or "brief me": greeting, time, weather, phone battery, glasses, reminders, top 3 headlines
   - "Set a timer for 5 minutes", "remind me at 6 pm to call Mom", "how much time is left", "cancel the timer"
   - "Remember that my car is on level B2" … later "where did I park?"; "remember this" saves what the camera sees
   - "What's the weather tomorrow?", "do I need an umbrella?", "any news about ISRO?"
   - "Torch on", "volume up", "pause the music", "next song"
   - "Take a photo and start recording" (several things at once), or any question at all

   **Conversation mode:** after each answer you hear a short beep, and it listens for your follow-up without another tap. Stay quiet for 6 seconds or say "thanks" to finish. The name ("Disha"), what it calls you ("Boss"), the accent and speed of its voice, and your home city are in Settings.

   **How it thinks:** common commands are handled on the phone at once. Questions about what you see go straight to the vision model with a fresh picture. Everything else goes to a "thinking" model (Qwen3.8 and others, free, no key), together with a fresh camera picture when the request is about what you see, so it can see and act in one step. It decides which of 21 tools to use: look, watch briefly, photo, timed video, photo series, background alert ("tell me when you see…"), stop tasks, timer, reminder, memory, weather, news, Wikipedia, torch, volume or music. Background tasks show on the main screen with a Stop button. It also knows the time, your battery, the glasses' state, your timers and everything you asked it to remember.

### New in 0.12.0: documents, directions, captions, QR, slides, two ways to present

| Say | What happens |
|---|---|
| "Disha, I want to make a document" (or "make a PDF called Lab report") | "Okay Boss. Put the first page…". Each page you hold still in front of the glasses is scanned by itself (or say "next"), cleaned up like a scanner, and she asks for the next page. "Done" makes one A4 PDF in Documents/DISHA. "Retake" drops the last page, "cancel" throws it away. With picture sending allowed she also reads the pages, so "summarise it" works. |
| "Save that" / "clip that" | With **instant replay** on ("turn on instant replay", or the Replay button) the last 30 s of the live view are kept in memory and saved to Movies/DISHA on request. |
| "Take me to the nearest metro station" / "navigate to India Gate" | Walking directions from OpenStreetMap (no key): finds the nearest station, ATM, hospital, chemist… or a named place, then turn-by-turn in the earbuds by GPS ("In 40 metres, turn left onto Janpath"), re-routes when you leave the route, and the camera warns about obstacles on the way. "Where now?", "stop navigation". |
| "Live captions" / "Be my translator" / "translate between Hindi and Tamil" | Captions full screen on the phone (and in the web view). The translator speaks each translation; turn the phone to the other person to show it. Everything said nearby is sent to the speech service: tell people. On the free service captions come a few seconds late; a free Groq key makes them almost live. "Disha, stop captions". |
| "Scan this QR code" / "scan this business card" | Read on the phone (ZXing, offline). Links and contacts are opened/saved only after you say yes (the phone's own contact screen, you tap Save); UPI codes are only read out, never paid; Wi-Fi passwords are not read aloud. Product barcodes go to the food check. |
| "Next slide", "change slide", "previous slide", "go to slide 5", "start the presentation", "black screen" | Moves the slides: in the web view's PDF viewer, and in real PowerPoint on the laptop through `tools/disha_presenter.ps1`. Only a soft chime, so it doesn't interrupt your talk. |
| "Presentation mode" (or the **Present** button) | The phone serves a live dashboard for the judges' laptop/projector: live camera, Disha's orb and conversation, captions, directions and the slides. Address shown in the app, e.g. `http://192.168.43.1:8080/482913/` (random code; the laptop must be on the same Wi-Fi or the phone's hotspot). |

**Two ways to show it (hackathon):**
1. **Android + USB (main):** glasses → USB → phone. Turn on Presentation mode and open the address on the laptop. For PowerPoint, on the laptop run:
   ```bash
   powershell -ExecutionPolicy Bypass -File tools\disha_presenter.ps1 -Url http://192.168.43.1:8080/482913/
   ```
2. **Glasses on their own, Wi-Fi web mode (firmware 0.3.0):** hold BOOT for 5 s (the board restarts; the RGB LED then blinks white every 2 s), or type `wifi on` in the Serial Monitor. Off by default and only you switch it on. The glasses join the network set in `src/config/disha_config.h` (best: the phone's or laptop's 2.4 GHz hotspot, so the browser has internet for the AI) or, with no network set, make their own hotspot **DISHA-CAM** (password `dishacam123`) at `http://192.168.4.1`. The page shows the live view, asks the free AI about it from the browser (no key; you can paste one in the page, kept only in that browser) and speaks the answers, takes photos / video to the card, and can describe the view every 15 s. Power the glasses from the laptop or a power bank. Hold BOOT 5 s again to switch Wi-Fi off. BOOT now: short press = photo, hold 1.5–4 s and let go = video.

**AI:** works without any key. In **Settings → AI BOOST** you can paste a key (Groq's free key is the fastest; OpenRouter, OpenAI or any OpenAI-compatible service also work). It is tried first for thinking, pictures and speech; the free services take over when it fails. The key stays on the phone and is never in backups. The thinking model now also has tools for documents, directions, slides, replay, QR and cards, and captions, so plain requests like "can you walk me to a chemist" work too.

**Offline:** with no internet, commands are understood by the phone's on-device recogniser (Android 12+ with Google's speech services; **Settings → Download offline speech**), and photos, video, instant replay, QR codes, PDFs, slides, timers and reminders still work. Questions that need the AI get a clear "no internet" answer.

**Look:** pure black (AMOLED) theme, rounded black-glass buttons with fading presses, the orb animated at the display's full frame rate, quick buttons for Make PDF, Captions, Translate talk, Scan QR, Replay / Save 30 s and Present.

### Your training survives updates (0.11.0)

Your wake-word recordings, memory, reminders, diary/places/document/photo notes and settings live in the app's private storage. **Installing a new APK over the app keeps all of it**: never uninstall first. This works because every APK is signed with the same key (`tools/signing/disha-debug.keystore`) and has a higher version number. The build script refuses to make a new key on its own.

As a safety net, for an uninstall or a new phone, use **Settings → BACKUP**:
- **Daily backup copy** (on by default): `Documents/DISHA/Backup/disha-backup.zip`, also made right after you record the wake words. It stays on the phone even if the app is uninstalled.
- **Save a backup…** writes a zip wherever you choose (Drive, Downloads). **Restore…** reads one back: it shows what's inside and asks first. The backup's settings and wake recordings replace the current ones. Memories, reminders and notes are added to the ones already on the phone.
- Backups never hold the Gemini key. Permissions (camera pictures, voice, meeting notes) are asked again after a restore. Google's cloud backup stays off, because it would upload your voice recordings without asking.
- When you uninstall, Android 10+ may offer **"Keep app data"**. Tick it to keep the training for a reinstall.

### Look and feel (0.10.0)

- **The Disha orb** replaces the MIC button. It breathes when idle, shows a turning ring while waiting for "Disha", pulses with your voice while listening, spins while thinking and shows sound waves while speaking. **Tap** to talk; **press and hold** to talk until you let go (good in noisy places).
- **Chat bubbles** for the conversation (long-press one to copy it), **status chips** (glasses, earbuds, wake word, AI, battery), a running REC timer, and the less-used camera buttons folded under *More camera controls*.
- **Listening:** the phone's noise suppression on every recording, soft chimes (listening, heard you, done, error, alerts) and **Response speed** in Settings: Quick 0.6 s / Normal 0.85 s / Patient 1.3 s of quiet ends what you say.
- **AI:** knows you're in India (rupees, km, Hinglish), answers first, saves lasting facts you mention ("I'm allergic to peanuts") without being asked, offers only what it can really do, and remembers the conversation across an app restart for 30 minutes.

### Skills (0.9.0)

| Say | What happens | Set up first (Settings → SKILLS) |
|---|---|---|
| "Where did I leave my keys?" / "When did I last see my bag?" | Searches notes of what the camera saw | **Visual memory** every 2/5/10 minutes (or say "start remembering what I see") |
| "Translate this" / "...into Hindi" | Reads a sign or menu in any language and says it in English or Hindi | – |
| "Is this healthy?" / "scan the barcode" | Reads the barcode, looks it up in Open Food Facts (free, no key): Nutri-Score, sugar, salt, fat, calories, allergens. Unknown product: reads the pack's label | – |
| "Read my messages" / "Reply to Rahul saying I'm on my way" | Reads new WhatsApp / SMS / other messages; a reply is sent with the app's own Reply button **only after you say yes** | **Notification access** |
| "Who's calling?" / "answer" / "reject" | Says the caller's name when the phone rings; answers or rejects | **Call control** (+ notification access for names) |
| "Scan this page" / "summarise it" / "read it back" | Transcribes the page, saves text + photo in Documents/DISHA and Pictures/DISHA, summarises | – |
| "Show the whiteboard photos from today" | Opens the smart gallery with matching photos (also the **Gallery** button) | **Smart gallery** (captions new phone photos) |
| "Take notes" … "stop taking notes" | Records, transcribes in 30-45 s pieces while you talk, then saves transcript + summary in Documents/DISHA | **Allow meeting notes** (tell people you're recording) |
| "What did I do today?" | A short spoken diary from photos, things seen, documents, events and places | Smart gallery / visual memory / **Remember places** |
| "Guide me" … "stop guiding" / "Which note is this?" | Every 8 s: what is ahead, warnings for steps, vehicles, obstacles. Recognises Indian notes and coins | – (an aid, never instead of a cane or guide) |
| "Disha, help" | After a **10-second countdown you can cancel** ("cancel", or the Stop button): SMS with your location to your emergency contact | **Emergency SOS**: name, number, your name, switch on; "Send a test message" to check |
7. **"Disha", hands-free:** in **Settings → Hands-free wake word**, tap **Record my wake words** and, after each beep, say "Disha", "Hello Disha" and "Hi Disha", twice each (about 20 seconds). Put the phone where you usually keep it first (for example your pocket). After that, whenever the assistant is idle, saying any of them makes it beep and listen. You can also say it in one breath: "Disha, take a photo".
   - It learns **your** voice: other people saying it won't wake it.
   - Waiting for the phrase happens entirely on the phone: nothing is recorded or sent. An unclear match is double-checked by the online speech service, if you allowed it.
   - It listens through the **phone's** microphone, not the earbuds. Keeping the earbud mic on all the time would lock the earbuds in low-quality call mode.
8. **Pocket mode:** lock the screen. The service keeps the glasses connected and recording. You can still talk to it with the wake phrase, the earbud tap or the notification's **Talk** button.

| Glasses button / light | Meaning |
|---|---|
| BOOT short press | photo to the microSD card |
| BOOT hold 1.5 s | start/stop video on the microSD card |
| RGB LED | yellow starting · green ready · cyan app connected · blue streaming · **purple recording** · red camera error |
| IO2 LED | on while the camera's pictures leave the board (privacy indicator) |

---

## 1. Verification status (be clear about what is proven)

| Item | Status |
|---|---|
| Firmware 0.2.0 compiles in both USB modes, `-Wall`, no warnings (arduino-cli 1.5.1, esp32 core 3.3.12) | **Verified on this PC** |
| Firmware 0.1.0 on **your board**: GC2145 detected, photo correct, self-tests OK, 14.9 / 3.6 / 2.3 fps at 320×240 / 640×480 / 800×600 (capture + JPEG, before USB) | **Verified on your hardware** |
| Firmware 0.2.0 microSD code (mount, photos, AVI video, listing) | Compiled; **not yet run on the board** |
| App 0.4.0 Kotlin code compiles with **no warnings** (kotlinc 2.0.21); APK built, signed, aligned, verified | **Verified on this PC** |
| 16 unit tests: protocol (golden vector, resync, frame reassembly), voice commands, wake-name stripping, AVI file structure, speech start/end detection, transcript filter | **Passed on this PC** (JVM) |
| New speech chain on real audio: a spoken sentence with background noise and silence → speech detector (start found within 30 ms, end found) → trimmed WAV → free Whisper with the app's exact request → transcript word for word | **Verified on this PC** (2026-10-10) |
| USB camera link with the Tecno: 282 frames received, CRC-32 OK (your screenshot) | **Verified on your hardware** |
| Earbud recording with the new recorder on the Tecno | **Not tested yet** |
| Thinking model with the app's exact prompt and 16 tools (2026-10-10, no key): "where did I park" answered from memory; "give me some light" → torch; "wake me up in 20 minutes" → 1200 s timer; "what's going on with ISRO" → news(ISRO); cricket question answered directly; "delete the wifi password thing" → forget fact 2; "call my mom" politely declined; "snap a pic and start recording" → both tools. One model first *claimed* actions without calling tools; the prompt rule added after that fixed it in retests. | **Verified from this PC** |
| Follow-up round (tool results → spoken answer) on Qwen3.8, Mistral-Small, gpt-oss-120b, e.g. "70 percent chance of light rain tomorrow, so grab an umbrella. Your 5 minute timer is set." | **Verified from this PC** |
| Weather (Open-Meteo), headlines (Google News RSS), Wikipedia, city from IP (ipwho.is): all answer without a key | **Verified from this PC** |
| 25 unit tests incl. time/duration parsing, reminders, speech clean-up, weather wording | **Passed on this PC** (JVM) |
| Timers/reminders firing with the screen off, torch, volume, music keys, proactive alerts, voice accents | **Not tested on the phone yet** |
| "Disha" wake word (0.8.0): on-phone matcher (MFCC + energy + deltas, time-warped against your 6 recordings, threshold calibrated to your voice within a tested range) plus speech-service confirmation for uncertain matches. Synthetic-voice tests: 9-10 of 12 "Disha / Hello Disha / Hi Disha" pass the phone check at four noise levels (misses: "Hey Disha", which is not recorded, and very fast speech); of 30 deliberately "sh"-heavy decoys ("Delicious", "Fishing", "Mission"...) 4-6 are sent for confirmation and none wake directly; another speaker is rejected. Stream test: all 7 names caught (1 instant, 6 confirmed), 2 of 7 decoys ignored, 5 sent for confirmation. | **Verified on this PC** (synthetic voices) |
| Wake phrase on the phone (pocket mic, battery use, screen off) | **Not tested yet** |
| Skills (0.9.0): 37 unit tests incl. barcode check digits, food verdict wording (real Coca-Cola data), "today/this week" ranges, photo/memory search, reply parsing (13 phrasings), 30+ new voice commands. Live, without a key: Open Food Facts lookup; barcode digits read from a photo by both vision models; a Hindi sign translated ("Wait! Work ahead is in progress. Slow down"); a printed notice transcribed word for word; the AI picks read_messages / reply_message / search_my_memory correctly and still refuses phone calls | **Verified from this PC** |
| Messages, calls, SOS SMS, guide mode, meeting notes, places, gallery on the phone | **Not tested yet** (need the phone; SOS: use "Send a test message") |
| 0.12.0 on this PC: APK builds with no warnings (ZXing 3.5.3 bundled, SHA-1 checked), same signing certificate, versionCode 12. 49 JVM tests incl. walking-direction maths and wording (turn announced once, at about 40 m; off-route after 3 fixes; arrival), QR content (UPI read-only, Wi-Fi password not spoken, vCard / MECARD), page detection for documents, captions cutting long speech, 25 new voice commands. Live, without a key: OSRM foot route and Overpass "nearest metro" in Delhi; Whisper reports the spoken language; English→Hindi and Hindi→English translation prompts; a business card read into exact JSON by two vision models; the laptop dashboard rendered with live state, Hindi captions and pdf.js | **Verified on this PC**; nothing of 0.12.0 run on the phone yet |
| Firmware 0.3.0 (Wi-Fi web mode, new BOOT timing) compiles in both USB modes with all warnings on: none; 38% / 37% of the 3 MB app partition | **Verified on this PC**; **not yet run on the board** |
| Updates keep the training (0.11.0): APK 0.11.0 is signed with the same certificate as every earlier build (SHA-256 `DC:33:05:D6…59:BB`), versionCode 11 > 10. 43 unit tests, including the backup file format: round trip, unsafe or unknown file names skipped, damaged or oversized files refused, key and consents never included | **Verified on this PC**; backup save/restore and the Documents copy **not yet run on the phone** |
| Agent tools with live free models (0.8.0): "photo every minute for 10 minutes" -> photo_series(10, 60); "tell me when you see a bus" -> alert_when_seen(bus); "keep an eye out for my friend in a red shirt and snap a picture" -> alert_when_seen(person in red shirt, photo); "film the next two minutes" -> record_video(120); "is the traffic moving? check for a few seconds" -> watch_briefly(5); seeing + acting from one picture (red ball "4521" -> take_photo + remember 4521); several pictures over time -> correct description of change | **Verified from this PC**; background tasks and timed recording **not yet run on the phone** |
| Camera "stuck" fixes: firmware 0.2.1 keeps streaming through short phone pauses and, in the fallback USB mode, no longer calls the ESP32 core's CDC `flush()`, which throws away queued data after 20 ms without progress. App 0.7.0 restarts a stalled live view by itself (after 4 s without frames), then reconnects if needed, and resumes live view after any reconnect. | Firmware compiles in both USB modes without warnings; **not yet run on the board** |
| Free no-key AI (OVHcloud) | **Verified from this PC on 2026-10-10**: all 5 vision models in the app's list read a test picture ("DISHA 47") with no key, using the app's exact request format (system prompt, history, picture). Limit measured from the service's own headers: 2 requests per minute per model. A 6th model (Qwen3.5-397B) was dropped: it kept reasoning and never answered. **Not yet run from the phone** |
| Gemini (optional) request format and model name | Based on Google's published API and third-party model trackers; **not yet called with a real key** (Settings > Test AI checks it) |
| Phone's built-in speech service on the Tecno | **Fails** ("speech service disconnected", Android error 11). Hence the online speech option. |
| Background operation with the screen off | **Not tested yet** |
| Your first phone ("pro 5+" mini) | **Cannot be used**: its USB port gives no data and no OTG power (your mouse test) |
| Gradle / Android Studio build | **Not run** (Gradle not downloaded); same Kotlin sources as the verified build |

---

## 2. Feasibility assessment (from your hardware and code)

| Question | Finding | Evidence |
|---|---|---|
| Board and pins | Freenove-style "ESP32-S3 WROOM CAM" layout: camera on GPIO 4/5/6/7/8-13/15-18, microSD (SD_MMC 1-bit) on 38/39/40, WS2812 on 48, LED on 2 | Your working `S3_CAM.ino`, and the same pin map in `tifinal os/TiFinalOS/config.h` |
| Module | ESP32-S3-N16R8: 16 MB flash, 8 MB **octal** PSRAM → *Tools > PSRAM: OPI PSRAM* | Module marking, `S3_CAM.ino` header. The firmware prints flash and PSRAM size at boot and warns if they don't match. |
| Camera "RHYX M21-45" | **GC2145** (Galaxycore, SCCB address 0x3C, PID 0x2145), max 1600x1200 | Your earlier sketches detect it as GC2145. Driver enabled in core 3.3.12 (`CONFIG_GC2145_SUPPORT=y`). DISHA-CAM reads the PID at boot and logs it. |
| JPEG from the sensor? | **No.** The GC2145 outputs RGB565/YUV422 only. JPEG must be encoded **on the ESP32-S3** in software. | Driver sensor table (`support_jpeg` false); `S3_CAM.ino` falls back from JPEG to RGB565; your old README notes the same |
| Native USB on the S3 | One full-speed (12 Mbit/s) USB PHY on GPIO19/20, shared by two controllers: **USB Serial/JTAG** (fixed CDC + JTAG) and **USB-OTG** (TinyUSB). Only one is active, chosen by *Tools > USB Mode*. | ESP32-S3 datasheet; `boards.txt` in core 3.3.12 |
| Which connector is native USB | **"USB-OTG"** = GPIO19/20 native USB. **"USB-UART"** = a WCH CH343/CH340 USB-to-serial bridge on UART0 (GPIO43/44). It is *not* native USB and is limited to UART speeds. | Board labels, Freenove layout |
| TinyUSB in core 3.3.12 | TinyUSB **0.21** with Vendor class **enabled**, Video (UVC) class compiled in, CDC enabled. Vendor TX/RX FIFOs are 64 bytes. | `sdkconfig` and `tusb_config.h` of `esp32s3-libs 3.3.12` |
| Bug found in core 3.3.12 | Arduino's `USBVendor` still defines the old one-argument `tud_vendor_rx_cb`; TinyUSB 0.21 calls a three-argument one, so `USBVendor::read()` would never receive data. | `USBVendor.cpp` vs `vendor_device.h` → DISHA-CAM bypasses `USBVendor` and uses TinyUSB's vendor API directly |
| Android side | A vendor-class (0xFF) bulk interface can be claimed with the standard **Android USB Host API** (API 12+), no root and no driver | Android `UsbManager`/`UsbDeviceConnection` |
| Pins and memory together | No pin conflicts: camera, SD (38-40), USB (19/20), UART (43/44), internal PSRAM (35-37) are separate. Memory: RGB565 frame buffers 2 x 150 KB at 320x240, up to 2 x 938 KB at 800x600, plus a 512 KB JPEG buffer, all in PSRAM; about 250 KB internal RAM stays free. | Pin map above; compile report |
| Power from the phone | Not measured. *Estimate:* 0.15-0.3 A at 5 V with both radios off, below the ~0.5 A most phones give over OTG. The firmware reports the last reset reason; **"brownout"** means the phone or cable can't supply enough. | Measure with a USB power meter in Phase 8 |

**Conclusion:** the required system is possible on your **existing** board and camera with **no hardware change**. You only need the right cable or adapter (section 5).

---

## 3. USB transport options and the decision

| Option | Feasible here? | Advantages | Drawbacks | Decision |
|---|---|---|---|---|
| **A. UVC webcam** | Technically possible (TinyUSB video class is compiled in) | Standard webcam class | Throughput is no better (same 12 Mbit/s bus) and the same software JPEG is still needed. UVC descriptors and controls would have to be hand-written: Arduino has no UVC wrapper. Android's Camera2 normally can't open USB webcams, so the app would need a native libuvc/libusb (NDK) library, with compatibility risk on older phones. A second interface would still be needed for commands (photo to SD, status). | **Rejected for now:** more risk, no gain |
| **B. Custom vendor bulk protocol over TinyUSB** (USB-OTG port) | **Yes** | Plain Android USB Host API, no driver. No kernel `cdc_acm` driver grabs it. No DTR/RTS chip-reset hazard. No ESP-IDF log text mixed into the data. Commands and video share one pipe. | Windows needs a WinUSB driver to open it (PC testing only); 64-byte FIFO in this core build limits throughput | **Selected (primary)** |
| B'. Same protocol over the S3's USB Serial/JTAG CDC (USB-OTG port, *USB Mode: Hardware CDC and JTAG*) | Yes | No TinyUSB. Appears as a COM port on Windows, so it can be bench-tested from a PC (`tools/usb_protocol_test.ps1`). | Some phones' kernels bind `cdc_acm` (the app detaches it). Certain DTR/RTS sequences reset the chip. ESP-IDF console output must be silenced. | **Fallback**, same firmware and app with one Tools-menu change |
| **C. Serial via the USB-UART bridge** | Possible | Simple | Limited by UART baud: CH340 max 2 Mbaud; CH343 and the S3 UART reach about 5 Mbaud (≈ 0.2-0.5 MB/s raw). Needs a CH34x driver inside the app. It is also the flashing/log port, and it isn't native USB. | **Not used for data** |

Full speed USB is 12 Mbit/s on the wire. Real-world bulk throughput for this firmware is **not measured yet**; *estimate* a few hundred KB/s. A 320x240 JPEG is roughly 8-20 KB (*estimate*), so USB should not be the bottleneck at the 1-5 fps target. On-chip JPEG encoding probably is; the `fps` serial command measures it.

---

## 4. Architecture

```
 GC2145 ──DVP──► ESP32-S3 (DISHA-CAM firmware)                    Android phone (DISHA GLASS OS)
 RGB565          camera task: capture RGB565 → JPEG (software)       UsbLinkConnection: 4 queued async
                 link task:   session, commands, keep-alive          bulk reads (no data loss on timeout)
                 protocol:    16-byte header + CRC-16,               MessageParser: resync + CRC checks
                              payload + CRC-32, 8 KB frame chunks    FrameAssembler: in-order + frame CRC
                 USB-OTG port ═══ USB bulk IN/OUT (full speed) ═══►  FrameDecoder: JPEG check + decode
                 USB-UART port ─► PC: flashing + debug log only      CameraLinkManager: permission, handshake,
                                                                     ping, reconnect, commands (no UI code)
                                                                     MainActivity: preview, stats, log
```

- **Camera task** (core 1) is the only code that touches the camera driver. It serves single captures and timed streaming, restarts the driver for resolution changes, re-initialises after 3 failed captures, and retries init every 5 s after an error.
- **Link task** parses commands and answers HELLO/PING/STATUS. It ends the session if the phone goes silent (5 s), USB detaches, or sending stalls (1.5 s). Streaming never runs without a session.
- **Watchdog**: both tasks are watched (10 s). A hang causes a panic and reboot, and the reboot reason reaches the app.
- **Privacy indicator**: LED "IO2" is on whenever camera frames are leaving the board.

---

## 5. Hardware connections

**For flashing and the debug log (PC):** USB-C *data* cable from the PC to the **USB-UART** connector. In the Arduino IDE the port shows as `USB-Enhanced-SERIAL CH343` or `USB-SERIAL CH340`.

**For the phone (runtime):** connect the phone to the **USB-OTG** connector. Use one of:

| Phone connector | Cable |
|---|---|
| USB-C | 1) USB-C to USB-C **data** cable. If the board does not power up (no power LED), its USB-C socket probably lacks the CC resistors the phone needs to switch to host mode. Then use 2): a **USB-C OTG adapter** (USB-C plug → USB-A socket) plus a USB-A to USB-C data cable. |
| micro-USB | **micro-USB OTG adapter or cable** (micro-B plug → USB-A socket) plus a USB-A to USB-C data cable |

- Many phones need OTG switched on (e.g. Oppo/Realme/OnePlus/Vivo: *Settings > Additional settings > OTG connection*). Some switch it off again after about 10 minutes idle.
- **Do not connect the PC (USB-UART) and the phone (USB-OTG) at the same time** unless the board's schematic shows the two USB 5 V inputs separated by diodes. Otherwise two 5 V sources feed each other. During phone tests the firmware forwards its log to the app (LOG section), so the PC cable isn't needed.
- microSD: can stay inserted; this firmware does not touch it.
- Camera ribbon: unchanged from your working setup.

---

## 6. Software versions

| Component | Version | Notes |
|---|---|---|
| Arduino IDE | 2.x (installed) | bundled arduino-cli 1.5.1 |
| Boards package | **esp32 by Espressif 3.3.12** (installed) | ESP-IDF 5.5.5 inside; includes esp32-camera and TinyUSB 0.21 |
| Extra Arduino libraries | **none** | |
| Android app | Kotlin 2.0.21, Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 | compileSdk/targetSdk 34, **minSdk 21 (Android 5.0)** until your phone's version is known |
| App dependencies | Kotlin standard library only (JUnit 4.13.2 for tests) | no AndroidX or third-party USB libraries |
| No-Gradle build (used here) | kotlinc 2.0.21, Android build-tools 34.0.0, JDK 17 | `tools/build_apk.ps1` |

---

## 7. Build, flash and install

### 7.1 Firmware

**Option 1, one command** (exact settings, no Tools menu to get wrong):

```bash
powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM5
```

(Replace `COM5` with the USB-UART port from Device Manager > Ports. Close the Serial Monitor first.)

**Option 2, Arduino IDE:** open `firmware/DISHA-CAM/DISHA-CAM.ino` and set *Tools*:

| Setting | Value |
|---|---|
| Board | ESP32S3 Dev Module |
| USB Mode | **USB-OTG (TinyUSB)** (fallback: Hardware CDC and JTAG) |
| USB CDC On Boot | **Disabled** (the sketch refuses to compile otherwise) |
| PSRAM | **OPI PSRAM** (the sketch refuses to compile otherwise) |
| Flash Size | 16MB (128Mb) |
| Partition Scheme | 16M Flash (3MB APP/9.9MB FATFS) |
| CPU Frequency | 240MHz (WiFi) |
| Flash Mode | QIO 80MHz |
| Upload Mode | UART0 / Hardware CDC |
| Upload Speed | 921600 |
| Core Debug Level | None |
| Port | the USB-UART COM port |

If the upload can't connect: hold **BOOT**, press and release **RST**, release **BOOT**, upload again. Press **RST** after uploading.

### 7.2 Android app

**Install the prebuilt APK** (`build/DishaGlassOS-debug.apk`, debug-signed):
- *By file:* copy it to the phone, open it, allow "Install unknown apps" for your file manager.
- *By adb* (USB debugging on, phone connected to the PC):

```bash
"%LOCALAPPDATA%\TiFinalBuild\sdk\platform-tools\adb.exe" install -r build\DishaGlassOS-debug.apk
```

**Rebuild the APK without Android Studio:**

```bash
powershell -ExecutionPolicy Bypass -File tools\build_apk.ps1
```

**Or with Android Studio:** *File > Open* → `android/DishaGlassOS`. Let it sync (it downloads Gradle 8.9 and the plugins), then *Run*. Both builds sign with `tools/signing/disha-debug.keystore`, so either one installs over the other and keeps your data.

**Updates keep your data** only with the same key and a higher `versionCode` (in `tools/build_apk.ps1` and `app/build.gradle.kts`). Raise it for every release, and keep a copy of the keystore somewhere safe (`tools/signing/README.txt`).

### 7.3 Android permissions in this stage

- **No runtime permissions.** USB access is granted through Android's own USB dialog.
- `android.hardware.usb.host` is declared as *not required*, so the app still installs on a phone that doesn't advertise it and then explains the problem.
- Plugging in DISHA-CAM (VID `0x303A`, PID `0x0002`) offers to open the app. Ticking **"Always open…"** also grants permanent USB permission for that device, which makes reconnection after re-plugging automatic.
- Saved JPEGs go to the app's own folder (`Android/data/com.disha.glassos/files/Pictures/`), which needs no storage permission.
- Later stages add `RECORD_AUDIO`, `INTERNET`, notification and foreground-service permissions, each with its own explanation.

---

## 8. Test checklist (do the phases in order)

### Phase 2: one image on the ESP32 (PC only, no phone)

1. Flash (7.1). Open the Serial Monitor at **115200**, line ending **Newline**, and press **RST**. Expected (your numbers will differ where shown as `…`):
   ```
   ===== DISHA-CAM 0.1.0 =====
   chip ESP32-S3 rev …, 240 MHz, flash 16 MB, PSRAM ≈8190 KB, reset reason: …
   CRC self-test: OK, protocol self-test: OK
   [usb] native USB started: tinyusb-vendor on the USB-OTG port
   Wi-Fi and Bluetooth are not used. Type "help" for serial commands.
   [cam] GC2145 (PID 0x2145) ready: 320x240 RGB565, sensor JPEG: no -> JPEG encoded on the ESP32-S3
   [cam] self-test frame OK: 320x240 JPEG … bytes, capture … ms, encode … ms, SOI/EOI valid
   [stat] camera ready GC2145 320x240 | usb no host, session none | sent 0 frames | heap … KB, psram … KB | … C
   ```
   The board's RGB LED goes yellow, then green.
2. Type `snap` → `[snap] OK 320x240 JPEG … bytes q80 | capture … ms, encode … ms | SOI/EOI valid | crc32 …`
3. Close the Serial Monitor and run:
   ```bash
   powershell -ExecutionPolicy Bypass -File tools\serial_snap.ps1 -Port COM5
   ```
   → `OK 320x240 JPEG … bytes, CRC-32 match, SOI/EOI valid`. The photo opens. **Check it is a real, correctly coloured image.** If it is upside down, type `flip` in the Serial Monitor (the app will get an orientation setting later).
4. Type `fps` → `[fps] 20 frames: X fps capture+encode at 320x240 q80 …`. **Write down X**: it is the on-chip limit before USB. Repeat after `res 640` and `res 800`, then `res 320`.

**Pass:** steps 1-3 succeed and the image is correct.

### Phase 3: single frame over USB to Android

1. Install the APK (7.2). Unplug the PC cable. Connect the phone to the board's **USB-OTG** port (section 5).
2. Expected: the board powers up. Android asks "Open DISHA GLASS OS to handle DISHA-CAM?" Tick **Always** and tap **OK**. Without the dialog, open the app; it asks for USB access.
3. Expected in the app: the status pill goes **USB CONNECTED** (amber), then **CAMERA READY** (green), with detail `GC2145 320×240 JPEG q80 · native USB vendor bulk (TinyUSB)`. The board's LED turns **cyan**. The DEVICE card shows `USB 0x303A:0x0002`, interface `"DISHA-CAM Link"`, two bulk endpoints with max packet 64, `Firmware: DISHA-CAM 0.1.0 · protocol v1 · tinyusb-vendor`, and the **phone's Android version** (please tell me what it says).
4. Tap **Capture frame** → the image appears; the stats line shows `#… capture · 320×240 JPEG · … bytes · … chunk(s)`, `request→frame … ms` and `CRC-32 OK`. LED IO2 blinks.
5. Tap **Save JPEG** → toast "Saved DISHA_….jpg".

**Pass:** 10 captures in a row with **dropped 0** and **all CRC error counters 0** in the USB LINK panel.

### Phase 4: continuous low-rate preview

1. FPS button **2 fps** → **Start stream**: the pill shows **STREAMING** (blue), the board LED turns blue and IO2 stays on, and the overlay shows about 2 fps.
2. Try 5 and 10 fps, then 640×480 and 800×600 while streaming. **Record** display fps, device fps (DEVICE line), `request→frame` latency, and any drops or CRC errors.
3. **Stop stream** → CAMERA READY.
4. **Cable test:** pull the cable while streaming → **USB DISCONNECTED** ("USB cable removed.") within about a second. Plug back in → **CAMERA READY** again within a few seconds, with no taps (needs "Always" from Phase 3).
5. **Reset test:** press RST on the board while connected → the app re-handshakes and returns to CAMERA READY. The DEVICE card shows `Last reset: reset pin`.
6. Tap **Copy** in the LOG panel and send me the log, together with the numbers from steps 2 and Phase 2 step 4.

**Pass:** steady preview at your target rate, zero CRC errors, and clean recovery in steps 4 and 5.

### Phase 5: voice assistant with Bluetooth earbuds (app 0.2.0)

Works without the camera too; camera commands then answer "The camera isn't connected".

| Feature | How it works |
|---|---|
| Earbud **mic** | While listening, the app switches the earbuds to headset mode (Bluetooth SCO/HFP) so speech is recorded from the earbuds. Afterwards it switches back. Turn off "Listen with the earbud mic" to use the phone mic instead. |
| Earbud **speaker** | Answers are spoken with Android TextToSpeech as assistant/media audio, which plays in connected earbuds (normal media quality), otherwise on the phone speaker |
| Earbud **tap** | Play/pause tap starts listening (best effort: only while the app is the last app that played audio, see `EarbudButton.kt`) |
| Fallback | No earbuds, or earbuds without the "Calls" profile → phone mic and/or phone speaker. The ASSISTANT panel shows the current route. |
| Commands (no AI) | take a photo (saved in the app's Pictures folder) · camera status · start / stop live view · connect / disconnect camera · stop · what time is it · help |
| Needs AI (next stage) | "what am I looking at" / "read this" already capture a **fresh frame** over USB, then say the vision AI isn't connected yet |
| Not yet | recording (storage stage), wake word, listening with the screen off |

Test:
1. Pair the earbuds with the phone, and make sure "Calls" / "Phone audio" is on in their Bluetooth settings.
2. Install app 0.2.0 over the old one.
3. Tap **MIC** and allow microphone access. A beep plays, the status says "Switching the earbuds to headset mode…", then "Listening through your earbuds…".
4. Say "**what time is it**". The answer is spoken in the earbuds and both lines appear in the transcript.
5. Say "**camera status**", then (camera connected) "**take a photo**". You should hear "Photo saved".
6. Tap **Stop** while it's speaking: it goes quiet immediately.
7. Copy the LOG and send it to me: it shows "Earbud mic on/off", what was heard and the command.

### Optional bench test of the USB protocol from the PC (fallback build)

```bash
powershell -ExecutionPolicy Bypass -File tools\flash_firmware.ps1 -Port COM5 -UsbMode hwcdc
```

Then unplug the USB-UART cable, connect the **USB-OTG** connector to the PC (a new COM port appears: "USB Serial Device" or "USB JTAG/serial debug unit"), and run:

```bash
powershell -ExecutionPolicy Bypass -File tools\usb_protocol_test.ps1 -Port COM7
```

It runs HELLO, 3 captures (saved to Pictures) and 5 s of streaming, then reports fps, KB/s and parser error counts. This isolates firmware problems from Android problems. Re-flash with the default `-UsbMode tinyusb` afterwards.

---

## 9. Troubleshooting

| Symptom | Likely cause → fix |
|---|---|
| Compile error "Tools > PSRAM must be OPI PSRAM" / "USB CDC On Boot must be Disabled" | Tools menu → set as in 7.1, or use `flash_firmware.ps1` |
| Upload: "Failed to connect" | BOOT + RST sequence (7.1). Close the Serial Monitor. Use the **USB-UART** port. |
| Boot log: `Camera init failed (0x20001)` (camera not detected) or `(0x105)` | Ribbon not seated: contacts toward the board, latch closed. Press RST. The firmware retries every 5 s. |
| Boot log: `PSRAM not found` | Tools > PSRAM > OPI PSRAM |
| Snapshot is green/purple or has scrambled colours | Report it: an RGB565 byte-order mismatch. Fixable in firmware, but I need to see the image. |
| Phone does nothing when plugged in, board LED off | The phone isn't supplying power: OTG switched off in Settings, a charge-only cable, or a C-to-C cable to a socket without CC resistors → use an OTG adapter (section 5) |
| App: **Wrong USB device**, "This is the board's USB-UART port" | Move the cable to the **USB-OTG** connector |
| App: **USB CONNECTED** but never CAMERA READY, then "did not answer the DISHA protocol" | Old firmware on the board, or *USB Mode* not TinyUSB → re-flash with `flash_firmware.ps1` |
| App: **No USB host** | The phone does not declare OTG support. Try enabling OTG in Settings; some phones genuinely lack it. |
| App: USB permission keeps being asked | Accept the plug-in dialog with **Always** ticked |
| Last reset: **brownout** in the DEVICE card | Insufficient USB power: use a shorter or better cable, or a powered OTG hub. Don't add a second 5 V source without a proper power design. |
| Frames dropped / CRC errors grow | Cable quality or length: try a short cable. Copy the log and send it to me. |
| Stream fps far below target | Expected at higher resolutions: encoding is CPU-bound. Compare with the serial `fps` result; lower the resolution or quality. |

---

## 10. Known limitations

- **Frame rate** is limited by software JPEG on the ESP32-S3 (the GC2145 has no JPEG engine). Measured on your board: 14.9 fps at 320×240, 3.6 fps at 640×480, 2.3 fps at 800×600, before USB. Recordings and live view run at these rates or less.
- **USB full speed only** (12 Mbit/s signalling); the ESP32-S3 has no high-speed USB.
- **Resolutions offered: 320×240, 640×480, 800×600.** The AI picture size (Settings) switches the camera for that one picture, which costs about half a second.
- **Videos are MJPEG in AVI**: they play in VLC (Android and PC), MX Player and Windows players; many phone gallery apps cannot play them. There is no audio track. Real-time speed comes from the capture timestamps.
- **Power cut while recording on the glasses card** (for example pulling the cable): the file keeps everything up to the last header update (every 30 frames) but has no final index. VLC plays it and may offer to fix the index.
- **Vision AI needs the internet.** The default free AI needs no key, but each of its 5 models answers only **2 questions per minute** from your internet connection. DISHA switches models when one is busy, which gives about 10 questions a minute in total; past that, it waits up to 20 s or tells you to try again in a minute. It is a public service run by OVHcloud. It could change its limits or start requiring a key; the app would then say so, and you can choose Gemini with your own free key in Settings. Pictures are sent only when you ask (or in watch mode), and only after you allow it in Settings, separately for each AI service.
- The free models answer in about 1 to 8 s. Qwen2.5-VL and Mistral-Small are the fastest; the Qwen3.x models reason before answering, so they are slower.
- **Screen-off listening** uses a foreground service with the microphone type. It works from the earbud tap or the notification's Talk button. The earbud tap only reaches DISHA if it was the last app to play sound; a music app can take it over.
- **The wake phrase is personal and uses the phone's mic.**
  - It recognises the voice that recorded the samples, so record again if it misses you often or wakes by mistake. Sensitivity is in Settings.
  - In a pocket, your voice is muffled, so record the samples in the same place.
  - It only works while the assistant is idle and the app or its notification is running. After a phone restart, open the app once, because Android only lets the app use the microphone in the background if it started from the screen.
  - While it waits, Android shows the microphone-in-use dot, and battery use is somewhat higher.
- **Timers and reminders** survive closing the app, but not a phone restart. They are spoken in the earbuds and shown as a notification with sound.
- **Live information comes from free public services:** Open-Meteo for weather, Google News RSS for headlines, Wikipedia, and ipwho.is to find your city from the internet connection when no home city is set. Only the city, topic or search words are sent. Memory and reminders stay on the phone.
- **Can't do:** place calls, start new chats, payments, browsing websites. It can only *reply* to messages that arrived as notifications, and only after you say yes. Guide mode and money recognition can be slow or wrong; they help, they don't replace a cane, a guide or checking yourself. SOS sends an SMS only; it does not call 112.
- **The FRIDAY (Irish) accent** needs the "English (Ireland)" voice in the phone's Google text-to-speech. Without it, the British voice is used.
- **Gemini as the thinking model** (when Gemini is chosen in Settings) uses Google's OpenAI-compatible endpoint. It is not tested, because I have no key.
- **Online speech recognition** sends only the detected speech (a few seconds) after you allow it. The free Whisper service allows about 4 requests a minute (2 models × 2), and silence is never uploaded. If it is busy, the assistant says so.
- **Earbud mic** uses the earbuds' call mode (Bluetooth SCO). Listening starts about a second later, and some earbud and phone combinations don't allow it outside calls; the app then falls back to the phone mic.
- The camera sensor runs continuously while the board is powered (power use).
- Some phones turn OTG off after idle time. Tecno phones may have an **OTG** switch in Settings.
- The primary USB transport has no Windows driver, so PC bench tests use the fallback build.
- The APK from `build_apk.ps1` is debug-signed with a local key; an Android Studio build is signed differently, so uninstall one before installing the other.

---

## 11. Next steps

| Step | Work |
|---|---|
| Hardware test | Flash 0.2.0 and check the microSD mount line in the boot log. Install 0.4.0, tap Settings > Test AI, connect the Tecno, test the camera, earbuds, AI, photos and recording, then send me the app log. |
| Wearable | Mount the board on the glasses, add cable strain relief and insulation, then measure current, heat and phone battery drain over 30 minutes. |
| Tuning | Choose resolution, frame rate and JPEG quality from your measurements; optionally put the sensor in standby when idle to save power. |

## 12. What I need from you

1. The boot log after flashing 0.2.0 (it should include the `[sd] … card mounted` line).
2. The result of **Settings > Test AI**.
3. The app log (LOG > Copy) after trying: what am I looking at, take a photo, start recording, stop recording.
