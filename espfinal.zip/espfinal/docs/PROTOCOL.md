# DISHA USB protocol, version 1

The protocol between the **DISHA-CAM** firmware (ESP32-S3) and the **DISHA GLASS OS** Android app, over the board's native USB port.

Implementations that must stay identical:

| Side | Files |
|---|---|
| Firmware | `firmware/DISHA-CAM/src/protocol/disha_protocol.h`, `crc.cpp`, `protocol_io.cpp` |
| Android | `android/DishaGlassOS/app/src/main/java/com/disha/glassos/protocol/*.kt` |
| PC test tools | `tools/DishaProtocol.cs` |

## 1. Transport

| Firmware build (Arduino *Tools > USB Mode*) | What the phone sees | Interface used |
|---|---|---|
| **USB-OTG (TinyUSB)**, the primary build | VID `0x303A`, PID `0x0002`, product "DISHA-CAM" | Vendor interface (class `0xFF/0x00/0x00`) named **"DISHA-CAM Link"**: 1 bulk OUT + 1 bulk IN endpoint, 64-byte packets (USB full speed) |
| **Hardware CDC and JTAG**, the fallback build | VID `0x303A`, PID `0x1001` (ESP32-S3 USB Serial/JTAG) | CDC data interface (class `0x0A`): 1 bulk OUT + 1 bulk IN. The JTAG interface (`0xFF/0xFF/0x01`) must **not** be used. |

Both are USB 2.0 **full speed** (12 Mbit/s signalling). The protocol is a byte stream: message boundaries come **only** from the length fields, never from USB packet boundaries.

**End-of-burst padding.** After the last message of a burst (a single reply, or the last chunk of a frame), the firmware sends one `0x00` byte as its own short USB packet. This completes the phone's pending bulk read immediately, even when the burst ended on a 64-byte packet boundary. Receivers must skip bytes that do not start a valid header, including these pad bytes.

## 2. Message format

All integers are **little-endian**.

```
offset size field
0      1    magic0      0xD1
1      1    magic1      0x5A
2      1    version     1
3      1    type        see section 3
4      2    seq         sender's message counter (1..65535, wraps, never 0)
6      2    ref         seq of the request this message answers; 0 if unsolicited
8      4    length      payload length in bytes
12     2    reserved    0
14     2    header CRC  CRC-16/CCITT-FALSE of bytes 0..13
16     n    payload
16+n   4    payload CRC CRC-32 (ISO-HDLC / zlib) of the payload; 0x00000000 for an empty payload
```

| Limit | Value | On violation |
|---|---|---|
| Payload, phone to device | 512 bytes | Device treats the header as corrupt and resynchronises |
| Payload, device to phone | 16384 bytes | Phone treats the header as corrupt and resynchronises |

### CRCs

| CRC | Parameters | Check value of ASCII `123456789` |
|---|---|---|
| CRC-16/CCITT-FALSE | poly `0x1021`, init `0xFFFF`, no reflection, no final XOR | `0x29B1` |
| CRC-32/ISO-HDLC | poly `0x04C11DB7` reflected (`0xEDB88320`), init and final XOR `0xFFFFFFFF` (same as zlib and `java.util.zip.CRC32`) | `0xCBF43926` |

### Receiving and resynchronisation

1. Skip bytes until `D1 5A`.
2. Wait for 16 bytes. If the header CRC is wrong, drop **one** byte and go to 1.
3. If `length` exceeds the receiver's limit, drop one byte and go to 1.
4. Wait for `16 + length + 4` bytes. If the payload CRC is wrong, drop one byte and go to 1.
5. Deliver the message and consume `16 + length + 4` bytes.

Dropping only one byte (never a whole claimed length) means a corrupt length field cannot swallow the valid messages that follow.

### Test vector

`CAPTURE_FRAME` with seq 3, ref 0, payload `01 00` (fresh, default quality):

```
D1 5A 01 10 03 00 00 00 02 00 00 00 00 00 02 C9 01 00 BE 23 C2 58
```

This vector is checked by `DishaProtocolTest.kt` (Android) and by the PC tools' self-test.

## 3. Message types

### Phone to device

| Type | Name | Payload | Device answer |
|---|---|---|---|
| `0x01` | HELLO | optional UTF-8 text (app name/version) | `HELLO_ACK`. Starts a new **session**: any running stream stops. |
| `0x02` | PING | 0-64 bytes | `PONG` echoing the payload |
| `0x03` | GET_STATUS | none | `STATUS` |
| `0x10` | CAPTURE_FRAME | `u8 fresh, u8 quality` (or empty = fresh, default quality) | `FRAME_CHUNK`s with `ref` = request seq and flag `REQUESTED`, or `RESULT` with an error |
| `0x11` | START_STREAM | `u8 fps (1-15), u8 quality (0 = current)` | `RESULT` OK, then `FRAME_CHUNK`s with `ref` 0 and flag `STREAM` |
| `0x12` | STOP_STREAM | none | `RESULT` OK |
| `0x13` | SET_RESOLUTION | `u16 width, u16 height` | `RESULT` (OK or `ERR_UNSUPPORTED` / `ERR_CAMERA`) |
| `0x14` | SET_ORIENTATION | `u8 vflip, u8 hmirror` | `RESULT` OK |
| `0x20` | TAKE_PHOTO | optional `u8 quality` (0 = 90) | `RESULT` OK "Saved IMG_00012.jpg (45 KB, 320x240)" or `ERR_STORAGE` / `ERR_CAMERA` |
| `0x21` | START_RECORDING | `u8 fps (1-15), u8 quality (0 = 75)`, or empty (5 fps) | `RESULT` OK "Recording VID_00003.avi at up to 5 fps" or `ERR_STORAGE` |
| `0x22` | STOP_RECORDING | none | `RESULT` OK "Saved VID_00003.avi: 120 frames, 24 s, 3.1 MB" (or "Not recording.") |
| `0x23` | GET_STORAGE_STATUS | none | `STORAGE` |
| `0x24` | LIST_FILES | optional `u8 max files (1-40, default 30)` | `FILE_LIST` |

microSD files live in `/DISHA` on the card: photos `IMG_nnnnn.jpg`, videos `VID_nnnnn.avi` (MJPEG in AVI, playable in VLC). Numbers never overwrite existing files. Recording runs on the board independently of the stream, survives the phone app closing, and continues in a new file when the resolution changes or a file reaches 1 GB. The firmware never formats the card. When a recording stops by itself (card full or removed), the board sends an unsolicited `STORAGE` message (ref 0).

- **fresh** = 1: the device discards two queued frames first, so the image was exposed after the request arrived. This costs about two frame periods.
- **quality**: software JPEG quality. `0` means the current setting (default 80); other values are clamped to 10-95.
- Resolutions offered in this version: **320x240, 640x480, 800x600**. Changing size restarts the camera driver (RGB565 buffers are sized at init), which takes a few hundred milliseconds. If the new size fails, the previous one is restored.

### Device to phone

| Type | Name | Payload |
|---|---|---|
| `0x80` | RESULT | `u8 status, u8 command type, UTF-8 message` |
| `0x81` | HELLO_ACK | JSON device information (below) |
| `0x82` | PONG | echo of the PING payload |
| `0x83` | STATUS | JSON status (below) |
| `0x84` | STORAGE | JSON microSD status (below); also unsolicited when a recording stops by itself |
| `0x85` | FILE_LIST | JSON: `{"dir":"/DISHA","mounted":true,"total":N,"files":[{"name":"VID_00003.avi","kb":3170},...]}` (videos first, then photos, newest first) |
| `0x90` | FRAME_CHUNK | 32-byte chunk header + image bytes (section 4) |
| `0xA0` | LOG | UTF-8 log line from the firmware (sent only during a session) |

### Status codes (RESULT)

| Code | Name | Code | Name |
|---|---|---|---|
| 0 | OK | 7 | ERR_NO_SESSION (send HELLO first) |
| 1 | ERR_UNKNOWN_COMMAND | 8 | ERR_TOO_LARGE |
| 2 | ERR_BAD_PAYLOAD | 9 | ERR_INTERNAL |
| 3 | ERR_BUSY (camera queue full) | 10 | ERR_BAD_VERSION |
| 4 | ERR_CAMERA | 11 | ERR_NOT_IMPLEMENTED |
| 5 | ERR_ENCODE | 12 | ERR_USB |
| 6 | ERR_UNSUPPORTED | 13 | ERR_STORAGE (no card, card full, write failed) |

The app also uses two codes of its own, which never appear on the wire: -1 (timeout) and -2 (not connected).

## 4. Frames

The GC2145 sensor cannot produce JPEG. The firmware captures **RGB565** into PSRAM and encodes **JPEG on the ESP32-S3** (baseline JPEG from esp32-camera's encoder). Each frame is sent as one or more `FRAME_CHUNK` messages carrying up to 8192 image bytes each.

```
FRAME_CHUNK payload
offset size field
0      4    frame id          increments per frame
4      4    total length      bytes of the complete image
8      4    offset            byte offset of this chunk's data in the image
12     2    chunk index       0..count-1
14     2    chunk count
16     2    width
18     2    height
20     1    pixel format      1 = JPEG
21     1    flags             0x01 FIRST, 0x02 LAST, 0x04 REQUESTED (answer to CAPTURE_FRAME), 0x08 STREAM
22     2    encode time (ms)  RGB565 -> JPEG on the ESP32
24     4    capture time      device uptime in ms when the frame was captured
28     4    frame CRC-32      CRC-32 of the complete image
32     m    image bytes       m = message length - 32
```

**Reassembly rules** (the phone must enforce all of them):
- A frame starts with chunk index 0 at offset 0. A chunk of a different frame id, or a new index 0, abandons the incomplete frame (counted as dropped).
- Chunks must arrive in order: `index == expected` and `offset == bytes received so far`, and `total` must not change.
- `offset + m <= total`; `total` must be greater than 0 and at most the receiver's limit (the app uses 2 MB).
- The frame is complete when `received == total`. Its CRC-32 must equal the frame CRC field, otherwise the frame is discarded.
- The JPEG must start with `FF D8` and end with `FF D9`, and its decoded size must equal width x height from the header.

Other messages (`RESULT`, `PONG`, `STATUS`, `LOG`) may appear **between** the chunks of one frame.

## 5. Sessions and keep-alive

- A session starts with `HELLO`. Commands other than HELLO without a session get `ERR_NO_SESSION`. The app treats that as "device restarted" and sends HELLO again.
- The device ends the session (and stops streaming) when the USB host detaches, when no message arrives from the phone for **5 s**, or when sending stalls for **1.5 s** (the phone stopped reading).
- The app sends `PING` every second and treats **4 s** without any received byte as a lost link. It then closes the USB connection and reconnects.

## 6. JSON documents

### HELLO_ACK

```json
{"fw":"DISHA-CAM","fwVersion":"0.1.0","proto":1,"transport":"tinyusb-vendor","session":1,
 "chip":"ESP32-S3","chipRev":0,"cpuMHz":240,"flashMB":16,"psramKB":8192,
 "resetReason":"power-on","maxChunk":8192,"maxPayload":16384,
 "resolutions":[[320,240],[640,480],[800,600]],
 "features":{"capture":true,"stream":true,"orientation":true,"sd":true,"recording":true},
 "camera":{ ...camera object... },"storage":{ ...storage object... }}
```

`transport` is `"tinyusb-vendor"` or `"hw-cdc"`. `resetReason` reports why the board last restarted; `"brownout (supply voltage dropped)"` usually means the phone's USB power or the cable is not good enough.

### STATUS

```json
{"uptimeMs":123456,"session":1,"sessionActive":true,"transport":"tinyusb-vendor","usbMounted":true,
 "usb":{"messagesSent":120,"kbSent":800,"sendFailures":0,"rxMessages":60,"rxCrcErrors":0,"rxDroppedBytes":0},
 "heapFree":250000,"heapMin":240000,"psramFree":6900000,"tempC":41.5,"resetReason":"power-on",
 "camera":{ ...camera object... }}
```

### Camera object

```json
{"state":"ready","problem":"","err":"0x0","sensor":"GC2145","pid":"0x2145","sensorJpeg":false,
 "source":"RGB565, JPEG encoded on ESP32-S3","format":"jpeg","width":320,"height":240,"quality":80,
 "vflip":1,"hmirror":0,"streaming":false,"fpsTarget":2,"fpsActual":0.0,"framesSent":0,
 "captureFailures":0,"encodeFailures":0,"sendFailures":0,"reinits":0,
 "lastJpegBytes":0,"lastEncodeMs":0,"lastCaptureMs":0}
```

`state` is `off`, `initializing`, `ready` or `error`. With `error`, `problem` holds a readable explanation (for example a reseat-the-ribbon-cable hint). Firmware 0.2.0 adds `"recording":true|false`.

### Storage object (STORAGE message, and `"storage"` inside HELLO_ACK and STATUS)

```json
{"mounted":true,"cardType":"SDHC","totalMB":30436,"usedMB":120,"freeMB":30316,"photos":12,"videos":3,
 "lastFile":"IMG_00012.jpg","dir":"/DISHA","problem":"",
 "recording":{"active":false,"file":"VID_00003.avi","frames":120,"seconds":24,"kb":3170,"files":1}}
```

With `"mounted":false`, `problem` explains why (no card, or not FAT32) and how to fix it without losing data.

## 7. Versioning

`version` in every header is 1. A receiver that gets another version must not interpret the payload: the firmware answers `ERR_BAD_VERSION`, and the app stops and asks for matching firmware/app versions. Additions that keep old messages unchanged (new message types, new JSON fields) do not change the version; unknown message types are answered with `ERR_UNKNOWN_COMMAND` (device) or logged and ignored (app).
